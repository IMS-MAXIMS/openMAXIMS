	/*
	v. 2.0.1
	+ handleEvent based event handlers replacement for addEl.
*/
var $ = function(id) { return document.getElementById(id); };

var Util =  
{
	_classRE: [],
	writeAssertsToDebugLog: false,
		
	nop: function(){},

	_unsupportedFeatures: [],
	reportUnsupported: function(moduleName, feature, detail) {
		var item = {module: String(moduleName), feature: String(feature), detail: detail ? String(detail) : ""};
		for(var i = 0; i < this._unsupportedFeatures.length; i++) {
			var prior = this._unsupportedFeatures[i];
			if(prior.module == item.module && prior.feature == item.feature) return item;
		}
		this._unsupportedFeatures.push(item);
		if(typeof console != "undefined" && console.warn) console.warn("Client Framework unsupported feature: " + item.module + " / " + item.feature + (item.detail ? " - " + item.detail : ""));
		return item;
	},
	
	parseBoolean: function(value) {
		if(typeof value == "boolean") return value;
		if(value === null || value === undefined) return false;
		if(typeof value == "number") return value != 0;
		var normalized = String(value).replace(/^\s+|\s+$/g, "").toLowerCase();
		if(normalized == "true" || normalized == "1") return true;
		if(normalized == "false" || normalized == "0" || normalized == "") return false;
		return Boolean(value);
	},

	resolveGlobal: function(name) {
		if(typeof window == "undefined" || !window) return null;
		return window[String(name)];
	},

	assert: function(funcOrStr, context) {
		if(typeof funcOrStr == "string") {
			var msg = "ASSERT: " + funcOrStr;
			this.writeAssertsToDebugLog ? CNFormManager._trace(msg) : alert(msg);
			return false;
		}
		var result = funcOrStr.apply(context || this);
		if(!result) {
			msg = "ASSERT failed: " + funcOrStr;
			this.writeAssertsToDebugLog ? CNFormManager._trace(msg) : alert(msg);
		}
		return result;
	},
	
	bind: function(obj, func) {
		return function(){ func.apply(obj, arguments); }; 
	},

	findElement: function(l)
	{
		while(l != null && !l.jsObject) l = l.parentElement || l.parentNode;
		return l;
	},
	
	findJSObject: function(l)
	{
		var l = Util.findElement(l);
		if(l) return l.jsObject;
		return null;
	},

	handleEvent: function(l, evName, prefix)
	{
		var handler = Util.dispatcher((prefix ? prefix : "") + evName);
		var eventName = evName.indexOf("on") == 0 ? evName.substr(2) : evName;
		var listener = function(ev) {
			var previousEvent = Event._currentEvent;
			Event._currentEvent = Event.normalize(ev);
			try {
				return handler.call(l, ev);
			} finally {
				Event._currentEvent = previousEvent;
			}
		};
		Event.nativeAdd(l, eventName, listener);
		return listener;
	},
		
	dispatcher: function(evName)
	{
		return function(nativeEvent)
		{
			var jso = Util.dispatchObject(nativeEvent);
			if(jso)
			{
				var handler = jso[evName];
				if(handler) return handler.call(jso, nativeEvent);
			}
		};
	},
	
	dispatchObject: function(nativeEvent)
	{
		var ev = nativeEvent;
		if(!ev && typeof Event != "undefined" && Event.current) ev = Event.current();
		if(!ev) return null;
		var target = ev.target;
		return Util.findJSObject(target);
	},

	eventTarget: function(nativeEvent)
	{
		var ev = nativeEvent;
		if(!ev && typeof Event != "undefined" && Event.current) ev = Event.current();
		return ev ? (ev.target) : null;
	},

	dispatchByClass: function(clazz)
	{
		var js = Util.dispatchObject();
		while(js && js.constructor != clazz)
		{
			// Try to seek deeper.
			js = Util.findJSObject(js.element.parentElement || js.element.parentNode)
		}
		if(js && js.constructor == clazz) return js;
		return null;
	},
	
	// TODO: rename to findByTag.
	findTag: function(l, tag)
	{
		while(l != null && l.tagName != tag) l = l.parentElement || l.parentNode;
		return l;
	},
	
	findByClassName: function(el, className)
	{
		while(el)
		{
			if(Util.hasClass(el, className)) return el;
			el = el.parentNode;
		}
		return el;
	},
	
	_reClassNameCache: {},
    _getClassRegEx: function(className) {
        var re = this._reClassNameCache[className];
        if (!re) {
            re = new RegExp('(?:^|\\s+)' + className + '(?:\\s+|$)');
            this._reClassNameCache[className] = re;
        }
        return re;
    },

	removeClass: function(l, className)
	{
		l.className = this.chop(l.className.replace(this._getClassRegEx(className), ' '));
	},
	
	hasClass: function(l, className) {
		var re = this._classRE[className];
		if(!re) re = this._classRE[className] = new RegExp('(?:^|\\s+)' + className + '(?:\\s+|$)');
		return re.test(l.className);
	},
	
	addClass: function(l, className) {
		if(!this.hasClass(l, className)) l.className += " " + className;
	},

	toggleClass: function(l, className, toggle) {
		toggle ? this.addClass(l, className) : this.removeClass(l, className);
	},

	// Controls in the server-provided dark header need the theme's light
	// foreground colour.  Use viewport geometry rather than offsetParent
	// chains: controls may be nested in containers and standards browsers do
	// not reproduce IE's offsetParent quirks.
	isInDarkHeader: function(element, formManager) {
		if(!element || !formManager || !formManager._darkHeight ||
			!formManager._formPlaceholder || !element.getBoundingClientRect ||
			!formManager._formPlaceholder.getBoundingClientRect) return false;

		// The theme owns the foreground colour; server darkHeight remains the
		// boundary for the partial dark filter surface.
		var formRect = formManager._formPlaceholder.getBoundingClientRect();
		var elementRect = element.getBoundingClientRect();
		return elementRect.top < formRect.top + formManager._darkHeight;
	},

	setDarkHeaderControlClass: function(element, formManager) {
		if(!element) return;
		this.toggleClass(element, "control_on_darkHeader",
			this.isInDarkHeader(element, formManager));
	},
	
	findAbsolutePos: function(el, offsetEl, checkRelative, checkScroll)
	{
		var x = 0, y = 0;
		if(!offsetEl) offsetEl = document.body;
		if(offsetEl == document.body && !checkRelative && !checkScroll) {
			var rect = el.getBoundingClientRect();
			//var doc = el.ownerDocument;
			return {x: rect.left - 2, y: rect.top - 2}
		}
		
		while(el != null && el != offsetEl)
		{
			if(checkRelative) {
				var computed = this.getComputedStyle(el);
				if(computed && computed.position != "static") break;
			}
			x += el.offsetLeft + el.clientLeft; 
			y += el.offsetTop + el.clientTop; 
			el = el.offsetParent;	
			if(checkScroll && el)
			{
				if(el.scrollLeft) x -= el.scrollLeft;
				if(el.scrollTop) y -= el.scrollTop;
			}
		}
		return {x: x, y: y};
	},
	
	calcElementOffset: function(l)
	{
		var xy = Util.findAbsolutePos(l, null, false);
		var ownerWindow = (l.ownerDocument && l.ownerDocument.defaultView) || window;
		var body = ownerWindow.document.body;
		xy.x -= body.scrollLeft || 0;
		xy.y -= body.scrollTop || 0;
		return xy;
	},
	
	// CNHost coordinates are pixel lengths, including numeric XML strings.
	cssLength: function(value) {
		if(typeof value == "number") return isFinite(value) ? value + "px" : "";
		if(typeof value == "string" && /^[+-]?(?:\d+\.?\d*|\.\d+)$/.test(value.trim()))
			return value.trim() + "px";
		return value;
	},

	setBounds: function(l, node)
	{
		this.setLocation(l, node);
		this.setSize(l, node);
	},
	
	setLocation: function(l, node)
	{
		var x = node.getAttribute("x");
		var y = node.getAttribute("y");
		if(x) l.style.left = Util.cssLength(x);
		if(y) l.style.top = Util.cssLength(y);
	},
	
	setSize: function(l, node)
	{
		var width = node.getAttribute("width");
		var height = node.getAttribute("height");
		if(width) l.style.width = Util.cssLength(width);
		if(height) l.style.height = Util.cssLength(height);
	},

	getStyle: function(element, property)
	{
		if(!element) return "";
		if(element.style && element.style[property]) return element.style[property];
		var computed = this.getComputedStyle(element);
		return (typeof computed.getPropertyValue == "function" ? computed.getPropertyValue(property) : computed[property]) || computed[property] || "";
	},
	
	cancelEvent: function(ev)
	{
		return Event.cancel(ev);
	},
	
	cancelBubble: function(ev)
	{
		var current = Event.normalize(ev) || Event.current();
		if(current) {
			if(current.stopPropagation) current.stopPropagation();
			if(current.stopPropagation) current.stopPropagation();
		}
	},

	// TODO: Move to objectmodel.js
	cloneObject: function(matrix)
	{
		var obj = {};
		for(var i in matrix) obj[i] = matrix[i];
		return obj;
	},

	// TODO: Move to objectmodel.js
	mixin: function(a, b) {
		for(var i in b) {
			a[i] = b[i]
		}
		if(b.hasOwnProperty("toString")) { // TODO: other don't enum methods?
			a.toString = b.toString;
		}
	},

	// TODO: Move to objectmodel.js
	merge: function(a, b) {
		var a = this.cloneObject(a);
		this.mixin(a, b);
		return a;
	},

	// TODO: Move to objectmodel.js
	conditionalMixin: function(a, b) {
		for(var i in b) {
			if(!a[i]) a[i] = b[i]
		}
	},

	findById: function(root, id)
	{
		if(!root) return null;

		// Tab buttons and their content containers deliberately share an id in
		// the historical runtime. A standards querySelector returns the first
		// match, which is the tab button, and then applies container visibility
		// to the wrong element. Prefer the semantic runtime element.
		var first = root.id == id ? root : null;
		if(first && (first.isContainer || first.isControl)) return first;
		var nodes = root.getElementsByTagName ? root.getElementsByTagName("*") : [];
		for(var i = 0; i < nodes.length; i++)
		{
			if(nodes[i].id == id && (nodes[i].isContainer || nodes[i].isControl)) return nodes[i];
			if(!first && nodes[i].id == id) first = nodes[i];
		}
		if(first) return first;

		var children = root.children || root.childNodes || [];
		for(var j = 0; j < children.length; j++)
		{
			var found = this.findById(children[j], id);
			if(found) return found;
		}
		return null;
	},

	getComputedStyle: function(element)
	{
		if(!element) return {};
		if(typeof window == "undefined" || typeof window.getComputedStyle != "function") throw new Error("Util: standard getComputedStyle is required");
		return window.getComputedStyle(element, null);
	},

	removeElement: function(element)
	{
		if(!element) return;
		if(element.remove) { element.remove(); return; }
		if(element.parentNode) element.parentNode.removeChild(element);
	},

	createElementFromHTML: function(markup, ownerDocument)
	{
		var source = String(markup);
		var match = /^\s*<([A-Za-z0-9]+)/.exec(source);
		if(!match) throw new Error("Invalid HTML element markup");
		var tagName = match[1].toLowerCase();
		var wrapperTag = (tagName == "tr" || tagName == "td" || tagName == "th" || tagName == "tbody" || tagName == "thead" || tagName == "tfoot") ? "table" : "div";
		var targetDocument = ownerDocument || document;
		var wrapper = targetDocument.createElement(wrapperTag);
		if(tagName == "td" || tagName == "th") wrapper.innerHTML = "<tbody><tr>" + source + "</tr></tbody>";
		else if(tagName == "tr") wrapper.innerHTML = "<tbody>" + source + "</tbody>";
		else wrapper.innerHTML = source;
		var matches = wrapper.getElementsByTagName ? wrapper.getElementsByTagName(tagName) : [];
		return matches.length ? matches[0] : (wrapper.firstElementChild || wrapper.firstChild);
	},

	createElement: function(tagName, className, attributes)
	{
		var element = document.createElement(tagName);
		if(className) element.className = className;
		if(attributes)
		{
			for(var name in attributes)
			{
				if(!attributes.hasOwnProperty(name)) continue;
				var value = attributes[name];
				try { element[name] = value; } catch(ignore) {}
				if(element.setAttribute) element.setAttribute(name, value);
			}
		}
		return element;
	},

	appendHTML: function(parent, markup, ownerDocument)
	{
		if(!parent) return null;
		var source = String(markup);
		var targetDocument = ownerDocument || parent.ownerDocument || document;
		var match = /^\s*<([A-Za-z0-9]+)/.exec(source);
		if(!match) throw new Error("Invalid HTML element markup");
		var tagName = match[1].toLowerCase();
		var wrapperTag = (tagName == "tr" || tagName == "td" || tagName == "th" || tagName == "tbody" || tagName == "thead" || tagName == "tfoot") ? "table" : "div";
		var wrapper = targetDocument.createElement(wrapperTag);
		if(tagName == "td" || tagName == "th") wrapper.innerHTML = "<tbody><tr>" + source + "</tr></tbody>";
		else if(tagName == "tr") wrapper.innerHTML = "<tbody>" + source + "</tbody>";
		else wrapper.innerHTML = source;

		var first = null;
		while(wrapper.firstChild)
		{
			var child = wrapper.firstChild;
			if(!first && child.nodeType == 1) first = child;
			parent.appendChild(child);
		}
		return first;
	},

	// Toolbar stuff.
	// TODO: mocv
	createToolbar: function(parentElement)
	{
		var toolbar = document.createElement("div");
		toolbar.className = "cnToolbar";
		toolbar.style.userSelect = "none";
		parentElement.appendChild(toolbar);
		return toolbar;
	},
	
	addButton: function(parentElement, cmd, param, caption, imgSrc, isPushable)
	{
		var b = document.createElement("span");
		parentElement.appendChild(b);
		b.style.userSelect = "none";
			
		b.isButton = true;
		b.className = "button_normal";
		b.isPushable = isPushable;
		b.cmd = cmd;
		b.title = caption;	
		b.param = param;
		b.state = "normal";
		Event.add(b, "mouseenter", this, this._button_onmouseenter);
		Event.add(b, "mouseleave", this, this._button_onmouseleave);
		Event.add(b, "mousedown", this, this._button_onmousedown);
		Event.add(b, "dblclick", this, this._button_onmouseup);
		Event.add(b, "mouseup", this, this._button_onmouseup);
		Event.add(b, "dragstart", this, this.cancelEvent);
		b.lastClickTime = 0;
		
		
		var img = document.createElement("img");
		b.appendChild(img);
		img.src = imgSrc;		
		img.style.userSelect = "none";
	
		return b;
	},
	
	addSeparator: function(parentElement)
	{
		var span = document.createElement("span");
		span.className = "cnToolbarSeparator";
		span.style.userSelect = "none";
		parentElement.appendChild(span);
		return span;
	},

	setButtonState: function(b, state)
	{
		b.state = state;
		setTimeout(function(){
			b.className = "button_" + state; // Avoid IE black fill bug.
		}, 0);
	},
	
	_button_onmouseenter:  function(ev)
	{
		var b = ev && (ev.target);
		
		if(b._disabled || b.parentElement._disabled) return;
	
		if(b.state == "normal") Util.setButtonState(b, "normalHover");
		else if(b.state == "pushed") Util.setButtonState(b, "pushedHover");
	},

	_button_onmouseleave: function(ev)
	{
		var b = ev && (ev.target);

		if(b._disabled || b.parentElement._disabled) return;
		
		if(b.state == "normalHover" || b.state == "normalDown") Util.setButtonState(b, "normal");
		else if(b.state == "pushedHover" || b.state == "pushedDown") Util.setButtonState(b, "pushed");
	},

	_button_onmousedown: function(ev)
	{
		var b = ev && (ev.target);	
		while(b && !b.isButton) b = b.parentElement;
		
		if(b._disabled || b.parentElement._disabled) return;
				
		if(!b.isPushable) 
		{
			Util.setButtonState(b, "normalDown");
		}
		else 
		{
			if(b.state == "pushedHover") Util.setButtonState(b, "normalDown");
			else Util.setButtonState(b, "pushedDown");
		}
	},
	
	_button_onmouseup: function(ev)
	{
		var b = ev && (ev.target);
		while(b && !b.isButton) b = b.parentElement;
		if(!b) return;
		
		if(b._disabled || b.parentElement._disabled) return;
		
		var current = new Date().getTime();
		var delta = current - b.lastClickTime;
		if (delta < 200) 
		{
			// This happens because of a bug, so we ignore it.
			return;
		}
		
		var jsObject = Util.findJSObject(ev && (ev.target));

		if(b._group && jsObject._groupButtons)
		{
			var groupButton = jsObject._groupButtons[b._group];
			if(groupButton) 
			{
				Util.setButtonState(groupButton, b.state == "pushedHover" ? "pushed" : "normal");
			}
			jsObject._groupButtons[b._group] = b;
		}

		if(b.state == "pushedDown") Util.setButtonState(b, "pushedHover");
		else Util.setButtonState(b, "normalHover");

		if(b.cmd) 
		{
			if(jsObject[b.cmd]) jsObject[b.cmd](b.param, b);
			b.lastClickTime = current;
		}
	},
	
	trim: function(str) {
		var	str = str.replace(/^\s\s*/, ''),
			ws = /\s/,
			i = str.length;
		while(ws.test(str.charAt(--i))){}
		return str.slice(0, i + 1);
	},

	cleanElement: function(cont)
	{
		var children = cont.children;
		var count = children.length;
		for(var i = count - 1; i >= 0; i--)
		{
			if(typeof cont.removeChild != "function") throw new Error("Util: standard removeChild is required");
			cont.removeChild(children[i]);
		}
	},

	padString: function(val, pad, n)
	{
		val = String(val);
		pad = String(pad);
		if(val.length < n) 
		{
			var pads = pad;
			for(var i = 1; i < val.length - n; i++) pads += pad;
			val = pads + val;
		}
		return val;
	},
	
	posPopup: function(popup, x, y)
	{
		popup.style.left = x;
		popup.style.top = y;

		var xy = Util.findAbsolutePos(popup, null, false, true);

		var b = xy.y + popup.offsetHeight;
		var r = xy.x + popup.offsetWidth;

		var body = (popup.ownerDocument || document).body;
		if(r > body.clientWidth)
			popup.style.left = (popup.offsetLeft - r + body.clientWidth - 4) + "px"; // 4 = shadowWidth

		if(b > body.clientHeight)
			popup.style.top = (popup.offsetTop - b + body.clientHeight - 4) + "px";
	},
	
	wrapIntoNode: function(ar)
	{
		ar.getAttribute = this.wrap_getAttribute;
		ar.setAttribute = this.wrap_setAttribute;
		ar.cloneNode = this._wrap_cloneNode;
		return ar;
	},
	_wrap_cloneNode: function()
	{
		return Util.cloneObject(this);
	},
	wrap_getAttribute: function(name)
	{
		var val = this[name];
		return val == undefined ? null : val;
	},
	wrap_setAttribute: function(name, value)
	{
		this[name] = value;
	},
	getCaller: function(obj, caller)
	{
		for(var i in obj)
		{
			if(obj[i] == caller) {
				return i;
			}
		}
		return caller;
	},
	
	benchmark: function(func, msg, context) { // NOTE: adds function call overhead.
		var start = new Date().getTime();
		if(context) func.apply(context)
		else func();
		var total = new Date().getTime() - start;
		msg = msg ? msg + ": " : "";
		if(CNFormManager) CNFormManager._trace(msg + total + "ms");
	},
	
	getElapsed: function(date) {
		return new Date().getTime() - date.getTime();
	},
	
	definitionTag: function(html) {
		return html.substr(0, html.indexOf(">") + 1);
	},

	escapeAttr: function(str) {
		return str.replace(/&/g, '&amp;').replace(/"/g, "&quot;").replace(/'/g, '&#39;').replace(/>/g, "&gt;").replace(/</g, "&lt;");
	},

	xmlNodeToJson: function(node) {
		return {tag: node.tagName, attributes: this.xmlAttributesToJson(node), children:  this.xmlNodeListToJson(node.childNodes)};
	},

	xmlNodeListToJson: function(childNodes) {
		var count = childNodes.length;
		var json = [];
		for(var i = 0; i < count; i++) {
			var node = childNodes[i];
			if(node.nodeType != 1) continue;

			json.push(this.xmlNodeToJson(node));
		}
		return json;
	},

	createXMLHttpRequest: function()
	{
		if(typeof XMLHttpRequest != "undefined") return new XMLHttpRequest();
		if(typeof window != "undefined" && window.XMLHttpRequest) return new window.XMLHttpRequest();
		throw new Error("Util: standard XMLHttpRequest is required");
	},

	createXMLDocument: function()
	{
				if(typeof document != "undefined" && document.implementation && document.implementation.createDocument)
		{
			return document.implementation.createDocument("", "", null);
		}
		throw new Error("Util: standard DOMImplementation.createDocument is required");
	},

	parseXML: function(xml)
	{
				if(typeof DOMParser != "undefined") return new DOMParser().parseFromString(String(xml), "text/xml");
		if(typeof window != "undefined" && window.DOMParser) return new window.DOMParser().parseFromString(String(xml), "text/xml");
		throw new Error("Util: standard DOMParser is required");
	},

	xmlText: function(node)
	{
		return node == null || node.textContent == null ? "" : String(node.textContent);
	},

	xmlInnerString: function(node)
	{
		if(node == null) return "";
		var result = "";
		for(var i = 0; i < node.childNodes.length; i++)
		{
			result += this.xmlString(node.childNodes[i]);
		}
		return result;
	},

	xmlString: function(node)
	{
		if(node == null) return "";
		if(typeof XMLSerializer != "undefined") return new XMLSerializer().serializeToString(node);
		if(typeof window != "undefined" && window.XMLSerializer) return new window.XMLSerializer().serializeToString(node);
		throw new Error("Util: standard XMLSerializer is required");
	},

	xmlSelectNodes: function(node, path)
	{
		if(!node) return [];
		var doc = node.nodeType == 9 ? node : node.ownerDocument;
		var w = typeof window != "undefined" ? window : null;
		var XPathResultType = (w && w.XPathResult) || (typeof XPathResult != "undefined" ? XPathResult : null);
		// XPath implementations reject DocumentFragment as a context node in
		// standards browsers. Use the standards DOM traversal below for
		// fragments instead of relying on a browser-specific XML extension.
		if(node.nodeType != 11 && doc && doc.evaluate && XPathResultType)
		{
			try
			{
				var result = doc.evaluate(path, node, null, XPathResultType.ORDERED_NODE_SNAPSHOT_TYPE, null);
				var nodes = [];
				for(var i = 0; i < result.snapshotLength; i++) nodes.push(result.snapshotItem(i));
				return nodes;
			}
			catch(ignore)
			{
				// Fall through to the standards DOM traversal for unsupported
				// XPath context nodes or expressions.
			}
		}
		// DOM traversal supports simple child paths when XPath is unavailable.
		var current = [node];
		var parts = String(path).replace(/^\.\//, "").split("/");
		for(var p = 0; p < parts.length; p++)
		{
			var part = parts[p];
			if(!part || part == ".") continue;
			var match = /^([^\[]+)(?:\[@([^=]+)=(["'])(.*?)\3\])?$/.exec(part);
			if(!match) return [];
			var tag = match[1], attr = match[2], value = match[4], next = [];
			for(var c = 0; c < current.length; c++)
			{
				var children = current[c].children || current[c].childNodes || [];
				for(var j = 0; j < children.length; j++)
				{
					var child = children[j];
					if(child.nodeType != 1 || (tag != "*" && child.tagName != tag)) continue;
					if(attr && child.getAttribute(attr) != value) continue;
					next.push(child);
				}
			}
			current = next;
		}
		return current;
	},

	xmlSelectSingleNode: function(node, path)
	{
		var nodes = this.xmlSelectNodes(node, path);
		return nodes.length ? nodes[0] : null;
	},


	xmlChildElements: function(node, tagName)
	{
		var children = node && (node.children || node.childNodes);
		var result = [];
		if(!children) return result;
		for(var i = 0; i < children.length; i++)
		{
			var child = children[i];
			if(child.nodeType == 1 && (!tagName || child.tagName == tagName)) result.push(child);
		}
		return result;
	},

	xmlAttributesToJson: function(node) {
		var attrs = node.attributes;
		var length = attrs.length;
		var json = {};
		for(var i = 0; i < length; i++) {
			var attr = attrs[i];
			json[attr.name] = attr.value;
		}
		return json;
	},

	arrayIndexOf: function(array, obj) {
		for(var i = 0; i < array.length; i++) {
			if(array[i] === obj) return i;
		}
		return -1;
	},

	call: function() {
		var d = Array.prototype.shift.apply(arguments);
		if(d) {
			if(d instanceof Array && d.length > 1) {
				if(d[1] instanceof Function) {
					return d[1].apply(d[0], arguments);
				} else {
					return d[0][d[1]].apply(d[0], arguments);
				}
			} else if(d instanceof Function) {
				d(arguments); // Call directly.
			}
		}
	},

	snapToGrid: function(v, grid) {
		return Math.round(v / grid) * grid;
	},
	
	htmlToText: function(html) 
	{
		return html
		// Remove line breaks
		.replace(/(?:\n|\r\n|\n\n|\r)/ig,"")
		// Turn <br>'s into single line breaks.
		.replace(/<\s*br[^>]*>/ig,"\n")
		// Turn </li>'s into line breaks.
		.replace(/<\s*\/li[^>]*>/ig,"\n")
		// Turn <p>'s into double line breaks.
		.replace(/<\s*p[^>]*>/ig,"\n\n")
		// Remove content in script tags.
		.replace(/<\s*script[^>]*>[\s\S]*?<\/script>/mig,"")
		// Remove content in style tags.
		.replace(/<\s*style[^>]*>[\s\S]*?<\/style>/mig,"")
		// Remove content in comments.
		.replace(/<!--.*?-->/mig,"")
		// Remove all remaining tags.
		.replace(/(<([^>]+)>)/ig,"")
		// Make sure there are never more than two
		// consecutive linebreaks.
		.replace(/\n{2,}/g,"\n\n")
		//.replace(/\n{2,}/g,"")
		// Remove tabs.
		.replace(/\t/g,"")
		// Remove newlines at the beginning of the text.
		.replace(/^\n+/m,"")
		// Replace multiple spaces with a single space.
		.replace(/ {2,}/g," ")
		// Decode HTML entities.
		.replace(/&([^;]+);/g, this.decodeHtmlEntity );
	},

	decodeHtmlEntity: function(m, n) 
	{
		var ENTITIES_MAP = 
		{
		  'nbsp' : 160,
		  'iexcl' : 161,
		  'cent' : 162,
		  'pound' : 163,
		  'curren' : 164,
		  'yen' : 165,
		  'brvbar' : 166,
		  'sect' : 167,
		  'uml' : 168,
		  'copy' : 169,
		  'ordf' : 170,
		  'laquo' : 171,
		  'not' : 172,
		  'shy' : 173,
		  'reg' : 174,
		  'macr' : 175,
		  'deg' : 176,
		  'plusmn' : 177,
		  'sup2' : 178,
		  'sup3' : 179,
		  'acute' : 180,
		  'micro' : 181,
		  'para' : 182,
		  'middot' : 183,
		  'cedil' : 184,
		  'sup1' : 185,
		  'ordm' : 186,
		  'raquo' : 187,
		  'frac14' : 188,
		  'frac12' : 189,
		  'frac34' : 190,
		  'iquest' : 191,
		  'Agrave' : 192,
		  'Aacute' : 193,
		  'Acirc' : 194,
		  'Atilde' : 195,
		  'Auml' : 196,
		  'Aring' : 197,
		  'AElig' : 198,
		  'Ccedil' : 199,
		  'Egrave' : 200,
		  'Eacute' : 201,
		  'Ecirc' : 202,
		  'Euml' : 203,
		  'Igrave' : 204,
		  'Iacute' : 205,
		  'Icirc' : 206,
		  'Iuml' : 207,
		  'ETH' : 208,
		  'Ntilde' : 209,
		  'Ograve' : 210,
		  'Oacute' : 211,
		  'Ocirc' : 212,
		  'Otilde' : 213,
		  'Ouml' : 214,
		  'times' : 215,
		  'Oslash' : 216,
		  'Ugrave' : 217,
		  'Uacute' : 218,
		  'Ucirc' : 219,
		  'Uuml' : 220,
		  'Yacute' : 221,
		  'THORN' : 222,
		  'szlig' : 223,
		  'agrave' : 224,
		  'aacute' : 225,
		  'acirc' : 226,
		  'atilde' : 227,
		  'auml' : 228,
		  'aring' : 229,
		  'aelig' : 230,
		  'ccedil' : 231,
		  'egrave' : 232,
		  'eacute' : 233,
		  'ecirc' : 234,
		  'euml' : 235,
		  'igrave' : 236,
		  'iacute' : 237,
		  'icirc' : 238,
		  'iuml' : 239,
		  'eth' : 240,
		  'ntilde' : 241,
		  'ograve' : 242,
		  'oacute' : 243,
		  'ocirc' : 244,
		  'otilde' : 245,
		  'ouml' : 246,
		  'divide' : 247,
		  'oslash' : 248,
		  'ugrave' : 249,
		  'uacute' : 250,
		  'ucirc' : 251,
		  'uuml' : 252,
		  'yacute' : 253,
		  'thorn' : 254,
		  'yuml' : 255,
		  'quot' : 34,
		  'amp' : 38,
		  'lt' : 60,
		  'gt' : 62,
		  'OElig' : 338,
		  'oelig' : 339,
		  'Scaron' : 352,
		  'scaron' : 353,
		  'Yuml' : 376,
		  'circ' : 710,
		  'tilde' : 732,
		  'ensp' : 8194,
		  'emsp' : 8195,
		  'thinsp' : 8201,
		  'zwnj' : 8204,
		  'zwj' : 8205,
		  'lrm' : 8206,
		  'rlm' : 8207,
		  'ndash' : 8211,
		  'mdash' : 8212,
		  'lsquo' : 8216,
		  'rsquo' : 8217,
		  'sbquo' : 8218,
		  'ldquo' : 8220,
		  'rdquo' : 8221,
		  'bdquo' : 8222,
		  'dagger' : 8224,
		  'Dagger' : 8225,
		  'permil' : 8240,
		  'lsaquo' : 8249,
		  'rsaquo' : 8250,
		  'euro' : 8364
		};

		// Determine the character code of the entity. Range is 0 to 65535
		// (characters in JavaScript are Unicode, and entities can represent
		// Unicode characters).
		var code;

		// Try to parse as numeric entity. This is done before named entities for
		// speed because associative array lookup in many JavaScript implementations
		// is a linear search.
		if (n.substr(0, 1) == '#') 
		{
			// Try to parse as numeric entity
			if (n.substr(1, 1) == 'x') 
			{
				// Try to parse as hexadecimal
				code = parseInt(n.substr(2), 16);
			}
			else 
			{
				// Try to parse as decimal
				code = parseInt(n.substr(1), 10);
			}
		}
		else 
		{
			// Try to parse as named entity
			code = ENTITIES_MAP[n];
		}

		// If still nothing, pass entity through
		return (code === undefined || code === NaN) ? '&' + n + ';' : String.fromCharCode(code);
	}
}
Util.chop = Util.trim;
Util.clone = Util.cloneObject;

var CNUtil = Util;
Util.getXY = Util.findAbsolutePos;

/**
*
*  Secure Hash Algorithm (SHA1)
*  http://www.webtoolkit.info/
*
**/

Util.SHA1 = new function() {

	function rotate_left(n,s) {
		var t4 = ( n<<s ) | (n>>>(32-s));
		return t4;
	};

	function lsb_hex(val) {
		var str="";
		var i;
		var vh;
		var vl;

		for( i=0; i<=6; i+=2 ) {
			vh = (val>>>(i*4+4))&0x0f;
			vl = (val>>>(i*4))&0x0f;
			str += vh.toString(16) + vl.toString(16);
		}
		return str;
	};

	function cvt_hex(val) {
		var str="";
		var i;
		var v;

		for( i=7; i>=0; i-- ) {
			v = (val>>>(i*4))&0x0f;
			str += v.toString(16);
		}
		return str;
	};


	function Utf8Encode(string) {
		string = string.replace(/\r\n/g,"\n");
		var utftext = "";

		for (var n = 0; n < string.length; n++) {

			var c = string.charCodeAt(n);

			if (c < 128) {
				utftext += String.fromCharCode(c);
			}
			else if((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);
				utftext += String.fromCharCode((c & 63) | 128);
			}
			else {
				utftext += String.fromCharCode((c >> 12) | 224);
				utftext += String.fromCharCode(((c >> 6) & 63) | 128);
				utftext += String.fromCharCode((c & 63) | 128);
			}

		}

		return utftext;
	};

	this.compute = function(msg) {
		var blockstart;
		var i, j;
		var W = new Array(80);
		var H0 = 0x67452301;
		var H1 = 0xEFCDAB89;
		var H2 = 0x98BADCFE;
		var H3 = 0x10325476;
		var H4 = 0xC3D2E1F0;
		var A, B, C, D, E;
		var temp;
	
		msg = Utf8Encode(msg);
	
		var msg_len = msg.length;
	
		var word_array = new Array();
		for( i=0; i<msg_len-3; i+=4 ) {
			j = msg.charCodeAt(i)<<24 | msg.charCodeAt(i+1)<<16 |
			msg.charCodeAt(i+2)<<8 | msg.charCodeAt(i+3);
			word_array.push( j );
		}
	
		switch( msg_len % 4 ) {
			case 0:
				i = 0x080000000;
			break;
			case 1:
				i = msg.charCodeAt(msg_len-1)<<24 | 0x0800000;
			break;
	
			case 2:
				i = msg.charCodeAt(msg_len-2)<<24 | msg.charCodeAt(msg_len-1)<<16 | 0x08000;
			break;
	
			case 3:
				i = msg.charCodeAt(msg_len-3)<<24 | msg.charCodeAt(msg_len-2)<<16 | msg.charCodeAt(msg_len-1)<<8	| 0x80;
			break;
		}
	
		word_array.push( i );
	
		while( (word_array.length % 16) != 14 ) word_array.push( 0 );
	
		word_array.push( msg_len>>>29 );
		word_array.push( (msg_len<<3)&0x0ffffffff );
	
	
		for ( blockstart=0; blockstart<word_array.length; blockstart+=16 ) {
	
			for( i=0; i<16; i++ ) W[i] = word_array[blockstart+i];
			for( i=16; i<=79; i++ ) W[i] = rotate_left(W[i-3] ^ W[i-8] ^ W[i-14] ^ W[i-16], 1);
	
			A = H0;
			B = H1;
			C = H2;
			D = H3;
			E = H4;
	
			for( i= 0; i<=19; i++ ) {
				temp = (rotate_left(A,5) + ((B&C) | (~B&D)) + E + W[i] + 0x5A827999) & 0x0ffffffff;
				E = D;
				D = C;
				C = rotate_left(B,30);
				B = A;
				A = temp;
			}
	
			for( i=20; i<=39; i++ ) {
				temp = (rotate_left(A,5) + (B ^ C ^ D) + E + W[i] + 0x6ED9EBA1) & 0x0ffffffff;
				E = D;
				D = C;
				C = rotate_left(B,30);
				B = A;
				A = temp;
			}
	
			for( i=40; i<=59; i++ ) {
				temp = (rotate_left(A,5) + ((B&C) | (B&D) | (C&D)) + E + W[i] + 0x8F1BBCDC) & 0x0ffffffff;
				E = D;
				D = C;
				C = rotate_left(B,30);
				B = A;
				A = temp;
			}
	
			for( i=60; i<=79; i++ ) {
				temp = (rotate_left(A,5) + (B ^ C ^ D) + E + W[i] + 0xCA62C1D6) & 0x0ffffffff;
				E = D;
				D = C;
				C = rotate_left(B,30);
				B = A;
				A = temp;
			}
	
			H0 = (H0 + A) & 0x0ffffffff;
			H1 = (H1 + B) & 0x0ffffffff;
			H2 = (H2 + C) & 0x0ffffffff;
			H3 = (H3 + D) & 0x0ffffffff;
			H4 = (H4 + E) & 0x0ffffffff;
	
		}
	
		var temp = cvt_hex(H0) + cvt_hex(H1) + cvt_hex(H2) + cvt_hex(H3) + cvt_hex(H4);
	
		return temp.toLowerCase();
	}
};
(function() {
    var p="=";
    var tab="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    Util.base64_decode = function(str) {
        var s=str.split(""), out=[];
        var l=s.length;
        while(s[--l]==p){ }	//	strip off trailing padding
        for (var i=0; i<l;){
            var t=tab.indexOf(s[i++])<<18;
            if(i<=l){ t|=tab.indexOf(s[i++])<<12 };
            if(i<=l){ t|=tab.indexOf(s[i++])<<6 };
            if(i<=l){ t|=tab.indexOf(s[i++]) };
            out.push((t>>>16)&0xff);
            out.push((t>>>8)&0xff);
            out.push(t&0xff);
        }
        while(out[out.length-1]==0){ out.pop(); }
        var strAr = [];
        for(var i = 0; i < out.length; i++) strAr.push(String.fromCharCode(out[i]));
        return strAr.join("");
    }
})();
/* Standards-only DOM event boundary. */
var Event = {
  _nextMethodID: 0,
  _objects: [],
  _currentEvent: null,

  _makeIndirectDelegate: function(objectID, methodID) {
    return function(nativeEvent) {
      var objectEntry = Event._objects && Event._objects[objectID];
      if (!objectEntry) {
        return;
      }

      var handlerEntry = objectEntry[1][methodID];
      if (!handlerEntry) {
        return;
      }

      var event = Event.normalize(nativeEvent);
      var previousEvent = Event._currentEvent;
      Event._currentEvent = event;
      try {
        return handlerEntry[1].call(objectEntry[0], event);
      } finally {
        Event._currentEvent = previousEvent;
      }
    };
  },

  normalize: function(nativeEvent) {
    var event = nativeEvent;
    if (!event) {
      return null;
    }

    return event;
  },

  current: function() {
    return this._currentEvent || null;
  },

  // Map the semantic KeyboardEvent.key value for the remaining numeric control
  // logic; browser-specific numeric event properties are intentionally ignored.
  keyValue: function(event) {
    if (!event) return 0;
    var key = event.key;
    var named = {
      Backspace: 8, Tab: 9, Enter: 13, Shift: 16, Control: 17,
      Alt: 18, Escape: 27, Space: 32, PageUp: 33, PageDown: 34,
      End: 35, Home: 36, ArrowLeft: 37, ArrowUp: 38,
      ArrowRight: 39, ArrowDown: 40, Insert: 45, Delete: 46
    };
    if (named[key] != null) return named[key];
    if (typeof key == "string" && key.length == 1) return key.toUpperCase().charCodeAt(0);
    return 0;
  },

  add: function(element, eventName, object, method) {
    if (!element) {
      var ownerName = object && object.constructor && object.constructor.name || "anonymous";
      throw new Error("Event.add: element is required for '" + eventName + "' on " + ownerName);
    }
    if (!object) {
      throw new Error("Event.add: object is required");
    }
    if (!method) {
      throw new Error("Event.add: method is required");
    }

    var handlers;
    if (object.__objectID == null || !this._objects[object.__objectID]) {
      handlers = [];
      object.__objectID = this._objects.length;
      this._objects.push([object, handlers]);
    } else {
      handlers = this._objects[object.__objectID][1];
    }

    if (method.__id == null) {
      method.__id = this._nextMethodID++;
    }

    var handlerEntry = handlers[method.__id];
    if (!handlerEntry) {
      handlerEntry = handlers[method.__id] = [
        this._makeIndirectDelegate(object.__objectID, method.__id),
        method
      ];
    }

    this.nativeAdd(element, eventName, handlerEntry[0]);
    return true;
  },

  del: function(element, eventName, object, method) {
    if (!object || object.__objectID == null || !method || method.__id == null) {
      return false;
    }

    var objectEntry = this._objects[object.__objectID];
    if (!objectEntry) {
      return false;
    }

    var handlerEntry = objectEntry[1][method.__id];
    if (!handlerEntry) {
      return false;
    }

    this.nativeDel(element, eventName, handlerEntry[0]);
    return true;
  },

  purge: function(object) {
    if (!object || object.__objectID == null) {
      return;
    }

    delete this._objects[object.__objectID];
    object.__objectID = null;
  },

  nativeAdd: function(element, eventName, handler) {
    if (!element || typeof element.addEventListener != "function") {
      throw new Error("Event.add: standard addEventListener is required");
    }
    var listeners = element.__clientFrameworkListeners || (element.__clientFrameworkListeners = []);
    var wrapped = function(nativeEvent) {
      var previousEvent = Event._currentEvent;
      Event._currentEvent = Event.normalize(nativeEvent);
      try { return handler.call(element, nativeEvent); }
      finally { Event._currentEvent = previousEvent; }
    };
    listeners.push({eventName: eventName, handler: handler, wrapped: wrapped});
    element.addEventListener(eventName, wrapped, false);
  },

  nativeDel: function(element, eventName, handler) {
    if (!element || typeof element.removeEventListener != "function") {
      throw new Error("Event.del: standard removeEventListener is required");
    }
    var listeners = element.__clientFrameworkListeners || [];
    for (var i = listeners.length - 1; i >= 0; i--) {
      var item = listeners[i];
      if (item.eventName == eventName && item.handler == handler) {
        element.removeEventListener(eventName, item.wrapped, false);
        listeners.splice(i, 1);
        return;
      }
    }
  },

  cancel: function(nativeEvent) {
    var event = this.normalize(nativeEvent) || this.current();
    if (!event) {
      return false;
    }

    if (event.preventDefault) {
      event.preventDefault();
    }
    if (event.stopPropagation) {
      event.stopPropagation();
    }

    return false;
  },

  destroy: function() {
    this._objects = null;
    this._currentEvent = null;
  }
};

function VistaSupport(){};
// Standards-only visual/event helpers. IE activation and VML are not
// part of the 2026 Client Framework runtime.
VistaSupport._listen = function(element, name, handler) {
	if(!element || typeof element.addEventListener != "function") throw new Error("VistaSupport requires addEventListener");
	element.addEventListener(name, handler, false);
};
VistaSupport._target = function(ev) {
	return ev && ev.target;
};
VistaSupport._style = function(element) {
	return element.style;
};
(function() {


	function _imageSetButton_onmouseenter(ev) {
		var span = VistaSupport._target(ev);
		if(span.disabled || span._disabled) return;
		VistaSupport.setImageSetState(span, "hover");
	}
	function _imageSetButton_onmouseleave(ev) {
		var span = VistaSupport._target(ev);
		if(span.disabled || span._disabled) return;
		VistaSupport.setImageSetState(span, "normal");
	}
	function _imageSetButton_onmousedown(ev) {
		var span = VistaSupport._target(ev);
		if(span.disabled || span._disabled || span._noClick) return;
		VistaSupport.setImageSetState(span, "pressed");
	}
	function _imageSetButton_onmouseup(ev) {
		_imageSetButton_onmouseenter(ev);
	}

	VistaSupport.setImageSetState = function(but, state) {
			var ar = but.style.backgroundPosition.split(" ");
		switch(state) {
			case "hover":
				but.style.backgroundPosition = -but.offsetWidth + "px " + ar[1];
				break;
			case "normal":
				but.style.backgroundPosition = "0px " + ar[1];
				break;
			case "pressed":
				but.style.backgroundPosition = -but.offsetWidth * 2 + "px " + ar[1];
				break;
		}

	}

	VistaSupport.createImageSetButton = function(src, width, height, topOffset) {
		topOffset = topOffset || 0;
		var span = document.createElement("span");
		span.style.width = width + "px";
		span.style.height = height + "px";	
		if(src) {
			src = CNFormManager.themeImagesPath + src;
			span.style.backgroundImage = "url('" + src + "')";
		}
		span.style.backgroundRepeat = "no-repeat";
		span.style.backgroundPosition = "0px " + -topOffset +"px";
		span.style.display = "inline-block";

		VistaSupport._listen(span, "mouseenter", _imageSetButton_onmouseenter);
		VistaSupport._listen(span, "mouseleave", _imageSetButton_onmouseleave);
		VistaSupport._listen(span, "mousedown", _imageSetButton_onmousedown);
		VistaSupport._listen(span, "mouseup", _imageSetButton_onmouseup);
	
		return span;
	}
	
	VistaSupport.updateImageSetButton = function(span, src, topOffset) {
		if(src) {
			src = CNFormManager.themeImagesPath + src;
			span.style.backgroundImage = "url('" + src + "')";
		}
		if(topOffset !== null) {
			var ar = span.style.backgroundPosition.split(" ");
			span.style.backgroundPosition = ar[0] + " " + -topOffset + "px";
		}
	}

})();

VistaSupport.imageTrans = function(l, toSrc, fast)
{
	// CSS transitions may animate this assignment; no browser-specific filter
	// API is required.
	l.src = toSrc;
}

VistaSupport.createImageButton = function(src, width, height)
{
	var img = document.createElement("img");
	if(width) img.width = width;
	if(height) img.height = height;
	img._src = src;
	img.src = CNFormManager.themeImagesPath + src;
	VistaSupport._listen(img, "mouseenter", VistaSupport._imageButton_onmouseenter);
	VistaSupport._listen(img, "mouseleave", VistaSupport._imageButton_onmouseleave);
	VistaSupport._listen(img, "mousedown", VistaSupport._imageButton_onmousedown);
	VistaSupport._listen(img, "mouseup", VistaSupport._imageButton_onmouseup);
	return img;
}
VistaSupport._imageButton_onmouseenter = function(ev)
{
	var img = VistaSupport._target(ev);
	if(img.disabled || img._disabled) return;
	img._hover = true;
	if(img._src) VistaSupport.imageTrans(img, CNFormManager.themeImagesPath + "hover-" + img._src);
}
VistaSupport._imageButton_onmouseleave = function(ev)
{
	var img = VistaSupport._target(ev);
	if(img.disabled || img._disabled) return;
	img._hover = false;
	if(img._src) VistaSupport.imageTrans(img, CNFormManager.themeImagesPath + img._src);
}
VistaSupport._imageButton_onmousedown = function(ev)
{
	var img = VistaSupport._target(ev);
	if(img.disabled || img._disabled) return;
	img._down = true;
	if(img._src) VistaSupport.imageTrans(img, CNFormManager.themeImagesPath + "down-" + img._src, true);
}
VistaSupport._imageButton_onmouseup = function(ev)
{
	var img = VistaSupport._target(ev);
	if(img.disabled || img._disabled) return;
	img._down = false;
	VistaSupport._imageButton_onmouseenter(ev);
}

VistaSupport.attachToTextBox = function(l)
{
	VistaSupport._listen(l, "mouseenter", this._textbox_onmouseenter);
	VistaSupport._listen(l, "mouseleave", this._textbox_onmouseleave);
	VistaSupport._listen(l, "focus", this._textbox_onmouseenter);
	VistaSupport._listen(l, "blur", this._textbox_onmouseleave);	
}
VistaSupport._textbox_onmouseenter = function(ev)
{
	var l = VistaSupport._target(ev);
	if(l.disabled || l.readOnly) return;
	if(l._anim) Animator.stop(l._anim);
	VistaSupport._style(l).borderColor = ThemeNonCSSStyles.box_borderHoverColors[0];
	VistaSupport._style(l).borderTopColor = ThemeNonCSSStyles.box_borderHoverColors[1];
}
VistaSupport._textbox_onmouseleave = function(ev)
{
	var l = VistaSupport._target(ev);
	if(l.disabled || l.readOnly || document.activeElement == l) return;
	if(ThemeNonCSSStyles.animateBoxes) {
		l._anim = new AnimVistaBoxFadeout(l);
		Animator.start(l._anim);
	} else {
		var ar = ThemeNonCSSStyles.box_borderNormalColors;
		VistaSupport._style(l).borderColor = ar[0];
		VistaSupport._style(l).borderTopColor = ar[1];
	}
}

VistaSupport.attachToJSCNBox = function(jso)
{
	var l = jso.element;
	VistaSupport._listen(l, "mouseenter", this._jscnbox_onmouseenter);
	VistaSupport._listen(l, "mouseleave", this._jscnbox_onmouseleave);
	// activate/deactivate are IE-only; focusin/focusout retain descendant focus behavior.
	VistaSupport._listen(l, "focusin", this._jscnbox_onmouseenter);
	VistaSupport._listen(l, "focusout", this._jscnbox_onmouseleave);	
}
VistaSupport._jscnbox_onmouseenter = function(ev)
{
	var l = VistaSupport._target(ev);
	if(l.disabled || l.readOnly) return;
	var jso = Util.dispatchObject(ev);
	if(jso._disabled || jso._readOnly) return;
	if(jso._anim) Animator.stop(jso._anim);

	VistaSupport._style(jso.element).borderColor = ThemeNonCSSStyles.box_borderHoverColors[0];
	VistaSupport._style(jso.element).borderTopColor = ThemeNonCSSStyles.box_borderHoverColors[1];
}
VistaSupport._jscnbox_onmouseleave = function(ev)
{
	var l = VistaSupport._target(ev);
	if(l.disabled || l.readOnly || document.activeElement == l) return;
	var jso = Util.dispatchObject(ev);
	if(jso._disabled || jso._readOnly || document.activeElement == jso.element
	|| ev && (ev.relatedTarget || ev.relatedTarget) && jso.element.contains(ev.relatedTarget || ev.relatedTarget)
	|| jso.element.contains(document.activeElement)) return;
	if(ThemeNonCSSStyles.animateBoxes) {
		jso._anim = new AnimVistaBoxFadeout(jso.element);
		Animator.start(jso._anim);
	} else {
		var ar = ThemeNonCSSStyles.box_borderNormalColors;
		jso.element.style.borderColor = ar[0];
		jso.element.style.borderTopColor = ar[1];
	}
}


VistaSupport.createHover = function(backgroundSrc, opacity)
{
	var overlay = document.createElement("div");
	overlay.className = "hoverRect";
	overlay.style.border = (CNFormManager.vista ? "1px" : "1.2px") + " solid " + ThemeNonCSSStyles.hoverRect_strokeColor;
	overlay.style.borderRadius = CNFormManager.vista ? "15%" : "0";
	overlay.style.boxSizing = "border-box";
	if(CNFormManager.vista && backgroundSrc) {
		overlay.style.backgroundImage = "url('" + CNFormManager.themeImagesPath + backgroundSrc + "')";
		if(opacity != null) overlay.style.opacity = opacity / 100;
	}
	return overlay;
}

var Animator =
{
	_running: 0,
	_animations: [], 
	_timeout: 10,
	_maxIterations: 1000,

	start: function()
	{
		for(var i = 0; i < arguments.length; i++) 
		{
			var anim = arguments[i];
			anim._maxIterations = this._maxIterations;
			this._animations.push(anim);
		}
		if(this._running == 0 && arguments.length > 0)
		{
			var obj = this;
			window.setTimeout(function(){ obj.animate(); obj = null; }, this._timeout);
		}
		this._running += arguments.length;
	},
	
	stop: function()
	{
		for(var i = 0; i < arguments.length; i++) 
		{
			arguments[i]._maxIterations = 0;
		}
	},
	
	animate: function()
	{
		var a = 0;
		var stop = false;
		while(a < this._animations.length)
		{
			var animation = this._animations[a];
			if(animation._maxIterations-- > 0 && animation.tick()) 
			{
				a++;
			}
			else
			{
				if(animation.onend)
				{
					var delegate = animation.onend;
					if(delegate instanceof Function) animation.onend();
					else if(delegate instanceof Array) delegate[0][ delegate[1] ]();

					animation.onend = null;
				}
				for(var i in animation) animation[i] = null; // Clean up animation.
				this._animations.splice(a, 1);
				if(--this._running <= 0) stop = true;
			}
		}
		if(!stop)
		{
			var obj = this;
			window.setTimeout(function(){ obj.animate(); obj = null; }, this._timeout);
		}
	},

	getRegression: function(progress)
	{
		return (1 - ((Math.cos(progress * Math.PI) + 1) / 2));
	},

	animating: function() {
		return this._running > 0;
	}
}

function AnimVistaFadeoutBase(){}
AnimVistaFadeoutBase.prototype =  
{
	progress: 0,
	step: 0.02,
	apply: function(ar){},
	tick: function()
	{
		this.progress += this.step;
		if(this.progress >= 1) 
		{
			this.apply(this._to)
			return false;
		}
		else
		{
			var ar = [];
			for(var i = 0; i < this._from.length; i++)
			{
				var f = this._from[i];
				var t = this._to[i];
				var mask = 0x0000FF;
				var value = 0;
				for(var j = 0; j < 3; j++)
				{
					var shift = j * 8
					var tm = (t & mask) >> shift;
					var fm = (f & mask) >> shift;
					var delta = tm - fm;
					var component = (fm + delta * this.progress) << shift;
					value += component;
					mask = mask << 8;
				}
				ar[i] = value;
			}
			
			this.apply(ar);
			return true;
		}
	}
}
AnimVistaFadeoutBase.toHexArray = function(strAr) {
	var ar = []
	for(var i = 0; i < strAr.length; i++) {
		ar[i] = parseInt("0x" + strAr[i].substring(1));
	}
	return ar;
}

function AnimVistaBoxFadeout(l)
{
	this.l = l;
	this._from = AnimVistaFadeoutBase.toHexArray(ThemeNonCSSStyles.box_borderHoverColors);
	this._to = AnimVistaFadeoutBase.toHexArray(ThemeNonCSSStyles.box_borderNormalColors);
}
AnimVistaBoxFadeout.prototype = new AnimVistaFadeoutBase();
AnimVistaBoxFadeout.prototype.apply = function(ar)
{
	if(ar[0] == this._to[0])
	{
		this.l.style.borderColor = "";
		this.l.style.borderTopColor = "";
	}
	else
	{
		this.l.style.borderColor = "#" + ar[0].toString(16);
		this.l.style.borderTopColor = "#" + ar[1].toString(16);
	}
}

function AnimResize(l, w, h, offX, offY)
{
	this.l = l;
	this.progress = 0;
	this.step = 0.1;
	this.finalW = w;
	this.finalH = h;
	this.startW = l.offsetWidth;
	this.startH = l.offsetHeight;
	this.diffW = this.finalW - this.startW;
	this.diffH = this.finalH - this.startH;
	this.startX = l.offsetLeft;
	this.startY = l.offsetTop;
	this.offY = offY;
	this.offX = offX;
}
AnimResize.prototype.tick = function()
{
	this.progress += this.step;
	var f = Animator.getRegression(this.progress);
	if(this.progress >= 1) 
	{
		if(this.finalH) this.l.style.height = this.finalH;
		if(this.finalW) this.l.style.width = this.finalW;
		if(this.offY) this.l.style.top = Math.round(this.startY - this.l.offsetHeight + this.startH) + "px";
		if(this.offX) this.l.style.left = Math.round(this.startX - this.l.offsetWidth + this.startW) + "px";
		if(this.l.shadow) this.l.shadow.syncPosition();
		return false;
	}
	else
	{
		if(this.finalW) 
		{
			var nextW = Math.round(this.startW + this.diffW * f);
			this.l.style.width = nextW + "px";		
			if(this.offX) this.l.style.left = (this.startX - nextW + this.startW) + "px";
		}
		if(this.finalH) 
		{
			var nextH = Math.round(this.startH + this.diffH * f);
			this.l.style.height = nextH + "px";		
			if(this.offY) this.l.style.top = (this.startY - nextH + this.startH) + "px";
		}
		if(this.l.shadow) this.l.shadow.syncPosition();
		return true;
	}
}

function AnimVistaFadeResize(l, deltaX, deltaY)
{
	var w = l.offsetWidth;
	var h = l.offsetHeight;
	var x = l.offsetLeft;
	var y = l.offsetTop;
	l.style.left = x + deltaX / 2;
	l.style.top = y + deltaY / 2;
	l.style.width = w - deltaX;
	l.style.height = h - deltaY;
	var anim1 = new AnimResize(l, w, h);
	var anim2 = new AnimMove(l, x, y);
	anim1.step = anim2.step = 0.075;
	Animator.start(anim1, anim2);
	return anim1;
}

function AnimMove(l, toX, toY, easing)
{
	this.l = l;
	this.progress = 0;
	this.step = 0.1;
	this.toX = toX;
	this.toY = toY;
	this.startX = l.offsetLeft;
	this.startY = l.offsetTop;
	this.diffX = toX - this.startX;
	this.diffY = toY - this.startY;
	this.easing = easing;
}
AnimMove.prototype.tick = function()
{
	this.progress += this.step;
	var f = this.easing ? Animator.getRegression(this.progress) : this.progress;
	
	if(this.progress >= 1) 
	{
		this.l.style.left = this.toX;
		this.l.style.top = this.toY;
		return false;
	}
	else
	{
		this.l.style.left = Math.round(this.startX + this.diffX * f) + "px";
		this.l.style.top = Math.round(this.startY + this.diffY * f) + "px";		
		return true;
	}
}

function AnimZoom(l, from, to, anchorBottom, anchorRight)
{
	this.l = l;
	this.from = from;
	this.to = to;
	this.anchorBottom = anchorBottom;
	this.anchorRight = anchorRight;
	this.xywh = {x: l.offsetLeft, y: l.offsetTop, w: l.offsetWidth, h: l.offsetHeight};
	l.style.zoom = from + "%";
	if(this.anchorBottom || this.anchorRight) this._anchor(from);
}
AnimZoom.prototype =
{
	progress: 0.1,
	step: 0.25,
	tick: function()
	{
		this.progress += this.step;
		if(this.progress >= 1) 
		{
			if(this.to == 100) this.l.style.zoom = "";
			else this.l.style.zoom = this.to + "%";
			if(this.anchorBottom || this.anchorRight) this._anchor(this.to);
			return false;
		}
		else
		{
			var zoom = Math.floor(this.from + (this.to - this.from) * this.progress);
			this.l.style.zoom = zoom + "%";
			if(this.anchorBottom || this.anchorRight) this._anchor(zoom);
			return true;
		}
	},
	_anchor: function(zoom) {
		zoom = zoom / 100;
		var ratio = 1 - zoom;
		if(this.anchorBottom) {
			var dH = this.xywh.h * ratio;
			this.l.style.top = this.xywh.y + dH + "px";
		}
		if(this.anchorRight) {
			var dW = this.xywh.w * ratio;
			this.l.style.left = this.xywh.x + dW + "px";
		}
	}
}

/*
	v. 2.3 client uniqueID (olsJSCN-14)
	v. 2.2
	+ subForms/layoutManagers for subForm containers.
	v. 2.1.1
	+ invalidControl
	v. 2.1
	+ attachAsFormToTag
	+ 1020
	
	TODO: 
	- divide this file into several module files.
	- document control/container processing workflow.
	
	DelayedControlsCreation:
		=> controls not created on <form> parsing, instead nodes stored
		=> on <data> parsing
			- visible controls and controls without data are created
			- invisible controls stored, but not created
				- subsequent data for invisible controls stored
				- if invisible control becomes visible
					- it's created
					- stored data loaded into control step-by-step
			- tabbed containers always created, even if they're invisible, this is for the correct tab button order
			- collapsable container's collapsed/expanded state is not applied immediately, but stored
			  and applied after all other controls are loaded.
			- every top level delayed control checked against all collapsable containers
			  and moved if needed.
		=> children containers and controls inside children containers are not created for delayed containers (xml nodes stored).
	
	Control naming: CN_formTagName.
	Control Interfaces:
	IXMLDataAware
	{
		loadData(dataNode : XMLElement) : void  - optional.
		storeData(xmldoc : XML document) : XMLElement or XML document fragment or null  - optional.
	}
	
	ICNControl extends IXMLDataAware
	{
		createElement(controlNode : XMLElement, parentElement: HTMLElement) : HTMLElement.
		validateLoading() : void - optional.
		isValid(): bool - optional.
		resetValue() : void - optional. used for invalid controls on postback.
	}
	
*/
function CNFormManager(isTabbed, mode, parentFormManager)
{
	switch(mode) {
		case CNFormManager.MODE_DIALOG:
			this.isDialog = true;
			break;
		case CNFormManager.MODE_ATTACH:
			this.isAttach = true;
			break;
		case CNFormManager.MODE_MAIN:
		default:
			this.isMain = true;
	}	
	this._mode = mode;
	
	this.sourceUrl = null;
	this.logoutUrl = null;
	this.debug = false;
	this.isTabbed = isTabbed;
	this.xmlEncoding = "utf-8";

	this.reportTimings = false;
	this._timings = [];
	this.reportStats = false;
	this._stats = [];
	
	this.defaultButton = null;
	
	this._xmlhttp = null;
	this._ideaNode = null;
	this._currentFormID = null;
	
	this._blink = null;
	this._blinks = [];
	this._blinkTextFromColor = "";
	this._blinkTextToColor = "";
	this._blinkBackgroundFromColor = "";
	this._blinkBackgroundToColor = "";

	this._dialogWillBeLoaded = false;
	this._timerIsStoped = false;
	
	this._navigation = null;

	this._isPostingBack = false;
	this._postbackElement = null;
	this._loading = false;
	this._firstButtonFocused = false;
	this._formDisabled = false;
	this._failed = false;
	this._halt = false;
	this._closing = false;
	this._dialogPending = false;
	this.nonInteractive = false;
	
	this._parentFormManager = parentFormManager;
	this._dialogReturnValue = null;
	this._queryString = [];
	this._sendQueryString = true;
	this._modalFocused = false;

	this.alertSourceUrl = null;
	this.alertTimeout = 30;
	this._alertStarted = false;
	
	this._navigationDisabled = false;
	this._editMode = false;
	this._tabbedGroups = [];
	this._currentFormCaption = "";
	this._messagesShown = false;
	
	this._layoutManager = null;
	this.disableLayoutManager = false;
	
	this._helpLink = null;

	this._menus = [];
	this._currentContextID = 0;
	this._pendingContextMenuData = null;
	this.contextMenuPending = false;
	
	//this._globalProgressbar = document.body.children['cn_globalProgressbar'];
	//this._globalProgressbarTO = null;
	
	this._uploadURL = null;	
	this._uploadDebug = false;
	
	this._customUrlWindow = null;	
	
	this._waitingForButtonPostback = false;

	this._formErrorShown = false;

	this._requiredIcons = [];
	
	this._selectLocationCombo = null;
	this._sendFormResized = false;
	
	this._screen = "default";
	
	this._timers = [];
	this.initiateUpload = false; // Contains postback element's initiateUpload status.
	
	this.delayedControlsCreation = false;
	this._delayedControls = []; // id => [node, parentElement]
	this._delayedContainers = []; // id => [node, parentElement]
	this._delayedCollapsableContainers = []; // # => [containerEl, expand?]
	
	this._messageBoxOffset = 0;
	this._messageBoxes = [];

	this._autoLockTO = null;
	this._autoLockTime = 0;		
	this._autoLockShutDown = false;
	this._autoLockPostData = false;	
	
	this._heartBeatTO = null;
	this._heartBeatTime = 0;	
	this._heartBeatShutDown = false;
	this._heartBeatClearEvents = false;
	this._heartBeatPostData = false;	
	
	this._customUrlsToBeClosed = [];
	
	this._toggledCollapsableContainers = [];
	
	// Initialization. ==========================
	if(this.isDialog) 
	{
		this._resizable = false;
		CNFormManager.themeLoaded = true;
	}
	else if(this.isAttach)
	{
		this._resizable = false;
		CNFormManager.themeLoaded = true;
	}
	else // if(mode == CNFormManager.MODE_MAIN)
	{
		CNFormManager._measureScrollbars();

		this._aboutDialogLoaded = false;
		
		if(!top.__ontopZ) top.__ontopZ = 1000;
		Event.add(window, "unload", this, this._window_onunload);
		this._uniqueID = this._fetchUniqueID();
		
		if(CNFormManager.disableContextMenu) Event.add(document, "contextmenu", this, this._document_oncontextmenu);
		
		this._parseQueryString();

		this._globalPlaceholder = document.getElementById("cn_globalPlaceholder") || Util.findById(document.body, "cn_globalPlaceholder");
		
		Event.add(document, "help", this, this._document_onhelp);
		Event.add(window, "resize", this, this._window_onresize);
		
		this._attachedFormManagers = {};
		this._controls = {};
	}

	this._disabler = Util.createElement("div");
	this._disabler.style.cssText = "position: absolute; background: #000; z-index: 1000; opacity: 0; visibility: hidden; width: 100%; height: 100%; top: 0px; left: 0px;";
	if(this.isMain)
	{
		document.body.appendChild(this._disabler);
	}
}

CNFormManager.strings = {};
CNFormManager.MODE_MAIN = 1;
CNFormManager.MODE_DIALOG = 2;
CNFormManager.MODE_ATTACH = 3;
CNFormManager.currentThemeName = null; // NOTE: no initial theme.
CNFormManager.defaultThemeName = "blue"; // Will be requested by default.
CNFormManager.vista = false; // Vista render mode.
CNFormManager.themeLoaded = false;
CNFormManager.usePacked = false; // If true, packed CSS theme is used.
CNFormManager.changingTheme = false;
CNFormManager.neutralImagesPath = "g/";
CNFormManager.neutralIconsPath = "g/icons/";
CNFormManager.disableContextMenu = true;
CNFormManager.scrollBarSize = 20; // Some safe fail-back value.
// Optional embedding-host origin for external event notifications.  The
// standalone client uses its own origin; cross-origin hosts must configure
// this explicitly rather than receiving messages sent to "*".
CNFormManager.externalEventTargetOrigin = null;

CNFormManager.themeJSObjects = []; // Array of jso, which will be destroyed on theme unload.

CNFormManager.formManagers = [];
CNFormManager._checkArray = function()
{
	if(CNFormManager.formManagers.length == 0) 
	{
		Util.assert("CNFormManager.formManagers.length == 0");
		return false;
	}
	return true;
}
CNFormManager.getBaseFormManager = function()
{
	if(!CNFormManager._checkArray()) return null;
	return CNFormManager.formManagers[0];
}
CNFormManager.getActiveFormManager = function()
{
	if(!CNFormManager._checkArray()) return null;
	return CNFormManager.formManagers[CNFormManager.formManagers.length - 1];
}

CNFormManager.initMainFormManager = function(isTabbed)
{
	var formManager = new CNFormManager(isTabbed == true)
	CNFormManager.formManagers.push(formManager);
	return formManager;
}

CNFormManager.removeFromCollection = function(formManager)
{
	for(var i = 0; i < CNFormManager.formManagers.length; i++)
	{
		if(CNFormManager.formManagers[i] == formManager)
		{
			CNFormManager.formManagers.splice(i, 1);
			break;
		}
	}
}

CNFormManager._trace = function(title, str, force)
{
	var formManager = CNFormManager.getActiveFormManager();
	if(!formManager || !formManager.debug && !force) return;

	var dt = new Date(); 
	var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds() + "." + dt.getMilliseconds();
	title = time + ": " + title;

	try
	{
		if(!CNFormManager._debugWindow) 
		{
			CNFormManager._debugWindow = window.open("", "cn_debug", "width=450, height=550, scrollbars=yes");
			var debugDocument = CNFormManager._debugWindow.document;
			var debugStyle = debugDocument.createElement("style");
			debugStyle.textContent = "body{ margin: 2px; } *{ font-family: tahoma; font-size: 11px; }";
			(debugDocument.head || debugDocument.documentElement).appendChild(debugStyle);
			if(!debugDocument.body)
			{
				var debugBody = debugDocument.createElement("body");
				debugDocument.documentElement.appendChild(debugBody);
			}
			window.focus();
		}
	
		var body = CNFormManager._debugWindow.document.body;
		if(!str) body.appendChild(body.ownerDocument.createTextNode(title));
		else
		{
			var div = Util.createElementFromHTML("<div style='background: gray; color: white; font-weight: bold; padding: 5px; '>", CNFormManager._debugWindow.document);
			body.appendChild(div);
			div.appendChild(body.ownerDocument.createTextNode(title));
			body.appendChild(body.ownerDocument.createTextNode(str));
		}
		Util.appendHTML(body, "<hr>");
		body.scrollTop = body.scrollHeight;
	}
	catch(e)
	{
	}
}

CNFormManager.destroyJSObjectsMap = function(map) {
	for(var i in map) {
		this.destroyJSObject(map[i]);
		map[i] = null;
	}
}
CNFormManager.destroyJSObjects = function(jsObjects)
{
	var count = jsObjects.length;
	for(var i = 0; i < count; i++)
	{
		this.destroyJSObject(jsObjects[i]);
		jsObjects[i] = null;
	}
}
CNFormManager.destroyJSObject = function(jsObject)
{
    Event.purge(jsObject);
	if(jsObject.unload) jsObject.unload();
	var el = jsObject.element;
	if(el)
	{
		var id = el.id;
		el.jsObject = null;
		Util.removeElement(el);
		jsObject.element = null;
	}
}

CNFormManager._measureScrollbars = function()
{
	var div = Util.createElement("div");
	div.style.cssText = "position: absolute; top: 0; left: 0; width: 100px; height: 100px; overflow: auto; visibility: hidden;";
	document.body.appendChild(div);
	var subDiv = Util.createElement("div");
	subDiv.style.cssText = "width: 200px; height: 200px;";
	div.appendChild(subDiv);
	
	CNFormManager.scrollBarSize = div.offsetWidth - div.clientWidth;
	Util.removeElement(div);
}

var proto = CNFormManager.prototype;
	
proto._window_onunload = function()
{
	CNFormManager.getBaseFormManager().window_onunload();
}
proto.window_onunload = function()
{
	this._shutDownTimers();		
	
	this._detachHTMLLayout();

	this._menus = null;
	
	PopupMenu.unload();

	this._globalPlaceholder = null;
	this._logout();
	
	if(CNFormManager._debugWindow) {
		CNFormManager._debugWindow.close();
		CNFormManager._debugWindow = null;
	}

	Event.destroy();
}

// Currently called by dialogs and attaches.
proto.destroy = function() {
	if(this._alertIcons) {
		CNFormManager.destroyJSObject(this._alertIcons);
	}

	this._deleteControls();
	if(this._layoutManager) { 
		this._layoutManager.unload();
		this._layoutManager = null;
	}
	this._formPlaceholder = null;
}

proto._startTiming = function(name)
{
	if(!this.reportTimings) return;
	this._timings[name] = new Date().getTime();
}
proto._endTiming = function(name)
{
	if(!this.reportTimings) return;
	this._timings[name] = new Date().getTime() - this._timings[name];
}
proto._changeStat = function(name, delta)
{
	this._stats[name] = this._stats[name] ? this._stats[name] + delta : delta;
}
	

proto._document_onhelp = function()
{
	var fm = CNFormManager.getActiveFormManager();
	if(fm && fm._helpLink) window.open(fm._helpLink)
	CNUtil.cancelEvent();
}

proto._window_onresize = function()
{
	var fm = CNFormManager.getBaseFormManager();
	fm._sendFormResized = true;
}

proto._formPlaceholder_onkeypress = function()
{
	if(Event.keyValue(Event.current()) == 13 && CNFormManager.getActiveFormManager().defaultButton != null) 
	{
		var fm = CNFormManager.getActiveFormManager();
		var b = fm.defaultButton;		
		if(b) 
		{
			Util.cancelEvent();
			b.doClick();
		}
	}
}
	
proto._dialog_formPlaceholder_onfocusout = function()
{
	// Disabled due to #1161. IE crash when TAB-navigating in grid inside dialog (cancelEvent crashes).
	/*
	try {
		if((Event.current() || {}).relatedTarget && (Event.current() || {}).relatedTarget._isPopup) return; // Allow popups to take focus.
	} catch(e) {} 

	var fm = CNFormManager.getActiveFormManager();
	if(!fm || !fm._dialogDiv) return;
	
	//CNFormManager._trace("_dialog_formPlaceholder_onfocusout 1");

	if(!(Event.current() || {}).relatedTarget || (Event.current() || {}).relatedTarget && !fm._dialogDiv.contains((Event.current() || {}).relatedTarget))
	{
		//CNFormManager._trace("_dialog_formPlaceholder_onfocusout - processing TAB out of dialog, from element.className" + event.className 
		//	+ " to element " + ((Event.current() || {}).relatedTarget ? Util.definitionTag((Event.current() || {}).relatedTarget.outerHTML) : "null"));

		var currentTI = 0;
		if(Util.eventTarget(Event.current()) && Util.eventTarget(Event.current()).tabIndex) 
		{
			currentTI = Util.eventTarget(Event.current()).tabIndex;
		}
		
		//CNFormManager._trace("_dialog_formPlaceholder_onfocusout 2");

		if(!fm._focusFirstFocusableControl(currentTI))
		{
			fm._focusFirstFocusableControl(0);
		}

		CNUtil.cancelEvent(event);		
	}

//	CNFormManager._trace("toElement.className" + (Event.current() || {}).relatedTarget.className 
//		+ " to element " + ((Event.current() || {}).relatedTarget ? Util.definitionTag((Event.current() || {}).relatedTarget.outerHTML) : "null"));

	if((Event.current() || {}).relatedTarget 
		&& ((Event.current() || {}).relatedTarget.tagName == "BODY" || !fm._formPlaceholder.contains((Event.current() || {}).relatedTarget)))
	{
		CNUtil.cancelEvent();
	}
	*/
}

proto._focusFirstFocusableControl = function(startTabIndex)
{
	startTabIndex = startTabIndex < 0 ? 0 : startTabIndex;
	//CNFormManager._trace("_focusFirstFocusableControl startTabIndex=" + startTabIndex);
	var l;
	var offset = 0;
	do
	{
		var result = this._findNextTabIndexControl(startTabIndex, offset);
		l = result.control;
		offset = result.offset;
	
		if(l) 
		{
			try
			{ 
				//CNFormManager._trace("_focusFirstFocusableControl - focus " + Util.definitionTag(l.outerHTML));		
				l.focus(); 
				break;
			} 
			catch(e)
			{
				// Element is hidden (in hidden container) -> find next.
				startTabIndex = l.tabIndex;
			}
		}
	} 
	while(l);
	return l ? true : false;
}

proto._checkIfVisible = function(l)
{
	do
	{
		var lcs = Util.getComputedStyle(l);
		if(lcs.visibility == "hidden" || lcs.display == "none") return false;
		if(lcs.visibility == "visible") return true;
		l = l.parentElement;
		this._it++;
	}
	while(l && l != document.body);
	return true;
}

proto._findFirstTabIndexControl = function()
{
	var params = {minTab: 999999, lowerTab: 0, control: null};
	this._findFirstTabIndexControlInternal(this._formPlaceholder, params);
	return params.control;
}

proto._findNextTabIndexControl = function(tabIndex, offset)
{
	var params = {minTab: 999999, lowerTab: tabIndex, control: null, offset: offset};
	this._findFirstTabIndexControlInternal(this._formPlaceholder, params);
	return params;
}

proto._findFirstTabIndexControlInternal = function(element, params)
{
	var all = element.getElementsByTagName("*");
	var allCount = all.length;
	for(var i = 0/*params.offset*/; i < allCount; i++)
	{
		var l = all[i];		
		if(Util.getStyle(l, "display") != 'none' && Util.getStyle(l, "visibility") != 'hidden' 
		&& l.tabIndex < params.minTab && l.tabIndex > params.lowerTab) 
		{
			params.minTab = l.tabIndex;
			params.control = l;
			params.offset = i;
		}
	}
}


proto._setDialogResult = function(closedByServer, errorProcessing)
{
	var obj = {closedByServer: closedByServer};
	if(errorProcessing) obj.gotError = true;
	this._dialogReturnValue = obj;
}

// NOTE: both arguments are optional.
proto.loadForm = function(dataXml, onreadyFunc)
{
	if(this._loading)
	{
		Util.assert("can't load form - still loading.");				
		return;
	}

	this._loading = true;
	this._failed = false;
	
	//Tooltip.hide(); // FWUI-1025-2 moved hide to be fired before new form render.
	this._beginProgress();
	
	this._ideaNode = null;
	this._messagesShown = false;
	this._onreadyFunc = onreadyFunc;		

	if(this._sendQueryString && !dataXml) {
		var dataXmlAr = ["<events><queryString>"];
		for(var param in this._queryString) {
			dataXmlAr.push('<p name="' + Util.escapeAttr(param) + '" value="' + Util.escapeAttr(this._queryString[param]) + '"/>');
		}
		if(dataXmlAr.length > 1) {
			dataXmlAr.push("</queryString></events>");
			dataXml = dataXmlAr.join("");
		}

		this._sendQueryString = false;
	}

	if(!CNFormManager.themeLoaded) dataXml = this._filterEventsXMLForTheme(dataXml);
	
	if(this._sendFormResized) 
	{
		dataXml = this._filterEventsXMLForResized(dataXml);
		this._sendFormResized = false;
	}

	this._dataXml = dataXml;
			
	if(this.isMain && !this._alertStarted) this._startAlerts();

	this._loadForm3();
}
	
proto._loadForm3 = function()
{
	var dataXml = this._dataXml;
	this._dataXml = null;
	
	this._roundTrip(dataXml);
}
	
proto._continueLoadForm = function(responseXML)
{
	this._endTiming("loadTime");

	if(responseXML != null) 
	{
		this._ideaNode = responseXML.documentElement;
		if(this._ideaNode) 
		{
			if(!this._executeClose_Error_Theme()) return;
		}
	}
	this._continueLoadForm2();
}

proto._continueLoadForm2 = function()
{
	if(this._ideaNode) {
		this._executeIdeaNode();
		if(this._onreadyFunc)
		{
			this[this._onreadyFunc]();
			this._onreadyFunc = null;
		}
	}
	this._loading = false;

	this._endProgress();
	if(this._failed) this._handleLoadFailed();
}

proto._logout = function(reload)
{
	if(this._loading) return;
	
	this._setNonInteractive(true);
	
	//If any window open by opemCustomUrl opened, close it
	if(this._customUrlWindow)
	{
		try {
			this._customUrlWindow.quit();
		}
		catch(e) {}	
	}
	
	if(this.logoutUrl)
	{
		window.open(this.logoutUrl, "_logout", 
					"location=no, menubar=no, resizable=no, scrollbars=no, status=no, "
					+ "toolbar=no, width=300, height=100");
	}
	
	this._setPatient("");
	
	this._shutDownTimers();		
	this._shutDownHeartBeat();
	this._shutDownAutoLock();
		
	var uniqueID = '<uniqueID value="' + this._uniqueID + '"/>'; 
	
	if(reload) {
		this.loadFormWithPostback('<events><logout source="App"/>' + uniqueID + '</events>');		
	} else {
		var data = '<events><logout source="IE"/>' + uniqueID + '</events>';
		CNFormManager._trace("Sending xml", data);
		var xmlhttp = Util.createXMLHttpRequest();
		xmlhttp.open("POST", this.sourceUrl, true);
		xmlhttp.send(data);		
	}
}

// This methods ensures we have postback state set properly.
proto.loadFormWithPostback = function(dataXml) 
{
    if(this._isLoading()) return;
    if(this._isPostingBack) {
       Util.assert("loadFormWithPostback this._isPostingBack");
    }
    this._isPostingBack = true;
    this._setNonInteractive(true);
    this.loadForm(dataXml, "_finishPostData");
}

proto._isLoading = function() {
    if(this._loading) {
        var debugXML = "[failed]";
        try {
            debugXML = this._dataXml ? (typeof this._dataXml == "string" ? this._dataXml : Util.xmlString(this._dataXml)) : 'empty';
        } catch(e) {}
        Util.assert("can't load form - still loading, attempted: " + debugXML);
        return true;
    }
    return false;
}

proto._roundTrip = function(xmldoc)
{
		if(!this.sourceUrl)
	{
		Util.assert("Invalid sourceUrl.")
		return;
	}

	var method = "POST";

	if(xmldoc) 
	{
		method = "POST";
		
		var xml;
		if(typeof(xmldoc) == "string") xml = xmldoc;
		else xml = Util.xmlString(xmldoc);
		
		CNFormManager._trace("Sending xml", xml);
	} else {
		Util.assert("No xmldoc");
		return;
	}

	this._startTiming("loadTime");

	this._xmlhttp = Util.createXMLHttpRequest();
	var formManager = this;
	this._xmlhttp.onreadystatechange = function() {
		formManager._xmlhttp_onreadystatechange();
	};
	this._xmlhttp.open(method, this.sourceUrl, true);
    this._xmlhttp.send(xmldoc);
}

proto._xmlhttp_onreadystatechange = function()
{
	if(!this._xmlhttp || this._xmlhttp.readyState != 4) return;
	this._xmlhttpIsReady();
}

proto._noop = function() {}

proto._checkXmlHttp = function(xmlhttp)
{
	if(xmlhttp.status != 200)
	{
		if(CNFormManager.themeLoaded)
		{
			this._processFormError2("Failed to load " + this.sourceUrl, null, false, "Server reports:", xmlhttp.responseText);
		}
		else
		{
			CNFormManager.getBaseFormManager()._globalPlaceholder.innerHTML = "<h2>Failed to load " + this.sourceUrl
												+ "</h2><br><h3>Server reports:</h3>" 
												+ xmlhttp.responseText;
		}

		this._finishLoadFailure("HTTP " + xmlhttp.status, xmlhttp.responseText);
		return false;
	}
	else
	{
		if(!xmlhttp.responseXML || !xmlhttp.responseXML.documentElement)
		{
			var errorStr = "";
			var parseError = xmlhttp.responseXML && xmlhttp.responseXML.parseError;
			if(parseError && parseError.errorCode != 0)
			{
				errorStr = parseError.reason + "Line: " + parseError.line + ", pos: " + parseError.linepos; 
			}
			//alert(errorStr);
			this._deleteLoadingBar();
			
			var message = "Error: Can't get XML document element";
			if(CNFormManager.themeLoaded) 
			{
				this._processFormError2(message, null, false, errorStr, xmlhttp.responseText);
			}
			else
			{
				CNFormManager.getBaseFormManager()._globalPlaceholder.textContent = message + "\n"
													+ errorStr
													+ "\n\n" 
									+ xmlhttp.responseText;
			}
			this._finishLoadFailure(message, errorStr || xmlhttp.responseText);
			return false;
		}
	}
	return true;
}

/*
	A terminal transport/response failure must release the same state that a
	successful _continueLoadForm2/_finishPostData path releases.  The historical
	client relied on IE's response/error behaviour and could leave the modal
	disabler in place forever when a standards-browser response was malformed or
	response processing threw.  Do not emulate the IE behaviour: report the
	failure, restore the UI boundary, and leave the original exception visible in
	console diagnostics.
*/
proto._finishLoadFailure = function(reason, detail)
{
	this._loading = false;
	this._isPostingBack = false;
	this._postbackElement = null;
	this._onreadyFunc = null;
	this._endProgress();
	this._setNonInteractive(false);
	this._navigationDisabled = false;

	var message = String(reason || "Client Framework response failed");
	if(detail) message += ": " + String(detail);
	if(typeof console != "undefined" && console.error) {
		console.error("Client Framework response failure: " + message);
	}
	return message;
}

proto._xmlhttpIsReady = function()
{
	if(!this._checkXmlHttp(this._xmlhttp)) 
	{
		CNFormManager._trace("Error Response from url: " + this.sourceUrl, this._xmlhttp.responseText);
		return null;
	}
	CNFormManager._trace("Response from url: " + this.sourceUrl, Util.xmlString(this._xmlhttp.responseXML));

	/*var start = new Date().getTime();
	xml_to_json(this._xmlhttp.responseXML.documentElement);
	CNFormManager._trace("xml_to_json: " + (new Date().getTime() - start) + "ms\n" + xml_to_json_nodes);*/

	try
	{
		this._continueLoadForm(this._xmlhttp.responseXML);
	}
	catch(e)
	{
		this._finishLoadFailure("response processing", e && e.message ? e.message : e);
		throw e;
	}
}

proto._removeBlink = function(divsColl)
{
	for (i=0; i < divsColl.length; i++) 
	{	 
		clearTimeout(this._blink);
	}
}

proto._enableTextAndBackgroundBlink = function(divsColl)
{ 		
	if (divsColl.length > 0)
		clearTimeout(this._blink);
  
   for (i=0; i < divsColl.length; i++) 
   { 
        objElement = divsColl[i]; 
		
		var myBlinkTextFromColor = objElement.blinkTextFromColor;
		var myBlinkTextToColor = objElement.blinkTextToColor;
		var myBlinkBackgroundFromColor = objElement.blinkBackgroundFromColor;
		var myBlinkBackgroundToColor = objElement.blinkBackgroundToColor;
		
		if (objElement.id == "blinkDiv")
		{
			if (myBlinkTextFromColor && myBlinkTextToColor)
			{
				if(objElement.style.color == myBlinkTextFromColor) 
				{ 
					objElement.style.color = myBlinkTextToColor; 
				} 
				else 
				{ 
					objElement.style.color = myBlinkTextFromColor; 					
				} 
			}
			if (myBlinkBackgroundFromColor && myBlinkBackgroundToColor)
			{
				if(objElement.style.background == myBlinkBackgroundFromColor) 
				{ 
					objElement.style.background = myBlinkBackgroundToColor; 
				} 
				else 
				{ 
					objElement.style.background = myBlinkBackgroundFromColor; 
				} 
			}			 
		}
   } 
   
   var self = this;
   this._blink = setTimeout( function() { self._enableTextAndBackgroundBlink(divsColl);}, 800); 
} 


proto._startAlerts = function()
{
	var base = CNFormManager.getBaseFormManager();
	if(base) setTimeout(function(){ base._doAlerts(); }, this.alertTimeout * 1000);
}

proto._doAlerts = function()
{
	if(!this.alertSourceUrl) return;
	
	if(Util.getStyle(this._formPlaceholder, "display") == 'none')
	{
		// We are at login or select role page.
		var base = CNFormManager.getBaseFormManager();
		if(base) setTimeout(function(){ base._doAlerts(); }, this.alertTimeout * 1000);
		return;
	}
	
	this._alert_xmlhttp = Util.createXMLHttpRequest();
	var formManager = this;
	this._alert_xmlhttp.onreadystatechange = function() {
		formManager._alert_xmlhttp_onreadystatechange();
	};
	this._alert_xmlhttp.open("GET", this.alertSourceUrl, true);
    this._alert_xmlhttp.send();
}

proto._alert_xmlhttp_onreadystatechange = function()
{
	if(!this._alert_xmlhttp || this._alert_xmlhttp.readyState != 4) return;
	this._alert_xmlhttpIsReady();
}

proto._alert_xmlhttpIsReady = function()
{
	if(this._alert_xmlhttp.status != 200)
	{
		if(typeof console != "undefined" && console.error)
			console.error("Client Framework alert request failed: HTTP " + this._alert_xmlhttp.status);
		return null;
	}
	if(!this._alert_xmlhttp.responseXML || !this._alert_xmlhttp.responseXML.documentElement)
	{
		if(typeof console != "undefined" && console.error)
			console.error("Client Framework alert request failed: response is not XML");
		return null;
	}
	CNFormManager._trace("Alert: Response from url: " + this.alertSourceUrl, Util.xmlString(this._alert_xmlhttp.responseXML));

	if(this._alertIcons) 
	{
		var xmlDoc = this._alert_xmlhttp.responseXML;
		var rootNode = xmlDoc.documentElement;
		var alertsNode = Util.xmlSelectSingleNode(rootNode, "alerts");
	
		if(alertsNode) this._alertIcons.loadData(alertsNode);
	}

	var base = CNFormManager.getBaseFormManager();
	if(base) setTimeout(function(){ base._doAlerts(); }, this.alertTimeout * 1000);
}


proto._executeClose_Error_Theme = function()
{
	this._startTiming("totalFormExecTime");

	if(this._formErrorShown) this._deleteFormError();
	
	var closeNode = Util.xmlSelectSingleNode(this._ideaNode, "close");
	if(this.isDialog && closeNode)
	{
		this._setDialogResult(true);		
		var noPostback = closeNode.getAttribute("postback") == "false";
		var node = this._ideaNode;
		this._closeDialog(noPostback);
		if(noPostback) // Redirect xml to base formmanager.
		{
			var fm = CNFormManager.getBaseFormManager();
			fm._setControlsDisabledState(false);
			fm._ideaNode = node;
			fm._messagesShown = false; // Reset messages status.
			fm._executeIdeaNode();
		}
		
		return false;
	}

	var errorNode = Util.xmlSelectSingleNode(this._ideaNode, "error");
	if(errorNode)
	{
		return this._processServerError(errorNode);
	}
	
	if(this.isMain)
	{
		this._startTiming("themeTime");
		if(this._processTheme()) 
		{
			this._endTiming("themeTime");
			return false;
		}
		this._endTiming("themeTime");
	}
	
	return true;
	// Caller calls execyteXML2.
}

proto._executeIdeaNode = function()
{
	var showProgressNode = Util.xmlSelectSingleNode(this._ideaNode, "showProgress");
	if(showProgressNode != null) {
		this._showProgress(showProgressNode);
	}

	if(this.isMain) {
		var node = Util.xmlSelectSingleNode(this._ideaNode, "debugWindow");
		if(node) this.debug = true;
	}

	if(this.isMain || this.isDialog) { // It's important to always process <screen>, event if sent to dialog FM.
		var screenNode = Util.xmlSelectSingleNode(this._ideaNode, "screen");
		if(screenNode) {
			var baseFM = CNFormManager.getBaseFormManager();
			baseFM._processScreen(screenNode);
		}
	}

	if(this.isMain) {
		this._startTiming("navigationCreationTime");
		var navigationNode = Util.xmlSelectSingleNode(this._ideaNode, "navigation");
		if(navigationNode)
		{
			var navCreateNode = Util.xmlSelectSingleNode(navigationNode, "create");
			if(navCreateNode)
			{
				this._deleteNavigation();
				this._createNavigation(navCreateNode);
			}
			if(this._navigation)
			{
				var navModifyNode = Util.xmlSelectSingleNode(navigationNode, "modify");
				if(navModifyNode) this._navigation.loadData(navModifyNode);
			}
		}
		this._endTiming("navigationCreationTime");

		if(this._topButtons) 
		{
			var topButtonsNode = Util.xmlSelectSingleNode(this._ideaNode, "topbuttons");
			if(topButtonsNode) this._topButtons.loadData(topButtonsNode);
		}
	} 
	if(this.isMain || this.isDialog) {
		var patientNode = Util.xmlSelectSingleNode(this._ideaNode, "patient");
		if(patientNode) {
			var textColor = null;
			var textColorAttr = patientNode.getAttribute("textColor");
			if(textColorAttr != null) textColor = String(textColorAttr);
			this._setPatient(String(Util.xmlText(patientNode)), textColor);
		}
	}
	if(this.isDialog && this._dialogNotShownYet) {
		this._dialogDiv.style.visibility = "visible";
		if(this._dialogDiv.shadow) this._dialogDiv.shadow.show();
		try
		{ 
			this._dialogDiv.focus(); 
		} 
		catch(e){}
		this._dialogNotShownYet = false;
	}


	this._startTiming("formCreationTime");
	var formNode = Util.xmlSelectSingleNode(this._ideaNode, "form");
	if(formNode) 
	{
		this._stats = [];
		this._deleteControls();

		var attr = formNode.getAttribute("navID");
		if(attr) this._currentFormID = String(attr);
		else this._currentFormID = null;
		
		attr = formNode.getAttribute("helpLink");
		if(attr) this._helpLink = String(attr);
		else this._helpLink = null;
		
		if(this.isMain && this.isTabbed)
		{
			if(this._navigation)
			{
				this._navigation.hideSecondLevel();
	
				if(this._navigation.isTopTabForm(this._currentFormID))
				{
					this._subLevelFrame.style.display = "none";
					this._formPlaceholder.style.top = 32;
					this._formPlaceholder.style.left = 6;
					if(this._layoutManager) this._layoutManager.formTopOffset = 0;
				}
				else
				{
					this._subLevelFrame.style.display = "block";
					this._navigation.showSecondLevel(this._currentFormID);
					
					this._formPlaceholder.style.top = 62;
					this._formPlaceholder.style.left = 8;
					if(this._layoutManager) this._layoutManager.formTopOffset = 20;					
				}
			}
			else
			{
				this._formPlaceholder.style.top = 24;
				this._formPlaceholder.style.left = 6;
				if(this._layoutManager) this._layoutManager.formTopOffset = 0;
			}
			LayoutManager._rightPadding = 6;
		}
		
		if(this.isMain)
		{
			var wAttr = formNode.getAttribute("width");
			if(wAttr)
			{
				var w = parseInt(wAttr, 10);
				var h = parseInt(formNode.getAttribute("height"), 10);
				if(this._layoutManager) this._layoutManager.setInitialBounds(w, h);
				//this._formPlaceholder.style.width = w;
				//this._formPlaceholder.style.height = h;
			}
			else
			{
				if(this._layoutManager) this._layoutManager.resetInitialBounds();
			}
		}
		
		this._executeXMLForm(formNode);
	}
	else
	{
		var formErrorNode = Util.xmlSelectSingleNode(this._ideaNode, "formError");
		if(formErrorNode) 
		{
			this._processFormError(formErrorNode);
			return;
		}
	}
	
	this._endTiming("formCreationTime");

	this._startTiming("dataProcessingTime");
	this._executeXMLData();
	this._endTiming("dataProcessingTime");

	if(this._navigation) this._navigation.selectFormNode(this._currentFormID);

	this._startTiming("validateLoading");
	this._validateLoading();
	this._endTiming("validateLoading");

	if(CNFormManager.getBaseFormManager()._alertIcons && this._ideaNode) this._loadAlertIcons();

	this._endTiming("totalFormExecTime");
	CNFormManager._trace("Loading complete", ' ');
	this._report();

	if(this.isMain || this.isDialog) {
		this._loadAttachedFMs();
		this._checkForURL();
		this._checkForCustomURL();
		this._checkforCloseURL();
		this._checkStoredLocations();
		this._processExternalEvents();
		this._testForXMLDialog();
		this._tryToProcessServerErrors();
		this._showMessagesTO();
		this._showPasswordDialogTO();		
		this._processDeleteFiles();
		this._runExternalApplication();
		this._startTimers();		
		//Load HeartBeat timer
		this._loadHeartBeatTimer(this._ideaNode);	
		//Load AutoLock timer
		this._loadAutoLockTimer(this._ideaNode);	
		
		// Allow loading to finish.
		var node = Util.xmlSelectSingleNode(this._ideaNode, "dialog");
		if(node)
		{
			this._dialogWillBeLoaded = true;
			this._dialogNode = node;
			this._deleteMessageBoxes();
			//setTimeout("CNFormManager.getActiveFormManager()._executeXMLDialog()", 0);
			var fm = this;
			setTimeout(function(){ fm._executeXMLDialog(); }, 0);
		}				
		else
		{
			this._dialogNode = null;		
			this._dialogWillBeLoaded = false;
		}
		
		
		clearTimeout(this._enableBlink);
		this._notifyScanningServlet();
		
	}
}

proto._notifyScanningServlet = function() 
{
	if (document.scanningApplet)
	{		
		document.scanningApplet.getNextImage();
	}		
}

proto._loadAttachedFMs = function() {
	for(var tag in this._attachedFormManagers) {
		var tagNode = Util.xmlSelectSingleNode(this._ideaNode, tag);
		if(tagNode != null) {
			var fm = this._attachedFormManagers[tag];
			fm._ideaNode = tagNode;
			fm._executeIdeaNode();
		}
	}
}

proto._unsafe_runExternalApplication = function(applicationPath)
{
	CNFormManager._trace("Unsupported feature: launching local applications is unavailable in standards browsers.", null, true);
	return false;
}
proto._runExternalApplication = function()
{
	var nodes = this._ideaNode && Util.xmlSelectNodes(this._ideaNode, "runFiles/file");
	if(nodes && nodes.length) CNFormManager._trace("Unsupported feature: runFiles requires a native application launcher.", null, true);
	return false;
}
proto._processDeleteFiles = function()
{
	var nodes = this._ideaNode && Util.xmlSelectNodes(this._ideaNode, "deleteFiles/file");
	if(nodes && nodes.length) CNFormManager._trace("Unsupported feature: server-requested local file deletion is unavailable in standards browsers.", null, true);
	return false;
}
proto._report = function()
{
	if(this.reportTimings || this.reportStats)
	{
		if(this.reportTimings)
		{
			var str = [];
			for(var i in this._timings)
			{
				str.push(i + ": " + this._timings[i] + "ms\n");
			}
			CNFormManager._trace("Load timings", str.join(""), true);
		}
		if(this.reportStats)
		{
			var str = [];
			for(var i in this._stats)
			{
				str.push(i + ": " + this._stats[i] + "\n");
			}
			CNFormManager._trace("Form stats", str.join(""), true);
		}
	}
}

proto._processExternalEvents = function() {
	var events = Util.xmlSelectNodes(this._ideaNode, "externalEvents/event");
	if(events.length > 0 && window.parent && window.parent != window && window.parent.postMessage) {
		var targetOrigin = CNFormManager.externalEventTargetOrigin;
		if(!targetOrigin && window.location && window.location.origin) targetOrigin = window.location.origin;
		if(!targetOrigin) {
			Util.reportUnsupported("CNFormManager", "cross-origin external event notifications", "Configure CNFormManager.externalEventTargetOrigin");
			return;
		}
		for(var i = 0; i < events.length; i++) {
			window.parent.postMessage({
				source: "openMAXIMS",
				type: "externalEvent",
				id: String(events[i].getAttribute("id"))
			}, targetOrigin);
		}
	}
}

proto._safelyClosePopups = function() { // Back port.
	// Close some popups.
	// TODO: custom events and global event, which all the popup-enabled controls should listen to.
	if(this._navigation && this._navigation.hideAllPopups) this._navigation.hideAllPopups();
	if(CN_combobox.currentCombobox) CN_combobox.currentCombobox.hidePopup();
	if(CN_answerbox.currentCombobox) CN_answerbox.currentCombobox.hidePopup();
	Tooltip.hide();
	PopupMenu.hideMenus();
	if(CNPopupCalendar.defaultInstance) CNPopupCalendar.defaultInstance.hide(true, false);
	if(this._topButtons) this._topButtons._hideMore2(true);
	if(CN_search._popup) CN_search._popup._hidePopup();
	CN_wysiwygeditor._hideAutocompleteUI();

	this._forceClosePasswordDialog();

    if(this._navigation && this._navigation.expand) this._navigation.expand(true); // Force navigation expand && restore screen items.
}

proto._forceClosePasswordDialog = function() { // Called by autolock.
	if(this._passwordDialog) {
		CNDialogManager.destroyDialog(this._passwordDialog);
		this._passwordDialog = null;
	}
}

CNFormManager.closeAllDialogs = function() {
	var toClose = [];
    for(var i = CNFormManager.formManagers.length - 1; i > 0; i--) {
		var fm = CNFormManager.formManagers[i];
		if(fm.isDialog) toClose.push(fm);
	}
	for(var i = 0; i < toClose.length; i++) {
		toClose[i]._closeDialog(true);
	}
}


proto._processScreen = function(screenNode)
{
	if(document.body.focus) document.body.focus();

	this._safelyClosePopups();
	CNFormManager.closeAllDialogs();
	
	//var animate = screenNode.getAttribute("animate") == "true";
	
	if(screenNode.getAttribute("clearForm") == "true")
	{
		this._deleteControls();		
	}

	if(this._screenLayoutManager)
	{
		var initialWidth = parseInt(screenNode.getAttribute("initialWidth"), 10);
		var initialHeight = parseInt(screenNode.getAttribute("initialHeight"), 10);
		if(!isNaN(initialWidth) && !isNaN(initialHeight)) 
			this._screenLayoutManager.setInitialBounds(initialWidth, initialHeight);

		this._screenLayoutManager.reload();
	}
	
	this._resetScreen();

	//if(animate) this._globalPlaceholder.style.visibility = "hidden";

	var items = Util.xmlSelectNodes(screenNode, "item");
	var count = items.length;
	for(var i = 0; i < count; i++)
	{
		this._processScreenItem(items[i]);
	}
	
	if(this._screenLayoutManager)
	{
		this._screenLayoutManager.doLayout();
	}
	


}
proto._resetScreen = function() {
	this._deleteScreenControls();
	this._resetScreenItems();
	this._destroyAttachedFMs();
}

proto._deleteScreenControls = function() {
	CNFormManager.destroyJSObjectsMap(this._controls);
	this._controls = {};
}

proto._resetScreenItems = function()
{
	for(var id in this._knownScreenItems)
	{
		var item = document.getElementById(id);
		if(!item)
		{
			CNUtil.assert("Can't find " + id + " to reset");
			continue;
		}
		
		item.style.display = "none";
	}
}

proto._processScreenItem = function(itemNode)
{
	var id = itemNode.getAttribute("id");
	if(!id) 
	{
		CNUtil.assert("_processScreenItem: no id for item " + Util.xmlString(itemNode));
		return;
	}
	id = String(id);
	
	var htmlID = "__si_" + id;
	var item = document.getElementById(htmlID);
	if(!item) 
	{
		//CNUtil.assert("_processScreenItem: no element found for item " + Util.xmlString(itemNode));
		//return;
		item = document.createElement("div");
		item.id = htmlID;
		item.style.cssText = "position: absolute; top: 0; left: 0; ";
		document.body.appendChild(item);
	}
	
	this._knownScreenItems[htmlID] = true;

	item.style.display = "block";
	
	var bounds = [];
	var attr = itemNode.getAttribute("x");
	if(attr)
	{
		var x = parseInt(attr, 10);
		var y = parseInt(itemNode.getAttribute("y"), 10);
		var w = parseInt(itemNode.getAttribute("width"), 10);
		var h = parseInt(itemNode.getAttribute("height"), 10);
		var anchor = parseInt(itemNode.getAttribute("anchor"), 2);
		
		if(isNaN(x) || isNaN(y) || isNaN(w) || isNaN(h))
		{
			CNUtil.assert("Valid x, y, width and height attributes required for item " + Util.xmlString(itemNode));
			return;
		}
		
		if(!isNaN(anchor) && this._screenLayoutManager)
		{
			this._screenLayoutManager.processRawElement(item, x, y, w, h, anchor);
		}
		else
		{
			item.style.left = x + "px";
			item.style.top = y + "px";
			item.style.width = w + "px";
			item.style.height = h + "px";
		}
		
		bounds = [w, h];
	}
	
	attr = itemNode.getAttribute("zIndex");
	if(attr)
	{
		item.style.zIndex = parseInt(attr, 10);
	}
	
	this._processScreenItemAttach(itemNode, item, bounds);

	attr = itemNode.getAttribute("control");
	if(attr) this._createThemeControl(String(attr), itemNode, item, id);
}
proto._createThemeControl = function(controlName, itemNode, item, id) {
	var controlClass = window['CN_' + controlName];
	if(!controlClass) return;
	var jso = new controlClass;
	jso.formManager = this;
	jso.elementID = id;
	jso.createElement(itemNode, item); // Passes itemNode as form tag to the control.

	this._controls[id] = jso;
}

proto._processScreenItemAttach = function(itemNode, item, bounds) {
	var attr = itemNode.getAttribute("attachAsFormToTag");
	if(attr == null) return;
	var attachAsFormToTag = String(attr);
	
	if(this._attachedFormManagers[attachAsFormToTag] != null) {
		Util.assert("Tag " + attachAsFormToTag + " is already used");	
		return;
	}
	
	var fm = new CNFormManager(false, CNFormManager.MODE_ATTACH, this);
	fm.debug = this.debug;
	fm.delayedControlsCreation = this.delayedControlsCreation;
	fm.sourceUrl = this.sourceUrl;
	fm._attachAsFormToTag = attachAsFormToTag;
	fm._formPlaceholder = item;
	if(bounds != null) fm._layoutManager = new LayoutManager(item, bounds[0], bounds[1]);
	
	this._attachedFormManagers[attachAsFormToTag] = fm;
}
proto._destroyAttachedFMs = function() {
	for(var tag in this._attachedFormManagers) this._attachedFormManagers[tag].destroy();
	this._attachedFormManagers = {};
}

proto._showMessagesTO = function()
{
	if(!this._ideaNode || this._messagesShown) return;

	var messagesNode = Util.xmlSelectSingleNode(this._ideaNode, "messages");

	if(messagesNode) {
		this._messagesPending = true;
		var fm = this;
		setTimeout(function(){ fm._showMessages(messagesNode); }, 100);
	}
}


proto._processFormError = function(formErrorNode)
{
    this._shutDownTimers();	
	
	var msgNode = Util.xmlSelectSingleNode(formErrorNode, "msg");
	var captionAttr = formErrorNode.getAttribute("caption")
	var titleAttr = formErrorNode.getAttribute("title");
	var browserTitleAttr = formErrorNode.getAttribute("browserTitle");
	var caption = null;
	var title = null;
	var msg = null;
	var browserTitle = null;

	if(captionAttr) caption = String(captionAttr);
	if(msgNode) msg = String(Util.xmlText(msgNode));
	if(titleAttr) title = String(titleAttr);
	if(browserTitleAttr) browserTitle = String(browserTitleAttr);
	this._processFormError2(caption, browserTitle, formErrorNode.getAttribute("suspend") == "true", title, msg);
}

proto._setFormCaptionText = function(caption, imgUrl)
{
	var formCaption;
	if(this.isMain) 
	{
		document.title = caption;
		formCaption = Util.findById(document, "__si_formCaption");
		if(formCaption) {
			var oldImage = formCaption.querySelector ? formCaption.querySelector(".captionImg") : null;
			formCaption.textContent = "";
			if(imgUrl) this._createFormCaptionImg(formCaption, imgUrl);
			else if(oldImage) formCaption.appendChild(oldImage);
			var captionText = Util.createElement("span", "formCaptionText");
			captionText.textContent = caption;
			formCaption.appendChild(captionText);
		}
	}
	else if(this.isDialog && this._dialogDiv._hasBackground)
	{
		if(CNFormManager.vista) CNDialogManager.setCaption(this._dialogDiv, caption);
		else
		{
			formCaption = Util.findById(this._dialogDiv, "formCaption1");
			if(formCaption) formCaption.textContent = caption;
			if(imgUrl) {
				this._createFormCaptionImg(formCaption, imgUrl);
			}
		}
	}
	this._currentFormCaption = caption;
}

proto._createFormCaptionImg = function(formCaption, imgUrl) {
	var img = document.createElement("img");
	img.className = "captionImg";
	img.src = String(imgUrl);
	formCaption.insertBefore(img, formCaption.firstChild);
}

proto._processFormError2 = function(caption, browserTitle, suspend, title, msg)
{
	this._deleteControls();
	if(this._darkHeader) this._darkHeader.style.visibility = "hidden";
	
	if(caption)	this._setFormCaptionText(caption);
	if(browserTitle) document.title = browserTitle;

	this._createFormError(title, msg);
	
	if(suspend)
	{
		this._failed = true;
		this._halt = true;
	}
	else
	{
		this._setNonInteractive(false);
		this._setNavigationDisabled(false);
	}
}

proto._createFormError = function(title, msg)
{
	var container = Util.createElementFromHTML("<div id='formErrorDiv' style='position: absolute; top: 0px; left: 0px; width: 800px; height: 600px; overflow: auto; '>");
	this._formPlaceholder.appendChild(container);
	container.onmousedown = Util.cancelBubble;
	container.onmouseup = Util.cancelBubble;
	container.onclick = Util.cancelBubble;
	
	var img = Util.createElementFromHTML("<img width=48 height=48 style='position: absolute; top: 16px; left: 24px; '>");
	container.appendChild(img);
	img.src = CNFormManager.neutralImagesPath + "exl-4.gif";

	var div1 = Util.createElementFromHTML("<div style='position: absolute; top: 28px; left: 90px; font-size: 18px; font-weight: bold; '>")
	container.appendChild(div1);

	div1.textContent = title ? title : "Form Error";
	
	var div2 = Util.createElementFromHTML("<div style='position: absolute; top: 68px; left: 90px; width: 700px; '>");
	container.appendChild(div2);	
	
	if(msg) div2.textContent = msg;
	
	this._formErrorShown = true;
}

proto._deleteFormError = function()
{
	var l = Util.findById(this._formPlaceholder, "formErrorDiv");
	if(l) Util.removeElement(l);
	this._formErrorShown = false;
}

proto._checkforCloseURL = function()
{
	if(!this._ideaNode) return;
	var urlNodes = Util.xmlSelectNodes(this._ideaNode, "closeUrl");
	var obj = this;
	setTimeout(function()
	{
		for(var i = 0; i < urlNodes.length; i++)
		{
			obj._closeUrl(urlNodes[i]);
		}
	}, 250);
}

proto._checkForURL = function()
{
	if(!this._ideaNode) return;
	var urlNodes = Util.xmlSelectNodes(this._ideaNode, "openUrl");
	var obj = this;
	setTimeout(function()
	{
		for(var i = 0; i < urlNodes.length; i++)
		{
			obj._openURL(urlNodes[i]);
		}
	}, 250);
	var openEmail = Util.xmlSelectSingleNode(this._ideaNode, "openEmail");
	if(openEmail != null) document.location = "mailto:" + openEmail.getAttribute("address");
}

proto._checkForCustomURL = function()
{
	if(!this._ideaNode) return;
	var urlNodes = Util.xmlSelectNodes(this._ideaNode, "openCustomUrl");
	var obj = this;
	setTimeout(function()
	{
		for(var i = 0; i < urlNodes.length; i++)
		{
			obj._openCustomUrl(urlNodes[i]);
		}
	}, 250);	
}

proto._wait = function(delay)
{
    var start = new Date().getTime();
    while (new Date().getTime() < start + delay);
}

proto._ieQuit = function()
{
	CNFormManager.getActiveFormManager().postData("<onCustomUrlWindowChanged eventName=\"onunload\"/>");			
}

proto._closeUrl = function(node) 
{	
	var id = String(node.getAttribute("id"));
	for(var x = 0; x < this._customUrlsToBeClosed.length; x++) 
	{
		if (this._customUrlsToBeClosed[x].id == parseInt(id))
		{
			var toBeClosedwindow = this._customUrlsToBeClosed[x].object;
			
			try {
				toBeClosedwindow.close();								
				this._customUrlsToBeClosed.splice(x, 1);
			} 
			catch(ex) {}
		}	
	}
}

function wopen(url, name, toolbar, status, menubar, location, resizable, fullscreen, height, width) 
{
	var options;
	wleft = 0;
    wtop = 0;
	
	if (fullscreen == "fullscreen=no" && (height == 0 || width == 0)) 
	{		
		if (height == 0 || width == 0)
		{
			width= screen.width;
			height = screen.height;
		}
		
		wleft = (screen.width - width) / 2;
		wtop = (screen.height - height) / 2;    		
	}
	else if (fullscreen == "fullscreen=yes")
	{
		fullscreen = "";	
		width= screen.availWidth;
		height = screen.availHeight - 5;		
	}
	
	options = 	'width=' + width + ', height=' + height + ', ' +
				'left=' + wleft + ', top=' + wtop + ', ' +	
				toolbar +
				status +
				menubar +
				location +
				resizable +
				fullscreen;

    var win = window.open('about:blank', // <- Note about:blank
                name, options);
				
	win.location.href = url;
	win.resizeTo(width, height);
    win.moveTo(wleft, wtop);
    win.focus();	
	
	return win;
}

proto._openCustomUrl = function(node) 
{	
	var id = String(node.getAttribute("id"));
	var url = String(node.getAttribute("value"));	
	var windowParam = Util.xmlSelectNodes(node, "windowParam");
	var handleWindowEvents = node.getAttribute("handleWindowEvents");
		
	var toolbar = "toolbar=no, ", status = "status=no, ", menubar ="menubar=no, ", location = "location=no, ", resizable ="resizable=no, ", fullscreen = "fullscreen=false", height = 0, width = 0;
		
	//Parse Window parameters
	if(windowParam.length > 0) 
	{				
		for(var i = 0; i < windowParam.length; i++) 
		{		
			if(String(windowParam[i].getAttribute("name")) == "ToolBar")
				toolbar = String(windowParam[i].getAttribute("value")) == "true" ? "toolbar=yes, " :"toolbar=no, ";
			else if(String(windowParam[i].getAttribute("name")) == "StatusBar")
				status = String(windowParam[i].getAttribute("value")) == "true" ? "status=yes, " :"status=no, ";
			else if(String(windowParam[i].getAttribute("name")) == "MenuBar")
				menubar =  String(windowParam[i].getAttribute("value")) == "true" ? "menubar=yes, " :"menubar=no, ";
			else if(String(windowParam[i].getAttribute("name")) == "AddressBar")
				location = String(windowParam[i].getAttribute("value")) == "true" ? "location=yes, " :"location=no, ";
			else if(String(windowParam[i].getAttribute("name")) == "Resizable")
				resizable = String(windowParam[i].getAttribute("value")) == "true" ? "resizable=yes, " :"resizable=no, ";			
			else if(String(windowParam[i].getAttribute("name")) == "Height" && !isNaN(parseInt(windowParam[i].getAttribute("value"))))
				height =parseInt(windowParam[i].getAttribute("value"));		
			else if(String(windowParam[i].getAttribute("name")) == "Width" && !isNaN(parseInt(windowParam[i].getAttribute("value"))))
				width = parseInt(windowParam[i].getAttribute("value"));		
			else if(String(windowParam[i].getAttribute("name")) == "FullScreen")
				fullscreen = String(windowParam[i].getAttribute("value")) == "true" ? "fullscreen=yes" : "fullscreen=no";			
		}				
	}
	
	if(width == 0 || height == 0)
	{
		width = screen.width;
		height = screen.height;
	}
	
	var customWindow = wopen(url, '', toolbar, status, menubar, location, resizable, fullscreen, height, width);
	var customWindowObj = new Object();
		customWindowObj.id = id;
		customWindowObj.object = customWindow;
	
	this._customUrlsToBeClosed.push(customWindowObj);
}

proto._openURL = function(node) 
{	
	var url = String(node.getAttribute("value"));
	var params = Util.xmlSelectNodes(node, "param");
	var windowName = node.getAttribute("window");
	windowName = windowName ? String(windowName) : ""
	var w;
	if(params.length > 0) {
		w = window.open("", windowName);
		var doc = w.document;
		var form = doc.createElement("form");
		for(var i = 0; i < params.length; i++) {
			var input = doc.createElement("input");
			input.type = "hidden";
			input.name = String(params[i].getAttribute("name"));
			input.value = String(params[i].getAttribute("value"));
			form.appendChild(input);
		}
		doc.body.appendChild(form);
		form.action = url;
		form.method = "POST";
		form.submit();
	} else {
		w = window.open(url, windowName);
	}
}


proto._checkStoredLocations = function()
{
	if(!this._ideaNode) return;

	var locations = Util.xmlSelectSingleNode(this._ideaNode, "storedLocations");
	if(locations)
	{
		var xml = Util.xmlString(locations);
		CNFormManager._storedLocationsXML = xml;
		try { if(window.localStorage) window.localStorage.setItem("storedLocations", xml); } catch(ignore) {}
	}
}

proto._loadAlertIcons = function()
{
	if(!this._ideaNode) return;
	var alertsNode = Util.xmlSelectSingleNode(this._ideaNode, "alerts");
	if(alertsNode) CNFormManager.getBaseFormManager()._alertIcons.loadData(alertsNode);
}

proto._showPasswordDialogTO = function()
{
	var base = CNFormManager.getBaseFormManager();
	if(base) setTimeout(function(){ base._showPasswordDialog(); }, 0);
}

proto._showPasswordDialog = function()
{
	if(!this._ideaNode) return;
	var node = Util.xmlSelectSingleNode(this._ideaNode, "passwordDialog");
	if(!node) return;

	this._shutDownTimers();	
	
	var title = String(node.getAttribute("title"));
	var text = String(node.getAttribute("text"));
	this._currentPassword = String(node.getAttribute("password"));

	if(!this._passwordDialog) 
	{
		var contents;
		if(CNFormManager.vista)
		{
			this._passwordDialog = CNDialogManager.createVistaDialog(title);
			this._passwordDialog.style.width = 450;
			this._passwordDialog.style.height = 156;
		}
		else
		{
			this._passwordDialog = CNDialogManager.createDialog(title);
			this._passwordDialog.style.width = 450;
			this._passwordDialog.style.height = 116;
		}
		var contents = CNDialogManager.getContents(this._passwordDialog);
		var img = Util.createElementFromHTML("<img width=48 height=48 class=dialogIcon>");
		contents.appendChild(img)
		img.src = CNFormManager.neutralImagesPath + "yesno-question-1.gif";

		var html = "<div style='height: 60px; width: 100%; "
			+ "position: relative; padding: 4px; margin: 5px; top: 2px; padding-left: 58px; "
			+ " overflow: auto; '><div id='messageText'></div>"
			+ "<div style='margin-top: 2px; padding: 6px; '><b>Password:</b> "
			+ "<input type='password' style='width: 160px; '/><span style='visibility: hidden; color: red; margin-left: 10px; '><b>Invalid password</b></span></div></div>";
		Util.appendHTML(contents, html);
		
		if(CNFormManager.vista) VistaSupport.attachToTextBox(contents.getElementsByTagName("input")[0]);
		
		var buttonWidth = 80;
		var spacing = 4;
		var b1 = CNDialogManager.createBottomButton(this._passwordDialog, "OK", true);
		b1.style.width = buttonWidth;
		var b2 = CNDialogManager.createBottomButton(this._passwordDialog, "Cancel", false);
		b2.style.width = buttonWidth;
		Event.add(this._passwordDialog, "keydown", this, CNUtil.cancelBubble); // Bypass disabler key block.		
	}
	else
	{
		var errorSpan = this._passwordDialog.getElementsByTagName("span")[CNFormManager.vista ? 0 : 1];
		errorSpan.style.visibility = "hidden"
	}
	var box = this._passwordDialog.getElementsByTagName("input")[0];
	box.value = "";
	Event.add(box, "keydown", this, this._passwordDialog_box_onkeydown);
	Util.findById(this._passwordDialog, "messageText").textContent = text;

	this._showDisabler(true, false, false);

	CNDialogManager.showDialog(this._passwordDialog, [this, "_passwordDialogCallback"], true);
	Event.add(this._passwordDialog, "focusout", this, this._passwordDialog_onfocusout);
	box.focus();
}

proto._passwordDialog_box_onkeydown = function()
{
	if(Event.keyValue(Event.current()) != 13) return;
	var fm = CNFormManager.getBaseFormManager();
	setTimeout(function(){ 
		if(fm._passwordDialogCallback(fm._passwordDialog, false))
		{
			fm._passwordDialog._finishDelegate = null;
			CNDialogManager.hideDialog(fm._passwordDialog, true, true);
	 	}
	}, 0);
}

proto._passwordDialog_onfocusout = function()
{
	var fm = CNFormManager.getBaseFormManager();
	if(!fm._passwordDialog.contains((Event.current() || {}).relatedTarget)) CNUtil.cancelEvent();
}

proto._passwordDialogCallback = function(dialog, cancel)
{
	if(cancel)
	{
	Event.del(dialog, "focusout", this, this._passwordDialog_onfocusout);
		this._hideDisabler();
		this.loadForm("<events><passwordDialog canceled=\"true\"/></events>");
	}
	else
	{
		var box = dialog.getElementsByTagName("input")[0];
		var errorSpan = dialog.getElementsByTagName("span")[CNFormManager.vista ? 0 : 1];
		if(box.value != this._currentPassword)
		{
			errorSpan.style.visibility = "inherit";
			return false;
		}
		else
		{
			Event.del(dialog, "focusout", this, this._passwordDialog_onfocusout);
			this._hideDisabler();
			this.loadForm("<events><passwordDialog canceled=\"false\"/></events>");
		}
	}
	return true;
}

proto._startTimers = function()
{
	if(!this._ideaNode) return;	
	
	var timersNode = Util.xmlSelectSingleNode(this._ideaNode, "timers");
	if(!timersNode) return;
	
	if(timersNode.getAttribute("reset") == "true") 
	{
		this._shutDownTimers();
		//return;
	}
	
	var timerNodes = Util.xmlSelectNodes(timersNode, "timer");
	var count = timerNodes.length;
	for(var i = 0; i < count; i++)
	{
		var timerNode = timerNodes[i];
		
		var attr = timerNode.getAttribute("id");
		if(!attr) continue;
		var id = String(attr);
		
		attr = timerNode.getAttribute("enabled");
		var enabled = attr != "false";

		var timer = this._timers[id];
		if(timer)
		{
			// Remove timer.
			window.clearInterval(timer.timer);
			delete this._timers[id];
		}
		if(enabled) this._setTimer(timerNode, id);		
	}
}

proto._setTimer = function(timerNode, id)
{
	var attr = timerNode.getAttribute("interval");
	if(attr == null)
	{
		CNUtil.assert("No interval specified for timer " + id);
		return false;
	}
	var value = parseInt(attr, 10);
	if(value < 2)
	{
		CNUtil.assert("Interval is < 2 for timer " + id);
		return false;
	}
	value = value * 1000;
	this._timers[id] = {id: id, timer: window.setInterval(this._setSafeInterfalDelegate(id), value), interval: value};
	this._timerIsStoped = false;
	return true;
}

proto._setSafeInterfalDelegate = function(id)
{
	var obj = this;
	return function()
	{
		obj.timer_interval(id);
	}
}

proto.timer_interval = function(id)
{
	if(this._failed || this._halt || this._isPostingBack || this._loading || this._dialogWillBeLoaded) return;
	
	this.postData("<timer id=\"" + id + "\"/>");
}

proto._shutDownTimers = function()
{
	this._suspendTimers();
	this._timers = [];
}

proto._suspendTimers = function()
{	
	this._timerIsStoped = true;
	for(var i in this._timers)
	{
		window.clearInterval(this._timers[i].timer);
	}
}

proto._shutDownHeartBeat = function()
{	
	if(this._heartBeatTO)
	{
		clearTimeout(this._heartBeatTO);
		CNFormManager._trace("Shutdown HeartBeat ...");
		this._heartBeatShutDown = true;
	}	
}

proto._shutDownAutoLock = function()
{	
	if(this._autoLockTO)
	{	
		clearTimeout(this._autoLockTO);
		CNFormManager._trace("Shutdown Autolock ...");
		this._autoLockShutDown = true;
	}	
}

proto._resumeTimers = function()
{
	this._suspendTimers();

	for(var id in this._timers)
	{
		var timer = this._timers[id];
		timer.timer = window.setInterval(this._setSafeInterfalDelegate(timer.id), timer.interval);
	}
}


proto._showMessages = function() {
	this._messagesPending = false;

	if(!this._ideaNode || this._messagesShown) return;

	PopupMenu.hideMenus();
	
	if (this._timers.length > 0  && this._timerIsStoped)
		this._resumeTimers();
	
	var messages = Util.xmlSelectNodes(this._ideaNode, "messages/message");
	if(messages) 
	{
		for(var i = 0; i < messages.length; i++) 
		{
			alert(Util.xmlText(messages[i]));
		}
	}
	
	if(Util.xmlSelectSingleNode(this._ideaNode, "messages/clear"))
	{
		this._deleteMessageBoxes();
	}

	var hasMessageBoxes = false;
	var mboxes = Util.xmlSelectNodes(this._ideaNode, "messages/messagebox");
	if(mboxes)
	{
		var animate = mboxes.length == 1;
		for(var i = 0; i < mboxes.length; i++)
		{
			this._showMessageBoxDialog(mboxes[i], animate);
			hasMessageBoxes = true;
		}
	}

	if(!hasMessageBoxes) {
	    this._hideDisabler();
	}
	
	this._messagesShown = true;
}

proto._createMessageBoxDialog = function()
{
	var dialog;
	if(CNFormManager.vista)
	{
		dialog = CNDialogManager.createVistaDialog("");
		dialog.style.width = 500;
		dialog.style.height = 166;
	}
	else
	{
		dialog = CNDialogManager.createDialog("");
		dialog.style.width = 500;
		dialog.style.height = 116;
	}
	CNDialogManager.getCloseButton(dialog).style.display = "none";

	var contents = CNDialogManager.getContents(dialog);

	var html = "<div style='height: 60px; width: 100%; "
		+ "position: relative; padding: 4px; margin: 5px; top: 6px; padding-left: 58px; "
		+ " overflow: auto; '><div id='messageText'></div>"
		+ "</div>";
	Util.appendHTML(contents, html);
	
	Event.add(dialog, "keydown", this, this._messageBox_onkeydown);
	
	return dialog;
}

proto._messageBox_onkeydown = function()
{
	if(Event.keyValue(Event.current()) == 13)
	{
		if(CNFormManager.vista)
		{
			var buttonJS = Util.dispatchObject();
			buttonJS.element.click();
		}
		else
		{
			var button = Util.findTag(Util.eventTarget(Event.current()), "BUTTON");
			button.click();
		}
	}
	Util.cancelBubble();
}

proto._showMessageBoxDialog = function(node, animate)
{
	this._showDisabler(true, true, false);
	
	var caption = String(node.getAttribute("caption"));
	var text = String(Util.xmlText(node));
	var imgAttr = node.getAttribute("img");
	var buttonAttr = node.getAttribute("buttons");
	var idAttr = node.getAttribute("id");


	var dialog = this._createMessageBoxDialog();
	if(idAttr)
	{
		dialog._id = String(idAttr);
	}

	CNDialogManager.setCaption(dialog, caption);

	var contents = CNDialogManager.getContents(dialog);

	var div = contents.lastChild;
	var messageDiv = div.firstChild;
	messageDiv.textContent = text;
	
	if(imgAttr)
	{
		var img = Util.createElementFromHTML("<img class=dialogIcon>");
		img.src = String(imgAttr);
		contents.appendChild(img)
	}
	
	var focused;
	if(buttonAttr)
	{
		var focusAttr = node.getAttribute("focus");

		var buttonWidth = 80;
		var spacing = 4;

		if(buttonAttr.indexOf("OK") != -1)
		{
			var b = CNDialogManager.createBottomButton(dialog, "OK", true);
			b._result = "OK";
			b.style.width = buttonWidth;
			if(CNFormManager.vista) b.jsObject.set_tabIndex(1); 
			else b.tabIndex = 1;
			if(focusAttr == "OK") focused = b;
		}
		if(buttonAttr.indexOf("Confirm") != -1)
		{
			var b = CNDialogManager.createBottomButton(dialog, "Confirm", true);
			b._result = "Confirm";
			b.style.width = buttonWidth;
			if(CNFormManager.vista) b.jsObject.set_tabIndex(1); 
			else b.tabIndex = 1;
			if(focusAttr == "Confirm") focused = b;
		}
		if(buttonAttr.indexOf("Yes") != -1)
		{
			var b = CNDialogManager.createBottomButton(dialog, "Yes", true);
			b._result = "Yes";
			b.style.width = buttonWidth;
			if(CNFormManager.vista) b.jsObject.set_tabIndex(2); 
			else b.tabIndex = 2;
			if(focusAttr == "Yes") focused = b;
		}
		if(buttonAttr.indexOf("No") != -1)
		{
			var b = CNDialogManager.createBottomButton(dialog, "No", true);
			b._result = "No";
			b.style.width = buttonWidth;
			if(CNFormManager.vista) b.jsObject.set_tabIndex(3); 
			else b.tabIndex = 3;
			if(focusAttr == "No") focused = b;
		}
		if(buttonAttr.indexOf("Cancel") != -1)
		{
			var b = CNDialogManager.createBottomButton(dialog, "Cancel", true);
			b._result = "Cancel";
			b.style.width = buttonWidth;
			if(CNFormManager.vista) b.jsObject.set_tabIndex(4); 
			else b.tabIndex = 4;
			if(focusAttr == "Cancel") focused = b;
		}
	}
	
	this._messageBoxes.push(dialog);
	
	CNDialogManager.showDialog(dialog, [this, "_messageBoxCallback"], true, animate);
	dialog.style.left = dialog.offsetLeft + this._messageBoxOffset + "px";
	dialog.style.top = dialog.offsetTop + this._messageBoxOffset + "px";

	this._messageBoxOffset += 16;
	if(this._messageBoxOffset > 100) this._messageBoxOffset = -16 * 5;

	div.style.height = messageDiv.offsetHeight + 8;
	dialog.style.height = messageDiv.offsetHeight + (CNFormManager.vista ? 116 : 100);
	
	if(dialog.shadow) dialog.shadow.syncPosition();	
	
	if(focused)
	{
		if(CNFormManager.vista) focused.jsObject.focus();
		else focused.focus();
	}
}

proto._messageBoxCallback = function(dialog, cancel)
{
	var posted = false;
	if(dialog._id)
	{
		var b;
		if(CNFormManager.vista) b = Util.findByClassName(Util.eventTarget(Event.current()), "cn_button");
		else b = Util.findTag(Util.eventTarget(Event.current()), "BUTTON");
		if(b) {
			this.postData("<messagebox id=\"" + dialog._id + "\" button=\"" + b._result + "\"/>");
			posted = true;
		}	
	}	

	CNDialogManager.destroyDialog(dialog);

	for(var i = 0; i < this._messageBoxes.length; i++)
	{
		if(this._messageBoxes[i] == dialog)
		{
			this._messageBoxes.splice(i, 1);
			break;
		}
	}

	if(this._messageBoxes.length == 0 && !posted)
	{
		// Remove "modality".
		this._hideDisabler();
	}

	return false; // Prohibit automatical hide.
}

proto._tryToProcessServerErrors = function()
{
	if(!this._ideaNode) return;
	
	var errorsNode = Util.xmlSelectSingleNode(this._ideaNode, "errors");
	if(errorsNode) 
	{
		this._processServerErrors(errorsNode);
		return;
	}
	
	var fatalErrorNode = Util.xmlSelectSingleNode(this._ideaNode, "fatalerror");
	if(fatalErrorNode)
	{
		this._processFatalServerError(fatalErrorNode);
	}
}

proto._setPatient = function(text, color)
{
	var spi;
	if(this.isMain) spi = Util.findById(document, "__si_shortPatientInfo");
	else if(this.isDialog) spi = this._dialogFormHeaderTextCont;	

	if(spi) {
		spi.textContent = text;
		if(color !== null) spi.style.color = color;
	}
}

proto._deleteNavigation = function()
{
	if(!this._navigation) return;
	CNFormManager.destroyJSObject(this._navigation);
	this._navigation = null;
}

proto._createNavigation = function(navigationNode)
{
	var type = navigationNode.getAttribute("type");
	if(!type) type = "CN_navigation";
	else type = "CN_" + type;

	var id = navigationNode.getAttribute("screenItemID");
	if(!id) id = "navigation";
	
	id = "__si_" + id;
	
	var parent = Util.findById(this._globalPlaceholder, id);
	if(!parent)
	{
		Util.assert("no " + id + " element found");
		return;
	}
	
	var clazz = null;
	try
	{
		clazz = Util.resolveGlobal(type);
	}
	catch(ex)
	{
		alert("Error: can't find navigation type " + type)
	}

	this._navigation = new clazz;

	this._navigation.formManager = this;
	this._navigation.createElement(navigationNode, parent);
}

proto._deleteControls = function()
{
	Tooltip.hide(); // FWUI-1025-2

	this._delayedControls = [];
	this._delayedContainers = [];
	this._delayedCollapsableContainers = [];
	
	this._toggledCollapsableContainers = [];

	// Delete menus.
	for(var i in this._menus)
	{
		this._menus[i].removeMenuTree();
	}
	this._menus = [];
	
	this._deleteMessageBoxes();
	
	this._deleteRequiredIcons();

	// Empty tab groups.
	for(var groupID in this._tabbedGroups)
	{
		var group = this._tabbedGroups[groupID];
		group.containers = null;
		Util.removeElement(group.tabTable);
	}
	
	this._tabbedGroups = [];

	this.defaultButton = null;

	if(this._layoutManager) this._layoutManager.reload();
	
	this._deleteControlsInternal(this._formPlaceholder);
	
	if(window.CN_uploadbox) CN_uploadbox.deleteForm(this);
}

proto._deleteMessageBoxes = function()
{
	this._messageBoxOffset = 0;
	for(var i = 0; i < this._messageBoxes.length; i++)
	{
		var mb = this._messageBoxes[i];
		if(mb) CNDialogManager.destroyDialog(mb);
	}
	this._messageBoxes = [];
}

proto._deleteRequiredIcons = function()
{
	for(var i in this._requiredIcons)
	{
		Util.removeElement(this._requiredIcons[i]);
		i++;
	}
	this._requiredIcons = [];
}

proto._deleteControlsInternal = function(element)
{
	if (element == null) return;
	var children = element.children;
	var childCount = children.length;
	
	var toDelete = [];
	for(var i = childCount - 1; i >= 0; i--)
	{
		var l = children[i];

		if(l.isControl) {
			CNFormManager.destroyJSObject(l.jsObject);
			Util.removeElement(l);
		}
		else if(l.isContainer) {
			var jso = l.jsObject;
			if(jso._layoutManager) {
				jso._layoutManager.unload();
				jso._layoutManager = l.containerElement._layoutManager = null;
			}

			this._deleteControlsInternal(l.containerElement);
			
			if(l._tabGroupID) {
				var group = this._tabbedGroups[l._tabGroupID];
				if(group) {
					delete this._tabbedGroups[l._tabGroupID];
					toDelete.push(group.tabTable);
				}
			}

			// Break cross reference.
			l.containerElement = null;
			l.disabler = null;
			l.jsObject = null;
			Util.removeElement(l);
		}
		/*else if(l._isTabbedContainer) { // Note: now cleaned by if(l._tabGroupID) {
			// Remove also tabbed containers (needed to clean-up sub-forms properly).
			CNFormManager.destroyJSObject(l.jsObject);
			l.jsObject = null;
			Util.removeElement(l);
		}*/
	}
	for(var i = 0; i < toDelete.length; i++) Util.removeElement(toDelete[i]);
}

proto._executeXMLForm = function(formNode)
{
	this._firstButtonFocused = false;

	var caption = formNode.getAttribute("caption");
	if(caption) caption = String(caption);
	else caption = "";

	this._setFormCaptionText(caption, formNode.getAttribute("captionImg"));

	if(this._darkHeader)
	{
		var darkHeight = parseInt(formNode.getAttribute("darkHeight"));
		if(!isNaN(darkHeight) && parseInt(darkHeight) > 0) 
		{
			// The surface class is applied after controls exist so login chrome,
			// which has its own full-page artwork, is not covered by the form
			// background layer.

			this._darkHeight = Math.max(1, darkHeight + (CNFormManager.vista ? 5 : 21));
			this._darkHeader.style.height = this._darkHeight + "px";
			this._darkHeader.style.visibility = "inherit";
			if(!CNFormManager.vista && this.isDialog) {
				Util.addClass(this._dialogDiv, "withDarkHeader");
			}
		}
		else
		{
			this._darkHeader.style.visibility = "hidden";
			Util.removeClass(this._darkHeader, "theme_darkFormSurface");
			if(!CNFormManager.vista && this.isDialog) {
				Util.removeClass(this._dialogDiv, "withDarkHeader");
			}
			this._darkHeight = 0;
		}
	}
			
	this._executeXMLControls(formNode.childNodes, this._formPlaceholder, true);

	// New Blue uses the server-provided darkHeight as the visible filter
	// surface.  Do not paint the rest of the form: grids and totals belong to
	// the light form surface.  Login has separate full-page artwork.
	if(this._formPlaceholder && this._darkHeader && this._darkHeight > 0 &&
		Util.hasClass(this._formPlaceholder, "theme_supportsDarkFormSurface"))
	{
		var isLoginForm = this._formPlaceholder.querySelector &&
			this._formPlaceholder.querySelector(".cn_logincontrol_newblue, .cn_logincontrol");
		Util.toggleClass(this._darkHeader, "theme_darkFormSurface", !isLoginForm);
		var formNodeDarkHeight = parseInt(formNode.getAttribute("darkHeight"), 10);
		if(!isLoginForm && !isNaN(formNodeDarkHeight) && formNodeDarkHeight > 0)
		{
			this._darkHeight = formNodeDarkHeight;
			this._darkHeader.style.height = this._darkHeight + "px";
			if(this._formPlaceholder.querySelectorAll)
			{
				var darkControls = this._formPlaceholder.querySelectorAll(
					".cn_label, .cn_label_bold, .cn_checkbox, .cn_radiobox, .radioItem");
				for(var darkIndex = 0; darkIndex < darkControls.length; darkIndex++)
					Util.setDarkHeaderControlClass(darkControls[darkIndex], this);
			}
		}
	}

}

proto._executeXMLControls = function(childNodes, parentElement, topLevel, forceCreation)
{
	var start;
	var childNodesCount = childNodes.length;
	var delay = !forceCreation && this.delayedControlsCreation;
	for(var i = 0; i < childNodesCount; i++)
	{
		var node = childNodes[i];
		if(node.nodeType != 1) continue;
		
		if(node.tagName == "container") 
		{
			// If delayed, we map only top level containers.
			if(delay) this._delayContainerCreation(node, parentElement);
			else this._executeXMLContainer(node, parentElement, true);
		}
		else 
		{
			if(delay) this._delayControlCreation(node, parentElement);
			else this._executeXMLControl(node, parentElement);
		}
	}

	// 28-jul-07: doLayout only for top call.
	if(this._layoutManager && topLevel) this._layoutManager.doLayout();
}

proto._delayControlCreation = function(node, parentElement)
{
	var id = String(node.getAttribute("id"));
	this._delayedControls[id] = [node, parentElement];
	if(this.reportStats) this._changeStat('delayedControls', 1);
}

proto._delayContainerCreation = function(node, parentElement)
{
	var id = String(node.getAttribute("id"));
	this._delayedContainers[id] = [node, parentElement];
	if(node.getAttribute("groupID") || node.getAttribute("collapsable") == "true")
	{
		// Always create tabbed containers, but without children.
		// Created, as we need correct tab buttons order.

		// Also always create collapsable containers, to be sure
		// layout is applied properly to the hidden collapsed containers and the form.
		this._executeXMLContainer(node, parentElement, false);
	}
	
	if(this.reportStats) this._changeStat('delayedContainers', 1);
}

proto._executeXMLContainer = function(node, parentElement, processChildren, isDelayedTopLevel)
{
	var captionAttr = node.getAttribute("caption");
	
	var groupIDAttr = node.getAttribute("groupID");
	var anchorAttr = node.getAttribute("anchor");
	var anchor = LayoutManager.TOPLEFT;
	if(anchorAttr) anchor = parseInt(anchorAttr, 2);
	
	var collapsable = node.getAttribute("collapsable") == "true";
	var scrollable = node.getAttribute("scrollable") != "false";

	var layoutManager = parentElement._layoutManager ? parentElement._layoutManager : this._layoutManager;

	var containerElement;
	var l;
	if(groupIDAttr)
	{
		containerElement = l = this._buildTabContainer(node, parentElement, anchor, groupIDAttr, isDelayedTopLevel, captionAttr, layoutManager);
	}
	else if(captionAttr || collapsable)
	{
		l = this._buildContainerWithHeader(node, parentElement, captionAttr, anchor, collapsable, isDelayedTopLevel, layoutManager);
		containerElement = l.containerElement;
	}
	else
	{
		l = document.createElement("div");
		parentElement.appendChild(l);
		l.jsObject = {};
		containerElement = l;
		if(layoutManager) layoutManager.processNewContainer(l, anchor, node, parentElement, isDelayedTopLevel);
		else CNUtil.setBounds(l, node);
	}

	l.containerElement = containerElement;
	containerElement.isContainerElement = true;
	l.isContainer = true;
	l.style.position = "absolute";
	if(scrollable) containerElement.style.overflow = "auto";
	else containerElement.style.overflow = 'hidden';	
	
	this._setID(l, node);
	
	if(this.reportStats) this._changeStat('containers', 1);

	if(processChildren) this._executeXMLControls(node.childNodes, containerElement, false);
	
	return l;
}

proto._buildTabContainer = function(node, parentElement, anchor, groupIDAttr, isDelayedTopLevel, captionAttr, layoutManager)
{
	l = document.createElement("div");
	l.className = "tabbedContainerContent";
	parentElement.appendChild(l);
	l.jsObject = {};

	var groupID = String(groupIDAttr);
	var tabbedGroup = this._tabbedGroups[groupID];
	if(!tabbedGroup)
	{
		// No tabbed table has been created yet.
		tabbedGroup = {};
		this._tabbedGroups[groupID] = tabbedGroup;
		
		tabbedGroup.tabTable = this._buildTabbedContainer(parentElement);
		tabbedGroup.groupID = groupID;
		tabbedGroup.tabTable.jsObject = {};
		tabbedGroup.containers = [];

		if(layoutManager) layoutManager.processNewTabsTable(tabbedGroup.tabTable, anchor, node, 
													parentElement, isDelayedTopLevel);
		else CNUtil.setBounds(tabbedGroup.tabTable, node, parentElement);
	}

	var tabsTD = tabbedGroup.tabTable.rows[0].cells[0];
	var tabTable = this._buildContainerTab(tabsTD);
	tabTable.id = String(node.getAttribute("id"));
	tabTable._autoPostBack = node.getAttribute("autoPostBack") == "true";
	tabTable._tabGroupID = groupID;

	l._tabGroupID = groupID;
	l.style.display = "none"; // 30-jul-2007
	l.style.visibility = "hidden"; // 2-feb-2008 - required for delayed mode+blue.
	
	tabbedGroup.containers.push(l);
	
	if(layoutManager)
	{
		layoutManager.processNewTabbedContainer(l, anchor, node, parentElement, isDelayedTopLevel);
	}
	else
	{
		CNUtil.setBounds(l, node);

		// Move down as header (with tab buttons) takes it size.
		l.style.top = parseInt(Util.getStyle(l, "top"), 10) + 22;
		l.style.height = parseInt(Util.getStyle(l, "height"), 10) - 22;
	}
	return l;
}

proto._buildContainerWithHeader = function(node, parentElement, captionAttr, anchor, collapsable, isDelayedTopLevel, layoutManager)
{
	var l = CN_panel_buildMiniBoxPanel(parentElement);
	l.jsObject = {};
	
	var containerElement;
	if(CNFormManager.vista)
	{
		containerElement = l.lastChild.firstChild;
	}
	else
	{
		var td = Util.findById(l, "contentTD");
		containerElement = document.createElement("div");
		td.appendChild(containerElement);
		
		containerElement.style.position = "absolute";
		containerElement.style.width = "100%";
		containerElement.style.height = "100%";
	}
	containerElement._isContainerPanel = true;
	if(captionAttr) Util.findById(l, "__panel_text").textContent = String(captionAttr);
	
	l.containerElement = containerElement;

	if(layoutManager)
	{
		layoutManager.processNewContainer(l, anchor, node, parentElement, isDelayedTopLevel);
		
		if(collapsable) this._initCollapsableContainer(l);
	}
	else CNUtil.setBounds(l, node);

	return l;
}

proto._initCollapsableContainer = function(l)
{
	var as = l.jsObject._anchorSide;
	if((as & LayoutManager.TOPBOTTOM) != LayoutManager.TOPBOTTOM)
	{
		var up;
		if((as & LayoutManager.TOP) == LayoutManager.TOP)
		{
			// Collapse up.
			l._collapseDirection = "up";
			up = true;
		}
		else if((as & LayoutManager.BOTTOM) == LayoutManager.BOTTOM)
		{
			// Collapse down.
			l._collapseDirection = "down";
			up = false;
		}
		else
		{
			return;
		}
		
		l._collapsable = true;
		this._addCollapseButton(l, up);
	}
}

proto._addCollapseButton = function(parentElement, up)
{
	if(CNFormManager.vista)
	{
		var l;

		if(CNFormManager.subTheme == "black") l = VistaSupport.createImageSetButton("collapse-set.gif", 20, 20, up ? 0 : 20);
		else l = VistaSupport.createImageButton(up ? "collapse-up.gif" : "collapse-down.gif", 20, 20);

		l.className = "cnCollapseButton";
		parentElement.appendChild(l);
	}
	else
	{
		var pt = Util.findById(parentElement, "__panel_text");
		var td = pt.parentElement;
	
		var l = Util.createElement("div", "cnCollapseButton", null);
		td.appendChild(l);
		var span = Util.createElement("span", null, null);
		l.appendChild(span);
		span.textContent = up ? '5' : '6';
		
		Event.add(l, "mouseenter", this, this._collapseButton_onmouseenter);
		Event.add(l, "mouseleave", this, this._collapseButton_onmouseleave);
	}
	//l.title = "Collapse";		
	Tooltip.set(l, "Collapse");
	Event.add(l, "click", this, this._collapseButton_onclick);	
}

proto._collapseButton_onmouseenter = function()
{
	var l = Util.eventTarget(Event.current());
	l.style.borderWidth = "1px";
	l.style.padding = "0px";
}

proto._collapseButton_onmouseleave = function()
{
	CNFormManager.getActiveFormManager()._unliteCollapseButton(Util.eventTarget(Event.current()));
}

proto._unliteCollapseButton = function(l)
{
	if(CNFormManager.vista) return;
	l.style.borderWidth = "0px";
	l.style.padding = "1px";
}

proto._collapseButton_onclick = function()
{
	CNFormManager.getActiveFormManager().collapseButton_onclick();
}
proto.collapseButton_onclick = function()
{
	var button = CNUtil.findByClassName(Util.eventTarget(Event.current()), "cnCollapseButton");
	
	var l = CNUtil.findElement(button);
	if(!l.isContainer)
	{
		Util.assert("not a container");
		return;
	}
	
	if(l._collapseDirection == "down") 
	{
		this._unliteCollapseButton(button);
	}

	if(this._layoutManager) 
	{
		this._layoutManager.toggleContainer(l);
		
		this._toggledCollapsableContainers[l.id] = l;
	}
}

proto._buildTabbedContainer = function(parentElement)
{
	var table = Util.createElement("table", null, {width: "100%", height: "100%", border: 0, cellpadding: 0, cellspacing: 0});
	table._isTabbedContainer = true;
	table.className = "standardsTabContainer";
	parentElement.appendChild(table);
	table.style.position = "absolute";
	table.style.zIndex = -1;
	
	var tabsTD = table.insertRow().insertCell();
	tabsTD.height = 22;
	
	var contentTD = table.insertRow().insertCell();
	contentTD.height = "100%";
	contentTD.className = "tabbedContainerTD"
	contentTD.textContent = " ";
	
	return table;
}

proto._buildContainerTab = function(parentElement)
{
	var l;
	if(CNFormManager.vista)
	{
		l = Util.createElement("div", "tabbedContainerButton");
		var div = document.createElement("div");
		l.appendChild(div);
		parentElement.appendChild(l);
		Event.add(l, "mouseenter", this, this._tabTable2_onmouseenter);
		Event.add(l, "mouseleave", this, this._tabTable2_onmouseleave);
	}
	else
	{
		// Standards tabs use one semantic table and CSS for the complete
		// surface. Do not recreate the historical three-slice image tabs.
		var table = l = Util.createElement("table", "tabbedContainerButton", {border: 0, cellpadding: 0, cellspacing: 0});
		table._standardsCssTab = true;
		parentElement.appendChild(table);
		table.style.zIndex = 1;
		table.style.display = "inline-table";
		table.style.position = "relative";
		table.style.cursor = "pointer";

		var tr = table.insertRow();
		tr.height = 28;

		var td1 = tr.insertCell();
		td1.className = "tabbedContainerButton_edge";

		var td2 = tr.insertCell();
		td2.className = "tabbedContainerButton_text";
		td2.style.userSelect = "none";

		var td3 = tr.insertCell();
		td3.className = "tabbedContainerButton_edge";
		this._setSelectedTab(table, false);
		Event.add(l, "mouseenter", this, this._tabTable_onmouseenter);
		Event.add(l, "mouseleave", this, this._tabTable_onmouseleave);
		Event.add(l, "click", this, this._standardsTabClick);
	}
	Event.add(l, "mousedown", this, this._tabTable_onmousedown);
	return l;	
}

// Standards browsers should not depend solely on the historical table
// mousedown boundary. The click path is idempotent because the selected flag
// prevents a second selection/postback when mousedown already handled it.
proto._standardsTabClick = function(nativeEvent)
{
	var event = nativeEvent || (typeof Event != "undefined" && Event.current ? Event.current() : null);
	var target = event && event.target;
	var tab = target;
	while(tab && tab.tagName != "TABLE") tab = tab.parentElement || tab.parentNode;
	if(!tab || !tab._standardsCssTab || tab._disabled || tab._selected) return;
	this._selectTab(tab, true);
	if(tab._autoPostBack) this.postData("tabchanged");
}

proto._tabTable2_onmouseenter = function()
{
	var tab = Util.eventTarget(Event.current());
	if(tab._disabled || tab.className.match(/tabbedContainerButton_selected/)) return;
	tab.className = "tabbedContainerButton tabbedContainerButton_hover";
}
proto._tabTable2_onmouseleave = function()
{
	var tab = Util.eventTarget(Event.current());
	if(tab._disabled || tab.className.match(/tabbedContainerButton_selected/)) return;
	tab.className = "tabbedContainerButton";	
}

proto._tabTable_onmouseenter = function()
{
	Util.eventTarget(Event.current()).style.textDecoration = "underline";
}
proto._tabTable_onmouseleave = function()
{
	Util.eventTarget(Event.current()).style.textDecoration = "";
}

proto._tabTable_onmousedown = function()
{
	var formManager = CNFormManager.getActiveFormManager();
	
	//If (this._formDisabled - showErrors dialog) ignore event;
	if (formManager && formManager._formDisabled) return;
	
	var tab;	
	if(CNFormManager.vista)
	{
		tab = CNUtil.findByClassName(Util.eventTarget(Event.current()), "tabbedContainerButton");
		if(tab._disabled) return;
	}
	else
	{
		tab = CNUtil.findTag(Util.eventTarget(Event.current()), "TABLE");
		try{ tab.focus(); } catch(e){}
	}	
	formManager._selectTab(tab, true);
	if(tab._autoPostBack) formManager.postData("tabchanged");
}

proto._selectTab = function(tabTable, userClick)
{
	var groupID = tabTable._tabGroupID;
	var group = this._tabbedGroups[groupID];
	if(!group) Util.assert("no such tab group: " + groupID);

	group.tabTable.style.visibility = "inherit";

	var oldTab = group.selectedTabButtonTable;
	if(oldTab)
	{
		this._setSelectedTab(oldTab, false);
	}

	this._setSelectedTab(tabTable, true);

	var container = this._getContainerForTab(tabTable);
	// Process delayed container before tab is actually selected.
	if(userClick && this.delayedControlsCreation)
	{
		var id = container.id;
		var ar = this._delayedContainers[id];
		if(ar)
		{
			this._initDelayedContainer(id, ar, container, groupID);
			this._processDelayedControlsWithoutData();
		}
	}
		
	group.selectedTabButtonTable = tabTable;
	
	if(userClick)
	{
		group.isDirty = true;

		if(oldTab)
		{
			var oldContainer = this._getContainerForTab(oldTab);
			oldContainer.style.visibility = "hidden";
			oldContainer.style.display = "none";
		}
		container.style.display = "block";
		container.style.visibility = "inherit";
		
	}
	if(this._layoutManager) this._layoutManager.doLayout();
}

proto._getContainerForTab = function(tabTable)
{
	var tabContainerTable = CNUtil.findTag(tabTable.parentNode || tabTable.parentElement, "TABLE");
	var parentElement = tabContainerTable.parentNode || tabContainerTable.parentElement;
	var container = Util.findById(parentElement, tabTable.id);
	return container;
}


proto._setSelectedTab = function(tabTable, selected, force)
{
	if(!force && tabTable._selected == selected) return;
	tabTable._selected = selected;
	
	if(CNFormManager.vista)
	{
		if(selected)
		{
			tabTable.className = "tabbedContainerButton tabbedContainerButton_selected";
			if(tabTable.previousSibling && Util.getStyle(tabTable.previousSibling, "display") != "none")
			{
				tabTable.style.left = "-2px";
				tabTable.style.marginRight = "-4px";
				tabTable.style.paddingLeft = tabTable.style.paddingRight = "2px";
			}
			else
			{
				tabTable.style.marginRight = "-2px";
				tabTable.style.paddingLeft = tabTable.style.paddingRight = "1px";
			}
		}
		else
		{
			tabTable.style.paddingLeft = tabTable.style.paddingRight = "0";
			tabTable.style.left = "0";
			tabTable.style.marginRight = "0";
			tabTable.className = "tabbedContainerButton"; 
		}
	}
	else
	{
		if(tabTable._standardsCssTab)
		{
			tabTable.className = selected ? "tabbedContainerButton tabbedContainerButton_selected" : "tabbedContainerButton";
			tabTable.style.top = "0px";
			tabTable.setAttribute("aria-selected", selected ? "true" : "false");
			return;
		}
		// Standards builds must not depend on the historical sliced tab images.
		// Any legacy table reaching this branch is intentionally unsupported.
		Util.reportUnsupported("formmanager", "legacy image-sliced tabs");
	}
}


proto._executeXMLControl = function(node, parentElement, isDelayedTopLevel, isDelayed)
{
	var controlType = node.tagName;
	
	var type = Util.resolveGlobal("CN_" + controlType);
	if(!type)
	{
		Util.assert("Can't create control: " + controlType);
		return;
	}
	
	var id = String(node.getAttribute("id"));

	var jsl = new type;
	jsl.formManager = this;
	jsl.elementID = id;

	var l = jsl.createElement(node, parentElement);
	if(!l.parentElement) 
	{
		parentElement.appendChild(l);
	}

	l.id = id;
	l.isControl = true;
	l.style.position = "absolute";
		
	var tabIndex = node.getAttribute("tabIndex");
	if(tabIndex !== null) 
	{
		var ti = parseInt(tabIndex, 10);
		if(jsl.set_tabIndex) jsl.set_tabIndex(ti);
		else l.tabIndex = ti;
	}

	var layoutManager = parentElement._layoutManager ? parentElement._layoutManager : this._layoutManager;

	var anchor = -1;
	if(layoutManager)
	{
		var anc = node.getAttribute("anchor");
		if(anc) anchor = parseInt(anc, 2);
		else anchor = 0;

		layoutManager.processNewControl(l, anchor, node, parentElement, isDelayedTopLevel);
	}
	else
	{
		CNUtil.setBounds(l, node);
		if(jsl.layout) jsl.layout();
	}
	
	var menuID = node.getAttribute("menuID");
	if(menuID != null)
	{
		l._menuID = String(menuID);
		Event.add(l, "mousedown", this, this._control_oncontextmenu);
	}

	if(jsl.supportsRequired && node.getAttribute("required") == "true")
	{
		this._putRequiredMark(l, parentElement, anchor);
	}

	if(isDelayed && parentElement.isContainerElement)
	{
		var cont = parentElement;
		while(cont && !cont.isContainer) cont = cont.parentNode;
		if(!cont)
		{
			Util.assert("!cont");
			return;
		}
		
		if(cont.__disabled)
		{
			this._setControlDisabled(l, true);
		}
	}

	if(jsl.onControlCreated) jsl.onControlCreated();
	
	if(this.reportStats) this._changeStat('controls', 1);
	
	return jsl;
}

CNFormManager._wrap_getAttribute = function(name)
{
	return this[name];
}

proto._putRequiredMark = function(l, parentElement, anchor)
{
	var icon = Util.createElementFromHTML("<span class='cnRequiredIconSpan'>");
	parentElement.appendChild(icon);
	icon.textContent = "*";
	icon._isRequiredIcon = true;
	icon._attachedToID = l.id;
	//icon.title = "Required";
	Tooltip.set(icon, "Required");
	icon.style.zIndex = 1000;
	
	this._requiredIcons[l.id] = icon;
	
	var y, x;
	if(l.jsObject._anchorTop) y = l.jsObject._anchorTop;
	else y = parseInt(l.style.top, 10) || l.offsetTop;
	if(l.jsObject._anchorLeft) x = l.jsObject._anchorLeft;
	else x = parseInt(l.style.left, 10) || l.offsetLeft;
	
	var markAnchor = anchor;
	if((anchor & LayoutManager.LEFTRIGHT) == LayoutManager.LEFTRIGHT) 
	{
		markAnchor = LayoutManager.RIGHT;
	}
	if((anchor & LayoutManager.TOPBOTTOM) == LayoutManager.TOPBOTTOM) 
	{
		markAnchor |= LayoutManager.TOP;
	}
	else if((anchor & LayoutManager.BOTTOM) == LayoutManager.BOTTOM) 
	{
		markAnchor |= LayoutManager.BOTTOM;	
	}
	
	y += 2;
	var layoutManager = parentElement._layoutManager ? parentElement._layoutManager : this._layoutManager;

	// Fake node.
	if(layoutManager)
	{
		x += l.jsObject._anchorW + 2;
		var node = {x: x, y: y, width: 3, height: 16, getAttribute: CNFormManager._wrap_getAttribute};
		icon.jsObject = {}
	
		if(anchor != -1) layoutManager.processNewControl(icon, markAnchor, node, parentElement);
		else layoutManager.processNewControl(icon, 0, node, parentElement);
		layoutManager.forceLayout(icon);
	}
	else
	{
		var w = l.offsetWidth || parseInt(l.style.width, 10) || 0;
		x += w + 2;
		icon.style.left = x;
		icon.style.top = y;
	}
}

proto._setID = function(l, node)
{
	var id = node.getAttribute("id");
	if(id) l.id = id;
}

proto._setNavigationDisabled = function(disabled)
{
	this._navigationDisabled = disabled;
	if(this._navigation && this._navigation.set_disabled) this._navigation.set_disabled(this._navigationDisabled);
	if(this._topButtons) this._topButtons.set_disabled(this._navigationDisabled);
	if(this._alertIcons) this._alertIcons.set_disabled(this._navigationDisabled);
	for(var i in this._controls) {
		var jso = this._controls[i];
		if(jso.set_disabled) jso.set_disabled(this._navigationDisabled);
	}
}

proto._setVistaColor1 = function(color)
{
	document.body.style.backgroundColor = color;
}

proto._executeXMLData = function(dataNode)
{
	var dataNode = Util.xmlSelectSingleNode(this._ideaNode, "data");
	if(!dataNode) 
	{
		if(this.delayedControlsCreation) this._processDelayedControlsWithoutData();
		return;
	}

	if(CNFormManager.vista)
	{
		var attr = dataNode.getAttribute("themeColor1");
		if(attr) this._setVistaColor1(String(attr));
	}

	if(this._navigation)
	{
		var attr = dataNode.getAttribute("canLeaveForm");
		if(attr)
		{
			this._setNavigationDisabled(attr == "false");
			this._editMode = (attr == "false");
		}
	}
	
	var attr = dataNode.getAttribute("browserTitle");
	if(attr !== null)
	{
		document.title = this._currentFormCaption + " " + String(attr);
	}

	attr = dataNode.getAttribute("uploadURL");
	if(attr) this._uploadURL = String(attr);

	attr = dataNode.getAttribute("uploadDebug");
	if(attr) this._uploadDebug = attr == "true";
	
	attr = dataNode.getAttribute("errorMode");
	if(attr) this._setErrorMode(attr == "true");

	var childNodes = Util.xmlSelectNodes(dataNode, "*");
	this._executeXMLData2(childNodes, this._formPlaceholder, true);
	
	this._executeControlsData(dataNode);
	
	if(this.delayedControlsCreation) this._processDelayedControlsWithoutData();
	
	attr = dataNode.getAttribute("defaultButton");
	if(attr) 
	{
		var b = Util.findById(this._formPlaceholder, String(attr));
		if(b && b.jsObject) this.defaultButton = b.jsObject;
	}

	this.changeFocus = dataNode.getAttribute("changeFocus") != "false";

	var attr = dataNode.getAttribute("focusedControl");
	if(attr)
	{
		var focusedID = String(attr);
		var el = Util.findById(this._formPlaceholder, focusedID);
		if(el) this._setFocusTO(el);
		else Util.assert('no ' + focusedID + ' control found to focus');
	}

	if(CNFormManager.vista) this._selectPendingContTabs();
}

// Processes out-of-form "_controls" collection.
proto._executeControlsData = function(dataNode) {
	for(var i in this._controls) {
		var jso = this._controls[i];
		var node = Util.xmlSelectSingleNode(dataNode, i + "[@id=\"" + jso.elementID + "\"]");
		if(node && jso.loadData) jso.loadData(node);
	}
}

proto._processDelayedControlsWithoutData = function()
{
	// Create/load controls which had no data.
	var toDelete = [];
	for(var id in this._delayedControls)
	{
		var ar = this._delayedControls[id];
		if(ar.length == 2) 
		{
			// Just exec, as no data supplied.
			// No need for relayout controls against collapsable containers
			// as we expand/collapse them later.
			this._executeXMLControl(ar[0], ar[1], false, true);
			toDelete.push(id);
		}
	}
	for(var i = 0; i < toDelete.length; i++)
	{
		delete this._delayedControls[toDelete[i]];
	}

	var toDelete = [];
	for(var id in this._delayedContainers)
	{
		var ar = this._delayedContainers[id];
		if(ar.length == 2) 
		{
			var groupID = ar[0].getAttribute("groupID");
			
			var cont = this._getElement(ar[1], id);
			this._executeDelayedContainer(id, ar, cont, groupID, null, cont ? cont._collapsable : false);

			toDelete.push(id);
		}
	}
	for(var i = 0; i < toDelete.length; i++)
	{
		delete this._delayedContainers[toDelete[i]];
	}

	// Expand/collapse delayed collapsable containers.
	for(var i = 0; i < this._delayedCollapsableContainers.length; i++)
	{
		var ar = this._delayedCollapsableContainers[i];
		if(ar[1]) this._layoutManager._expandContainer(ar[0]);
		else this._layoutManager._collapseContainer(ar[0])
	}
	this._delayedCollapsableContainers = [];

	if(this._layoutManager) this._layoutManager.doLayout();
}

// Vista only.
proto._selectPendingContTabs = function()
{
	// Select all tabs. Actual tab selection happens here (for loaded xml).
	for(var id in this._tabbedGroups)
	{
		var group = this._tabbedGroups[id];
		if(group.selectedTabButtonTable) 
		{
			group.tabTable.style.visibility = "inherit";
			this._setSelectedTab(group.selectedTabButtonTable, true, true);
		}
		else
		{
			if(this._areAllTabsHidden(group))
			{
				// hide tab container.
				group.tabTable.style.visibility = "hidden";
			}
		}
	}	
}

proto._setErrorMode = function(isErrorMode)
{
	var item = document.getElementById("__si_formRedHeaderBG");
	if(!item) return;
	
	item.style.visibility = isErrorMode ? "inherit" : "hidden";
}

proto._setFocusTO = function(el)
{
	setTimeout(function() { 
		try { 
			var jso = el.jsObject;
			if(jso && jso.focus) {
				jso.focus();
				if(jso.select) jso.select();
			} else {
				el.focus(); 
				if(el.select) el.select(); 
			}
		} catch(ex){} }, 500);
}

proto._executeXMLData2 = function(childNodes, parentElement, topLevel)
{
	var childNodesCount = childNodes.length;
	for(var i = 0; i < childNodesCount; i++)
	{
		var node = childNodes[i];
		if(node.nodeType != 1) continue;

		var tagName = node.tagName;
		if(tagName == "menu")
		{
			this._loadMenu(node);
		}
		else 
		{
			var id = this._getID(node);
			if(id === null) continue;

			if(tagName == "container")
			{
				this._loadContainer(id, node, parentElement, topLevel);
			}
			else
			{				
				this._loadControl(id, node, parentElement, topLevel);
			}
		}
	}
}

proto._loadContainer = function(id, node, parentElement, topLevel)
{
	var container = null;

	if(this.delayedControlsCreation)
	{
		var ar = this._delayedContainers[id];
		if(ar)
		{
			var createNode = ar[0];
			var tabGroupID = createNode.getAttribute("groupID");						
			var collapsable = createNode.getAttribute("collapsable") == "true";

			var visibleAttr = node.getAttribute("visible");
			var isHidden = visibleAttr == "false";
			if(isHidden
			// Visible not specified and we have node data delayed -> add data to delayed array.
			|| visibleAttr == null && (ar.length > 2 || tabGroupID || collapsable) /* don't init non excplicely visible tab containers */
			)
			{
				var delayedData;
				if(ar.length == 2) 
				{
					delayedData = [];
					ar.push(delayedData);
				}
				else delayedData = ar[2];
				
				delayedData.push(node); // Delay data node.
				
				if(tabGroupID)
				{
					// We still should process tabContainer attributes
					// to be sure tab buttons state is valid.
					this._processTabbedContainer(id, node, tabGroupID);
					if(isHidden)
					{
						container = this._getElement(parentElement, id);
						container.style.visibility = "hidden"; // Explicely hide it.
					}
				} 
				else if(collapsable)
				{
					container = this._getElement(parentElement, id);
					this._loadCollapsableCont(node, container);
					if(isHidden)
					{
						container.style.visibility = "hidden"; // Explicely hide it.
					}
				}
				
				return;
			}
			// We gonna create and process this container.
			container = this._initDelayedContainer(id, ar, null, tabGroupID, topLevel, collapsable);
		}
	}
	
	if(container === null)
	{
		container = this._getElement(parentElement, id);
		if(!container) return;
	}
	
	this._loadDataIntoContainer(id, container, node, parentElement);
}

// Also called when tab container set visible by user click.
proto._initDelayedContainer = function(id, ar, container, tabGroupID, topLevel, collapsable)
{
	delete this._delayedContainers[id];
	if(this.reportStats) this._changeStat('delayedContainers', -1);
	
	container = this._executeDelayedContainer(id, ar, container, tabGroupID, topLevel, collapsable);
	
	// Execute delayed data nodes.
	if(ar.length > 2)
	{
		var delayedNodes = ar[2];
		for(var i = 0; i < delayedNodes.length; i++)
		{
			var delayedNode = delayedNodes[i];
			this._loadDataIntoContainer(id, container, delayedNode);
		}
	}
	
	return container;
}

proto._executeDelayedContainer = function(id, ar, container, tabGroupID, topLevel, collapsable)
{
	var parentElement = ar[1];
	if(tabGroupID || collapsable)
	{
		if(container === null) container = this._getElement(parentElement, id);
		if(container === null)
		{
			Util.assert("!container for id: " + id);
			return;
		}
		// This is tabbed or visible collapsable container, container element/tabs were created already.
		// Just process children.
		this._executeXMLControls(ar[0].childNodes, container.containerElement, false, true);
	}
	else
	{
		// Create container.
		container = this._executeXMLContainer(ar[0], parentElement, true, topLevel);
	}
	return container;
}

proto._loadDataIntoContainer = function(id, container, node)
{
	var formNode = Util.xmlSelectSingleNode(node, "form");
	if(formNode != null) this._loadContainerSubForm(container, formNode, node);

	var oldVisibility = Util.getStyle(container, "visibility");
	this._setCommonProperties(container, node, true);
	
	if(this._layoutManager && oldVisibility == "hidden" 
	&& oldVisibility != Util.getStyle(container, "visibility"))
	{
		this._layoutManager.forceContainerLayout(container);
	}
	
	if(node.getAttribute("scrollTop") == "true")
	{
		container.containerElement.scrollTop = container.containerElement.scrollLeft = 0;
	}
	
	var tgID = container._tabGroupID;
	if(tgID) 
	{
		this._processTabbedContainer(id, node, tgID);
	} else {
		var attr = node.getAttribute("caption");
		if(attr) {
			this._setContainerCaption(container, String(attr));
		}
	}
	
	this._setContainerDisabled(container, container.__disabled ? true : false);

	this._executeXMLData2(node.childNodes, container.containerElement, false);

	if(container._collapsable) this._loadCollapsableCont(node, container);
}
proto._setContainerCaption = function(container, caption) {
	if(CNFormManager.vista) {
		container.children[1].textContent = caption;
	} else {
		container.rows[0].cells[1].firstChild.textContent = caption;
	}		
}

proto._loadContainerSubForm = function(container, formNode, contNode) {
	var contElement = container.containerElement;
	this._subFromDeleteControls(container, contElement);

	var widthAttr = formNode.getAttribute("width");
	var heightAttr = formNode.getAttribute("height");
	if(widthAttr != null && heightAttr != null) {
		var jso = container.jsObject;
		jso._layoutManager = contElement._layoutManager = new LayoutManager(contElement, parseInt(widthAttr, 10), parseInt(heightAttr, 10));
		//container.jsObject._layoutManager._inSubForm = true; // Debug var.
		jso.isSubForm = true;
	}
	
	this._executeXMLControls(formNode.childNodes, contElement, false, false);
}

proto._subFromDeleteControls = function(container, contElement) {
	this._deleteControlsInternal(contElement);

	if(this._layoutManager) this._layoutManager.cleanupContainer(container);
	var jso = container.jsObject;

	if(jso._layoutManager) {
		jso._layoutManager.unload();
		jso._layoutManager = contElement._layoutManager = null;
	}

	// Remove all delayed controls and containers for this container.
	var toDelete = [];
	for(var id in this._delayedControls) {
		var ar = this._delayedControls[id];
		if(ar.length > 1 && ar[1] == contElement) {
			toDelete.push(id);
		}
	}
	for(var i = 0; i < toDelete.length; i++) {
		delete this._delayedControls[toDelete[i]];
	}
	var toDelete = [];
	for(var id in this._delayedContainers) {
		var ar = this._delayedContainers[id];
		if(ar.length > 1 && ar[1] == contElement) {
			toDelete.push(id);
		}
	}
	for(var i = 0; i < toDelete.length; i++) {
		delete this._delayedContainers[toDelete[i]];
	}
	
	// Remove required icons.
	var toDelete = [];
	var spans = container.getElementsByTagName("span");
	var count = spans.length;
	for(var i = 0; i < count; i++) {
		var span = spans[i];
		if(span._isRequiredIcon) {
			toDelete.push(span);
		}
	}
	for(var i = 0; i < toDelete.length; i++) {
		var icon = toDelete[i];
		delete this._requiredIcons[icon._attachedToID];
		Util.removeElement(icon);
	}
}

proto._loadCollapsableCont = function(node, container)
{
	var collapsedAttr = node.getAttribute("collapsed");
	if(collapsedAttr && this._layoutManager)
	{
		if(this.delayedControlsCreation) 
		{
			this._delayedCollapsableContainers.push([container, collapsedAttr == "false"]);
		}
		else
		{
			if(collapsedAttr == "false") this._layoutManager._expandContainer(container);
			else this._layoutManager._collapseContainer(container)
		}
	}
}

proto._loadControl = function(id, node, parentElement, topLevel)
{
	var l = null, jso;
	if(this.delayedControlsCreation)
	{
		var ar = this._delayedControls[id];
		if(ar)
		{
			var visibleAttr = node.getAttribute("visible");
			if(visibleAttr == "false" 
			// Visible not specified and we have node data delayed -> add data to delayed array.
			|| visibleAttr == null && ar.length > 2) 
			{
				var delayedData;
				if(ar.length == 2) 
				{
					delayedData = [];
					ar.push(delayedData);
				}
				else delayedData = ar[2];
				
				delayedData.push(node); // Delay data node.
				
				// Don't process invisibles.
				return;
			}

			delete this._delayedControls[id];
			if(this.reportStats) this._changeStat('delayedControls', -1);
			jso = this._executeXMLControl(ar[0], ar[1], topLevel, true);

			if(!jso) 
			{
				Util.assert("!jso");
				return;
			}
			l = jso.element;
			
			// Execute delayed data nodes.
			if(ar.length > 2)
			{
				var delayedNodes = ar[2];
				for(var i = 0; i < delayedNodes.length; i++)
				{
					var delayedNode = delayedNodes[i];
					this._loadDataIntoControl(jso, delayedNode, parentElement);
				}
			}
		}
	}
	
	if(l === null)
	{
		l = this._getElement(parentElement, id);
		if(!l) return;

		jso = l.jsObject;
		if(!jso)
		{
			Util.assert("Not a js control: " + l.id);
			return;
		}
	}
	
	this._loadDataIntoControl(jso, node, parentElement);
}

proto._loadDataIntoControl = function(jso, node, parentElement)
{
	if(jso.supportsRequired) this._processRuntimeRequired(jso.element, jso, node, parentElement);
	this._setCommonProperties(jso.element, node);
	if(jso.loadData) jso.loadData(node);
}

proto._processTabbedContainer = function(id, node, tgID)
{
	var group = this._tabbedGroups[tgID];
	if(!group) return;
	
	var tabButtonsTD = group.tabTable.rows[0].cells[0];
	var tab = Util.findById(tabButtonsTD, id);

	var captionAttr = node.getAttribute("caption");
	var tabDisabledAttr = node.getAttribute("headerEnabled");
	if(!tab)
	{
		CNFormManager._trace("Tabbed container button not found: " + id + " in group " + tgID);
		return;
	}
		
	if(CNFormManager.vista)
	{
		if(captionAttr) tab.firstChild.textContent = String(captionAttr);

		if(tabDisabledAttr) 
		{
			var disabled = tab._disabled = tabDisabledAttr == "false";
			tab.className = disabled ? "tabbedContainerButton tabbedContainerButton_disabled" : "tabbedContainerButton";
		}
	}
	else
	{
		var tabRow = tab.rows && tab.rows[0];
		var captionCell = tabRow && tabRow.cells && tabRow.cells[1];
		if(captionAttr && captionCell) captionCell.textContent = String(captionAttr);
		if(tabDisabledAttr) tab.disabled = tabDisabledAttr == "false";
	}

	var tabVisibleAttr = node.getAttribute("headerVisible");
	if(tab && tabVisibleAttr)
	{
		group.reselect = true;
		if(tabVisibleAttr == "true")
		{
			tab.style.display = "inline";
			tab.style.visibility = "inherit";
		}
		else
		{
			tab.style.display = "none";
			tab.style.visibility = "hidden";
		}
	}

	var visibleAttr = node.getAttribute("visible");

	if(CNFormManager.vista) 
	{
		if(visibleAttr == "true")
		{
			var oldTab = group.selectedTabButtonTable;
			if(oldTab) this._setSelectedTab(oldTab, false);
			group.selectedTabButtonTable = tab;
		}
		else if(visibleAttr == "false")
		{
			if(group.selectedTabButtonTable == tab) group.selectedTabButtonTable = null;
		}
	}
	else
	{
		if(visibleAttr == "true")
		{
			this._selectTab(tab);
		}
		else if(visibleAttr == "false" && this._areAllTabsHidden(group))
		{
			// hide tab container.
			group.tabTable.style.visibility = "hidden";
		}
	}
}

proto._areAllTabsHidden = function(group)
{
	for(var i = 0; i < group.containers.length; i++)
	{
		if(Util.getStyle(group.containers[i], "visibility") != 'hidden')
		{
			 return false;
		}
	}	
	return true;
}

proto._processRuntimeRequired = function(l, jso, node, parentElement)
{
	var attr = node.getAttribute("required");
	if(attr)
	{
		var icon = this._requiredIcons[l.id];
		if(attr == "true")
		{
			if(!icon) this._putRequiredMark(l, parentElement, jso._anchor);
			else icon.style.display = 'inline';
		}
		else
		{
			if(icon) icon.style.display = 'none';
		}
	}
}

proto._loadMenu = function(node)
{
	var topPlaceholder = document.body;

	var id = String(node.getAttribute("id")); //this._getMenuID(String(node.getAttribute("id")));
	var oldMenu = this._menus[id]; //topPlaceholder.children[id];
	if(oldMenu) {
		oldMenu.removeMenuTree();
	}

	if(node.childNodes.length > 0)
	{
		var menu = new PopupMenu(topPlaceholder, "beforeend");
		//menu.element.id = id;
		this._fillMenu(node, menu, id);
		this._menus[id] = menu;
	}
	else
	{
		delete this._menus[id];
	}
}

proto._fillMenu = function(node, menu, menuID)
{
	var itemNodes = Util.xmlSelectNodes(node, "items/*");
	for(var i = 0; i < itemNodes.length; i++)
	{
		var itemNode = itemNodes[i];
		
		if(itemNode.tagName == "menuitem")
		{
			var text = String(itemNode.getAttribute("text"));
			var img = null;
			var imgAttr = itemNode.getAttribute("img");	 
			if(imgAttr) img = String(imgAttr);
			
			var isEnabled = itemNode.getAttribute("enabled") != "false";
			var isVisible = itemNode.getAttribute("visible") != "false";
	
			var l;
			if(itemNode.hasChildNodes())
			{
				var submenuResult = menu.createSubmenuEx(text, img);
				this._fillMenu(itemNode, submenuResult.submenu, menuID)
				l = submenuResult.item;
			}
			else
			{
				l = menu.createItem(text, img);
				l.onmenuclick = this._menuItem_onmenuclick;
				l._id = String(itemNode.getAttribute("id"));
				l._parentMenuID = menuID;
				if(img && !isEnabled)
				{

				}
				
				var attr = itemNode.getAttribute("wrap");
				if(attr != null)
				{
					l.children[1].style.whiteSpace = attr == "true" ? "normal" : "nowrap";
					l.children[1].style.marginLeft = "30px";
				}
			}
			l.disabled = !isEnabled;
			if(!isVisible) l.style.display = "none";
		}
		else if(itemNode.tagName == "separator")
		{
			menu.createHR();
		}
	}
}

proto._getID = function(node)
{
	var id = String(node.getAttribute("id"));
	if(!id)
	{
		alert("Error: id required but not specified in data section.");
		return null;
	}
	return id;
}

proto._getElement = function(parentElement, id)
{
	if (parentElement == null || parentElement.children == null) return;	
	
	var l = Util.findById(parentElement, id);
	if(!l) 
	{
		//alert("Can't get element " + id + " to bind data to.");
		return null;
	}

	if(l.length) 
	{
		alert("Id conflict: " + id);
		//Util.showCaller(this, this._getElement.caller)
		return null;
	}
	
	return l;
}

proto._setCommonProperties = function(l, node, setDisplay)
{
	// Always set common properties.
	var visible = node.getAttribute("visible");
	
	var requiredIcon = this._requiredIcons[l.id];
	if(visible !== null) 
	{
		if(visible == "true")
		{
			l.style.visibility = "inherit";
			if(requiredIcon) requiredIcon.style.visibility = "inherit";
			if(setDisplay) l.style.display = 'block';
		}
		else
		{
			if(document.activeElement != null && l.contains(document.activeElement))
			{
				try
				{ 
					document.activeElement.blur(); 
				}
				catch(ex){}
			}
			l.style.visibility = "hidden";
			if(requiredIcon) requiredIcon.style.visibility = "hidden";
			if(setDisplay) l.style.display = 'none';
		}
	}

	var disabled = false;
	var attr = node.getAttribute("enabled");
	if(attr !== null) 
	{
		disabled = attr == "false";
		// Always store disabled in __disabled as we manipulate with disabled
		// and can reset just loaded disabled state.
		l.__disabled = disabled;

		if(l.isControl)
		{
			if(l.jsObject.set_disabled) l.jsObject.set_disabled(disabled);
			else l.disabled = disabled;
			
			if(requiredIcon) requiredIcon.style.visibility = disabled ? "hidden" : "inherit";
		}
	}
	else if(l.__disabled === null) l.__disabled = false;
}

proto._setNonInteractive = function(val)
{
	this.nonInteractive = val;
	if(this.nonInteractive)
	{
		this._showDisabler(true, true, true);
	}
	else
	{
		this._hideDisabler();
	}
}

proto._setControlsDisabledState = function(disabled, accountModalFocus, doNotSetCursor)
{
	if(!CNFormManager.themeLoaded || this._formDisabled == disabled || !this._formPlaceholder) return;

	if(disabled)
	{
		// Try to store active element.
		var l = document.activeElement;
		if(l != null && this._formPlaceholder.contains(l)) this._storedActiveElement = l;
		else this._storedActiveElement = null;
	}

	this._formDisabled = disabled;

	this._setControlsDisabledStateInternal(this._formPlaceholder, disabled, accountModalFocus);
	
	if(!disabled)
	{
		// Try to restore active element.
		if(this._storedActiveElement && this._storedActiveElement.parentElement
		&& Util.getStyle(this._storedActiveElement, "display") != 'none'
		&& Util.getStyle(this._storedActiveElement, "visibility") != 'hidden'
		&& !this._storedActiveElement.disabled
		&& !this._storedActiveElement.readOnly)  
		{
			var l = this._storedActiveElement;
			try
			{
				if(l.focus) l.focus(); 
				if(l.select) l.select();
			}
			catch(e){} // We can't detect is l actually visible now. Just eat exception.
			this._storedActiveElement = null;
		}
	}
}

proto._setControlsDisabledStateInternal = function(parentElement, disabled, accountModalFocus)
{
	var children = parentElement.children;
	var childCount = children.length;
	
	for(var i = 0; i < childCount; i++)
	{
		var l = children[i];
		if(l.isContainer)
		{
			this._setContainerDisabled(l, disabled, accountModalFocus);
			continue;
		}
		
		this._setControlDisabled(l, disabled, accountModalFocus);
	}
}

proto._setControlDisabled = function(l, disabled, accountModalFocus)
{
	if(!l.isControl || l.jsObject.doNotDisable
	|| accountModalFocus && l == this._modalFocusedElement) return;
	
	var value = this._getControlDisabledState(l, disabled);
	
	if(l.jsObject.set_disabled) l.jsObject.set_disabled(value);
	else l.disabled = value;
	
	var requiredIcon = this._requiredIcons[l.id];
	if(requiredIcon) 
	{
		requiredIcon.style.visibility = value || Util.getStyle(l, "visibility") == 'hidden' ? "hidden" : "inherit";
	}
}

proto._setContainerDisabled = function(container, disabled, accountModalFocus)
{
	if(container.__disabled) disabled = true;
	this._setControlsDisabledStateInternal(container.containerElement, disabled, accountModalFocus);
}

proto._getControlDisabledState = function(l, disabled)
{
	var value;
	if(disabled) value = disabled;
	else value = l.__disabled ? true : false;
	return value;
}

proto._validateLoading = function()
{
	if(this._formPlaceholder == null) return;
	var children = this._formPlaceholder.children;
	this._validateLoadingInternal(children);
}

proto._validateLoadingInternal = function(children)
{
	var childCount = children.length;
	
	for(var i = 0; i < childCount; i++)
	{
		var l = children[i];
		if(l.isContainer)
		{
			this._validateLoadingInternal(l.containerElement.children);
		}
		else if(l.isControl)
		{
			if(l.jsObject.validateLoading) l.jsObject.validateLoading();
		}
	}
}

proto.fail = function(str)
{
	alert("ERROR: " + str);
	this._failed = true;
	this._halt = true;
}

proto._createDisabler = function()
{
	return Util.createElementFromHTML('<div style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; background: white; z-index: 10000; opacity: 0.5; ">');
}

proto._handleLoadFailed = function()
{
	this._setControlsDisabledState(true);

	// Disable everything.
	if(this._halt) this._showDisabler(true, false);
}

// If invalidIDAr != null, all invalid ids will be collected there
proto._checkAreElementsValid = function(parent, invalidControlsAr) 
{
	var children = parent ? parent.children : this._formPlaceholder.children;
	var childCount = children.length;
	for(var i = 0; i < childCount; i++)
	{
		var l = children[i];
		if(l.isContainer) 
		{
			this._checkAreElementsValid(l.containerElement, invalidControlsAr);
			continue;
		}
		
		if(!l.isControl) continue;
		
		var jso = l.jsObject;

		// NOTE: checks even hidden controls.
		if(jso.isValid && !jso.isValid())
		{
			// Deny postback.
			// Reset current navigation node.
			//if(this._navigation) this._navigation.selectFormNode(this._currentFormID);
			//if(!l.jsObject.doNotShowErrorMessage) 
			//{
			//	if(l.jsObject.validationString) alert(l.jsObject.validationString);
			//	else alert(l.id + " is invalid.");
			//}

			//return false;
			
			invalidControlsAr.push(jso);
		}
	}
//	return true;
}

proto.postData = function(postbackElement)
{
	if(this._isPostingBack || this._waitingForButtonPostback) return false;
	this._isPostingBack = true;
	
	var isAutoLockPostBack = this._postbackElement == "<autoLock/>";
	if (!this._heartBeatShutDown && !isAutoLockPostBack && !this._autoLockPostData)	this._resetHeartBeat();	
	//if (!this._heartBeatPostData)
		//this._resetHeartBeat();	
	
	var validate = true;
	if(postbackElement && postbackElement.jsObject && postbackElement.jsObject.validator === false) 
	{
		validate = false;
	}
	
	var invalidControlsAr = [];
	this._checkAreElementsValid(null, invalidControlsAr);

	if(validate && invalidControlsAr.length > 0)
	{
		this._flashInvalidControl(invalidControlsAr[0]); // Report only first control.
		this._isPostingBack = false;
		this._postbackElement = null;
		return false;
	}
	else if(!validate)
	{
		this._resetInvalidControls();
		if(invalidControlsAr.length > 0) this._invalidControlsAr = invalidControlsAr;
	}

	this._setNonInteractive(true);

	this._postbackElement = postbackElement;
	//setTimeout("CNFormManager.getActiveFormManager()._continuePostData()", 0);
	
	var fm = this;
	
	if (typeof(this._postbackElement) == "string" && this._postbackElement.indexOf("scannedImage") !== -1)
	{
		this._continuePostData();
		return true;
	}

	setTimeout(function(){ fm._continuePostData()}, 0);
	
	return true;
}

proto._flashInvalidControl = function(jso) {
	if(this._navigation) this._navigation.selectFormNode(this._currentFormID);
	if(!jso.doNotShowErrorMessage) 
	{
		if(jso.validationString) alert(jso.validationString);
		else alert(jso.element.id + " is invalid.");
	}
}

proto._resetInvalidControls = function(parent)
{
	var children = parent ? parent.children : this._formPlaceholder.children;
	var childCount = children.length;
	for(var i = 0; i < childCount; i++)
	{
		var l = children[i];
		if(l.isContainer) 
		{
			this._resetInvalidControls(l.containerElement);
			continue;
		}
		
		if(!l.isControl) continue;
		var jso = l.jsObject;

		// NOTE: checks even hidden controls.
		if(jso.resetValue && jso.isValid && !jso.isValid())
		{
			jso.resetValue();
		}
	}
}


proto.lightPostData = function(xmlStr) {
	if(this._isPostingBack || this._waitingForButtonPostback) return false;
	this._isPostingBack = true;
	
	var xmldoc = Util.parseXML(xmlStr);
	var pi = xmldoc.createProcessingInstruction("xml", "version=\"1.0\" encoding=\"" + this.xmlEncoding + "\"");
	xmldoc.insertBefore(pi, xmldoc.documentElement);
	var ev = xmldoc.createElement("events");
	ev.setAttribute("lightweight", "true");
	ev.appendChild(xmldoc.documentElement);
	xmldoc.appendChild(ev);

	this.loadForm(xmldoc, "_finishPostData"); // Called immediately.
}

proto._continuePostData = function()
{
	var xmldoc = Util.createXMLDocument();
	var pi = xmldoc.createProcessingInstruction("xml", "version=\"1.0\" encoding=\"" + this.xmlEncoding + "\"");
	xmldoc.appendChild(pi);

	var dataNode = xmldoc.createElement("events");
	xmldoc.appendChild(dataNode);
	
	var isTabChange = this._postbackElement == "tabchanged";

	var autoPostBackGroup = this._storeTabChanges(xmldoc, dataNode, isTabChange);
	
	var stringPostback = typeof(this._postbackElement) == "string";
	
	this.initiateUpload = !stringPostback && this._postbackElement.jsObject.initiateUpload;

	//Hearbeat called postbak?
	var isEmptyHeartBeat = this._postbackElement == "<empty/>";
	var isAutoLockPostBack = this._postbackElement == "<autoLock/>";

	if (!isEmptyHeartBeat)
	{	
		this._postElementsData(xmldoc, dataNode, this._formPlaceholder.children);
		this._postInvalidControls(xmldoc, dataNode);
	}

	for(var id in this._toggledCollapsableContainers)
	{
		var cont = this._toggledCollapsableContainers[id];
		var contNode = xmldoc.createElement("collapsablecontainer");
		contNode.setAttribute("id", cont.id);
		contNode.setAttribute("collapsed", cont._collapsed ? "true" : "false");
		dataNode.appendChild(contNode);		
	}
	this._toggledCollapsableContainers = [];

	if(this._navigation) {
		var node = this._navigation.storeData(xmldoc);
		if(node) dataNode.appendChild(node);
	}

	if(stringPostback)
	{
		if(this._postbackElement.length > 0 && this._postbackElement.charAt(0) == '<' && !isEmptyHeartBeat)
		{
			// Raw xml.
			var tempdoc = Util.parseXML(this._postbackElement);
			dataNode.appendChild(tempdoc.documentElement);
		}
		// Predefined events.
		else if(this._postbackElement == "topbutton")
		{
			var tag = "topbutton";
			if(this._topButtonAction) tag = this._topButtonAction;
			var buttonNode = xmldoc.createElement(tag);
			if(this._topButtonID) buttonNode.setAttribute("id", this._topButtonID);
			dataNode.appendChild(buttonNode);
			this._topButtonID = null;
			this._topButtonAction = null;
		}
		else if(this._postbackElement == "menu")
		{
			var menuClickNode = xmldoc.createElement("menuclick");
			menuClickNode.setAttribute("menuID", this._currentMenuID);
			menuClickNode.setAttribute("menuItemID", this._currentMenuItemID);
			menuClickNode.setAttribute("controlID", this._currentContextID);
			dataNode.appendChild(menuClickNode);
		}
		else if(this._postbackElement == "tabchanged")
		{
			if(autoPostBackGroup) this._storeTabChange(xmldoc, dataNode, autoPostBackGroup);
		}
	}
	// Control events.
	else if(this._postbackElement && (!this._navigation || this._postbackElement != this._navigation.element)) 
	{
		this._storeData(this._postbackElement, xmldoc, dataNode);

		if(this.initiateUpload)
		{
			// Ask uploadbox to upload data.
			this._postXmlDoc = xmldoc;
			CN_uploadbox.handleUpload(this, xmldoc, "_uploadCallback");	// Called via callback.
			return;
		}
	}
	
	//If postbak was called by heartbeat  -> don't reset heartBeatCounter		
	if(isEmptyHeartBeat)
	{
		var tempdoc = Util.parseXML(this._postbackElement);
		dataNode.appendChild(tempdoc.documentElement);
	}
	// Postback was called by other controls not heartbeat -> reset heartBeatCounter
	else
	{
	
		var heartBeatNode = xmldoc.createElement("empty");
		if(isAutoLockPostBack)
		{			
			heartBeatNode.setAttribute("autolock", "true");
		}
		heartBeatNode.setAttribute("reset", "true");
		dataNode.appendChild(heartBeatNode);
	}
	
	if(this.isAttach) {
		dataNode.setAttribute("forAttachedForm", this._attachAsFormToTag);
		this._parentFormManager.postData(Util.xmlString(dataNode));
	} else {
		this.loadForm(xmldoc, "_finishPostData"); // Called immediately.
	}
}
proto._uploadCallback = function()
{
	var xmldoc = this._postXmlDoc;
	this._postXmlDoc = null;
	this.loadForm(xmldoc, "_finishPostData");
}

proto._postInvalidControls = function(xmldoc, dataNode) {
	if(this._invalidControlsAr != null && this._invalidControlsAr.length > 0) {
		for(var i = 0; i < this._invalidControlsAr.length; i++) {
			var node = xmldoc.createElement("invalidControl");
			node.setAttribute("id", this._invalidControlsAr[i].element.id);
			dataNode.appendChild(node);
		}
	}

	this._invalidControlsAr = null;
}

proto._storeTabChanges = function(xmldoc, dataNode, skipAutoPostBack)
{
	var autoPostBackGroup = null;
	// Handle tabbed containers.
	for(var groupID in this._tabbedGroups)
	{
		var group = this._tabbedGroups[groupID];
		var table =  group.selectedTabButtonTable;
		if(group.isDirty && table)
		{
			if(table._autoPostBack && skipAutoPostBack) 
			{
				autoPostBackGroup = group;
				continue;
			}
			this._storeTabChange(xmldoc, dataNode, group)
		}
	}
	return autoPostBackGroup;
}

proto._storeTabChange = function(xmldoc, dataNode, group)
{
	var table =  group.selectedTabButtonTable;
	var node = xmldoc.createElement("containertabselected");
	node.setAttribute("groupID", String(group.groupID));
	node.setAttribute("containerID", String(table.id));
	dataNode.appendChild(node);
	group.isDirty = false;
}

proto._postElementsData = function(xmldoc, dataNode, children)
{
	var childCount = children.length;
	for(var i = 0; i < childCount; i++)
	{
		var l = children[i];
		if(l.isContainer)
		{
			this._postElementsData(xmldoc, dataNode, l.containerElement.children);
			continue;
		}

		if(!l.isControl || l == this._postbackElement) continue;
		this._storeData(l, xmldoc, dataNode);
	}
}

proto._finishPostData = function()
{
	if(!this._isPostingBack) return;
	
	if(!this._failed && !this._dialogPending && !this._messagesPending) 
	{
		this._setNonInteractive(false);
		//if(this.isDialog) alert("set interactive " + this._currentFormID)
	}

	this._isPostingBack = false;
	this._postbackElement = null;

	if(this._pendingContextMenuData)
	{
		Tooltip.hide();
		this._showContextMenu(this._pendingContextMenuData);
		this._pendingContextMenuData = null;
		this.contextMenuPending = false;
	}
	
	this._finishAttachedPostData();
}
proto._finishAttachedPostData = function() {
	for(var tag in this._attachedFormManagers) this._attachedFormManagers[tag]._finishPostData();
}

proto._storeData = function(l, xmldoc, dataNode)
{
	var jsObject = l.jsObject;
	if(!jsObject.storeData) return;
	
	var node = jsObject.storeData(xmldoc);
	if(node)
	{
		var id = l.id;
		if(id) 
		{
			// XMLElement.
			if(node.nodeType == 1 && !node.getAttribute("id")) node.setAttribute("id", id);
			// XMLDocumentFragment.
			else if(node.nodeType == 11)
			{
				var nodes = Util.xmlSelectNodes(node, "*");
				var nodeCount = nodes.length;
				for(var i = 0; i < nodeCount; i++) nodes[i].setAttribute("id", id);
			}
		}
		dataNode.appendChild(node);			
	}
}

proto._testForXMLDialog = function()
{
	if(Util.xmlSelectSingleNode(this._ideaNode, "dialog")) this._dialogPending = true;
}

proto._processServerError = function(errorNode)
{
	this._shutDownTimers();	
	
	if(this.isDialog) 
	{
		this._setDialogResult(false);
		this._closeDialog(true);
	}

	var result = true;
	var attr = errorNode.getAttribute("id");
	if(attr)
	{
		var id = String(attr);
		switch(id)
		{
			case "0":
				result = false;
				// NOTE: reset load state.
				this._endProgress();
				this._setNonInteractive(false);
				this._loading = false;
				this._isPostingBack = false;
				break;
	
			case "1":
			case "2":
				this._failed = true;
				this._halt = true;
				break;
				
			case "3":
				this._failed = true;
				break;				
		}
	}
	if(Util.xmlText(errorNode)) alert(Util.xmlText(errorNode));
	return result;
}

proto._processServerErrors = function(errorsNode)
{
	this._shutDownTimers();	
	
	var title = String(errorsNode.getAttribute("title"));
	var errors = Util.xmlSelectNodes(errorsNode, "error");

	if(CNFormManager.themeLoaded)
	{
		this._setControlsDisabledState(true);
		this._navigationDisabled = true;
		this._showErrorsDialog(title, errors, [this, "_finishProcessServerErrors"]);
	}
	else
	{
		Util.assert("got <errors>, but no theme loaded.");
	}

	return false;
}

proto._processFatalServerError = function(errorNode)
{
	this._shutDownTimers();	
		
	var title = String(errorNode.getAttribute("title"));
	var msg = "";
	var buildInfo = "";
	var stackTrace = "";
	
	if(errorNode.getAttribute("suspend") == "true")
	{
		this._failed = true;
		this._halt = true;
	}

	var msgNode = Util.xmlSelectSingleNode(errorNode, "msg");
	if(msgNode) msg = Util.xmlText(msgNode);
	var buildInfoNode = Util.xmlSelectSingleNode(errorNode, "buildinfo");
	if(buildInfoNode) buildInfo = Util.xmlText(buildInfoNode);
	var stackTraceNode = Util.xmlSelectSingleNode(errorNode, "stacktrace");
	if(stackTraceNode) stackTrace = Util.xmlText(stackTraceNode);
	
	if(CNFormManager.themeLoaded)
	{
		this._setControlsDisabledState(true);
		var fm = CNFormManager.getBaseFormManager();
		
		fm._navigationDisabled = true;
		fm._showFatalErrorDialog(title, msg, buildInfo, stackTrace, this._halt ? null : [this, "_finishProcessServerErrors"]);
	}
	else
	{
		Util.assert("got <fatalerror>, but no theme loaded.\n\n" + title + 
				"\n" + msgNode + "\n" + buildInfo + "\n" + stackTrace);
	}

	return false;
}

proto._finishProcessServerErrors = function()
{
    this._navigationDisabled = false;
	this._setControlsDisabledState(false);
	this._loading = false;
	this._isPostingBack = false;
}

proto._executeXMLDialog = function()
{
	var node = this._dialogNode;
	if(!node) return;
	this._dialogNode = null;
	
	var urlAttr = node.getAttribute("url");
	if(!urlAttr) return;
	
	this._suspendTimers();

	var form = null;
	var idAttr = node.getAttribute("id");
	if(idAttr) form = "<events><navigation form=\"" + String(idAttr) + "\"/></events>"
	
	this._idAttr = idAttr;
	this._toDialogOpenState();

	var resizable = node.getAttribute("resizable") == "true";
	var dialogFM = new CNFormManager(false, CNFormManager.MODE_DIALOG, this);
	dialogFM.delayedControlsCreation = this.delayedControlsCreation;
	dialogFM._initFromNode(node, resizable);

	dialogFM.debug = this.debug;
	CNFormManager.formManagers.push(dialogFM);
	
	dialogFM.sourceUrl = String(urlAttr);
	dialogFM.loadForm(form);
}

proto._initFromNode = function(node, resizable)
{
	var width = 800;
	var widthAttr = node.getAttribute("width");
	if(widthAttr) width = parseInt(widthAttr, 10);

	var height = 600;
	var heightAttr = node.getAttribute("height");
	if(heightAttr) height = parseInt(heightAttr, 10);

	var createBG = node.getAttribute("background") != "false";
	var formHeader = node.getAttribute("formHeader") == "true";
	this._createDialogWindow(createBG, width, height, resizable, formHeader);
	if(formHeader) {
		this._cloneAlertsToDialog();
	}

	var closeButton = node.getAttribute("closeButton") != "false";
	if(createBG)
	{
		if(resizable)
		{
			this._resizable = resizable;
			this._layoutManager = new LayoutManager(this._formPlaceholder, width, height);
		}
		else if(!CNFormManager.vista)
		{
			var but = Util.findById(this._dialogDiv, "__dialogMaxButton");	
			but.style.display = "none";
		}
	}
		
	if(!closeButton)	
	{
		var but;
		if(CNFormManager.vista) but = CNDialogManager.getCloseButton(this._dialogDiv);
		else but = Util.findById(this._dialogDiv, "__dialogCloseButton");

		if(but) 
		{
			if(createBG && resizable)
			{
				but._disabled = true;

			}
			else
			{
				but.style.display = 'none'; // Hide close for non-resizible dialogs.
			}
		}
	}
}
proto._cloneAlertsToDialog = function() {
	this._alertIcons = CNFormManager.getBaseFormManager()._alertIcons.cloneToDialogHeader(this._formHeader);
	this._alertIcons.element.style.display = "block";
	this._alertIcons.formManager = this;
}

proto._createDialogWindow = function(createBG, dialogWidth, dialogHeight, resizable, formHeader)
{
	if(createBG)
	{
		if(CNFormManager.vista)
		{
			var formHeaderHeight = formHeader ? 34 : 0;
			this._dialogDiv = CNDialogManager.createVistaDialog(null, resizable);
			this._dialogDiv.style.width = dialogWidth + 32 + "px";
			this._dialogDiv.style.height = dialogHeight + 51 + formHeaderHeight + "px";
			this._formPlaceholder = CNDialogManager.getContents(this._dialogDiv);
			
			var header = $('__si_darkHeader').cloneNode(true);
			header.id = "";
			header.style.left = 0;
			header.style.top = 0;
			header.style.width = "100%";
			header.style.display = "block";
			header.style.visibility = "hidden";
			
			this._formPlaceholder.appendChild(header);
			this._darkHeader = header;			
			
			if(formHeader) {
				this._createVistaFormHeader();
			}
			
			CNDialogManager.getBottom(this._dialogDiv).style.display = "none";
			CNDialogManager.showDialog(this._dialogDiv, [this, "_dialog_closeButton_onclick"], 
				true, false, [this, "_dialog_toggleMaximize"]);
			this._dialogDiv.style.visibility = "hidden";
		}
		else
		{
			var formHeaderHeight = formHeader ? 34 : 0;
			// + 11 = dialog caption img.
			this._dialogDiv = this._createAndShowDialogDiv(dialogWidth + 30, dialogHeight + 63 + 11 + formHeaderHeight, resizable, formHeader);
			this._formPlaceholder = Util.findById(this._dialogDiv, "formPlaceholder1");
		}
		this._dialogDiv._hasBackground = true;
	}
	else
	{
		this._formPlaceholder = this._dialogDiv = this._createAndShowSimpleDialogDiv(dialogWidth, dialogHeight);
		this._formPlaceholder.style.zIndex = top.__ontopZ++;
	}
		
	this._dialogNotShownYet = true;
	Event.add(this._formPlaceholder, "keypress", this, this._formPlaceholder_onkeypress); // Default button.
	Event.add(this._dialogDiv, "focusout", this, this._dialog_formPlaceholder_onfocusout);	

	this._dialogDiv.appendChild(this._disabler);
}
proto._createVistaFormHeader = function() {
	var div = document.createElement("div");
	div.className = "dialogFormHeader";

	var div2 = document.createElement("div");
	div2.className = "dialogFormHeader2";
	div.appendChild(div2);

	var div3 = this._dialogFormHeaderTextCont = document.createElement("div");
	div3.className = "dialogFormHeader3";
	div2.appendChild(div3);

	var contOuter = this._formPlaceholder.parentNode.parentNode;
	contOuter.style.paddingTop = "60px";
	contOuter.insertBefore(div, contOuter.lastChild);

	this._formHeader = div2;
}

proto._dialog_toggleMaximize = function(dialog, maximize)
{
	this._layoutManager.doLayout();
	this._layoutManager.setHandleResizes(maximize); // Don't process resizes in initial state.
}

proto._toDialogOpenState = function()
{
	this._setControlsDisabledState(true);
	this._showDisabler(false, true);
}

proto._closeDialog = function(doNotSendEvent)
{
	this.destroyDialog();
	this._parentFormManager.proceedChildDialogClosed(this, doNotSendEvent);
}

proto.destroyDialog = function()
{
	if(!this._dialogDiv) Util.assert("destroyDialog() - !this._dialogDiv");
	Event.del(this._formPlaceholder, "keypress", this, this._formPlaceholder_onkeypress);
	Event.del(this._dialogDiv, "focusout", this, this._dialog_formPlaceholder_onfocusout);
	CNDialogManager.hidePopup(this._dialogDiv, null, true);


	this.destroy();


	if(this._dialogDiv._hasBackground) CNDialogManager.destroyDialog(this._dialogDiv);
	else this._dialogDiv.parentNode.removeChild(this._dialogDiv);
	this._dialogDiv = null;
}

proto.proceedChildDialogClosed = function(childFM, doNotSendEvent)
{
	this._hideDisabler();

	CNFormManager.removeFromCollection(childFM);

	if(!doNotSendEvent) {

		var result = childFM._dialogReturnValue;
		if(result.gotError)
		{
			// Dialog got error.
			this._processServerError();
			return;
		}

		var idAttr = this._idAttr;
		this._idAttr = null;

		var byServer = String(result.closedByServer).toLowerCase();
		var idStr = "";
		if(idAttr) idStr = 'id="' + String(idAttr) + '" ';

		this._dialogPending = false;

		this._formDisabled = false;

		this._setControlsDisabledState(true);
		this.loadForm('<events><dialogWasClosed ' + idStr + 'byServer="' + byServer + '"/></events>', "_finishXMLDialog");
	} else {
		this._finishXMLDialog();
	}
}

proto._finishXMLDialog = function()
{
	var self = this;
//	setTimeout(function() {
//		if(!self._formPlaceholder) return; // FM was already deleted (dialog force closed).
		self._setControlsDisabledState(false);
		self._finishPostData(); // Call this for "parent" dialog too.
		self._resumeTimers();		
//	}, 50); // Timeout for vml round buttons, which doesn't redraw itself if set_disable is called too fast after screen item reshow (e.g. after lock).
}

proto._createAndShowSimpleDialogDiv = function(width, height)
{
	var formPlaceholder1 = Util.createElementFromHTML('<div style="position: absolute; overflow: auto; ">');
	formPlaceholder1.style.height = height;
	formPlaceholder1.style.width = width;
	document.body.appendChild(formPlaceholder1);

	formPlaceholder1.style.top = (document.body.clientHeight - formPlaceholder1.offsetHeight) / 2;
	formPlaceholder1.style.left = (document.body.clientWidth - formPlaceholder1.offsetWidth) / 2;
	return formPlaceholder1;
}

proto._createAndShowDialogDiv = function(width, height, resizable, formHeader)
{
	var div = Util.createElementFromHTML("<div class=cnFormDialogDiv style='border: 1px solid #8F929E; visibility: hidden; '>");
	document.body.appendChild(div);

	div.style.position = "absolute";
	div.style.width = width;
	div.style.height = height;
	div.style.zIndex = top.__ontopZ++;
	div.style.top = (document.body.clientHeight - div.offsetHeight) / 2;
	div.style.left = (document.body.clientWidth - div.offsetWidth) / 2;

	var table = Util.createElementFromHTML('<table width=100% height=100% border=0 cellpadding=0 cellspacing=0>');
	div.appendChild(table);
	var tbody = document.createElement('tbody');
	table.appendChild(tbody);
	var tr = Util.createElementFromHTML('<tr>');
	tbody.appendChild(tr);
	var td = Util.createElementFromHTML('<td height=42>');
	tr.appendChild(td);

	var table2 = Util.createElementFromHTML('<table width=100% border=0 cellpadding=3 cellspacing=0>');
	td.appendChild(table2);
	var tbody2 = document.createElement('tbody');
	table2.appendChild(tbody2);
	var tr2 = document.createElement('tr');
	tbody2.appendChild(tr2);
	var td2 = Util.createElementFromHTML('<td width=2>');
	tr2.appendChild(td2);
	var captionTD = Util.createElementFromHTML('<td height=42 style="cursor: default; ">');
	tr2.appendChild(captionTD);
	var formCaption1 = Util.createElementFromHTML('<h1 id=formCaption1>');
	captionTD.appendChild(formCaption1);
	var td3 = Util.createElementFromHTML("<td width=16 style='position: relative; '>");
	tr2.appendChild(td3);

	var dialogCloseButton = Util.createElementFromHTML("<span id=__dialogCloseButton class='dialogTopButton dialogCloseButton'>");
	td3.appendChild(dialogCloseButton);
	var span = Util.createElementFromHTML('<span>');
	dialogCloseButton.appendChild(span);
	span.textContent = 'r';
	
	var maxButton = Util.createElementFromHTML("<span id=__dialogMaxButton class='dialogTopButton dialogMaxButton'>");
	td3.appendChild(maxButton);
	var span = Util.createElementFromHTML('<span>');
	maxButton.appendChild(span);
	span.textContent = '1';

	var tr12 = document.createElement('tr');
	tbody.appendChild(tr12);
	var td3 = Util.createElementFromHTML('<td valign=top height=100% style="padding: 0px; padding-top: 0px; ">');
	tr12.appendChild(td3);
	
	var table3 = Util.createElementFromHTML('<table width=100% height=100% border=0 cellpadding=0 cellspacing=0>');
	td3.appendChild(table3);
	var tbody3 = document.createElement('tbody');
	table3.appendChild(tbody3);
	var tr31 = document.createElement('tr');
	tbody3.appendChild(tr31);
	var td4 = Util.createElementFromHTML('<td width=12>');
	tr31.appendChild(td4);
	var _img1 = Util.createElementFromHTML('<img width=12 height=12>');
	td4.appendChild(_img1);
	var _td1 = Util.createElementFromHTML('<td width=100%>');
	tr31.appendChild(_td1);
	var td5 = Util.createElementFromHTML('<td width=12>');
	tr31.appendChild(td5);
	var _img2 = Util.createElementFromHTML('<img width=12 height=12>');
	td5.appendChild(_img2);
	var tr32 = document.createElement('tr');
	tbody3.appendChild(tr32);
	var _td2 = document.createElement('td');
	tr32.appendChild(_td2);
	var td6 = Util.createElementFromHTML('<td bgcolor=white valign=top height=100% width=100% style="position: relative; ">');
	tr32.appendChild(td6);
	
	if(formHeader) {
		var blueFormHeader = document.getElementById("__si_formHeaderBG");
		var formHeaderBG = blueFormHeader.cloneNode(true);
		formHeaderBG.style.width = "100%";
		formHeaderBG.style.position = "static";
		formHeaderBG.id = "";
		formHeaderBG.style.display = "block";

		var formHeaderDiv = this._formHeader = document.createElement("div");
		formHeaderDiv.className = "dialogFormHeaderDiv";
		formHeaderDiv.appendChild(formHeaderBG);
		
		var textCont = this._dialogFormHeaderTextCont = document.createElement("div");
		textCont.className = "dialogFormHeaderTextCont";
		formHeaderDiv.appendChild(textCont);
	
		td6.appendChild(formHeaderDiv);
	}
	
	var darkHeader1 = Util.createElementFromHTML('<div style="position: absolute; left: -9px; top: -11px; padding-right: 0px;\
		right: -9px; height: 200px; visibility: inherit; padding-bottom: 2px; ">');
	td6.appendChild(darkHeader1);
	this._darkHeader = darkHeader1;
	
	var FORM_HEADER_HEIGHT = 22;
	if(formHeader) darkHeader1.style.top = -9 + FORM_HEADER_HEIGHT + "px"; // 22 - blue dialog formHeader extra height.
	
	var table4 = Util.createElementFromHTML('<table width=100% height=100% border="0" cellpadding="0" cellspacing="0">');
	darkHeader1.appendChild(table4);
	var tbody4 = document.createElement('tbody');
	table4.appendChild(tbody4);

	var tr41 = document.createElement('tr');
	tbody4.appendChild(tr41);
	var td411 = Util.createElementFromHTML('<td>');
	tr41.appendChild(td411);
	var _img3 = Util.createElementFromHTML('<img width="12" height="14">');
	td411.appendChild(_img3);
	var _td3 = Util.createElementFromHTML('<td width="100%" height="14">');
	tr41.appendChild(_td3);
	var td412 = Util.createElementFromHTML('<td>');
	tr41.appendChild(td412);
	var _img4 = Util.createElementFromHTML('<img width="12" height="14">');
	td412.appendChild(_img4);
	
	var tr42 = document.createElement('tr');
	tbody4.appendChild(tr42);
	var _td4 = Util.createElementFromHTML('<td width="12" height="100%">');
	tr42.appendChild(_td4);
	var _td5 = Util.createElementFromHTML('<td width="100%" height="100%">');
	tr42.appendChild(_td5);
	var _td6 = Util.createElementFromHTML('<td width="12" height="100%">');
	tr42.appendChild(_td6);
	
	var tr43 = document.createElement('tr');
	tbody4.appendChild(tr43);
	var td431 = document.createElement('td');
	tr43.appendChild(td431);
	var _img5 = Util.createElementFromHTML('<img width="12" height="13">');
	td431.appendChild(_img5);
	var _td7 = Util.createElementFromHTML('<td width="100%" height="13">');
	tr43.appendChild(_td7);
	var td432 = document.createElement('td');
	tr43.appendChild(td432);
	var _img6 = Util.createElementFromHTML('<img width="12" height="13">');
	td432.appendChild(_img6);

	var formPlaceholder1 = Util.createElementFromHTML('<div id="formPlaceholder1" style="position: relative; overflow: auto; ">');
	td6.className = "dialogContentTD";
	td6.appendChild(formPlaceholder1);	
	//formPlaceholder1.style.height = height - 70;
	//formPlaceholder1.style.width = width - 26;
	formPlaceholder1.style.height = "100%";
	if(formHeader) {
		formPlaceholder1.style.top = formPlaceholder1.offsetTop +  FORM_HEADER_HEIGHT - 4 + "px";
		td6.style.paddingBottom = "12px";
	}
	//formPlaceholder1.style.width = width - 26;
	var _td8 = document.createElement('td');
	tr32.appendChild(_td8);
	
	var tr33 = document.createElement('tr');
	tbody3.appendChild(tr33);
	var td331 = document.createElement('td');
	tr33.appendChild(td331);
	var _img7 = Util.createElementFromHTML('<img width=12 height=14>');
	td331.appendChild(_img7);
	var _td9 = document.createElement('td');
	tr33.appendChild(_td9);
	var td332 = document.createElement('td');
	tr33.appendChild(td332);
	var _img8 = Util.createElementFromHTML('<img width=12 height=14>');
	td332.appendChild(_img8);

	new Shadow(div, false, false);

	_img1.src = CNFormManager.themeImagesPath + "bg-1-2r_01.gif";
	_img2.src = CNFormManager.themeImagesPath + "bg-1-2r_03.gif";
	_img3.src = CNFormManager.themeImagesPath + "darkHeader-2_01.gif";
	_img4.src = CNFormManager.themeImagesPath + "darkHeader-2_03.gif";
	_img5.src = CNFormManager.themeImagesPath + "darkHeader-2_07.gif";
	_img6.src = CNFormManager.themeImagesPath + "darkHeader-2_09.gif";
	_img7.src = CNFormManager.themeImagesPath + "bg-1-2r_07.gif";
	_img8.src = CNFormManager.themeImagesPath + "bg-1-2r_09.gif";
	_td1.style.background = "url(" +CNFormManager.themeImagesPath + "bg-1-2r_02.gif)";
	_td2.style.background = "url(" +CNFormManager.themeImagesPath + "bg-1-2r_04.gif)";
	_td3.style.background = "url(" +CNFormManager.themeImagesPath + "darkHeader-2_02.gif)";
	_td4.style.background = "url(" +CNFormManager.themeImagesPath + "darkHeader-2_04.gif)";
	_td5.style.background = "url(" +CNFormManager.themeImagesPath + "darkHeader-2_05.gif)";
	_td6.style.background = "url(" +CNFormManager.themeImagesPath + "darkHeader-2_06.gif)";
	_td7.style.background = "url(" +CNFormManager.themeImagesPath + "darkHeader-2_08.gif)";
	_td8.style.background = "url(" +CNFormManager.themeImagesPath + "bg-1-2r_06.gif)";
	_td9.style.background = "url(" +CNFormManager.themeImagesPath + "bg-1-2r_08.gif)";
	
	var closeButton = dialogCloseButton;
	Event.add(closeButton, "mouseenter", this, this._dialog_closeButton_onmouseenter);
	Event.add(closeButton, "mouseleave", this, this._dialog_closeButton_onmouseleave);
	Event.add(closeButton, "click", this, this._dialog_closeButton_onclick);
	
	Event.add(maxButton, "mouseenter", this, this._dialog_closeButton_onmouseenter);
	Event.add(maxButton, "mouseleave", this, this._dialog_closeButton_onmouseleave);
	Event.add(maxButton, "click", this, this._dialog_maxButton_onclick);

	Event.add(captionTD, "mousedown", this, this._dialog_captionTD_onmousedown)
	Event.add(captionTD, "select", this, CNUtil.cancelEvent);
	Event.add(captionTD, "dragstart", this, CNUtil.cancelEvent);
	
	return div;
}

proto._dialog_closeButton_onmouseenter = function()
{
	var l = Util.eventTarget(Event.current());
	if(l._disabled) return;
	l.className += " dialogTopButtonHover";
}
proto._dialog_closeButton_onmouseleave = function()
{
	var l = Util.eventTarget(Event.current());
	if(l._disabled) return;
	Util.removeClass(l, "dialogTopButtonHover");
}
proto._dialog_closeButton_onclick = function()
{
	var l = Util.findByClassName(Util.eventTarget(Event.current()), "dialogTopButton");
	if(l._disabled) return;
	CNFormManager.getActiveFormManager().dialog_closeButton_onclick();
}
proto.dialog_closeButton_onclick = function()
{
	this._setDialogResult(false);
	this._closeDialog();
} 
proto._dialog_maxButton_onclick = function()
{
	var fm = CNFormManager.getActiveFormManager();
	fm.toggleDialogMaximize();
}

proto.toggleDialogMaximize = function()
{
	this._dialogDiv._maximized ? this.restoreDialog() : this.maximizeDialog();
	this._dialog_toggleMaximize(this._dialogDiv, this._dialogDiv._maximized);
}
proto.maximizeDialog = function()
{
	var maxButton = Util.findById(this._dialogDiv, "__dialogMaxButton");
	maxButton.firstChild.textContent = "2";
	var dialog = this._dialogDiv;
	dialog._maximized = true;
	dialog._storedBounds = {x: dialog.offsetLeft, y: dialog.offsetTop, w: dialog.offsetWidth, h: dialog.offsetHeight };
	dialog.style.width = "100%";
	dialog.style.height = "100%";
	dialog.style.left = 0;
	dialog.style.top = 0;
	
	if(dialog.shadow) dialog.shadow.hide();
}
proto.restoreDialog = function()
{
	var maxButton = Util.findById(this._dialogDiv, "__dialogMaxButton");
	maxButton.firstChild.textContent = "1";
	var dialog = this._dialogDiv;
	dialog._maximized = false;
	var b = dialog._storedBounds;
	dialog.style.left = b.x;
	dialog.style.top = b.y;
	dialog.style.width = b.w;
	dialog.style.height = b.h;

	if(dialog.shadow) dialog.shadow.show();
}

proto._dialog_captionTD_onmousedown = function()
{
	var td = CNUtil.findTag(Util.eventTarget(Event.current()), "TD");
	if(!td) return;
	var cnDialogDiv = CNUtil.findByClassName(td, "cnFormDialogDiv");
	if(cnDialogDiv._maximized) return;
	
	var formManager = CNFormManager.getActiveFormManager();

	var captureTarget = document;
	Event.add(captureTarget, "mousemove", formManager, formManager._dialog_captionTD_onmousemove);
	Event.add(captureTarget, "mouseup", formManager, formManager._dialog_captionTD_onmouseup);
	
	CNFormManager._draggedDialog = {dialog: cnDialogDiv, td: td, captureTarget: captureTarget, formManager: formManager};
	
	CNFormManager._startX = cnDialogDiv.offsetLeft - (Event.current() || {}).screenX;
	CNFormManager._startY = cnDialogDiv.offsetTop - (Event.current() || {}).screenY;
}

proto._dialog_captionTD_onmousemove = function()
{
	var cnDialogDiv = CNFormManager._draggedDialog.dialog;
	
	cnDialogDiv.style.left = (CNFormManager._startX + (Event.current() || {}).screenX) + "px";
	cnDialogDiv.style.top = (CNFormManager._startY + (Event.current() || {}).screenY) + "px";
	
	cnDialogDiv.shadow.syncPosition();
}

proto._dialog_captionTD_onmouseup = function()
{
	if(!CNFormManager._draggedDialog) return;
	var td = CNFormManager._draggedDialog.td;
	this._dialog_captionTD_onlosecapture();
}

proto._dialog_captionTD_onlosecapture = function()
{
	if(!CNFormManager._draggedDialog) return;
	var drag = CNFormManager._draggedDialog;
	var td = drag.td;
	var formManager = drag.formManager;

	Event.del(drag.captureTarget, "mousemove", formManager, formManager._dialog_captionTD_onmousemove);
	Event.del(drag.captureTarget, "mouseup", formManager, formManager._dialog_captionTD_onmouseup);

	var cnDialogDiv = CNFormManager._draggedDialog.dialog;
	
	var left = parseInt(Util.getStyle(cnDialogDiv, "left"), 10) || 0;
	var top = parseInt(Util.getStyle(cnDialogDiv, "top"), 10) || 0;
	if(left < 0) cnDialogDiv.style.left = "0px";
	if(top < 0) cnDialogDiv.style.top = "0px";	


	CNFormManager._draggedDialog = null;
}

proto._showDisabler = function(doBlock, hidden, waitCursor)
{
	if(!this._disabler) return;
	if(this.isDialog) {
		if(!this._dialogDiv) return;
		this._disabler.style.zIndex = Util.getStyle(this._dialogDiv, "zIndex") + 1;
	}
	this._disabler.style.cursor = waitCursor ? "wait" : "default";
	this._disabler.style.visibility = "inherit";
	this._disabler.style.display = "block";
	
	var baseFM = CNFormManager.getBaseFormManager();
	if(doBlock)
	{
		// Block everything.
		if(!baseFM._doBlock) Event.add(document.body, "keydown", baseFM, CNUtil.cancelEvent);
	}
	else
	{
		if(baseFM._doBlock) Event.del(document.body, "keydown", baseFM, CNUtil.cancelEvent);
	}
	baseFM._doBlock = doBlock;
}

proto._hideDisabler = function()
{
	var baseFM = CNFormManager.getBaseFormManager();
	if(baseFM._doBlock) 
	{
		Event.del(document.body, "keydown", baseFM, CNUtil.cancelEvent);
		baseFM._doBlock = false;
	}
	this._disabler.style.cursor = "default";
	this._disabler.style.visibility = "hidden";
	this._disabler.style.display = "none";
}

proto.modalFocusElement = function(l)
{
	if(this._modalFocusedElement)
	{
		Util.assert("this._modalFocusedElement != null");
		return;
	}
	this._modalFocusedElement = l;
	this._modalFocused = true;
	
	this._setControlsDisabledState(true, true, true);
}


proto.modalBlurElement = function(probe)
{
	var l = this._modalFocusedElement;
	if(!l)
	{
		Util.assert("this._modalFocusedElement == null");
		return;
	}
	if(l != probe) Util.assert("l != probe");
	
	this._setControlsDisabledState(false, true, true);
	this._modalFocused = false;
	this._modalFocusedElement = null;
}

proto.topButtonClick = function(id, action, alwaysEnabled)
{
	if(this.isNavigationDisabled() && !alwaysEnabled || this._loading) return;
	
	var currentEvent = Event.current();
	if(currentEvent) CNUtil.cancelEvent(currentEvent);
	
	this._topButtonID = id;
	this._topButtonAction = action;
	this.postData("topbutton");
	this._suspendTimers();
}

/*
*/

proto._filterAttribute = function(str)
{
	return str.replace("\"", "&quot;").replace(">", "&gt;").replace("<", "&lt;");
}


proto._getStoredLocationsXML = function()
{
	var xml = CNFormManager._storedLocationsXML;
	try { if(window.localStorage) xml = window.localStorage.getItem("storedLocations") || xml; } catch(ignore) {}
	if(!xml) return null;
	try { return Util.xmlSelectSingleNode(Util.parseXML(xml), "storedLocations"); } catch(ignore) { return null; }
}

proto._getStoredLocationsXMLString = function()
{
	var rootEl = this._getStoredLocationsXML();
	if(rootEl) 
	{
		var xml = Util.xmlString(rootEl);
		return xml;
	}
	return "";
}

proto._finishHideDisabler = function()
{
	this._hideDisabler();
}



proto.logoutButtonClick = function(alwaysEnabled)
{
	if(this.isNavigationDisabled() && !alwaysEnabled || this._loading) return;
	this._logout(true);
}

proto._loadAboutDialog = function()
{
	if(this._aboutDialogLoaded) return;
	
	var node = Util.xmlSelectSingleNode(this._ideaNode, "aboutDialog");
	if(!node) return;
	
	if(node)
	{
		this._aboutDialogLoaded = true;
		this._aboutDialogTitle = String(node.getAttribute("title"));
		var mainHTMLNode = Util.xmlSelectSingleNode(node, "mainHTML");
		if(mainHTMLNode) this._aboutDialogMainHTML = String(Util.xmlText(mainHTMLNode));

		var secondHTMLNode = Util.xmlSelectSingleNode(node, "secondHTML");
		if(secondHTMLNode) this._aboutDialogSecondHTML = String(Util.xmlText(secondHTMLNode));
	}
}

proto.aboutButtonClick = function(alwaysEnabled)
{
	if(this.isNavigationDisabled() && !alwaysEnabled || !this._aboutDialogLoaded) return;
	if(!this._aboutDialog) this._aboutDialog = this._buildAboutDialog();
	CNDialogManager.showDialog(this._aboutDialog, null, true);	
}

proto._buildAboutDialog = function()
{
	var l;
	if(CNFormManager.vista)
	{
		l = CNDialogManager.createVistaDialog(this._aboutDialogTitle);
		l.style.width = "530px";
		l.style.height = "330px";
	}
	else
	{
		l = CNDialogManager.createDialog(this._aboutDialogTitle);
		l.className = l.className + " dialog_about";
		l.style.width = "500px";
		l.style.height = "300px";
	}	
	

	var contents = CNDialogManager.getContents(l);
	var siteLogo1 = Util.createElementFromHTML("<img class='aboutDialogSiteLogo1'>");
	contents.appendChild(siteLogo1);
	siteLogo1.src = CNFormManager.strings['loginLogo'];

//	var siteLogo2 = Util.createElementFromHTML("<img class='aboutDialogSiteLogo2'>");
//	contents.appendChild(siteLogo2);
//	siteLogo2.src = CNFormManager.neutralImagesPath + "logo-part-2.gif";

	var b2 = CNDialogManager.createBottomButton(l, "OK", true);
	b2.style.width = 80;
	
	var div1 = Util.createElementFromHTML("<div class='aboutDialogDiv1'>");
	contents.appendChild(div1);
	if(this._aboutDialogMainHTML) div1.innerHTML = this._aboutDialogMainHTML;

	if(this._aboutDialogSecondHTML)
	{
		var sep = Util.createElementFromHTML("<div class='aboutDialogSeparator'>");
		contents.appendChild(sep);
		
		var div2 = Util.createElementFromHTML("<div class='aboutDialogDiv2'>");
		contents.appendChild(div2);
		div2.innerHTML = this._aboutDialogSecondHTML;
	}
	else
	{
		l.style.height = CNFormManager.vista ? "250px" : "226px";
	}

	return l;
}

proto._document_oncontextmenu = function()
{
	var l = Util.eventTarget(Event.current());
	if(l) CNUtil.cancelEvent();
}

proto._parseQueryString = function() {
	var qs = location.search;
	if(qs.indexOf("?") == 0) qs = qs.substr(1);
	var ar = qs.split("&");
	for(var i = 0; i < ar.length; i++) {
		var pair = ar[i].split("=");
		if(!pair[0]) continue;
		this._queryString[String(pair[0])] = pair[1] ? pair[1] : "";
	}
}

// NOTE: only strings allowed as xml argument or else jscript leaks memory.
proto._loadFormTO = function(xml)
{
	var obj = this;
	setTimeout(function(){ obj._processLoadFormTO(xml); }, 0);
}

proto._processLoadFormTO = function(xml)
{
	this.loadForm(xml);
}

proto._showYesNoDialog = function(title, message, delegate)
{
	if(!this._yesNoDialog) 
	{
		if(CNFormManager.vista)
		{
			this._yesNoDialog = CNDialogManager.createVistaDialog(title);	
			this._yesNoDialog.style.width = 430;
			this._yesNoDialog.style.height = 140;
		}
		else
		{
			this._yesNoDialog = CNDialogManager.createDialog(title);
			this._yesNoDialog.style.width = 400;
			this._yesNoDialog.style.height = 100;
		}
		var contents = CNDialogManager.getContents(this._yesNoDialog);
		var img = Util.createElementFromHTML("<img width=48 height=48 class='dialogIcon'>");
		contents.appendChild(img)
		img.src = CNFormManager.neutralImagesPath + "yesno-question-1.gif";
		var html = "<div style='padding: 8px; margin-left: 48px; '>" + message + "</div>";
		Util.appendHTML(contents, html);
		var buttonWidth = 80;
		var b2 = CNDialogManager.createBottomButton(this._yesNoDialog, "Yes", true);
		b2.style.width = buttonWidth;
		var b1 = CNDialogManager.createBottomButton(this._yesNoDialog, "No", false);
		b1.style.width = buttonWidth;
	}
	CNDialogManager.showDialog(this._yesNoDialog, delegate, true);
}

proto._showOKDialog = function(title, message, delegate)
{
	if(!this._okDialog)
	{
		if(CNFormManager.vista)
		{
			this._okDialog = CNDialogManager.createVistaDialog(title);
			this._okDialog.style.width = 430;
			this._okDialog.style.height = 140;
		}
		else
		{
			this._okDialog = CNDialogManager.createDialog(title);
			this._okDialog.style.width = 400;
			this._okDialog.style.height = 100;
		}
		var contents = CNDialogManager.getContents(this._okDialog);
		var img = Util.createElementFromHTML("<img width=48 height=48 class='dialogIcon'>");
		contents.appendChild(img)
		img.src = CNFormManager.neutralImagesPath + "yesno-question-1.gif";
		var html = "<div style='padding: 8px; margin-left: 48px; '>" + message + "</div>";
		Util.appendHTML(contents, html);
		var buttonWidth = 80;
		var b2 = CNDialogManager.createBottomButton(this._okDialog, "OK", true);
		b2.style.width = buttonWidth;
	}
	CNDialogManager.showDialog(this._okDialog, delegate, true);
}

proto._showErrorsDialog = function(title, errorNodeList, delegate)
{
	if(!this._errorsDialog) 
	{
		if(CNFormManager.vista)
		{
			this._errorsDialog = CNDialogManager.createVistaDialog(title);
			this._errorsDialog.style.width = 530;
			this._errorsDialog.style.height = 250;
		}
		else
		{
			this._errorsDialog = CNDialogManager.createDialog(title);
			this._errorsDialog.style.width = 500;
			this._errorsDialog.style.height = 220;
		}
		
		var contents = CNDialogManager.getContents(this._errorsDialog);

		var img = Util.createElementFromHTML("<img width=48 height=48 class='dialogIcon'>");
		contents.appendChild(img)
		img.src = CNFormManager.neutralImagesPath + "error-1.gif";

		var html = "<div id='messageDiv' style='height: 160px; width: 435px; position: relative; padding: 4px; margin: 5px; top: 5px; margin-left: 58px; overflow: auto; '></div>";
		Util.appendHTML(contents, html);
		var buttonWidth = 80;
		var b2 = CNDialogManager.createBottomButton(this._errorsDialog, "Close", true);
		b2.style.width = buttonWidth;
	}
	var str = '';
	for(var i = 0; i < errorNodeList.length; i++)
	{
		str += Util.xmlText(errorNodeList[i]) + "\n\n";
	}
	Util.findById(this._errorsDialog, "messageDiv").textContent = str;
	CNDialogManager.showDialog(this._errorsDialog, delegate, true);
}

proto._showFatalErrorDialog = function(title, msg, buildInfo, stackTrace, delegate)
{
	if(!this._fatalErrorsDialog) 
	{
		if(CNFormManager.vista)
		{
			this._fatalErrorsDialog = CNDialogManager.createVistaDialog(title);
			this._fatalErrorsDialog.style.width = 530;
			this._fatalErrorsDialog.style.height = 185;
		}
		else
		{
			this._fatalErrorsDialog = CNDialogManager.createDialog(title);
			this._fatalErrorsDialog.style.width = 500;
			this._fatalErrorsDialog.style.height = 150;
		}
		this._fatalErrorsDialog.style.overflow = "hidden";
		var contents = CNDialogManager.getContents(this._fatalErrorsDialog);
				
		var img = Util.createElementFromHTML("<img width=48 height=48 class='dialogIcon'>");
		contents.appendChild(img)
		img.src = CNFormManager.neutralImagesPath + "error-2.gif";

		var html = "<div id='messageDiv' class='fatalErrorDialogMessageDiv1'></div>";
		Util.appendHTML(contents, html);
		var buttonWidth = 80;

		var b1 = CNDialogManager.createBottomButton(this._fatalErrorsDialog, "Details");
		b1.style.width = buttonWidth;
		Event.add(b1, "click", this, this._fatalErrorDetailsClick);
		var b2 = CNDialogManager.createBottomButton(this._fatalErrorsDialog, "Close", true);
		b2.style.width = buttonWidth;
		
		var span = Util.createElementFromHTML("<span class='fatalErrorDialogSpan1'>");
		contents.appendChild(span);
		span.textContent = "Stack Trace:";
		
		var div = Util.createElementFromHTML("<div id=message2Div class='fatalErrorDialogMessageDiv2'>");
		contents.appendChild(div);

		var span = Util.createElementFromHTML("<span class='fatalErrorDialogSpan2'>");
		contents.appendChild(span);
		span.textContent = "Build Information:";

		var div = Util.createElementFromHTML("<div id=message3Div class='fatalErrorDialogMessageDiv3'>");
		contents.appendChild(div);
	}

	Util.findById(this._fatalErrorsDialog, "messageDiv").textContent = msg;
	Util.findById(this._fatalErrorsDialog, "message2Div").textContent = stackTrace;
	Util.findById(this._fatalErrorsDialog, "message3Div").textContent = buildInfo;
	this._fatalErrorsDialog._collapsed = true;

	CNDialogManager.showDialog(this._fatalErrorsDialog, delegate, true);
}

proto._fatalErrorDetailsClick = function()
{
	var dialog = CNDialogManager._findDialogDiv(Util.eventTarget(Event.current()));
	var contents = CNDialogManager.getContents(dialog);
	var display;
	if(dialog._collapsed)
	{
		dialog.style.height = CNFormManager.vista ? 415 : 385;
		display = 'block';
	}
	else
	{
		dialog.style.height = CNFormManager.vista ? 185 : 150;
		display = 'none';
	}
	for(var i = 3; i < contents.children.length; i++) contents.children[i].style.display = display;		
	dialog._collapsed = !dialog._collapsed;
	if(dialog.shadow) dialog.shadow.syncPosition();
}


// Theme support. =================================
proto._filterEventsXMLForTheme = function(xml)
{
	if(!CNFormManager.currentThemeName) CNFormManager.currentThemeName = CNFormManager.defaultThemeName;
	var tagName = "updateTheme";
	var tag = "<" + tagName + " theme=\"" + CNFormManager.currentThemeName + "\"/>";
	var uniqueID = '<uniqueID value="' + this._uniqueID + '"/>';
	if(!xml)
	{
		return "<events>" + tag + uniqueID + "</events>";
	}
	else if(typeof(xml) == "string")
	{
		// String.
		var closingPos = xml.indexOf("</events>");
		if(closingPos == -1) 
		{
			Util.assert("invalid events xml: closingPos == -1.");
			return "";
		}
		return xml.substring(0, closingPos) + tag + uniqueID + xml.substr(closingPos);
	}
	else 
	{
		// DOM.
		var events = Util.xmlSelectSingleNode(xml.documentElement, "events");
		var element = xml.createElement(tagName);
		element.setAttribute("theme", CNFormManager.currentThemeName);
		events.appendChild(element);
		
		element = xml.createElement("uniqueID");
		element.setAttribute("value", this._uniqueID);
		events.appendChild(element);
		
		return xml;
	}
}

proto._filterEventsXMLForResized = function(xml)
{
	if(!this._formPlaceholder) return;
	var rehide = false;
	if(Util.getStyle(this._formPlaceholder, "display") == "none")
	{
		//this._formPlaceholder.style.display = "block";
		rehide = true;
	}
	
	var w = this._formPlaceholder.offsetWidth;
	var h = this._formPlaceholder.offsetHeight;
	
	if(rehide)
	{
		//this._formPlaceholder.style.display = "none";
	}

	var tag = "<formSizeChanged width=\"" + w + "\" height=\"" + h + "\"/>";

	if(!xml)
	{
		return "<events>" + tag + "</events>";
	}
	else if(typeof(xml) == "string")
	{
		// String.
		var closingPos = xml.indexOf("</events>");
		if(closingPos == -1) 
		{
			Util.assert("invalid events xml: closingPos == -1.");
			return "";
		}
		return xml.substring(0, closingPos) + tag + xml.substr(closingPos);
	}
	else 
	{
		// DOM.
		var events = Util.xmlSelectSingleNode(xml, "events");
		var element = xml.createElement("formSizeChanged");
		element.setAttribute("width", w);
		element.setAttribute("height", h);
		events.insertBefore(element, events.firstChild);
		return xml;
	}
}

proto._deleteLoadingBar = function() {
	var pb = document.getElementById("cn_progressBar");
	if(pb) pb.parentNode.removeChild(pb);
}

// NOTE: return true -> breaks xml processing flow.
proto._processTheme = function()
{
	var htmlNode = Util.xmlSelectSingleNode(this._ideaNode, "html");
	if(!htmlNode)
	{
		if(!CNFormManager.themeLoaded)
		{
			this.fail("<html> theme is required in server response.");
		}
		return false;
	}
	
	// Got new theme.
	var attr = htmlNode.getAttribute("theme");
	if(!attr)
	{
		this.fail("No theme attribute in <html> element.");
		return true;
	}

	var themeName = String(attr);
	if(CNFormManager.themeLoaded && CNFormManager.currentThemeName == themeName) return false;
	
	CNFormManager.changingTheme = true;

	this._deleteLoadingBar();

	this._themeHtml = String(Util.xmlText(htmlNode));

	CNFormManager.currentThemeName = themeName;
	CNFormManager.themeImagesPath = "themes/" + CNFormManager.currentThemeName + "/g/";
	
	
	CNFormManager.vista = CNFormManager.currentThemeName == "vista";
	if(CNFormManager.currentThemeName == "black") {
		CNFormManager.vista = true;
		CNFormManager.subTheme = "black";
	}
	
	// Deactivate old stylesheet.
	var cn_globalStyleLink = document.getElementById("cn_globalStyleLink");

	this._detachHTMLLayout();

	var tabsAttr = htmlNode.getAttribute("tabs");
	if(tabsAttr == "true") this.isTabbed = true;

	this._loadAboutDialog();
	
	var href;
	if(CNFormManager.usePacked) href = "packed/themes/css/" + CNFormManager.currentThemeName + ".css.gz";
	else href = "themes/" + CNFormManager.currentThemeName + "/css/" + "allthemestyles.css";
	if(CNFormManager.assetVersion) href += "?v=" + encodeURIComponent(CNFormManager.assetVersion);
	
	if(!cn_globalStyleLink || href.toLowerCase() != cn_globalStyleLink.href.toLowerCase())
	{
		var link = Util.createElement("link", null, {rel: "stylesheet", id: "cn_globalStyleLink"});
		if(cn_globalStyleLink && cn_globalStyleLink.parentNode)
		{
			cn_globalStyleLink.parentNode.replaceChild(link, cn_globalStyleLink);
		}
		else
		{
			document.body.insertBefore(link, document.body.firstChild);
		}

		cn_globalStyleLink = link;
		cn_globalStyleLink._load = true;
		Event.add(cn_globalStyleLink, "load", this, this._globalStyleLink_onload);
		cn_globalStyleLink.href = href;
		return true; // Break flow.
	}
	else
	{
		this._processTheme2(false);
		return false;
	}
}

proto._globalStyleLink_onload = function()
{
	var cn_globalStyleLink = document.getElementById("cn_globalStyleLink");
	if(!cn_globalStyleLink || !cn_globalStyleLink._load) return;
	cn_globalStyleLink._load = false;
	var formManager = CNFormManager.getBaseFormManager();
	formManager._processTheme2(true);
}

proto._processTheme2 = function(doContinue)
{
	// The server may return a cached legacy New Blue layout containing the
	// dark-header PNGs. Strip those tags before innerHTML parses them, so the
	// browser never requests obsolete artwork; the standards theme supplies
	// the surface with CSS instead.
	if(typeof this._themeHtml == "string")
	{
		this._themeHtml = this._themeHtml.replace(/<img\b[^>]*(?:darkHeader_img[12]|dark-header-bg_0[12]\.png)[^>]*>/gi, "");
	}
	this._globalPlaceholder.innerHTML = this._themeHtml;
	this._themeHtml = null;

	this._initHTMLLayout();

	CNFormManager.changingTheme = false;

	if(doContinue) 
	{
		this._continueLoadForm2();
	}
}

proto._detachHTMLLayout = function()
{
	CNFormManager.destroyJSObjects(CNFormManager.themeJSObjects);
	CNFormManager.themeJSObjects = [];

	this._resetScreen();

	if(CNFormManager.themeLoaded)
	{
		window.ThemeNonCSSStyles = null;
		
		CNPopupCalendar.destroyDefaultCalendar();

		if(this._selectLocationCombo) 
		{
			CNFormManager.destroyJSObject(this._selectLocationCombo);
			this._selectLocationCombo = null;
		}

		Tooltip.destroy();
		if(this._alertIcons) CNFormManager.destroyJSObject(this._alertIcons);
		if(this._topButtons) CNFormManager.destroyJSObject(this._topButtons);
		if(this._layoutManager) this._layoutManager.unload();
		if(this._screenLayoutManager) this._screenLayoutManager.unload();

		// NOTE: i == 0 is a top form manager.
		for(var i = 1; i < CNFormManager.formManagers.length; i++)
		{
			CNFormManager.formManagers[i].destroyDialog();
			CNFormManager.formManagers[i] = null;
		}


		// Delete dialogs.
		if(this._passwordDialog) Util.removeElement(this._passwordDialog);
		if(this._aboutDialog) Util.removeElement(this._aboutDialog);
		if(this._errorsDialog) Util.removeElement(this._errorsDialog);
		if(this._fatalErrorsDialog) Util.removeElement(this._fatalErrorsDialog);
		
		this._deleteControls();
		this._deleteNavigation();
	
		Event.del(this._formPlaceholder, "keypress", this, this._formPlaceholder_onkeypress);
		
		Util.removeElement(this._formPlaceholder);
	}

	this._formPlaceholder = null;
	this._knownScreenItems = null;
}

proto._initHTMLLayout = function()
{
	//this._reinitScripts(this._globalPlaceholder); - currently scripts work with deffer attribute, but for standards, it can be required.

	// Switch control styling.
	CN_button.setTheme(CNFormManager.currentThemeName);
	CN_imagebutton.setTheme(CNFormManager.currentThemeName);
	CN_combobox.setTheme(CNFormManager.currentThemeName);
	CN_logincontrol = CNFormManager.currentThemeName == "new-blue"
		? CN_logincontrol_newblue
		: (CNFormManager.vista ? CN_logincontrol_vista : CN_logincontrol_pre);
	CNPopupCalendar.createDefaultCalendar();

	var children = this._globalPlaceholder.children;
	
	this._formPlaceholder = Util.findById(this._globalPlaceholder, "__si_form");
	
	this._darkHeader = Util.findById(this._globalPlaceholder, "__si_darkHeader");

	Event.add(this._formPlaceholder, "keypress", this, this._formPlaceholder_onkeypress);
	
	this._setThemeStrings();
	
	var aiPlaceholder = Util.findById(this._globalPlaceholder, "__si_alertIcons");
	if(aiPlaceholder) 
	{	
		this._alertIcons = new AlertIcons(aiPlaceholder);
		this._alertIcons.formManager = this;
	}
	
	this._topRightControls = Util.findById(this._globalPlaceholder, "__si_topRightControls");
	if(this._topRightControls)
	{
		// The historical theme layout supplies these elements as screen items.
		// Some standards-browser layout paths retain only topRightControls,
		// leaving the header background above the toolbar in the stacking order.
		Util.addClass(this._topRightControls, "screenItem");
		Util.addClass(this._topRightControls, "si_topRightControls");
		this._topButtons = new TopButtons(this._topRightControls);
		this._topButtons.formManager = this;
	}

	if(!this.disableLayoutManager) 
	{
		this._layoutManager = new LayoutManager(this._formPlaceholder, 
			848/*this._formPlaceholder.offsetWidth*/, 
			632/*this._formPlaceholder.offsetHeight*/);
	}
	this._initScreens();
	
	if(!CNFormManager.vista)
	{
	}

	Tooltip.buildElement();

	CNFormManager.themeLoaded = true;
}
proto._setThemeStrings = function() {
	var copyrightDiv = $('__copyrightDiv');
	if(copyrightDiv && CNFormManager.strings['copyright']) {
		copyrightDiv.innerHTML = CNFormManager.strings['copyright'];
	}
}

/*proto._reinitScripts = function(l) {
	var tags = l.getElementsByTagName("script");
	var count = tags.length;
	var removeAr = [];
	for(var j = 0; j < count; j++)
	{
		var old = tags[j];
		var newScript = document.createElement('script'); 
	    newScript.type = "text/javascript"; 
	    
	    if(old.src) newScript.src = old.src
	    else newScript.textContent = old.textContent;

		l.appendChild(newScript); 

		removeAr.push(old);
	}
	for(var i = 0; i < removeAr.length; i++)
	{
		var old = removeAr[i];
		old.parentNode.removeChild(old);
	}
}*/

proto._initScreens = function()
{
	this._knownScreenItems = [];

	if(!this.disableLayoutManager) 
	{
		this._screenLayoutManager = new LayoutManager(this._globalPlaceholder, 0, 0);
		this._screenLayoutManager.setHandleResizes(true);
		this._screenLayoutManager.onResized = this._screenLayoutManager_onResized;
	}
}

// this == _screenLayoutManager.
proto._screenLayoutManager_onResized = function()
{
	var fm = CNFormManager.getBaseFormManager();
	fm._layoutManager.doLayout();
}


proto.isNavigationDisabled = function()
{
	return this._modalFocused || this._navigationDisabled || this._editMode;
} 

proto._control_oncontextmenu = function(ev)
{
	var currentEvent = Event.normalize(ev) || Event.current() || {};
	if(currentEvent.button != 2) return;

	var fm = CNFormManager.getActiveFormManager();

	var jsObject = CNUtil.findJSObject(Util.eventTarget(Event.current()));
	var l = jsObject.element;
	var x = currentEvent.clientX;
	var y = currentEvent.clientY;

	var menuData;

	if(jsObject.get_disabled && jsObject.get_disabled() || jsObject._disabled) return;
	
	if(jsObject.getContextMenuData) menuData = jsObject.getContextMenuData();
	else if(l) menuData = {menuID: l._menuID, targetID: l.id};
	
	if(!menuData) {
		return;
	}
	
	menuData.x = x;
	menuData.y = y;

	if(fm._isPostingBack || fm.contextMenuPending)
	{
		fm._pendingContextMenuData = menuData;
	}
	else 
	{
		Tooltip.hide();
		// Check required for answerbox rightclick.
		fm._showContextMenu(menuData);
	}
}
proto._showContextMenu = function(menuData)
{
	this._currentContextID = menuData.targetID;
	var topPlaceholder = document.body;

	var menu = this._menus[menuData.menuID];
	if(menu) {
		menu.show(document.body.scrollLeft + menuData.x, document.body.scrollTop + menuData.y);
	}
}

proto._menuItem_onmenuclick = function(ev)
{
	var fm = CNFormManager.getActiveFormManager();
	var target = ev && (ev.target || ev.target);
	var id = target._parentMenuID;
	fm._currentMenuID = id;
	fm._currentMenuItemID = target._id;
	fm.postData("menu");
}

proto.waitForButtonClick = function()
{
	// Do not allow to autoPostBack, wait for button onclick.
	this._waitingForButtonPostback = true;
}

proto.buttonClicked = function()
{
	this._waitingForButtonPostback = false;
}

// Progress bar ========================================================================================================
proto._beginProgress = function() {
/*	if(this._globalProgressbarTO != null) clearTimeout(this._globalProgressbarTO);
	var obj = this;
	this._globalProgressbarTO = setTimeout(function(){ obj._beginProgressTO(); }, 500);*/
}

proto._beginProgressTO = function() {
	//if(Util.getStyle(this._globalProgressbar, "visibility") != "hidden") return;
	var l = this._globalProgressbar;
	this._globalProgressbar.style.visibility = "visible";
	if(this._globalProgressbar.shadow) this._globalProgressbar.shadow.show();
	this._progressStarted = true;
}

proto._endProgress = function() {
	if(!this._progressStarted) return;
	if(this._globalProgressbarTO != null) clearTimeout(this._globalProgressbarTO);
	if(this._globalProgressbar.shadow) this._globalProgressbar.shadow.hide();
	this._globalProgressbar.style.visibility = "hidden";
	this._progressStarted = false;
}

proto._createProgressBar = function() {
	var l = this._globalProgressbar = document.createElement("div");
	l.className = "cn_globalProgressbar";
	l.innerHTML = '<div></div><img width="250" height="16" src="g/und-progress-bar-1.gif">';
	new Shadow(l);
	document.body.appendChild(l);
}

proto._showProgress = function(showProgressNode) {
	if(!this._globalProgressbar) this._createProgressBar();
	var labelAttr = showProgressNode.getAttribute("label");
	var textDiv = this._globalProgressbar.firstChild;
	if(labelAttr) textDiv.textContent = String(labelAttr);
	else textDiv.textContent = "";

	var self = this;
	setTimeout(function() {
		self._beginProgressTO();
		self.lightPostData("<progressWaiting/>");
	}, 0);
}


var proto = CNFormManager.prototype;

proto._loadHeartBeatTimer = function(heartBeatNode) {
	var heartBeatTimer = Util.xmlSelectSingleNode(heartBeatNode, "heartbeat");	
	if(heartBeatTimer)
	{
		if(heartBeatTimer.getAttribute("reset") == "true")
		{			
			this.pauseHeartBeatTimer();
			var fm = CNFormManager.getBaseFormManager();
			fm._heartBeatTime = 0;
			fm._heartBeatTO = 0;
			
			return;
		}
	
		var attr = heartBeatTimer.getAttribute("interval");
		if(attr == null)
		{
			Util.assert("No interval specified for heartBeatTimer");
			return;
		}
		var val = parseInt(attr, 10);
		if(val < 2)
		{
			Util.assert("Interval is < 2 for heartBeatTimer");
			return false;
		}
		CNFormManager._trace("Load HeartBeat with time: " + val)
		this._startHeartBeatTimer(val);
	}
	
}

proto._startHeartBeatTimer = function(timeoutSeconds)
{
	// this may be == to dialog fm, so using base fm.
	var fm = CNFormManager.getBaseFormManager();
	if(timeoutSeconds == fm._heartBeatTime) return;

	if(!fm._heartBeatTO)
	{
		Event.add(document, "keydown", fm, fm._resetHeartBeat);
		Event.add(document, "mousedown", fm, fm._resetHeartBeat);
	}

	fm._heartBeatTime = timeoutSeconds;
	fm._resetHeartBeat();
}
// API
proto.pauseHeartBeatTimer = function() {
    if(this != CNFormManager.getBaseFormManager()) {
		CNFormManager._trace("pauseHeartBeatTimer(): this != CNFormManager.getBaseFormManager() -> is  dialog FormManager");
		this._heartBeatPaused = false;
		return;
    }
    this._heartBeatPaused = true;
	CNFormManager._trace("Pause HeartBeat ...");
    if(this._heartBeatTO) clearTimeout(this._heartBeatTO);
}
proto.resumeHeartBeatTimer = function() {
    if(this != CNFormManager.getBaseFormManager()) {
       CNFormManager._trace("resumeHeartBeatTimer(): this != CNFormManager.getBaseFormManager() -> is  dialog FormManager");
	   return;
    }
    this._heartBeatPaused = false;
	CNFormManager._trace("Resume HeartBeat ...");
    this._resetHeartBeat();
}
proto._resetHeartBeat = function() { // Executed on each click/other user activity. Should be fast.
	// this may be == to dialog fm, so using base fm.
	var fm = CNFormManager.getBaseFormManager();
	if(!fm || fm._heartBeatPaused || fm._heartBeatShutDown) return;
    if(fm._heartBeatTO) clearTimeout(fm._heartBeatTO);
	if(!fm._heartBeatTime) return;
	CNFormManager._trace("Reset HeartBeat. New heartBeatTime " + fm._heartBeatTime);
    fm._heartBeatTO = setTimeout(function(){ fm._heartBeat(); }, fm._heartBeatTime * 1000);	
}

proto._heartBeat = function()
{
	this.pauseHeartBeatTimer();

    // this = base fm.
	Event.del(document, "keydown", this, this._resetHeartBeat);
	Event.del(document, "mousedown", this, this._resetHeartBeat);

	// Close some popups.
    // TODO: custom events and global event, which all the popup-enabled controls should listen to.
	this._safelyClosePopups();
	
	this._heartBeatPostData = true;	
	this._heartBeatPaused = false;
	CNFormManager.getActiveFormManager().postData("<empty/>");		
	this._heartBeatPostData = false;
}

var proto = CNFormManager.prototype;

proto._loadAutoLockTimer = function(autoLockNode) 
{
	var lockTimer = Util.xmlSelectSingleNode(autoLockNode, "autoLockTimer");
	if(lockTimer)
	{
		if(lockTimer.getAttribute("reset") == "true")
		{			
			this.pauseAutoLockTimer();
			var fm = CNFormManager.getBaseFormManager();
			
			fm._autoLockTime = 0;
			fm._autoLockTO = 0;
			
			return;
		}
		
		var attr = lockTimer.getAttribute("interval");
		if(attr == null)
		{
			Util.assert("No interval specified for autoLockTimer");
			return;
		}
		var val = parseInt(attr, 10);
		if(val < 2)
		{
			Util.assert("Interval is < 2 for autoLockTimer");
			return false;
		}
		CNFormManager._trace("Load AutoLock with time: " + val);
		this._startAutoLockTimer(val);
	}
}

proto._startAutoLockTimer = function(timeoutSeconds)
{
	// this may be == to dialog fm, so using base fm.
	var fm = CNFormManager.getBaseFormManager();
	if(timeoutSeconds == fm._autoLockTime) return;

	if(!fm._autoLockTO)
	{
		Event.add(document, "keydown", fm, fm._resetAutoLock);
		Event.add(document, "mousedown", fm, fm._resetAutoLock);
	}

	fm._autoLockTime = timeoutSeconds;
	fm._resetAutoLock();
}
// API
proto.pauseAutoLockTimer = function() 
{
    if(this != CNFormManager.getBaseFormManager()) {
        CNFormManager._trace("pauseAutoLockTimer(): this != CNFormManager.getBaseFormManager() -> is  dialog FormManager");
		this._autoLockPaused = false;
		return;
    }
    this._autoLockPaused = true;
	CNFormManager._trace("Pause AutoLock ...");
    if(this._autoLockTO) clearTimeout(this._autoLockTO);
}
proto.resumeAutoLockTimer = function() {
    if(this != CNFormManager.getBaseFormManager()) {
       CNFormManager._trace("resumeAutoLockTimer(): this != CNFormManager.getBaseFormManager() -> is  dialog FormManager");
	   return;
    }
    this._autoLockPaused = false;
	CNFormManager._trace("Resume AutoLock ...");
    this._resetAutoLock();
}
proto._resetAutoLock = function() { // Executed on each click/other user activity. Should be fast.
	// this may be == to dialog fm, so using base fm.
	var fm = CNFormManager.getBaseFormManager();
	if(!fm || fm._autoLockPaused || fm._autoLockShutDown) return;
    if(fm._autoLockTO) clearTimeout(fm._autoLockTO);
	if(!fm._autoLockTime) return;
	CNFormManager._trace("Reset AutoLock. New autoLockTime " + fm._autoLockTime);
    fm._autoLockTO = setTimeout(function(){ fm._autoLock(); }, fm._autoLockTime * 1000);
	if(!fm._autoLockTO)
	{
		Event.add(document, "keydown", fm, fm._resetAutoLock);
		Event.add(document, "mousedown", fm, fm._resetAutoLock);
	}

}

proto._autoLock = function()
{
	this._autoLockPostData = true;	
	this.pauseAutoLockTimer();

    // this = base fm.
	Event.del(document, "keydown", this, this._resetAutoLock);
	Event.del(document, "mousedown", this, this._resetAutoLock);

	// Close some popups.
    // TODO: custom events and global event, which all the popup-enabled controls should listen to.
	this._safelyClosePopups();

	// NOTE: dialogs and other popups handled by enforceDialog(). 
	CNFormManager.getActiveFormManager().postData("<autoLock/>");
	this._autoLockPostData = false;		
}

// API
// Enforces given dialog FM to be the single visible dialog at the time.
proto.enforceDialog = function() {
	if(!this.isDialog) {
		CNFormManager._trace("enforceDialog() !this.isDialog");
		return;
	}
	if(this != CNFormManager.getActiveFormManager()) {
		CNFormManager._trace("enforceDialog() this != CNFormManager.getActiveFormManager()");
		return;
	}

	this._tempHideAllPopups(); // NOTE: this can cause some unwanted delegates to be called on messagebox.hide (e.g. fm._finishProcessServerErrors).
}
proto.deforceDialog = function() {
	// Dialogs and popups in this port are DOM surfaces, restored below.

	var bodyChildren = document.body.children;

	for(var i = 0; i < bodyChildren.length; i++) {
		var l = bodyChildren[i];
		if(l._tempHidden !== null && l._tempHidden !== undefined) {
			l.style.visibility = l._tempHidden;
			l._tempHidden = null;
		}
	}
}

proto._tempHideAllPopups = function() {
	// Preserve each visible body-level popup until the lock dialog closes.

	var bodyChildren = document.body.children;
	var baseFM = CNFormManager.getBaseFormManager(); 
	for(var i = 0; i < bodyChildren.length; i++) {
		var l = bodyChildren[i];
		if(l == baseFM._formPlaceholder || l == this._formPlaceholder) continue;

		var style = Util.getComputedStyle(l);
		if((style.position == "absolute" || style.position == "fixed") && style.display != "none" && style.visibility != "hidden") {
			l._tempHidden = style.visibility;
			l.style.visibility = 'hidden';
		}
	}
}

proto = null;
var proto = CNFormManager.prototype;

proto._fetchUniqueID = function() {
	var tagName = "unique_id";
	var storage = null;
	try { storage = window.sessionStorage || window.localStorage; } catch(ex3) {}
	if(storage)
	{
		try
		{
			var stored = storage.getItem(tagName);
			if(stored) return stored;
			var generated = this._generateUniqueID();
			storage.setItem(tagName, generated);
			return generated;
		}
		catch(ex4) {}
	}
	throw new Error("Unique ID: standard Web Storage is required");
}
proto._generateUniqueID = function() {
	var id = Util.SHA1.compute(navigator.userAgent + "-" + Math.random() + "-" + (new Date().getTime()), "hex");
	return id;
}

proto = null;

/*
	v. 2.2
	+ subForms/layoutManagers for subForm containers.
*/

function LayoutManager(container, initialWidth, initialHeight)
{
	this.setInitialBounds(initialWidth, initialHeight);

	this._resizedControls = [];
	this._container = container;
	container._layoutManager = this;
	
	this._contentDeltaWidth = -1;
	this._contentDeltaHeight = -1;
	this._to = null;

	this.formTopOffset = 0;
	
	this._TAHidden = null;

	this._collapsedHeight = 27;	
	this._resizesHandled = false;
	this._resizeObserver = null;
	this._collapsedContainers = [];
}
LayoutManager.TOP = 0x1;    // 1
LayoutManager.LEFT = 0x2;   // 10
LayoutManager.RIGHT = 0x4;  // 100
LayoutManager.BOTTOM = 0x8; // 1000
LayoutManager.LEFTRIGHT = LayoutManager.LEFT | LayoutManager.RIGHT; //  110
LayoutManager.TOPBOTTOM = LayoutManager.TOP | LayoutManager.BOTTOM;	// 1001
LayoutManager.TOPLEFT = LayoutManager.TOP | LayoutManager.LEFT;

var proto = LayoutManager.prototype;

// Event.
proto.onPreResize = null;
proto.onResized = null;

proto.setHandleResizes = function(handle)
{
	if(handle) 
	{
		if(!this._resizesHandled) 
		{
			if(typeof ResizeObserver != "function")
			{
				if(typeof Util != "undefined" && Util.reportUnsupported)
					Util.reportUnsupported("LayoutManager", "element resize observation", "ResizeObserver is required by the standards-browser client");
				return;
			}
			var lm = this;
			this._resizeObserver = new ResizeObserver(function()
			{
				lm._formContent_onresize({currentTarget: lm._container});
			});
			this._resizeObserver.observe(this._container);
		}
	}
	else 
	{
		if(this._resizeObserver)
		{
			this._resizeObserver.disconnect();
			this._resizeObserver = null;
		}
	}
	this._resizesHandled = handle;
}

proto.setInitialBounds = function(initialWidth, initialHeight)
{
	this._initialWidth = initialWidth;
	this._initialHeight = initialHeight;
	
	this._originalInitialWidth = this._initialWidth;
	this._originalInitialHeight = this._initialHeight;
}

proto.resetInitialBounds = function()
{
	this._initialWidth = this._originalInitialWidth;
	this._initialHeight = this._originalInitialHeight;
}

proto.reload = function()
{
	this._resizedControls = [];
	this._collapsedContainers = [];
}

proto.unload = function()
{
	this.setHandleResizes(false);
	this.reload();
	this._container._layoutManager = null;
	this._container = null;
}

proto.processRawElement = function(l, x, y, w, h, anchor)
{
	var node = {x: x, y: y, width: w, height: h, getAttribute: CNFormManager._wrap_getAttribute};
	if(!l.jsObject) l.jsObject = {}

	if(anchor != -1) this.processNewControl(l, anchor, node, l.parentElement);
	else this.processNewControl(l, 0, node, l.parentElement);
}

proto.processNewControl = function(l, anchor, node, parentElement, isDelayedTopLevel)
{
	this._processLayout(l, anchor, node, false, parentElement, false);
	
	this._relayoutAgainstCollaspable(l);
}

proto._relayoutAgainstCollaspable = function(l)
{
	for(var id in this._collapsedContainers)
	{
		var cont = this._collapsedContainers[id];
		var jso = l.jsObject;
		// Commented because of FWUI-775 - this made bottom anchored controls to jump up on cont._delta distance.
		// Reactivated for 809, but moved to anchor* from offsets in expand container.
		if(cont._collapseDirection == "down") 
		{
			// Makes sense, as only bottom anchored contols can be placed below collapsable container.
			if(jso._anchorTop > cont.jsObject._anchorTop) 
			{
				jso._anchorTop -= cont._delta;
			}
		}
		else // up*/
		if(cont._collapseDirection == "up")
		{
			// Need to check non-anchored controls also.
			//if(l.offsetTop > cont.offsetTop)
			if(jso._anchorTop > cont.jsObject._anchorTop) 
			{
				if(jso._anchorTop !== undefined) jso._anchorTop -= cont._delta;
				else l.style.top = Util.cssLength(l.offsetTop - cont._delta);
			}
		}
	}
}

proto._processLayout = function(l, anchor, node, isTabbedContainer, parentElement, isContainer)
{
	if(this._contentDeltaWidth == -1) this._collectContentDeltaSize();

	var contentDeltaWidth;
	var contentDeltaHeight;
	var collection;
	var initialWidth;
	var initialHeight;
	var containerHeaderHeight = 0;

	if(parentElement._isContainerPanel)
	{
		while(parentElement && !parentElement.isContainer) parentElement = parentElement.parentElement;
		containerHeaderHeight = 30;
	}

	if(parentElement.isContainer && !parentElement.jsObject.isSubForm) 
	{
		collection = parentElement.jsObject._resizedControls;
		if(!collection) 
		{
			collection = parentElement.jsObject._resizedControls = [];
		}
		var xy = this._collectContainerDeltaSize(parentElement);
		contentDeltaWidth = xy.x;
		contentDeltaHeight = xy.y;
		initialWidth = parentElement.jsObject._anchorW;
		initialHeight = parentElement.jsObject._anchorH - containerHeaderHeight;
	}
	else 
	{
		collection = this._resizedControls;
		contentDeltaWidth = this._contentDeltaWidth;
		contentDeltaHeight = this._contentDeltaHeight;
		initialWidth = this._initialWidth;
		initialHeight = this._initialHeight;
	}
	
	var jso = l.jsObject;

	var x = parseInt(node.getAttribute("x"));
	var y = parseInt(node.getAttribute("y"));
	var w = parseInt(node.getAttribute("width"));
	var h = parseInt(node.getAttribute("height"));
	
	if(isTabbedContainer)
	{
		y += 22;
		h -= 22;
	}
	
	jso._anchorW = w;
	jso._anchorH = h;
	jso._anchor = anchor;

	var pushed = false;

	// Always push everything - this is required to move controls below top collapsable container.
	collection.push(l);
	pushed = true;

	// Pre-set them. Needed for required marks.
	if(!isNaN(x)) jso._anchorLeft = x;
	if(!isNaN(y)) jso._anchorTop = y;

	// Optimization for usual anchor.
	if(anchor == 0 || anchor == LayoutManager.TOPLEFT)
	{
		if(!isNaN(x)) l.style.left = Util.cssLength(x);
		if(!isNaN(y)) l.style.top = Util.cssLength(y);
		if(!isNaN(w)) l.style.width = Util.cssLength(w);
		if(!isNaN(h)) l.style.height = Util.cssLength(h);
		if(jso.layout) jso.layout();
		return;
	}
	
	var leftRight = (anchor & LayoutManager.LEFTRIGHT) == LayoutManager.LEFTRIGHT;
	var topBottom = (anchor & LayoutManager.TOPBOTTOM) == LayoutManager.TOPBOTTOM;
	
	if(leftRight || topBottom)
	{
		if(leftRight)
		{
			if(!isNaN(x)) l.style.left = Util.cssLength(x);
		}
		else
		{
			if(!isNaN(w)) l.style.width = Util.cssLength(w);
		}
		
		if(topBottom)
		{
			if(!isNaN(y)) l.style.top = Util.cssLength(y);
		}
		else
		{
			if(!isNaN(h)) l.style.height = Util.cssLength(h);
		}

		jso._anchorSide = anchor & (LayoutManager.LEFTRIGHT | LayoutManager.TOPBOTTOM);
		if(!pushed)
		{
			collection.push(l);
			pushed = true;
		}
		//this._setRecalculatedSize(l, contentDeltaWidth, contentDeltaHeight);
	}
	
	if(!leftRight)
	{
		if((anchor & LayoutManager.RIGHT) == LayoutManager.RIGHT && !isNaN(x) && !isNaN(w))
		{
			jso._anchorSide = jso._anchorSide | LayoutManager.RIGHT;
			jso._anchorLeft = x;
			l.style.left = Util.cssLength(x); // Set initial x (for non-resized layout).
			if(!pushed)
			{
				pushed = true;
				collection.push(l);
			}
		}
		else if(!isNaN(x))
		{
			l.style.left = Util.cssLength(x);
		}
		if(!isNaN(w)) l.style.width = Util.cssLength(w);
	}
	if(!topBottom)
	{
		if((anchor & LayoutManager.BOTTOM) == LayoutManager.BOTTOM && !isNaN(y) && !isNaN(h))
		{
			jso._anchorSide = jso._anchorSide | LayoutManager.BOTTOM;
			jso._anchorTop = y;
			l.style.top = Util.cssLength(y);  // Set initial y (for non-resized layout).
			if(!pushed)
			{
				pushed = true;
				collection.push(l);
			}
		}
		else if(!isNaN(y))
		{
			l.style.top = Util.cssLength(y);
		}
		if(!isNaN(h)) l.style.height = Util.cssLength(h);
	}
	if(l.parentElement.isContainer && !l.parentElement.jsObject._anchorSide)
	{
		this._setRecalculatedSize(l, contentDeltaWidth, contentDeltaHeight);
	}
}
// Removes layoutmanager controls tracking array.
proto.cleanupContainer = function(container) {
	container.jsObject._resizedControls = [];
}

proto._collectContentDeltaSize = function()
{
	var w, h;
	w = this._container.offsetWidth;
	h = this._container.offsetHeight;
	
	this._contentDeltaWidth = w - this._initialWidth;
	this._contentDeltaHeight = h - this._initialHeight - this.formTopOffset;

	if(this._contentDeltaWidth < -100) this._contentDeltaWidth = -100;
	if(this._contentDeltaHeight < 0) this._contentDeltaHeight = 0;
}

proto._collectContainerDeltaSize = function(container)
{
	var x = container.offsetWidth - container.jsObject._anchorW;
	var y = container.offsetHeight - container.jsObject._anchorH;
	
	if(x < -100) x = -100;
	if(y < 0) y = 0;
	
	return {x: x, y: y};
}

proto._setRecalculatedSize = function(l, contentDeltaWidth, contentDeltaHeight)
{
	var jso = l.jsObject;
	
	if(jso._anchor == 0 || jso._anchor == LayoutManager.TOPLEFT) return;
	
	if((jso._anchorSide & LayoutManager.LEFTRIGHT) == LayoutManager.LEFTRIGHT) 
	{
		var w = contentDeltaWidth + jso._anchorW;
		if(w > 0) l.style.width = Util.cssLength(w + "px");
	}
	else if((jso._anchorSide & LayoutManager.RIGHT) == LayoutManager.RIGHT) 
	{
		l.style.left = Util.cssLength(jso._anchorLeft + contentDeltaWidth);
	}

	if((jso._anchorSide & LayoutManager.TOPBOTTOM) == LayoutManager.TOPBOTTOM) 
	{
		var h = contentDeltaHeight + jso._anchorH;
		if(h > 0) l.style.height = Util.cssLength(h + "px");
	}
	else if((jso._anchorSide & LayoutManager.BOTTOM) == LayoutManager.BOTTOM) 
	{
		// `pixelTop` is an IE-only CSSOM property.  It is silently ignored by
		// Safari/Chrome, leaving bottom-anchored controls at their design-time
		// position when the form grows.
		l.style.top = Util.cssLength((jso._anchorTop + contentDeltaHeight) + "px");
	}

	if(jso.layout) jso.layout();
	if(jso._layoutManager) {
		jso._layoutManager.doLayout();
	}
}

proto._formContent_onresize = function()
{
	var ev = Event.normalize(arguments[0]);
	var src = ev && (ev.currentTarget || ev.target || ev.target);
	if(!src) src = window;
	var lm = src._layoutManager;
	if(!lm) return;

	if(lm._to) clearTimeout(lm._to);
	lm._to = setTimeout(function(){ lm.doLayout(); }, 100);
}
proto.doLayout = function()
{
	if(!this.constructor) return;

	if(this.onPreResize) this.onPreResize();

	this._handle_onresize();
	
	if(this.onResized) this.onResized();
}
proto._handle_onresize = function()
{
	this._collectContentDeltaSize();
	this._resizeControls(this._resizedControls, this._contentDeltaWidth, this._contentDeltaHeight);
	
	if(this._TAHidden != null)
	{
		this._changeTAVisibility(this._TAHidden, true);
		this._TAHidden = null;
	}
}
proto._resizeControls = function(collection, contentDeltaWidth, contentDeltaHeight)
{
	for(var i = 0; i < collection.length; i++)
	{
		var l = collection[i];
		this._setRecalculatedSize(l, contentDeltaWidth, contentDeltaHeight);
		if(l.isContainer && l.jsObject._resizedControls && !l.jsObject.isSubForm)
		{
			var xy = this._collectContainerDeltaSize(l);
			this._resizeControls(l.jsObject._resizedControls, xy.x, xy.y);
		}
	}
}
proto.forceLayout = function(l)
{
	this._setRecalculatedSize(l, this._contentDeltaWidth, this._contentDeltaHeight);	
}
proto.forceContainerLayout = function(l)
{
	if(!l.isContainer) return;
	var xy = this._collectContainerDeltaSize(l);

	if(!l.jsObject._resizedControls) return;

	this._resizeControls(l.jsObject._resizedControls, xy.x, xy.y);
}


proto.processNewTabsTable = function(tabsTable, anchor, node, parentElement, isDelayedTopLevel)
{
	this._processLayout(tabsTable, anchor, node, false, parentElement, false);
	
	//if(isDelayedTopLevel)
	this._relayoutAgainstCollaspable(l);
}

proto.processNewTabbedContainer = function(contentElement, anchor, node, parentElement, isDelayedTopLevel)
{
	this._processLayout(contentElement, anchor, node, true, parentElement, false);

	//if(isDelayedTopLevel)
	this._relayoutAgainstCollaspable(l);
}

proto.processNewContainer = function(l, anchor, node, parentElement, isDelayedTopLevel)
{
	this._processLayout(l, anchor, node, false, parentElement, true);

	//if(isDelayedTopLevel)
	this._relayoutAgainstCollaspable(l);
}


proto.toggleContainer = function(l)
{
	if(!l._collapsed) this._collapseContainer(l, true);
	else this._expandContainer(l);
}

proto._collapseContainer = function(l, animate, skipParentCheck)
{
	if(l._collapsed) return;

	if(!skipParentCheck && l.parentNode._layoutManager) return l.parentNode._layoutManager._collapseContainer(l, animate, true);

	l._expandedHeight = l.offsetHeight;
	l.jsObject._expandedAnchorH = l.jsObject._anchorH;

	this._initialHeight -= l.jsObject._anchorH - this._collapsedHeight;

	l.jsObject._anchorH = this._collapsedHeight;
	
	l._collapsed = true;
	
	l.containerElement.style.overflow = "hidden";
	
	animate = false;
	
	if(l._collapseDirection == "down") 
	{
		if(!animate) this._collapseDown(l);
		else this._animateCollapseDown(l);
	}
	else if(l._collapseDirection == "up") 
	{
		if(!animate) this._collapseUp(l);
		else this._animateCollapseUp(l);
	}
}

proto._collapseDown = function(l)
{
	this._collapsedContainers[l.id] = l;

	this._changeTAVisibility(l, false);
	l.containerElement.style.visibility = "hidden";	
	l.style.height = Util.cssLength(this._collapsedHeight);

	var delta = l.jsObject._expandedAnchorH - l.jsObject._anchorH;
	l._delta = delta;
	var anchTop = l.jsObject._anchorTop;
	var resizedControls = this._resizedControls;
	for(var i = 0; i < resizedControls.length; i++)	{
		var control = resizedControls[i];
		if(control == l) continue;
		var jso = control.jsObject;
		if(jso._anchorTop !== undefined && jso._anchorTop > anchTop) {
			jso._anchorTop -= delta;
		}
	}
	this._updateContainer(l);
	this.doLayout();
}

proto._changeTAVisibility = function(l, visible)
{
	var tas = l.getElementsByTagName ? l.getElementsByTagName("TEXTAREA") : [];
	for(var i = 0; i < tas.length; i++)
	{
		var ta = tas[i];
		
		if(visible)
		{
			if(ta._lm_currentVisibility) 
			{
				ta.style.visibility = ta._lm_currentVisibility;
			}
			else ta.style.visibility = "inherit";
			ta._lm_tempHidden = false;
		}
		else
		{
			if(!ta._lm_tempHidden)
			{
				var computed = window.getComputedStyle(ta, null);
				ta._lm_currentVisibility = computed && (computed.visibility ||
					(computed.getPropertyValue && computed.getPropertyValue("visibility"))) || "visible";
			}
			ta._lm_tempHidden = true;
			ta.style.visibility = "hidden";
		}
	}
}


proto._expandContainer = function(l, skipParentCheck)
{
	if(!l._collapsed) return;

	 if(!skipParentCheck && l.parentNode._layoutManager) return l.parentNode._layoutManager._expandContainer(l, true); 
	
	l.containerElement.style.visibility = "visible";

	l.jsObject._anchorH = l.jsObject._expandedAnchorH;
	this._initialHeight += l.jsObject._anchorH - l.offsetHeight;
	l.style.height = Util.cssLength(l._expandedHeight);
	
	var resizedControls = this._resizedControls;

	if(l._collapseDirection == "down")  // Means, container is on the bottom.
	{
		for(var i = 0; i < resizedControls.length; i++)
		{
			var control = resizedControls[i];
			if(control == l) continue;
			if(control.jsObject._anchorTop > l.jsObject._anchorTop)
			{
				control.jsObject._anchorTop += l._expandedHeight - this._collapsedHeight;
			}
		}
	}
	else if(l._collapseDirection == "up")  // Means, container is on the top.
	{
		for(var i = 0; i < resizedControls.length; i++)
		{
			var control = resizedControls[i];
			if(control == l) continue;
			if(control.offsetTop > l.offsetTop)
			{
				var delta = l.jsObject._expandedAnchorH - this._collapsedHeight;
				if(control.jsObject._anchorTop !== undefined) control.jsObject._anchorTop += delta;
				else control.style.top = Util.cssLength(control.offsetTop + delta);
			}
		}
	}
		
	delete this._collapsedContainers[l.id];
	
	l._collapsed = false;
	this._updateContainer(l);			
	
	l.containerElement.style.overflow = "hidden";
	
	this._changeTAVisibility(l, false);
	this._TAHidden = l;

	this.doLayout();
	
	l.containerElement.style.overflow = "visible";
}

proto._animateCollapseDown = function(l)
{
	var anim = new AnimResize(l, l.offsetWidth, this._collapsedHeight, false, true);
	var obj = this;
	anim.onend = function(){ obj._collapseDown(l); }
	Animator.start(anim);
}

proto._animateCollapseUp = function(l)
{
	var anim = new AnimResize(l, l.offsetWidth, this._collapsedHeight, false, false);
	var obj = this;
	anim.onend = function(){ obj._collapseUp(l); }
	Animator.start(anim);
}

proto._collapseUp = function(l)
{
	this._collapsedContainers[l.id] = l;

	this._changeTAVisibility(l, false);	

	l.containerElement.style.visibility = "hidden";
	
	l.style.height = Util.cssLength(this._collapsedHeight);
	var delta = l._delta = l.jsObject._expandedAnchorH - this._collapsedHeight;
				
	var resizedControls = l.parentElement.isContainer ? l.parentElement.jsObject._resizedControls : this._resizedControls; // FWUI-1351 - added support for collapsable cont. inside sub-form
	for(var i = 0; i < resizedControls.length; i++)
	{
		var control = resizedControls[i];
		if(control == l) continue;
		if(control.offsetTop > l.offsetTop)
		{
			if(control.jsObject._anchorTop !== undefined) control.jsObject._anchorTop -= delta;
			else control.style.top = Util.cssLength(control.offsetTop - delta);
		}
	}

	l.style.overflow = "hidden";

	this._updateContainer(l);
	
	this.doLayout();
}

proto._updateContainer = function(l)
{
	var collapsed = l._collapsed;
	// NOTE: doesn't support scrollable = false.
	l.containerElement.style.overflow = collapsed ? "hidden" : "auto";

	var button = CNFormManager.vista ? l.lastChild : null;
	if(!button)
	{
		var table = l.children && l.children[0];
		var row = table && table.rows && table.rows[0];
		var cell = row && row.cells && row.cells[1];
		var divs = cell && cell.getElementsByTagName ? cell.getElementsByTagName("div") : [];
		button = divs[0] || (cell && cell.firstElementChild) || (cell && cell.firstChild);
	}
	if(!button) return;
	Tooltip.set(button, collapsed ? "Expand" : "Collapse");
	var upper = l._collapseDirection != "down";

	var up;
	if(l._collapsed) up = !upper;
	else up = upper;

	if(CNFormManager.vista)
	{
		if(CNFormManager.subTheme == "black") {
			VistaSupport.updateImageSetButton(button, null, up ? 0 : 20);
		} else {
			var src;
			if(l._collapsed) src = upper ? "collapse-down.gif" : "collapse-up.gif";
			else src = upper ? "collapse-up.gif" : "collapse-down.gif";
			button.src = CNFormManager.themeImagesPath + (button._hover ? "hover-" : '') + src;
			button._src = src;
		}
	}
	else 
	{
		if(l._collapsed) button.textContent = upper ? "6" : "5";
		else button.textContent = upper ? "5" : "6";
	}
}

/*
	v. 2.0.4
*/
function CNDialogManager(){}

CNDialogManager._dialog_closeButton_onmouseenter = function()
{
	var l = Util.eventTarget(Event.current());
	l.style.border = "1px solid white";
	l.style.padding = "0px";
}

CNDialogManager._dialog_closeButton_onmouseleave = function()
{
	var l = Util.eventTarget(Event.current());
	l.style.border = "0px";
	l.style.padding = "1px";
}

CNDialogManager._findDialogDiv = function(l)
{
	while(l && !l._isDialogDiv) l = l.parentNode || l.parentElement;
	return l;
}

// Blue only.
CNDialogManager._popupDiv_onmousedown = function()
{
	var l = CNDialogManager._findDialogDiv(Util.eventTarget(Event.current()));
	if(Util.getStyle(l, "zIndex") != top.__ontopZ) l.style.zIndex = top.__ontopZ++;
	Util.cancelEvent();
}

CNDialogManager._captionDiv_onmousedown = function()
{
	var l = CNDialogManager._findDialogDiv(Util.eventTarget(Event.current()));	
	if(Util.getStyle(l, "zIndex") != top.__ontopZ) l.style.zIndex = top.__ontopZ++;
	if(CNFormManager.vista && 
		!Util.eventTarget(Event.current()).className.match(/dialogContOuter|dialogCaption/)) return;
	
	if(l._maximized) return;
	
	CNDialogManager._dragged = l;
	CNDialogManager._dragStarted = false;
	CNDialogManager._dragTarget = document;
	Event.add(CNDialogManager._dragTarget, "mousemove", CNDialogManager, CNDialogManager._captionDiv_doDrag);
	Event.add(CNDialogManager._dragTarget, "mouseup", CNDialogManager, CNDialogManager._captionDiv_finishDrag);
}
CNDialogManager._captionDiv_doDrag = function()
{
	var l = CNDialogManager._dragged;
	if(!l) return;
	
	if(!CNDialogManager._dragStarted)
	{
		CNDialogManager._startLeft = l.offsetLeft;
		CNDialogManager._startTop = l.offsetTop;
		var startEvent = Event.current() || {};
		CNDialogManager._x = startEvent.screenX;
		CNDialogManager._y = startEvent.screenY;
		CNDialogManager._dragStarted = true;
	}

	var currentEvent = Event.current() || {};
	l.style.left = (CNDialogManager._startLeft + currentEvent.screenX - CNDialogManager._x) + "px";
	l.style.top = (CNDialogManager._startTop + currentEvent.screenY - CNDialogManager._y) + "px";
	
	if(l.shadow) l.shadow.syncPosition();
}

CNDialogManager._captionDiv_finishDrag = function()
{
	var l = CNDialogManager._dragged;
	if(!l) return;
	var target = CNDialogManager._dragTarget;
	Event.del(target, "mousemove", CNDialogManager, CNDialogManager._captionDiv_doDrag);
	Event.del(target, "mouseup", CNDialogManager, CNDialogManager._captionDiv_finishDrag);
	CNDialogManager._dragStarted = false;
	CNDialogManager._dragged = null;
	CNDialogManager._dragTarget = null;
}

CNDialogManager._popup_cancel = function()
{
	CNDialogManager.hidePopup(null, false);
}
CNDialogManager._popup_commit = function()
{
	CNDialogManager.hidePopup(null, true);
}

CNDialogManager._maximize_onclick = function()
{
	var dialog = CNDialogManager._findDialogDiv(Util.eventTarget(Event.current()));
	if(dialog) CNDialogManager.toggleDialogMaximize(dialog);
}

CNDialogManager.toggleDialogMaximize = function(dialog)
{
	dialog._maximized ? CNDialogManager.restoreDialog(dialog) : CNDialogManager.maximizeDialog(dialog);
}

CNDialogManager._setTopButtonImage = function(button, image)
{
	var element = button.firstChild;
	var source = CNFormManager.themeImagesPath + image;
	element.src = source;
}

CNDialogManager.maximizeDialog = function(dialog)
{
	if(dialog._maximized) return;
	dialog._maximized = true;
	dialog._storedBounds = {x: dialog.offsetLeft, y: dialog.offsetTop, w: dialog.offsetWidth, h: dialog.offsetHeight };
	dialog.className = "popupDialog popupDialogMaximized";
	dialog.style.width = "100%";
	dialog.style.height = "100%";
	dialog.style.top = 0;
	dialog.style.left = 0;
	
	var max = CNDialogManager.getMaxButton(dialog);
	max._img = "restore.png";
	CNDialogManager._setTopButtonImage(max, "restore.png");
	
	if(dialog._maxDelegate) dialog._maxDelegate[0][dialog._maxDelegate[1]](dialog, true);
}

CNDialogManager.restoreDialog = function(dialog)
{
	if(!dialog._maximized) return;
	dialog._maximized = false;
	dialog.className = "popupDialog";
	var b = dialog._storedBounds;
	dialog.style.left = b.x + "px";
	dialog.style.top = b.y + "px";
	dialog.style.width = b.w + "px";
	dialog.style.height = b.h + "px";
	
	var max = CNDialogManager.getMaxButton(dialog);
	max._img = "maximize.png";
	CNDialogManager._setTopButtonImage(max, "maximize.png");
	
	if(dialog._maxDelegate) dialog._maxDelegate[0][dialog._maxDelegate[1]](dialog, false);
}


CNDialogManager.hidePopup = function(dialog, commit, doNotCallback)
{
	if(dialog == null && Event.current()) dialog = CNDialogManager._findDialogDiv(Util.eventTarget(Event.current()));
	if(!dialog) return;
	
	var closeIt = true;
	if(!doNotCallback)
	{
		var fd = dialog._finishDelegate;
		if(fd) 
		{
			closeIt = fd[0][fd[1]](dialog, !commit) !== false;
		}
	}
	
	if(closeIt)
	{
		if(dialog.shadow) dialog.shadow.hide();
		dialog.style.visibility = "hidden";
		dialog._finishDelegate = null;
	}
	if(CNDialogManager._activePopup == dialog) 
	{
		CNDialogManager._activePopup = null;
		Event.del(document, "mousedown", CNDialogManager, CNDialogManager._document_onmousedown);
		Event.del(document, "keypress", CNDialogManager, CNDialogManager._document_onkeypress);
	}
}

// NOTE: revisit - too complicated buttons clean up.
CNDialogManager.destroyDialog = function(dialog)
{
	dialog._finishDelegate = null;
	dialog._maxDelegate = null;
	if(CNFormManager.vista)
	{
		this._destroyButtonsIn(dialog);
		this._destroyButtonsIn(this.getBottom(dialog));
	}

	if(dialog.shadow) dialog.shadow.destroy();
	Util.removeElement(dialog);	
}

CNDialogManager._destroyButtonsIn = function(cont)
{
	var children = cont.children;
	var count = children.length;
	var toDelete = [];
	for(var i = 0; i < count; i++)
	{
		var child = children[i];
		if(child.className.indexOf("cn_button") != -1)
		{ 
			toDelete.push(child.jsObject);
		}
	}
	
	for(var i = 0; i < toDelete.length; i++)
	{
		CNFormManager.destroyJSObject(toDelete[i]);
	}
}

// Content elements start from ix = 2.
CNDialogManager.createDialog = function(title)
{
	var popupDiv = Util.createElement("div", "cnPopupDialogDiv");
	popupDiv._isDialogDiv = true;
	popupDiv.style.display = "none";
	
	document.body.appendChild(popupDiv);
			
	var captionDiv = Util.createElement("div", "cnPopupDialogCaption"); // 0
	popupDiv.appendChild(captionDiv);
	captionDiv.textContent = title;

	var closeButton = Util.createElement("div", "cnDialogCloseButton", null); // 1
	popupDiv.appendChild(closeButton);
	var span = Util.createElement("span", null, null);
	closeButton.appendChild(span);
	span.textContent = 'r';
	
	var dialogContOuter = Util.createElement("div", "dialogContOuter"); // 2
	popupDiv.appendChild(dialogContOuter);

	var contentsDiv = Util.createElement("div", "dialogContents");
	dialogContOuter.appendChild(contentsDiv);
	
	var bottomDiv = Util.createElement("div", "dialogBottom")
	contentsDiv.appendChild(bottomDiv);

	Event.add(closeButton, "mouseenter", CNDialogManager, CNDialogManager._dialog_closeButton_onmouseenter);
	Event.add(closeButton, "mouseleave", CNDialogManager, CNDialogManager._dialog_closeButton_onmouseleave);
	Event.add(closeButton, "click", CNDialogManager, CNDialogManager._popup_cancel);

	new Shadow(popupDiv, false, false);

	Event.add(popupDiv, "mousedown", CNDialogManager, CNDialogManager._popupDiv_onmousedown);
	Event.add(captionDiv, "mousedown", CNDialogManager, CNDialogManager._captionDiv_onmousedown);
	
	return popupDiv;
}

// Note, resizable is used by fm dialog-forms only. Blue dialog is created by fm.
CNDialogManager.createVistaDialog = function(title, resizable)
{
	var dialog = $('__vistaDialogBG').cloneNode(true);
	dialog.removeAttribute("id");
	dialog._isDialogDiv = true;
	dialog._isResizable = resizable;
	
	document.body.appendChild(dialog);
	var tr = dialog.firstChild.rows[0];
	Event.add(dialog.children[4], "mousedown", CNDialogManager, CNDialogManager._captionDiv_onmousedown);	
	Event.add(dialog.children[3], "mousedown", CNDialogManager, CNDialogManager._captionDiv_onmousedown);	
	
	var close = dialog.firstChild.nextSibling;
	close._img = resizable ? "close-2.png" : "close.png";
	Event.add(close, "mouseenter", CNDialogManager, CNDialogManager._topButton_onmouseenter);
	Event.add(close, "mouseleave", CNDialogManager, CNDialogManager._topButton_onmouseleave);
	Event.add(close, "mousedown", CNDialogManager, CNDialogManager._topButton_onmousedown);
	Event.add(close, "mouseup", CNDialogManager, CNDialogManager._topButton_onmouseup);
	Event.add(close, "click", CNDialogManager, CNDialogManager._topButton_onclick);
	if(title != null) CNDialogManager.setCaption(dialog, title);
	
	if(resizable)
	{
		var max = CNDialogManager.getMaxButton(dialog);
		max.style.visibility = "visible";
		close.firstChild.className = "withMaximize";
		max._img = "maximize.png";
		Event.add(max, "mouseenter", CNDialogManager, CNDialogManager._topButton_onmouseenter);
		Event.add(max, "mouseleave", CNDialogManager, CNDialogManager._topButton_onmouseleave);
		Event.add(max, "mousedown", CNDialogManager, CNDialogManager._topButton_onmousedown);
		Event.add(max, "mouseup", CNDialogManager, CNDialogManager._topButton_onmouseup);
		Event.add(max, "click", CNDialogManager, CNDialogManager._maximize_onclick);
	}

	return dialog;
}

CNDialogManager.getContents = function(dialog)
{
	if(CNFormManager.vista) return dialog.children[4].lastChild.firstChild;
	return dialog.children[2].firstChild;
}
CNDialogManager.getBottom = function(dialog)
{
	return this.getContents(dialog).firstChild;
}

CNDialogManager.setCaption = function(dialog, caption)
{
	if(CNFormManager.vista) 
	{
		var captionDiv = dialog.children[3].lastChild;
		captionDiv.textContent = caption;
		captionDiv.style.position = "relative"; // Workaround.
		dialog.children[3].firstChild.style.width = captionDiv.offsetWidth + 12 + "px";
		captionDiv.style.position = "absolute";
	}
	else
	{
		dialog.firstChild.textContent = caption;
	}
}
CNDialogManager.getCloseButton = function(dialog)
{
	return dialog.children[1];
}
CNDialogManager.getMaxButton = function(dialog)
{
	return dialog.children[2];
}

CNDialogManager._idCount = 0;
CNDialogManager.createDialogButton = function(dialog, caption, commit)
{
	var b;
	if(CNFormManager.vista)
	{
		var button = new CN_button();
		button.elementID = "autoid_" + CNDialogManager._idCount++;
		b = button.createElement(Util.wrapIntoNode({}), dialog);
		b.id = "";
		button.loadData(Util.wrapIntoNode({value: caption}));
		CNFormManager.themeJSObjects.push(button);
	}
	else
	{
		b = Util.createElement("button", "cnDialogButton");
		b.textContent = caption;
		Event.add(b, "mouseenter", CNDialogManager, _CN_button_onmouseenter);
		Event.add(b, "mouseleave", CNDialogManager, _CN_button_onmouseleave);
		dialog.appendChild(b);
	}
	if(commit === true) Event.add(b, "click", CNDialogManager, CNDialogManager._popup_commit);
	else if(commit === false) Event.add(b, "click", CNDialogManager, CNDialogManager._popup_cancel);
	return b;
}

CNDialogManager.createBottomButton = function(dialog, caption, commit)
{
	var bottom = this.getBottom(dialog);
	var b = this.createDialogButton(bottom, caption, commit);
	b.style.marginLeft = "4px";
	b.style.position = "relative";
	b.style.display = "inline";
	return b;
}

CNDialogManager.showDialog = function(dialogElement, onFinishDelegate, centered, animate, onMaximizeDelegate)
{
	dialogElement.style.zIndex = top.__ontopZ++;
	dialogElement.style.visibility = "hidden";
	dialogElement.style.display = "block";
	if(centered)
	{
		dialogElement.style.left = (document.body.clientWidth - parseInt(dialogElement.offsetWidth)) / 2;
		dialogElement.style.top = (document.body.clientHeight - parseInt(dialogElement.offsetHeight)) / 2;
	}

	if(onFinishDelegate) dialogElement._finishDelegate = onFinishDelegate;
	if(onMaximizeDelegate) dialogElement._maxDelegate = onMaximizeDelegate;
	dialogElement.style.visibility = "visible";
	if(dialogElement.shadow) dialogElement.shadow.show();
}

CNDialogManager.showPopupDialog = function(dialogElement, onFinishDelegate)
{
	if(CNDialogManager._activePopup) 
	{
		CNDialogManager.hideDialog(CNDialogManager._activePopup);
	}
	else
	{
		Event.add(document, "mousedown", CNDialogManager, CNDialogManager._document_onmousedown);
		Event.add(document, "keypress", CNDialogManager, CNDialogManager._document_onkeypress);
	}
	CNDialogManager._activePopup = dialogElement;

	CNDialogManager.showDialog(dialogElement, onFinishDelegate);
}

CNDialogManager.hideDialog = function(dialogElement)
{
	CNDialogManager.hidePopup(dialogElement, false);
}

CNDialogManager._document_onmousedown = function()
{
	Event.del(document, "mousedown", CNDialogManager, CNDialogManager._document_onmousedown);
	if(!CNDialogManager._activePopup.contains(Util.eventTarget(Event.current()))) 
	{
		CNDialogManager.hidePopup(CNDialogManager._activePopup, false);
	}
}

CNDialogManager._document_onkeypress = function(ev)
{
	Event.del(document, "keypress", CNDialogManager, CNDialogManager._document_onkeypress);
	if(Event.keyValue(Event.normalize(ev)) == 27)
	{
		CNDialogManager.hidePopup(CNDialogManager._activePopup, false);
	}
}

CNDialogManager._topButton_onmouseenter = function()
{
	var l = Util.eventTarget(Event.current());
	if(l._disabled) return;
	l.style.zIndex = 2;
	CNDialogManager._setTopButtonImage(l, "hover-" + l._img);
}
CNDialogManager._topButton_onmouseleave = function()
{
	var l = Util.eventTarget(Event.current());
	if(l._disabled) return;
	CNDialogManager._setTopButtonImage(l, l._img);
	l.style.zIndex = 1;
}
CNDialogManager._topButton_onmousedown = function()
{
	var l = Util.findByClassName(Util.eventTarget(Event.current()), "dialogTopButton");
	if(l._disabled) return;
	CNDialogManager._setTopButtonImage(l, "down-" + l._img);
}
CNDialogManager._topButton_onmouseup = function()
{
	var l = Util.findByClassName(Util.eventTarget(Event.current()), "dialogTopButton");
	if(l._disabled) return;
	CNDialogManager._setTopButtonImage(l, "hover-" + l._img);
}
CNDialogManager._topButton_onclick = function()
{
	var l = Util.findByClassName(Util.eventTarget(Event.current()), "dialogTopButton");
	if(l._disabled) return;
	CNDialogManager.hidePopup(null, false);
}

/*
 * Alert notification strip.
 *
 * The historical client creates the alert chrome here; it is not supplied by
 * the theme HTML.  Keep that boundary explicit so the standards client works
 * with both the historical placeholder and newer theme shells.
 */
function AlertIcons(element, isCloned)
{
	this.element = Util.createElement("div", "cn_alert_icons");
	element.appendChild(this.element);
	this.element.innerHTML = "<span class=alertsContainer><span class=alertsSpan></span></span>";
	this.element.jsObject = this;

	this._container = this.element.firstChild || this.element.children[0];
	this._span = this._container.firstChild || this._container.children[0];

	this._leftButton = VistaSupport.createImageSetButton(null, 18, 18, 0);
	this._leftButton.style.display = "";
	this._leftButton.className = "leftAlertsButton";
	this.element.insertBefore(this._leftButton, this.element.firstChild);

	this._rightButton = VistaSupport.createImageSetButton(null, 18, 18, 18);
	this._rightButton.style.display = "";
	this._rightButton.className = "rightAlertsButton";
	this.element.appendChild(this._rightButton);

	this._leftButton._isLeftButton = true;
	this._rightButton._isRightButton = true;
	Event.add(this._leftButton, "mousedown", this, this._button_onmousedown);
	Event.add(this._leftButton, "mouseup", this, this._button_onmouseup);
	Event.add(this._leftButton, "mouseleave", this, this._button_onmouseup);
	Event.add(this._rightButton, "mousedown", this, this._button_onmousedown);
	Event.add(this._rightButton, "mouseup", this, this._button_onmouseup);
	Event.add(this._rightButton, "mouseleave", this, this._button_onmouseup);

	if(!isCloned) this._cloned = [];
	this._isCloned = isCloned;
	this._icons = [];
	this._timer = null;
	this._idClicked = -1;
	this._scrollStep = 3;
}
var proto = AlertIcons.prototype;

proto.unload = function()
{
	this.clean(true);
	Event.purge(this);
}

proto.clean = function(doNotUpdate)
{
	for(var i in this._icons)
	{
		Util.removeElement(this._icons[i]);
	}
	this._icons = [];

	if(!doNotUpdate) this._updatePlaceholder();
}

proto.loadData = function(node)
{
	this._lastIcon = null;
	this._idClicked = -1;

	var removeall = Util.xmlSelectSingleNode(node, "removeall");
	if(removeall) this._removeAll();

	var removealerts = Util.xmlSelectNodes(node, "removealert");
	for(var i = 0; i < removealerts.length; i++)
	{
		var id = removealerts[i].getAttribute("id");
		if(!id) continue;
		this._removeAlert(String(id));
	}
	if(removeall || removealerts.length > 0) this._setSpanLeft(0);

	var newalerts = Util.xmlSelectNodes(node, "newalert");
	for(var i = 0; i < newalerts.length; i++)
	{
		this._addAlert(newalerts[i]);
	}

	var self = this;
	setTimeout(function(){ self._updatePlaceholder(); });

	this._sort();

	if(newalerts.length > 0 && !this._isCloned)
	{
		var attr = node.getAttribute("sound");
		if(attr)
		{
			var alertSound = document.getElementById("__si_alert_sound");
			if(!alertSound)
			{
				alertSound = document.createElement("audio");
				alertSound.id = "__si_alert_sound";
				alertSound.preload = "auto";
				alertSound.setAttribute("aria-hidden", "true");
				alertSound.style.display = "none";
				document.body.insertBefore(alertSound, document.body.firstChild);
			}
			alertSound.src = String(attr);
			alertSound.currentTime = 0;
			var playResult = alertSound.play();
			if(playResult && playResult["catch"]) playResult["catch"](function() {});
		}
	}

	if(!this._isCloned)
	{
		for(var i = 0; i < this._cloned.length; i++) {
			this._cloned[i].loadData(node);
		}
	}
}

proto._removeAll = function()
{
	var list = [];
	for(var id in this._icons) list.push(id);
	for(var i = 0; i < list.length; i++) this._removeAlert(list[i]);
	this._icons = [];
}

proto.storeData = function(xmldoc)
{
	if(this._idClicked == -1) return;
	var node = xmldoc.createElement("alert");
	node.setAttribute("id", this._idClicked);
	if(this._isCloned) node.setAttribute("fromDialog", "true");
	this._idClicked = -1;
	return node;
}

proto._sort = function()
{
	var list = [];
	for(var id in this._icons) list.push(this._icons[id]);

	list.sort(function(a, b)
	{
		if(a._sortIX < b._sortIX) return -1;
		if(a._sortIX == b._sortIX) return 0;
		return 1;
	});

	for(var i = 0; i < list.length; i++) this._span.appendChild(list[i]);
}

proto._addAlert = function(node)
{
	var id = node.getAttribute("id");
	var icon = node.getAttribute("icon");
	if(!id || !icon) return;
	id = String(id);
	icon = String(icon);

	var sortIX = 0;
	var attr = node.getAttribute("sortIndex");
	if(attr) sortIX = parseInt(attr, 10);

	var img = this._icons[id];
	if(!img)
	{
		img = Util.createElement("img", null, {width: 16, height: 16});
		img.style.marginRight = "2px";
		this._icons[id] = img;
		img._id = id;
		Event.add(img, "click", this, this._img_onclick);
	}
	img.src = icon;
	img._sortIX = sortIX;

	// Always move the icon to the beginning of the alert strip.
	if(!this._lastIcon) this._span.insertBefore(img, this._span.firstChild);
	else this._lastIcon.parentNode.insertBefore(img, this._lastIcon.nextSibling);
	this._lastIcon = img;

	var tooltip = node.getAttribute("tooltip");
	if(tooltip) Tooltip.attach(img, String(tooltip));

	if(node.getAttribute("alwaysEnabled") == "true")
	{
		img._alwaysEnabled = true;
		img.style.cursor = "pointer";
	}
}

proto._removeAlert = function(id)
{
	var icon = this._icons[String(id)];
	if(icon)
	{
		Util.removeElement(icon);
		delete this._icons[id];
	}
}

proto._getSpanLeft = function()
{
	var value = parseInt(Util.getStyle(this._span, "left"), 10);
	if(isNaN(value)) value = this._span.offsetLeft || 0;
	return value;
}

proto._setSpanLeft = function(value)
{
	this._span.style.left = String(value) + "px";
}

proto._updatePlaceholder = function()
{
	if(this._container.clientWidth == 0) return;

	var spanLeft = this._getSpanLeft();
	if(this._span.offsetWidth > this._container.clientWidth)
	{
		Util.toggleClass(this.element, "cn_alert_icons_w_right",
			spanLeft + this._span.offsetWidth > this._container.clientWidth);
		Util.toggleClass(this.element, "cn_alert_icons_w_left", spanLeft < 0);
		this._rightButton.style.visibility =
			spanLeft + this._span.offsetWidth > this._container.clientWidth ? "visible" : "hidden";
		this._leftButton.style.visibility = spanLeft < 0 ? "visible" : "hidden";
	}
	else
	{
		Util.removeClass(this.element, "cn_alert_icons_w_right");
		Util.removeClass(this.element, "cn_alert_icons_w_left");
		this._leftButton.style.visibility = this._rightButton.style.visibility = "hidden";
	}
}

proto._button_onmousedown = function(nativeEvent)
{
	var jso = CNUtil.dispatchObject(nativeEvent);
	if(jso && jso.button_onmousedown) jso.button_onmousedown(nativeEvent);
	Util.cancelEvent(nativeEvent);
}
proto.button_onmousedown = function(nativeEvent)
{
	var target = Util.eventTarget(nativeEvent);
	if(target && target._isLeftButton) this.scrollRight();
	else this.scrollLeft();
}

proto._button_onmouseup = function(nativeEvent)
{
	var jso = CNUtil.dispatchObject(nativeEvent);
	if(jso && jso.button_onmouseup) jso.button_onmouseup(nativeEvent);
}
proto.button_onmouseup = function(nativeEvent)
{
	this._updatePlaceholder();
	if(!this._timer) return;
	clearTimeout(this._timer);
	this._timer = null;
}

proto.scrollLeft = function()
{
	var left = this._getSpanLeft() - this._scrollStep;
	if(left + this._span.offsetWidth <= this._container.clientWidth)
	{
		left = this._container.clientWidth - this._span.offsetWidth;
		this._setSpanLeft(left);
		this._updatePlaceholder();
	}
	else
	{
		this._setSpanLeft(left);
		var obj = this;
		this._timer = setTimeout(function(){ obj.scrollLeft(); }, 20);
	}
}

proto.scrollRight = function()
{
	var left = this._getSpanLeft() + this._scrollStep;
	if(left >= 0)
	{
		this._setSpanLeft(0);
		this._updatePlaceholder();
	}
	else
	{
		this._setSpanLeft(left);
		var obj = this;
		this._timer = setTimeout(function(){ obj.scrollRight(); }, 20);
	}
}

proto._img_onclick = function(nativeEvent)
{
	var jso = CNUtil.dispatchObject(nativeEvent);
	if(jso && jso.img_onclick) jso.img_onclick(nativeEvent);
}
proto.img_onclick = function(nativeEvent)
{
	var target = Util.eventTarget(nativeEvent);
	if(!target) return;
	if(this._disabled && !target._alwaysEnabled) return;

	this._idClicked = target._id;
	this.formManager.postData(this.element);
}

proto.set_disabled = function(val)
{
	this._disabled = val;
	this._span.className = this._disabled ? "alertsSpan alertsSpan_disabled" : "alertsSpan";
}

proto.cloneImagesFrom = function(otherAlerts)
{
	var cloned = otherAlerts._span.cloneNode(true);
	this._container.replaceChild(cloned, this._span);
	this._span = cloned;

	var imgs = this._span.getElementsByTagName("img");
	for(var i = 0; i < imgs.length; i++) this._icons[imgs[i]._id] = imgs[i];
	this._updatePlaceholder();
}

proto.cloneToDialogHeader = function(header)
{
	var cloned = new AlertIcons(header, true);
	cloned.cloneImagesFrom(this);
	this._cloned.push(cloned);
	return cloned;
}

/*
	v. 2.0.4
*/
function TopButtons(element)
{
	this._cols = 3;
	this._colWidth = 166;
	this._scrollStep = 8;
	
	this.element = element;
	element.jsObject = this;

	this._topSpan = document.createElement("span");
	this.element.appendChild(this._topSpan);

	this._defaultButtons = false;

	this._timer = null;
	this._buttons = [];
	this._sections = [];
	this._disabled = false;
	
	this._createMore();
	
	if(CNFormManager.vista) this._buildHover();
}
var proto = TopButtons.prototype; 

proto._buildHover = function()
{
	var div = this._hoverDiv = Util.createElementFromHTML("<div class='topButtonHover'>");
	document.body.appendChild(div);
	var div1 = Util.createElementFromHTML("<div class='topButtonHover1'>");
	div.appendChild(div1);
	var div2 = Util.createElementFromHTML("<div class='topButtonHover2'>");
	div.appendChild(div2);
	var div3 = Util.createElementFromHTML("<div class='topButtonHover3'>");
	div.appendChild(div3);
}


proto.unload = function()
{
	this._buttons = null;
	this._sections = null;

	if(this._moreDiv && this._moreDiv.shadow) 
	{
		this._moreDiv.shadow.destroy();
		this._moreDiv.shadow = null;
	}

	if(this._moreDiv)
	{
		this._moreDiv.jsObject = null;
		this._moreDiv = null;
	}
}

proto.loadData = function(node)
{
	var createNode = Util.xmlSelectSingleNode(node, "create");
	if(createNode) 
	{
		this._clean();

		var linkNodes = Util.xmlSelectNodes(createNode, "link");
		var count = linkNodes.length;
		this._createButtons(this._topSpan, linkNodes, count, true);
		//this._modifyButtonsByNodes(linkNodes, count);	 // No need, as modifyButton is called for every button in _createButton.

		this._createMoreSections(createNode);
	}

	var modifyNode = Util.xmlSelectSingleNode(node, "modify");
	if(modifyNode)
	{
		var linkNodes = Util.xmlSelectNodes(modifyNode, "link");
		var count = linkNodes.length;
		this._modifyButtonsByNodes(linkNodes, count);	

		this._modifyMoreSections(modifyNode);
	}
}

proto.set_disabled = function(disabled)
{
	this._disabled = disabled;
	Util.toggleClass(this.element, "topRightControls_disabled", disabled);
}

proto._createMoreSections = function(node)
{
	var moreNode = Util.xmlSelectSingleNode(node, "more");
	if(!moreNode) return;
	
	this._modifyMore(moreNode);
	
	var sections = Util.xmlSelectNodes(moreNode, "section");
	for(var i = 0; i < sections.length; i++)
	{
		this._createSection(sections[i]);
	}
}

proto._modifyMore = function(node)
{
	var attr = node.getAttribute("visible");
	this._moreLink.style.display = attr != "false" ? "inline-flex" : "none";
	
	var doResize = false;
	attr = node.getAttribute("colWidth");
	if(attr)
	{
		var colWidth = parseInt(attr, 10);
		if(!isNaN(colWidth) && colWidth != this._colWidth)
		{
			this._colWidth = colWidth;
			doResize = true;
			var w = this._colWidth + "px";
			for(var id in this._buttons)
			{
				var b = this._buttons[id];
				if(!b._top) 
				{
					b.style.width = w;
				}
			}
		}
	}

	attr = node.getAttribute("cols");
	if(attr)
	{
		var cols = parseInt(attr, 10);
		if(!isNaN(cols) && cols != this._cols) 
		{
			this._cols = cols;
			doResize = true;
		}
	}
	
	if(doResize) this._resizeMoreSubDiv();
}

proto._resizeMoreSubDiv = function()
{
	this._moreSubDiv.style.width = (this._cols * this._colWidth + 2) + "px";
	var lines = this._moreSubDiv.getElementsByTagName("div");
	var count = lines.length;
	//var w = (this._cols * this._colWidth - 6) + "px";
	for(var i = 0; i < count; i++)
	{
		var line = lines[i];
		if(line.className != "sectionCaptionLine") continue;
		this._resizeSectionLine(line);
		//line.style.width = w;
	}
}

proto._createSection = function(node)
{
	var div = document.createElement("div");
	this._moreSubDiv.appendChild(div);

	this._createSectionCaption(div);
	
	var linkNodes = Util.xmlSelectNodes(node, "link");
	var count = linkNodes.length;
	this._createButtons(div, linkNodes, count, false);
	this._modifyButtonsByNodes(linkNodes, count);	
		
	var attr = node.getAttribute("id");
	if(attr) this._sections[String(attr)] = div;
	
	this._modifySection(div, node);
}

proto._modifyMoreSections = function(node)
{
	var moreNode = Util.xmlSelectSingleNode(node, "more");
	this._modifyMore(moreNode);

	var sections = Util.xmlSelectNodes(moreNode, "section");
	count = sections.length;
	for(var i = 0; i < count; i++)
	{
		var sectionNode = sections[i];
		this._modifySectionByNode(sectionNode);
		
		var linkNodes = Util.xmlSelectNodes(sectionNode, "link");
		var count = linkNodes.length;
		if(count > 0) this._modifyButtonsByNodes(linkNodes, count);			
	}
}

proto._modifySectionByNode = function(node)
{
	var attr = node.getAttribute("id");
	if(!attr) return;
	var id = String(attr);

	var section = this._sections[id];
	if(!section) return;
	
	this._modifySection(section, node);
}

proto._modifySection = function(section, node)
{
	var attr = node.getAttribute("visible");
	if(attr) section.style.display = attr == "true" ? "block" : "none";

	attr = node.getAttribute("caption");
	if(attr != null)
	{
		var caption = String(attr);
		var captionDiv = section.firstChild;
		if(caption == "")
		{
			captionDiv.lastChild.textContent = "";
			captionDiv.style.display = "none";
		}
		else
		{
			captionDiv.lastChild.textContent = caption;
			captionDiv.style.display = "block";
		}
		this._resizeSectionLine(captionDiv.firstChild);
	}
}

proto._createSectionCaption = function(div)
{
	var captionDiv = document.createElement("div");
	div.insertBefore(captionDiv, div.firstChild);
	captionDiv.className = "sectionCaptionDiv";

	var span2 = document.createElement("div");
	span2.className = "sectionCaptionLine";
	captionDiv.appendChild(span2);
	
	var span1 = document.createElement("span");
	span1.className = "sectionCaptionText";
	captionDiv.appendChild(span1);
	
	this._resizeSectionLine(span2);

	captionDiv.style.display = "none";
}

proto._resizeSectionLine = function(l)
{
	var x = l.nextSibling.offsetWidth;
	l.style.left = x + "px";
	l.style.width = Math.max(1, ((this._colWidth * this._cols) - 6) - x) + "px";
}

proto._modifyButtonsByNodes = function(linkNodes, count)
{
	for(var i = 0; i < count; i++)
	{
		var linkNode = linkNodes[i];

		var id = String(linkNode.getAttribute("id"));
		var button = this._buttons[id];
		if(!button) continue;
		
		this._modifyButton(button, linkNode);
	}
}

proto._modifyButton = function(link, linkNode)
{
	var attr = linkNode.getAttribute("text");
	if(attr != null)
	{
		if(attr == "")
		{
			link.lastChild.textContent = "";
			link.lastChild.style.display = "none";
		}
		else
		{
			link.lastChild.style.display = "inline";
			link.lastChild.textContent = String(attr);
		}
	}

	attr = linkNode.getAttribute("image");
	if(attr != null)
	{
		var imgSpan = link.firstChild;
		if(link._top)
		{
			if(attr == "")
			{
				imgSpan.style.display = "none";
			}
			else
			{
				imgSpan.style.display = "inline-block";
					imgSpan.style.backgroundImage = "url('" + CNFormManager.themeImagesPath + attr + "')";
			}
		}
		else
		{
			link.firstChild.style.display = "inline-block";
			if(attr == "")
			{
					imgSpan.style.backgroundImage = "";
			}
			else
			{
					imgSpan.style.backgroundImage = "url('" + CNFormManager.themeImagesPath + attr + "')";
			}
		}
	}

	var attr = linkNode.getAttribute("action");
	if(attr != null) link._action = String(attr);
	else
	{
		attr = linkNode.getAttribute("url")
		if(attr != null) link._url = String(attr);
	}

	var attr = linkNode.getAttribute("enabled");
	if(attr) this._button_setDisabled(link, attr == "false");

	attr = linkNode.getAttribute("visible");
	if(attr) this._button_setVisible(link, attr == "true");
	
	attr = linkNode.getAttribute("alwaysEnabled")
	if(attr)
	{
		var alwaysEnabled = attr == "true";
		link._alwaysEnabled = alwaysEnabled;
		link.style.cursor = alwaysEnabled ? "pointer" : "";
	}
}

proto._createMore = function()
{
	var link = Util.createElementFromHTML("<a href='#' class='moreButton hoverable' tabIndex='-1'>");
	link.style.display = "none";

	var moreText = document.createElement("span");
	moreText.className = "moreText";
	moreText.textContent = "More";
	link.appendChild(moreText);

	this.element.appendChild(document.createTextNode("  "));
	this.element.appendChild(link);
	var moreIcon = document.createElement("span");
	moreIcon.className = "moreIcon";
	var downAr = Util.createElementFromHTML("<img src='" + CNFormManager.themeImagesPath + "/down-ar-1.gif'>");
	moreIcon.appendChild(downAr);
	link.appendChild(moreIcon);
	Event.add(link, "mouseover", this, this._more_onmouseover);
	Event.add(link, "mouseout", this, this._more_onmouseout);
	
	var div = document.createElement('div');
	div.className = "topButtonsMoreDiv"
	document.body.appendChild(div);	
	this._moreDiv = div;	
	
	this._moreLink = link;
	new Shadow(div, false, true);
	
	Event.add(div, "mouseover", this, this._moreDiv_onmouseover);
	Event.add(div, "mouseout", this, this._moreDiv_onmouseout);
		
	this._moreDiv.jsObject = this;

	var subDiv = document.createElement("div");
	this._moreDiv.appendChild(subDiv);
	this._moreSubDiv = subDiv;
}

proto._more_onmouseout = function()
{
	CNUtil.dispatchObject().more_onmouseout();
}
proto.more_onmouseout = function()
{
	if(this._moreDiv.contains((Event.current() || {}).relatedTarget)) return;
	this._hideMore();
}

proto._more_onmouseover = function()
{
	CNUtil.dispatchObject().more_onmouseover();
}
proto.more_onmouseover = function()
{
	if(this._hideMoreTO) 
	{
		clearTimeout(this._hideMoreTO)
		this._hideMoreTO = null;
	}
	
	if(Util.getStyle(this._moreDiv, "visibility") == "inherit") return;

	if(CNFormManager.vista) this._showHover(this._moreLink);
	
	var l = CNUtil.findTag(Util.eventTarget(Event.current()), "A");
	var xy = CNUtil.findAbsolutePos(l);
	//this._moreDiv.style.display = "block";
	this._moreDiv.style.visibility = "inherit";
	this._moreDiv.style.width = "10px";
	this._moreDiv.style.height = "10px";

	var offset = CNFormManager.vista ? 4 : 0;
	this._moreDiv.style.left = xy.x - this._moreDiv.offsetWidth + l.offsetWidth + offset + "px";
	this._moreDiv.style.top = xy.y + l.offsetHeight - 6 + "px";
	
	l.style.opacity = "1";
	
	var w = this._moreSubDiv.offsetWidth + 2;
	this._moreInAnim = new AnimResize(this._moreDiv, w, this._moreSubDiv.offsetHeight + 2, w, 0);	
	this._moreInAnim.onend = function()
	{
		if(this.l.shadow) this.l.shadow.show();
	}	
	Animator.start(this._moreInAnim);
}

proto._moreDiv_onmouseout = function()
{
	CNFormManager.getBaseFormManager()._topButtons.moreDiv_onmouseout();
}
proto.moreDiv_onmouseout = function()
{
	if(this._moreDiv == (Event.current() || {}).relatedTarget || this._moreDiv.contains((Event.current() || {}).relatedTarget)) return;
	this._hideMore();
}

proto._moreDiv_onmouseover = function()
{
	CNFormManager.getBaseFormManager()._topButtons.moreDiv_onmouseover();
}
proto.moreDiv_onmouseover = function()
{
	if(this._hideMoreTO) 
	{
		clearTimeout(this._hideMoreTO)
		this._hideMoreTO = null;
	}
}

proto._hideMore = function()
{
	if(this._hideMoreTO) return;

	var obj = this;	
	this._hideMoreTO = setTimeout(function(){ obj._hideMore2(); }, 250)
}

proto._hideMore2 = function()
{
	if(CNFormManager.vista) this._hoverDiv.style.visibility = "hidden";

	if(this._moreInAnim) Animator.stop(this._moreInAnim);
	this._hideMoreTO = null;
	if(this._moreDiv.style.visibility == "hidden") return;
	
	if(this._moreDiv.shadow) this._moreDiv.shadow.hide();
	
	var anim = new AnimResize(this._moreDiv, 10, 10, this._moreDiv.offsetWidth, 0);
	anim.onend = function()
	{
		this.l.style.visibility = "hidden";
	}
	Animator.start(anim);
	this._moreLink.style.opacity = "0.75";
}


proto._button_setDisabled = function(button, disabled)
{
	if(disabled)
	{
		button.className = "topButton";
		button.style.cursor = "default";
	}
	else
	{
		button.className = "topButton hoverable";
		button.style.cursor = "";
	}
	button._disabled = disabled;
	button.style.opacity = disabled ? "0.25" : "0.75";
}

proto._button_setVisible = function(button, visible)
{
	button.style.display = visible ? (button._top ? 'inline-flex' : 'inline-block') : 'none';
}

proto._createButtons = function(parent, linkNodes, count, isTop)
{
	var w = this._colWidth + "px";
	for(var i = 0; i < count; i++)
	{
		var linkNode = linkNodes[i];
		var button = this._createButtonIn(parent, linkNode, isTop);
		if(!isTop) button.style.width = w;
	}
}

proto._createButtonIn = function(parent, linkNode, isTop)
{
	var link = Util.createElementFromHTML("<a href=# class='topButton hoverable' tabIndex=-1>");
	parent.appendChild(link);

	var img = document.createElement("span");
	img.className = "imgSpan"
	if(isTop) link._top = true;
	else img.style.display = "inline-block"; // Show image placeholder for more link alignment.
	link.appendChild(img);
	Event.add(link, "mouseenter", this, this._link_onmouseenter);
	Event.add(link, "mouseleave", this, this._link_onmouseleave);
	Event.add(link, "click", this, this._link_onclick);

	var span = document.createElement("span");
	link.appendChild(span);
	
	var attr = linkNode.getAttribute("id");
	if(attr)
	{
		var id = link._id = String(attr);
		this._buttons[id] = link;
	}

	this._modifyButton(link, linkNode);

	return link;
}

proto._link_onmouseenter = function()
{
	var l = Util.eventTarget(Event.current());
	if(l._disabled || this.formManager.isNavigationDisabled() && !l._alwaysEnabled) 
	{
		l.style.cursor = "no-drop";
		return;
	}
	if(CNFormManager.vista) 
	{
		var jso = Util.dispatchObject();
		if(!jso._moreDiv.contains(l)) jso._showHover(l);
	}
	l.style.opacity = "1";
}

proto._showHover = function(l)
{
	var hoverDiv = this._hoverDiv;
	var xy = Util.findAbsolutePos(l, hoverDiv.parentNode || hoverDiv.parentElement);
	hoverDiv.children[1].style.width = l.offsetWidth + 4;
	hoverDiv.style.left = xy.x - 5;
	hoverDiv.style.top = xy.y - 2;
	hoverDiv.style.visibility = "inherit";		
}

proto._link_onmouseleave = function()
{
	var l = Util.eventTarget(Event.current());
	if(l._disabled) return;
	l.style.cursor = "";
	
	if(CNFormManager.vista)
	{
		var jso = Util.dispatchObject();
		if(!jso._moreDiv.contains(l)) jso._hoverDiv.style.visibility = "hidden";
	}
	l.style.opacity = "0.75";
}

proto._clean = function()
{
	var al = document.activeElement;

	for(var id in this._buttons)
	{
		this._buttons[id].className = ""; // 929 - topbuttons recreation moves focus from combo.
		this._buttons[id].style.cssText = "";
		Util.removeElement(this._buttons[id]);
	}
	this._buttons = [];

	for(var id in this._sections)
	{
		Util.removeElement(this._sections[id]);
	}
	this._sections = [];
}

proto._link_onclick = function()
{
	CNUtil.dispatchObject().link_onclick();
}
proto.link_onclick = function()
{
	CNUtil.cancelEvent();
	var link = CNUtil.findTag(Util.eventTarget(Event.current()), 'A');
	if(link._disabled) return;	

	this._hideMore2();

	if(link._url) window.open(link._url);
	else if(link._action == "logout") this.formManager.logoutButtonClick(link._alwaysEnabled);
	else if(link._action == "about") this.formManager.aboutButtonClick(link._alwaysEnabled);	
	else if(link._action == "print") this.formManager.topButtonClick(6, null, link._alwaysEnabled);
	else if(link._id) this.formManager.topButtonClick(link._id, null, link._alwaysEnabled);
}

/*
	v. 0.22
	+ theme support.
	v. 0.12
	+ initial release.
*/
function CN_tabnavigation()
{
	this.formManager = null;
	this._currentTabsDiv = null;
	this._selectedLevels = [];
}

var proto = CN_tabnavigation.prototype;

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);

	var id2 = node.getAttribute("screenItemID2");
	if(!id2)
	{
		alert("ASSERT: screenItemID2 is required for tabnavigation");
		return;
	}

	id2 = "__si_" + id2;
	this._level2ParentElement =	document.getElementById(id2);
	if(!this._level2ParentElement) 
	{
		alert("ASSERT: no " + id2 + " element found by tabnavigation");
		return;
	}
	
	this._level2ParentElement.jsObject = this;
	
	this.element = l;
	l.jsObject = this;

	l.className = "cn_tabnavigation";
	l.style.userSelect = "none";
	
	this._buildElements(node);
	return l;
}

proto.loadData = function(node)
{
	this._loadDataWalkNodes(node, 0);
}

proto.storeData = function(xmldoc)
{
	if(!this._selectedNodeId) 
	{
		alert("ASSERT: no _selectedNodeId.");
		return;
	}
	
	var node = xmldoc.createElement("navigation");
	node.setAttribute("form", this._selectedNodeId);
	return node;
}

proto.unload = function()
{
	for(var i = 0; i < this._selectedLevels.length; i++) this._selectedLevels[i] = null;
	this._selectedLevels = null;

	this._level2ParentElement.jsObject = null;
	this._level2ParentElement.innerHTML = "";
	this._level2ParentElement = null;
}

proto._loadDataWalkNodes = function(parentNode, level)
{
	var subNodes = Util.xmlSelectNodes(parentNode, "node");
	var count = subNodes.length;
	for(var i = 0; i < count; i++)
	{
		var node = subNodes[i];
		var attr = node.getAttribute("id");
		if(!attr)
		{
			alert("ASSERT: no id for data/navigation/node.");
			continue;
		}
		var id = String(attr);
		var tab;
		if(level == 0) tab = this.element.querySelector("#" + "navigationTab_" + id);
		else if(level == 1) tab = this._level2ParentElement.querySelector("#" + "navigationTab_" + id);
		else
		{
			alert("ASSERT: only two levels are supported for tabnavigation.");
			return;
		}
		
		if(tab.length)
		{
			alert("ASSERT: got tab collection for id " + id);
			return;
		}

		attr = node.getAttribute("enabled");
		if(attr) tab.disabled = attr == "false";

		attr = node.getAttribute("visible");
		if(attr) 
		{
			tab.style.display = attr == "false" ? "none" : "inline";
		}
		
		if(level == 0) this._loadDataWalkNodes(node, level + 1);
	}
}

proto._buildElements = function(node)
{
	var nodes = Util.xmlSelectNodes(node, "node");
	var count = nodes.length;
	for(var i = 0; i < count; i++)
	{
		var node = nodes[i];

		var tab = this._appendTab(node, this.element, 0);

		var subNodes = Util.xmlSelectNodes(node, "node");
		if(subNodes.length > 0)
		{
			var subTabsDiv = (function(){ var el = document.createElement("div"); el.className = 'subTabsDiv'; return el; })();
			this._level2ParentElement.appendChild(subTabsDiv);
			this._buildSubNodes(subNodes, subTabsDiv);
			subTabsDiv._parentNodeId = tab._nodeId;
			subTabsDiv._parentTabId = String(tab.id);
			subTabsDiv.id = "navigationTabsDiv_" + tab._nodeId;
		}
	}
}

proto._buildSubNodes = function(nodes, parentElement)
{
	var count = nodes.length;
	for(var i = 0; i < count; i++)
	{
		var node = nodes[i];
		this._appendTab(node, parentElement, 1);
	}
}

proto._appendTab = function(node, parentElement, level)
{
	var table = (function(){ var el = document.createElement("table"); el.align = 'bottom'; el.border = '0'; el.cellPadding = '0'; el.cellSpacing = '0'; el.className = 'topTab'; return el; })();
	parentElement.appendChild(table);
	var tbody = document.createElement('tbody');
	table.appendChild(tbody);
	var tr = document.createElement("tr");
	tbody.appendChild(tr);
	var td1 = document.createElement("td");
	tr.appendChild(td1);
	var img1 = (function(){ var el = document.createElement("img"); el.width = '12'; el.height = '26'; return el; })();
	td1.appendChild(img1);
	var td2 = (function(){ var el = document.createElement("td"); el.valign = 'top'; el.className = 'topTabTextTD'; el.nowrap = 'on'; el.style.userSelect = "none"; return el; })();
	tr.appendChild(td2)
	var td3 = document.createElement("td");
	tr.appendChild(td3);
	var img3 = (function(){ var el = document.createElement("img"); el.width = '11'; el.height = '26'; return el; })();
	td3.appendChild(img3);
	
	table._level = level;

	td2.textContent = String(node.getAttribute("caption"));

	var attr = node.getAttribute("id");
	if(!attr) alert("ASSERT: no id for navigation node: " + node.getAttribute("caption"));
	var id = String(attr);

	table._nodeId = id;
	table.id = "navigationTab_" + id;

	this.unselectTab(table);
	
	Event.add(table, "mouseenter", this, this._tab_onmouseenter);
	Event.add(table, "mouseleave", this, this._tab_onmouseleave);	
	Event.add(table, "click", this, this._tab_onclick);
	
	return table;
}

proto._findTopTab = function(nodeId)
{
	var children = this.element.children;
	var count = children.length;
	for(var i = 0; i < count; i++)
	{
		var child = children[i];
		if(child._nodeId == nodeId)
		{
			return child;
		}
	}
	return null;
}

proto.selectFormNode = function(nodeId)
{
	var id = "navigationTab_" + nodeId;
	
	// 1. Try to find top tab.
	var tab = this.element.querySelector("#" + id);
	if(tab) 
	{
		if(tab.length > 0) tab = tab[0];
		this.selectTab(tab);
		return;
	}
	
	// 2. Try to find sub tab.
	tab = this._level2ParentElement.querySelector("#" + id);
	if(tab) 
	{
		if(tab.length > 0) tab = tab[0];
		this.selectTab(tab);
		// And also select top tab.
		
		var tabDiv = tab.parentElement;
		tabDiv.style.visibility = "inherit";
		var topTab = this.element.querySelector("#" + tabDiv._parentTabId);
		this.selectTab(topTab);
		
		return;
	}
	alert("ASSERT: can't find navigation tab: " + nodeId);	
}

proto.showSecondLevel = function(formId)
{
	var tab = this._level2ParentElement.querySelector("#" + "navigationTab_" + formId);
	if(!tab)
	{
		alert("ASSERT: can't find tab: " + formId);
		return;
	}

	if(tab.length > 0)
	{
		alert("ASSERT: duplicate navigation nodes with id: " + formId);
		tab = tab[0];
	}

	var tabsDiv = tab.parentElement;
	tabsDiv.style.visibility = "inherit";
	this._currentTabsDiv = tabsDiv.id;
	
	this._level2ParentElement.style.display = "block";
	
	var topTab = this.element.querySelector("#" + tabsDiv._parentTabId);
	this.selectTab(topTab);
}

proto.hideSecondLevel = function()
{
	this._level2ParentElement.style.display = "none";
	if(!this._currentTabsDiv) return;
	
	var tabsDiv = this._level2ParentElement.querySelector("#" + this._currentTabsDiv);
	if(!tabsDiv)
	{
		alert("ASSERT: can't find tabsDiv " + this._currentTabsDiv)
		return;
	}
	tabsDiv.style.visibility = "hidden";
	this._currentTabsDiv = null;
}

proto.isTopTabForm = function(formId)
{
	return this._findTopTab(formId) != null;
}


proto.selectTab = function(tab)
{
	var selectedTab = this._selectedLevels[tab._level];
	if(selectedTab == tab) return;
	if(selectedTab) this.unselectTab(selectedTab);
	
	var suffix = "";
	if(tab._level > 0 && CNFormManager.currentThemeName == "blue") suffix = "-2";

	tab.className = "topTabSelected";
	tab.rows[0].cells[0].children[0].src = CNFormManager.themeImagesPath + "tab-header-2" + suffix + "_01.gif";
	tab.rows[0].cells[1].style.background = "url(" + CNFormManager.themeImagesPath + "tab-header-2_02.gif)";
	tab.rows[0].cells[2].children[0].src = CNFormManager.themeImagesPath + "tab-header-2" + suffix + "_03.gif";	
	tab._isSelected = true;
	
	this._selectedLevels[tab._level] = tab;
}

proto.unselectTab = function(tab)
{
	var suffix = "";
	if(tab._level > 0 && CNFormManager.currentThemeName == "blue") suffix = "-2";

	tab.className = "topTab";
	tab.rows[0].cells[0].children[0].src = CNFormManager.themeImagesPath + "tab-header-1" + suffix + "_01.gif";
	tab.rows[0].cells[1].style.background = "url(" + CNFormManager.themeImagesPath + "tab-header-1_02.gif)";
	tab.rows[0].cells[2].children[0].src = CNFormManager.themeImagesPath + "tab-header-1" + suffix + "_03.gif";	
	tab._isSelected = false;
}

proto._unhoverTab = function(tab)
{
	tab.style.textDecoration = "";
	tab.rows[0].cells[1].style.color = "";
}


// Event handlers. ==========================================
proto._tab_onmouseenter = function(ev)
{
	if(this.formManager._loading || this.formManager.isNavigationDisabled()) return;
	
	var tab = Util.eventTarget(ev);
	tab = CNUtil.findTag(tab, "TABLE");
	if(!tab) return;
	if(tab._isSelected) return;
	tab.style.textDecoration = "underline";
	tab.rows[0].cells[1].style.color = "#5555aa";
}

proto._tab_onmouseleave = function(ev)
{
	this.tab_onmouseleave(ev);
} 
proto.tab_onmouseleave = function(ev)
{
	if(this.formManager._loading || this.formManager.isNavigationDisabled()) return;
	
	var tab = Util.eventTarget(ev);
	tab = CNUtil.findTag(tab, "TABLE");
	if(!tab) return;
	if(tab._isSelected) return;
	this._unhoverTab(tab);
} 

proto._tab_onclick = function(ev)
{
	this.tab_onclick(ev);
}
proto.tab_onclick = function(ev)
{
	if(this.formManager._loading || this.formManager.isNavigationDisabled()) return;

	var tab = CNUtil.findTag(Util.eventTarget(ev), "TABLE");
	if(tab._isSelected) return;
	this._unhoverTab(tab);
	this.selectTab(tab);

	this._selectedNodeId = null;
	if(tab._level == 1 /*|| String(tab._nodeId).length == 6*/)
	{
		this._selectedNodeId = tab._nodeId;
	}
	else
	{
		// Try to find first second level node.
		var tabsDiv = this._level2ParentElement.querySelector("#" + "navigationTabsDiv_" + tab._nodeId);
		if(tabsDiv)
		{
			var tab = tabsDiv.children[0];
			if(tab) this._selectedNodeId = tab._nodeId;
		}
	}
	if(this._selectedNodeId) this.formManager.postData(this.element);	
	else alert("ASSERT: no form available.");
}
var proto = {},
	NavigationCollapseMixin = proto;
proto._unloadCollapseMixin = function() {
	if(this._collapseButton) {
		this._collapseButton.parentNode.removeChild(this._collapseButton);
		this._collapseButton = null;
	}
}
proto._storeCollasedState = function(fragment) {
	if(this._navigationCollapedChanged) {
		var node = fragment.ownerDocument.createElement("navigation");
		node.setAttribute("collapsed", this._navigationCollapsed ? "true" : "false");
		fragment.appendChild(node);
		this._navigationCollapedChanged = false;
	}
}
proto._buildCollapseElements = function() {
	if(CNFormManager.currentThemeName != "blue") return;

	this._collapseBorder = document.createElement("div");
	this._collapseBorder.className = "cn_navigation_collapseBorder";
	this.element.parentNode.appendChild(this._collapseBorder); // Attach to screen item.

	this._collapseButton = VistaSupport.createImageSetButton("nav-collapse-set-2.gif", 4, 22, 0);
	this._collapseButton.className = "collapseButton";
	this._collapseBorder.appendChild(this._collapseButton);
	Tooltip.attach(this._collapseButton, "Click to collapse the navigation");
	Event.add(this._collapseButton, "mouseenter", this, this._collapseButton_mouseenter);
	Event.add(this._collapseButton, "mouseleave", this, this._collapseButton_mouseleave);
	Event.add(this._collapseButton, "click", this, this._collapseButton_click);

	this._pinButton = VistaSupport.createImageSetButton("pin-set.gif", 16, 16, 0);
	this._pinButton.className = "cn_navigation_pinButton";
	this.element.appendChild(this._pinButton);
	Tooltip.attach(this._pinButton, this.pinCollapseText);
	Event.add(this._pinButton, "click", this, this._pinButton_click);

	this._updateCollapseElements();
}
proto._updateCollapseElements = function() {
	if(this._canExpandCollapse) {
		this._pinButton.style.display
			= this._collapseBorder.style.display = "";
		if(this._collapsedTab) {
			this._collapsedTab.style.cursor = "";

		}
	} else {
		this._pinButton.style.display
			= this._collapseBorder.style.display = "none";
		if(this._collapsedTab) {
			this._collapsedTab.style.cursor = "default";

		}
	}
}

proto.pinCollapseText = "Click to collapse the navigation";
proto._collapseButton_mouseenter = function() {
	VistaSupport.setImageSetState(this._collapseButton, "hover");
	Util.addClass(this._collapseBorder, "hover");
}
proto._collapseButton_mouseleave = function() {
	VistaSupport.setImageSetState(this._collapseButton, "normal");
	Util.removeClass(this._collapseBorder, "hover");
}
proto._collapseButton_click = function() {
	if(this._navigationCollapsed) {
		this.expand();
	} else {
		this.collapse();
	}
}

proto.collapse = function(skipAnimation) {
	if(CNFormManager.currentThemeName != "blue") return;
	if(this._animating || !this._quickExpand && this._navigationCollapsed) return;

	this._clear_quickExpandLeaveTO();

	var self = this;
	var animate = ThemeNonCSSStyles.animateNavigation && !skipAnimation;
	this._collapseNavigation(animate, function() {
		self._postCollapse();
	});
}

proto.expand = function(skipAnimation) {
	if(CNFormManager.currentThemeName != "blue") return;
	if(this._animating || !this._navigationCollapsed) return;

	this._preExpand();
	var animate = ThemeNonCSSStyles.animateNavigation && !skipAnimation;
	this._expandNavigation(animate);
}
proto._preExpand = function() {
	this._collapsedTab.style.display = "none";
	this._pinButton.tipText = this.pinCollapseText;
	Tooltip.hide();

	if(this._quickExpand) {
		this._pinButton.style.backgroundImage = "url(" + CNFormManager.themeImagesPath + "pin-set.gif" + ")";
		if(this._pinButton._tipText) {
			this._pinButton.tipText = this._pinButton._tipText;
			this._pinButton._tipText = null;
		}
	}
}


proto._postCollapse = function() {
	this._collapseBorder.style.visibility = "hidden";

	Tooltip.hide();

	if(!this._collapsedTab) this._createCollapsedTab();
	else this._collapsedTab.style.display = "";

	this._leftLine.style.display = "block";
}
proto._createCollapsedTab = function() {
	var div = this._collapsedTab = document.createElement("div");
	div.className = "cn_navigation_collapsedTab";
	div.innerHTML = "<div class='div1'></div><div class='div2'></div><div class='div3'>Navigation</div>";
	var formSI = $("__si_form");
	formSI.appendChild(div);

	Event.add(div, "mouseenter", this, this._collapsedTab_mouseenter);
	Event.add(div, "mouseleave", this, this._collapsedTab_mouseleave);
	Event.add(div, "click", this, this._collapsedTab_click);

	var line = this._leftLine = $('__si_leftFormBGLine');
	formSI.appendChild(line);
}


proto._collapsedTab_mouseenter = function() {
	if(!this._canExpandCollapse) return;

	Util.addClass(this._collapsedTab, "hover");

	if(this._animating) return;

	var self = this;
	this._quickExpandTO = setTimeout(function() {
		self.quickExpand();
	}, 500);
}
proto._collapsedTab_mouseleave = function() {
	if(!this._canExpandCollapse) return;

	Util.removeClass(this._collapsedTab, "hover");

	if(this._animating) return;

	if(this._quickExpandTO) {
		clearTimeout(this._quickExpandTO);
		this._quickExpandTO = null;
	}
}
proto._collapsedTab_click = function() {
	if(this._animating || !this._canExpandCollapse) return;

	this.quickExpand();
}
proto._pinButton_click = function() {
	if(this._animating) return;

	if(this._quickExpand) {
		this.expand(false);
	} else if(this._navigationCollapsed) {
		this.expand();
	} else {
		this.collapse();
	}
	Util.cancelEvent();
}


proto.collapsedNavigationTabWidth = 20;

proto._collapseNavigation = function(animate, completeCallback) {
	var navScreenItem = $("__si_navigation");
	if(!navScreenItem) return; // Can't process unknown screen items.
	var navBGScreenItem = $("__si_navigationBG");

	if(!this._quickExpand) this._lastNavigationParams = {bgWidth: navBGScreenItem.offsetWidth, bgX: navBGScreenItem.offsetLeft, x: navScreenItem.offsetLeft};
	else {
		this._endQuickExpand();
	}

	var self = this;
	var onend = function() {
		navScreenItem.style.display = "none";
		navBGScreenItem.style.display = "none";

		if(!self._quickExpand) {
			self._reserveFormSpace();
			self._navigationCollapedChanged = true;
		}

		self._navigationCollapsed = true;
		self._quickExpand = false;
		self._animating = false;

		if(completeCallback) completeCallback();
	}

	if(animate) {
		this._animating = true;
		var anim1 = new AnimMove(navBGScreenItem, -navBGScreenItem.offsetWidth, navBGScreenItem.offsetTop);
		anim1.onend = onend;
		Animator.start(anim1,
				new AnimMove(navScreenItem, -navBGScreenItem.offsetWidth, navScreenItem.offsetTop));
	} else {
		navBGScreenItem.style.left = -navBGScreenItem.offsetWidth + "px";
		navScreenItem.style.left =  -navBGScreenItem.offsetWidth + "px";

		onend();
	}

}

proto._reserveFormSpace = function() {
	var formSI = $("__si_form");
	formSI.style.left = formSI.offsetLeft - this._lastNavigationParams.bgWidth + this.collapsedNavigationTabWidth + "px";
	formSI.jsObject._anchorW += this._lastNavigationParams.bgWidth - this.collapsedNavigationTabWidth;

	var darkHeaderLeftMargin = 6;
	var darkHeader = $('__si_darkHeader');
	darkHeader.style.left = darkHeader.offsetLeft - this._lastNavigationParams.bgWidth + darkHeaderLeftMargin + "px";
	darkHeader.jsObject._anchorW += this._lastNavigationParams.bgWidth - darkHeaderLeftMargin;

	CNFormManager.getBaseFormManager()._screenLayoutManager.doLayout();
}
proto._releaseFormSpace = function() {
	var formSI = $("__si_form");
	formSI.style.left = formSI.offsetLeft + this._lastNavigationParams.bgWidth - this.collapsedNavigationTabWidth + "px";
	formSI.jsObject._anchorW -= this._lastNavigationParams.bgWidth - this.collapsedNavigationTabWidth;

	var darkHeaderLeftMargin = 6;
	var darkHeader = $('__si_darkHeader');
	darkHeader.style.left = darkHeader.offsetLeft + this._lastNavigationParams.bgWidth - darkHeaderLeftMargin + "px";
	darkHeader.jsObject._anchorW -= this._lastNavigationParams.bgWidth - darkHeaderLeftMargin;

	CNFormManager.getBaseFormManager()._screenLayoutManager.doLayout();
}

proto._expandNavigation = function(animate, completeCallback) {
	if(!this._navigationCollapsed) return;
	var self = this;
	var navScreenItem = $("__si_navigation");
	if(!navScreenItem) return; // Can't process unknown screen items.
	navScreenItem.style.display = "block";

	var navBGScreenItem = $("__si_navigationBG");
	navBGScreenItem.style.display = "block";

	this._releaseFormSpace();
	navBGScreenItem.style.zIndex = "";
	navScreenItem.style.zIndex = "";

	this._leftLine.style.display = "none";

	if(this._quickExpand) this._endQuickExpand();

	var onend = function() {
		self._navigationCollapsed = false;
		self._navigationCollapedChanged = true;
		self._quickExpand = false;
		self._animating = false;
		if(completeCallback) completeCallback();
	}
	if(animate) {
		this._animating = true;
		this._animateExpand(navScreenItem, navBGScreenItem, onend);
	} else {
		navScreenItem.style.left = this._lastNavigationParams.x + "px";
		navBGScreenItem.style.left = this._lastNavigationParams.bgX + "px";
		onend();
	}

}
proto._animateExpand = function(navScreenItem, navBGScreenItem, onendCallback) {
	var anim1 = new AnimMove(navBGScreenItem, this._lastNavigationParams.bgX, navBGScreenItem.offsetTop);
   	anim1.onend = onendCallback;
	Animator.start(anim1,
			new AnimMove(navScreenItem, this._lastNavigationParams.x, navScreenItem.offsetTop));
}
proto.quickExpand = function() {
	if(this._quickExpandTO) {
		clearTimeout(this._quickExpandTO);
		this._quickExpandTO = null;
	}
	if(this._animating) return;

	if(!this._navigationCollapsed) return;
	var navScreenItem = $("__si_navigation");
	if(!navScreenItem) return;
	navScreenItem.style.display = "block";
	var navBGScreenItem = $("__si_navigationBG");
	navBGScreenItem.style.display = "block";
	navBGScreenItem.style.zIndex = 1000;
	navScreenItem.style.zIndex = 1001;

	this._collapseBorder.style.visibility = "hidden";

	this._pinButton.style.backgroundImage = "url(" + CNFormManager.themeImagesPath + "pin-2-set.gif" + ")";
	this._pinButton.tipText = "Click to restore the navigation";

	this._animateExpand(navScreenItem, navBGScreenItem);

	Event.add(document.body, "mouseup", this, this._quickExpand_document_mouseup);
	Event.add(navScreenItem, "mouseleave", this, this._quickExpand_navScreenItem_mouseleave);
	Event.add(navScreenItem, "mouseenter", this, this._quickExpand_navScreenItem_mouseenter);

	this._quickExpand = true;
}
proto._quickExpand_document_mouseup = function() {
	if(this._animating) return;

	var navScreenItem = $("__si_navigation");
	var navBGScreenItem = $("__si_navigationBG");
	if(!navScreenItem.contains(Event.current().target) && !navBGScreenItem.contains(Event.current().target)) {
		this.collapse();
	}
}
proto._quickExpand_navScreenItem_mouseleave = function() {
	if(this._animating) return;
	this._quickExpandStartLeaveTO();
}
proto._quickExpandStartLeaveTO = function() {
	var self = this;
	this._quickExpandLeaveTO = setTimeout(function() {
		self.collapse();
	}, 1000);
}
proto._quickExpand_navScreenItem_mouseenter = function() {
	if(this._animating) return;

	this._clear_quickExpandLeaveTO();
}
proto._clear_quickExpandLeaveTO = function() {
	if(this._quickExpandLeaveTO) {
		clearTimeout(this._quickExpandLeaveTO);
		this._quickExpandLeaveTO = null;
	}
}

proto._endQuickExpand = function() {
	if(this._quickExpand) {
		this._collapseBorder.style.visibility = "";
		Event.del(document.body, "mouseup", this, this._quickExpand_document_mouseup);
		var navScreenItem = $("__si_navigation");
		Event.del(navScreenItem, "mouseleave", this, this._quickExpand_navScreenItem_mouseleave);
		Event.del(navScreenItem, "mouseenter", this, this._quickExpand_navScreenItem_mouseenter);
	}
}
proto = null;
/*
	v. 2.0.2
	+ simplified move/slide code, using Animator now.
*/
function CN_navigation()
{
	this.formManager = null;

	this.isBuilt = false;
	
	this.activePanel = null;
	this.panelCount = 0;
	this.panels = null;
	
	this.disabler = null;
	
	this._disabled = false;

	this.resizeTimeout = null;

	this.indent = 19;
	this.selectedItem = null;
	this.selectedForm = null;
	this._structure = {};
}

CN_navigation.deltaY = 80;

var proto = CN_navigation.prototype;

// Standards DOM nodes expose parentNode; IE exposed parentElement.
function navigationParent(element)
{
	return element && element.parentNode;
}

proto.onnodeselected = function(ev)
{
	this.formManager.postData(this.element);
}

proto.createElement = function(node, parentElement)
{
	var l = Util.createElement("div");
	parentElement.appendChild(l);
	
	this.element = l;
	l.jsObject = this;

	l.className = "cn_navigation";
	Event.add(l, "resize", this, this._element_onresize);
	
	this._init(node);
	
	if(CNFormManager.vista)
	{
		this._hover = VistaSupport.createHover('item-gradient-5.gif', 30);
		this._hover.strokecolor = ThemeNonCSSStyles.hoverRect_strokeColor2;
		this._select = VistaSupport.createHover('item-gradient-5.gif', 30);
	}

	return l;
}

proto.unload = function()
{
	this._unloadCollapseMixin();

	this._structure = null;
	this._deleted = true;
	this.panels = null;
	Event.del(this.element, "resize", this, this._element_onresize);
}

proto.loadData = function(node) {
	this._walkDataNode(node, this.element);
	this.finishBuild();

	if(CNFormManager.currentThemeName == "blue") {
		if(!this._canExpandCollapse) this._canExpandCollapse = node.getAttribute("canExpandCollapse") == "true";        
		else this._canExpandCollapse = node.getAttribute("canExpandCollapse") != "false";

		var attr = node.getAttribute("collapsed");
		if(attr) {
			if(attr == "true") this.collapse(true);
			else this.expand(true);  
		}

		this._updateCollapseElements();		
	}
}

proto._walkDataNode = function(node, parentElement)
{
	var childNodes = Util.xmlChildElements(node, "node");
	var childCount = childNodes.length;
	for(var i = 0; i < childCount; i++)
	{
		var subNode = childNodes[i];
		
		var attr = subNode.getAttribute("id");
		if(!attr)
		{
			Util.assert("navigation/modify/node without id");
			continue;
		}
		var id = String(attr);
		
		var container;
		var item = this._structure[id]; //parentElement.children[id];
		
		// NOTE: item == nodeDiv for nodes and == navigationPanel for panels.
		
		if(!item)
		{
			Util.assert("Can't find item, parentNodeID: " + node.getAttribute("id") 
			+ " + requesting " + id + " from " + parentElement.outerHTML);
		}
		
		if(item.length) continue;

		if(parentElement == this.element 
		|| item.className == "cn_navigation_panel") container = item.children[1];
		else container = item;
		
		if(item)
		{
			var enabledAttr = subNode.getAttribute("enabled");
			if(enabledAttr)
			{
				if(item.className != "cn_navigation_panel")
				{
					if(enabledAttr == "true" && item.disabled) 
					{
						item.disabled = false;
						item.children[0].children[1].style.cursor = "";
					}
					else if(enabledAttr == "false" && !item.disabled) 
					{
						item.children[0].children[1].style.cursor = "default";
						item.disabled = true;
					}
				}
			}
			var attr = subNode.getAttribute("visible");
			if(attr) 
			{
				var hidden = attr == "false";
				if(item.className == "cn_navigation_panel")
				{
					item.style.display =  hidden ? "none" : "block";
				}
				else
				{
					item._hidden = hidden;
					if(parentElement.expanded !== false) item.style.display = hidden ? "none" : "block";
				}
			}
		}
		else
		{
			Util.assert("Can't find navigation node: " + id);
		}
		// this._walkDataNode(subNode, container);
	}
}

proto.storeData = function(xmldoc) {
	var fragment = xmldoc.createDocumentFragment();
	
	if(this._navigationCollapedChanged) {
		var node = xmldoc.createElement("navigation");
		node.setAttribute("collapsed", this._navigationCollapsed ? "true" : "false");
		fragment.appendChild(node);
		this._navigationCollapedChanged = false;
	}

	if(this._formSelected) {
		var node = xmldoc.createElement("navigation");
		node.setAttribute("form", this.selectedForm);
		fragment.appendChild(node);
		this._formSelected = false;
	}

	return fragment;
}

proto.isValid = function()
{
	return true;
}

proto.selectFormNode = function(id)
{
	if(id === null) 
	{
		// Ensure we have some panel selected and layout is ok.
		this.showActivePanel();
		return;
	}
	// NOTE: Initially id is numeric.
	var item = this._structure[id]; 
	if(item) this.selectItemDiv(item.firstChild);
}

// Properties. ========================================================
proto.set_disabled = function(value)
{
	value = Util.parseBoolean(value);
	if(this._disabled == value) return;
	this._disabled = value;

	if(this.isBuilt) this._set_disabled();
}
proto._set_disabled = function()
{
	if(this._disabled) 
	{
		this.element.className = "cn_navigation cn_navigation_disabled";
	}
	else 
	{
		this.element.className = "cn_navigation";
	}
}

// Element functions. ===================================================
proto._init = function(node)
{
	this.element.style.userSelect = "none";

	this._canExpandCollapse = node.getAttribute("canExpandCollapse") != "false";

	this.buildElements(node);

	this.finishBuild();
}

proto.buildElements = function(node)
{
	this.disabler = Util.createElement("div");
	this.disabler.style.cssText = "position: absolute; background: white; z-index: 1000; opacity: 0.5; width: 100%; height: 100%; visibility: hidden;";

	//this.panels = this.element.children;
	this.panels = [];

	var nodes = Util.xmlChildElements(node, "node");

	var count = nodes.length;
	for(var i = 0; i < count; i++) this.buildElement(nodes[i], i)

	this._buildCollapseElements();

	this.isBuilt = true;
}

proto.finishBuild = function()
{
	// Control deleted before it was completely built.
	if(this._deleted) return;

	if(this.panels.length > 0) 
	{
		this.showPanel(this.panels[0]);
	}
	
	this._set_disabled();
}

proto._setFinishBuildTO = function(time)
{
	var obj = this;
	setTimeout(function(){ obj.finishBuild(); }, time);
}

//proto._headerColors = ["blue", "red", "yellow", "green", "orange", "violet", "yellow2"];

proto.buildElement = function(node, ix)
{
	var panel = Util.createElement("div", "cn_navigation_panel", null);
	this.element.appendChild(panel);
	this.panels.push(panel);
	
	var attr = node.getAttribute("id");
	if(attr) this._structure[String(attr)] = panel; //panel.id = "n" + String(attr);

	var content = Util.createElement("div", "contentDiv", {id: "contentDiv"});
	panel.appendChild(content);
	panel.contentDiv = content;
	
	var but = Util.createElement("div", "panelButton", {id: "panelButton"});
	panel.insertBefore(but, panel.firstChild);
	panel.panelButton = but;
	
	var text = String(node.getAttribute("caption"));
	
	var table = Util.createElement("table", null, {width: "100%", border: 0, cellpadding: 0, cellspacing: 0});
	but.appendChild(table);
	var tbody = Util.createElement("tbody");
	table.appendChild(tbody);
	var tr = Util.createElement("tr");
	tbody.appendChild(tr);
	var td1 = Util.createElement("td");
	tr.appendChild(td1);
	var img1 = Util.createElement("img", null, {width: 12, height: 28});
	td1.appendChild(img1);
	var td2 = Util.createElement("td", "panelContentTD", {width: "100%"});
	tr.appendChild(td2);
	var td3 = Util.createElement("td");
	tr.appendChild(td3);
	var img2 = Util.createElement("img", null, {width: 12, height: 28});
	td3.appendChild(img2);
	
	td2.textContent = text;

	if(CNFormManager.currentThemeName == "silver")
	{
		img1.src = CNFormManager.themeImagesPath + 'win-header-2-1_01.gif';
		img2.src = CNFormManager.themeImagesPath + 'win-header-2-1_03.gif';
		td2.style.background = "url('" + CNFormManager.themeImagesPath + "win-header-2-1_02.gif')";
	}
	else if(CNFormManager.vista)
	{
		img1.style.display = img2.style.display = "none";
	}
	else
	{
		//var colorPart = this._headerColors[ix];
		//if(!colorPart) colorPart = this._headerColors[0];
		var colorPart = "orange";
	
		img1.src = CNFormManager.themeImagesPath + 'win-header-2-' + colorPart + '_01.gif';
		img2.src = CNFormManager.themeImagesPath + 'win-header-2-' + colorPart + '_03.gif';
		td2.style.background = "url('" + CNFormManager.themeImagesPath + 'win-header-2-' + colorPart + "_02.gif')";
	}
	
	Event.add(but, "click", this, this._panelButton_onclick);
	Event.add(but, "dblclick", this, this._panelButton_onclick);
	Event.add(but, "mouseenter", this, this._panelButton_onmouseenter);
	Event.add(but, "mouseleave", this, this._panelButton_onmouseleave);

	this.panelCount++;
	
	var subNodes = Util.xmlChildElements(node, "node");
	if(subNodes.length > 0) this.buildNodes(subNodes, 0, content);
}

proto.buildNodes = function(nodes, level, parentElement)
{
	var count = nodes.length;
	for(var i = 0; i < count; i++)
	{
		this.buildNode(nodes[i], level, i, parentElement);
	}
}

proto.buildNode = function(node, level, index, parentElement)
{
	var nodeDiv = Util.createElement("div");
	parentElement.appendChild(nodeDiv);
	Event.add(nodeDiv, "select", this, CNUtil.cancelEvent);

	var itemDiv = Util.createElement("div", "itemDiv", {isItemDiv: true});
	if(level == 0) itemDiv.style.fontWeight = "bold"
	
	var attr = node.getAttribute("id");

	if(attr) 
	{
		var id = String(attr);
		this._structure[id] = nodeDiv;
		nodeDiv._id = id;
	}
	
	itemDiv.nodeIndex = index;
	nodeDiv.appendChild(itemDiv);
	
	if(node.childNodes.length > 0) itemDiv._isFolder = true;
	
	itemDiv.className += " clickable";
	nodeDiv._clickable = true;	

	var img = Util.createElement("img", "itemImage");
	itemDiv.appendChild(img);
	
	img.width = 9;
	img.height = 12;

	var subNodes = Util.xmlChildElements(node, "node");
	if(subNodes.length > 0)
	{
		var expanded = node.getAttribute("expanded") == "true";
	
		if(!expanded && this.expandLevel >= level) expanded = true;
		nodeDiv.expanded = expanded;
		img.src = CNFormManager.themeImagesPath + "simple-" + (expanded ? "minus" : "plus") + ".gif";
		Event.add(img, "click", this, this._itemImage_onclick);
		Event.add(img, "dblclick", this, this._itemImage_onclick);
		if(CNFormManager.vista) {
			Event.add(img, "mouseenter", this, this._itemImage_onmouseenter);
			Event.add(img, "mouseleave", this, this._itemImage_onmouseleave);
		}
	}
	else
	{
		img.src = CNFormManager.themeImagesPath + "tree-arrow.gif";
	}

	var text = Util.createElement("span", "textSpan");
	
	Event.add(text, "click", this, this._itemDiv_onclick);
	Event.add(text, "dblclick", this, this._itemDiv_onclick);
	Event.add(text, "mouseover", this, this._itemDiv_onmouseover);
	Event.add(text, "mouseleave", this, this._itemDiv_onmouseleave);

	itemDiv.appendChild(text);

	text.textContent = String(node.getAttribute("caption"));
	nodeDiv.style.marginLeft = level > 0 ? this.indent : 0;
	
	if(node.getAttribute("selected") == "true") this.selectItemDiv(itemDiv);
	
	if(subNodes.length > 0)
	{
		var contDiv = document.createElement("div");
		contDiv.className = "contDiv";
		nodeDiv.appendChild(contDiv);
		contDiv.style.display = expanded ? "block" : "none";
		this.buildNodes(subNodes, level + 1, contDiv);
	}
}

proto.selectItemDiv = function(itemDiv, anim)
{
	var selectedItem = this.get_selectedItem();
	//if(selectedItem == itemDiv) return;

	if(selectedItem && selectedItem.style) 
	{
		if(CNFormManager.vista)
		{
			this._select.style.visibility = "hidden";
		}
		else
		{

			selectedItem.children[selectedItem.children.length - 1].style.background = "";
			selectedItem.style.color = "";
			//selectedItem.children[1].style.cursor = "pointer";
			CNUtil.removeClass(selectedItem, "selectedItemDiv");
		}
	}
	// May be null to deselect node.
	if(itemDiv && itemDiv.style) 
	{
		// Try to find and show panel.
		var panel = itemDiv;
		while(panel != null && panel.className != "cn_navigation_panel") panel = navigationParent(panel);
		//if(this.activePanel != panel) 
		this.showPanel(panel, anim);

		if(CNFormManager.vista)
		{
			itemDiv.style.position = "relative";
			itemDiv.appendChild(this._select);

			var hover = this._select;
			var textDiv = itemDiv.children[1];
			hover.style.left = 10;
			hover.style.width = textDiv.offsetWidth + 2;
			hover.style.height = textDiv.offsetHeight;
			this._select.style.visibility = "inherit";
		}
		else
		{
			itemDiv.style.color = Util.getStyle(itemDiv, "xl--selected-color");

		}		
	}
	this.set_selectedItem(itemDiv);	
}

proto.set_selectedItem = function(l)
{
	this.selectedItem = l;
}

proto.get_selectedItem = function()
{
	return this.selectedItem;
}

proto.showPanel = function(l, slide)
{
	if(!l || !this.element.contains(l) || l.className != "cn_navigation_panel") return;
	if(Util.getStyle(l, "display") == "none") return;
	
	var prevPanelTop = 0;
	var prevPanelBottom = 0;

	var activePanelHeight = this.element.clientHeight;
	
	for(var j = 0; j < this.panels.length; j++) 
	{
		var panel = this.panels[j];
		if(panel == l) break;
		if(Util.getStyle(panel, "display") == "none") continue

		if(slide) Animator.start(new AnimMove(panel, 0, prevPanelTop));
		else panel.style.top = prevPanelTop;
		
		var h = panel.panelButton.offsetHeight - 1;
		prevPanelTop += h;
		activePanelHeight -= h;
	}
	
	for(var j = this.panels.length - 1; j > 0; j--) 
	{
		var panel = this.panels[j];
		if(panel == l) break;
		if(Util.getStyle(panel, "display") == "none") continue;
		
		var y = this.element.clientHeight - prevPanelBottom - panel.panelButton.offsetHeight;

		if(slide) Animator.start(new AnimMove(panel, 0, y));
		else panel.style.top = y;
		
		var h = panel.panelButton.offsetHeight - 2;
		prevPanelBottom += h;
		activePanelHeight -= h;
	}

	var h = l.panelButton.offsetHeight - 1;
	l.contentDiv.style.height = Math.max(activePanelHeight - h - 3, 0);
	
	if(slide) Animator.start(new AnimMove(l, 0, prevPanelTop));
	else l.style.top = prevPanelTop;
	
	if(this.activePanel != l)
	{
		if(this.activePanel)
		{
			var button = this.activePanel.panelButton		
			button.className = "panelButton";
			button.children[0].style.color = "";
		}
		this.activePanel = l;
		var button = this.activePanel.panelButton
		button.className = "panelButton panelButtonSelected";
		button.children[0].style.color = Util.getStyle(button, "xl--selected-color");		
	}
}

proto.showPanel2 = function(l)
{
	if(!l || !this.element.contains(l) || l.className != "cn_navigation_panel"
	|| Util.getStyle(l, "display") != "block" || this.panels.length == 0) return;

	if(this.panels.length == 1) this.showPanel(this.panels[0], true);
	else if(l != this.activePanel) 
	{
		this.showPanel(l, true);
	}
	else
	{
		var prevPanel = this._findPreviousVisibleSibling(l);
		if(l == this.panels[0] || !prevPanel) 
		{
			var nextPanel = this._findNextVisibleSibling(l);
			if(nextPanel) this.showPanel(nextPanel, true);
		}
		else if(prevPanel)
		{
			this.showPanel(prevPanel, true);
		}
	}
}

proto._findNextVisibleSibling = function(l)
{
	do
	{
		l = l.nextSibling;
	}
	while(l && Util.getStyle(l, "display") != "block");
	return l;
}

proto._findPreviousVisibleSibling = function(l)
{
	do
	{
		l = l.previousSibling;
	}
	while(l && Util.getStyle(l, "display") != "block");
	return l;
}

proto.showActivePanel = function()
{
	if(!this.activePanel) return;
	this.showPanel(this.activePanel, false);
}

proto.getClickableItemDiv = function(l)
{
	var itemDiv = this.getItemDiv(l);
	var node = navigationParent(itemDiv);
	if(node._clickable !== true) return null;
	return itemDiv;
}

proto.getItemDiv = function(l)
{
	var itemDiv = l;
	while(itemDiv && !itemDiv.isItemDiv) itemDiv = navigationParent(itemDiv);
	return itemDiv;
}


// Event handlers. =========================================
proto._panelButton_onmouseenter = function()
{
	var panel = CNUtil.findByClassName(Util.eventTarget(Event.current()), "panelButton");
	if(panel) panel.className += " panelButtonHover";
}

proto._panelButton_onmouseleave = function()
{
	var panel = CNUtil.findByClassName(Util.eventTarget(Event.current()), "panelButton");
	if(panel) CNUtil.removeClass(panel, "panelButtonHover");
}

proto._panelButton_onclick = function()
{
	var l = Util.eventTarget(Event.current());
	while(l && l.className != "cn_navigation_panel") l = navigationParent(l);

	CNUtil.findJSObject(l).showPanel2(l);
}

proto._element_onresize = function()
{
	if(CNFormManager.changingTheme || this.formManager._loading) return;
	CNUtil.findJSObject(Util.eventTarget(Event.current())).element_onresize();
}
proto.element_onresize = function()
{
	if(!this.activePanel) return;
	if(this.resizeTimeout != null) 
	{
		clearTimeout(this.resizeTimeout);
		this.resizeTimeout = null;
	}
	var obj = this;
	this.resizeTimeout = setTimeout(function(){ obj.showActivePanel(); }, 10);
}


proto._itemDiv_onmouseover = function()
{
	CNUtil.findJSObject(Util.eventTarget(Event.current())).itemDiv_onmouseover();
}
proto.itemDiv_onmouseover = function()
{
	var itemDiv = this.getClickableItemDiv(Util.eventTarget(Event.current()));
	if(itemDiv == null || navigationParent(itemDiv).disabled) return;
	
	if(CNFormManager.vista)
	{
		if(itemDiv._isFolder)
		{
			var img = itemDiv.children[0];
			img.src = "themes/vista/g/hover-" + (itemDiv.parentNode.expanded ? "minus" : "plus") + ".gif";
		}
		this._syncHoverPos(itemDiv, this._hover);
		this._hover.style.visibility = "inherit";
	}
	else
	{
		var textDiv = itemDiv.children[itemDiv.children.length - 1];
		itemDiv.style.color = Util.getStyle(itemDiv, "xl--hover-color");
		textDiv.style.background = Util.getStyle(itemDiv, "xl--hover-background")
		itemDiv.className += " hoveredItemDiv";
	}
}

proto._syncHoverPos = function(itemDiv, hover)
{
	var textDiv = itemDiv.children[1];
	var p = navigationParent(navigationParent(itemDiv));
	hover.style.top = itemDiv.offsetTop;
	hover.style.left = textDiv.offsetLeft - 1;
	hover.style.width = textDiv.offsetWidth + 2;
	hover.style.height = textDiv.offsetHeight;
	if(navigationParent(hover) != p) p.appendChild(hover);
}

proto._itemDiv_onmouseleave = function()
{
	CNUtil.findJSObject(Util.eventTarget(Event.current())).itemDiv_onmouseleave();
}
proto.itemDiv_onmouseleave = function()
{
	var itemDiv = this.getClickableItemDiv(Util.eventTarget(Event.current()));
	if(itemDiv == null || navigationParent(itemDiv).disabled) return;

	if(CNFormManager.vista)
	{
		if(itemDiv._isFolder)
		{
			var img = itemDiv.children[0];
			img.src = "themes/vista/g/simple-" + (itemDiv.parentNode.expanded ? "minus" : "plus") + ".gif";	
		}
		this._hover.style.visibility = "hidden";
	}
	else
	{
		itemDiv.style.color = "";
		itemDiv.children[itemDiv.children.length - 1].style.background = "";
		CNUtil.removeClass(itemDiv, "hoveredItemDiv");
	}
}

proto._itemImage_onmouseenter = function()
{
	var jso = Util.dispatchObject();
	var itemDiv = jso.getClickableItemDiv(Util.eventTarget(Event.current()));
	if(itemDiv == null || navigationParent(itemDiv).disabled) return;
	var img = Util.eventTarget(Event.current());
	img.src = "themes/vista/g/hover-" + (itemDiv.parentNode.expanded ? "minus" : "plus") + ".gif";
}

proto._itemImage_onmouseleave = function()
{
	var jso = Util.dispatchObject();
	var itemDiv = jso.getClickableItemDiv(Util.eventTarget(Event.current()));
	if(itemDiv == null || navigationParent(itemDiv).disabled) return;
	var img = Util.eventTarget(Event.current());
	img.src = "themes/vista/g/simple-" + (itemDiv.parentNode.expanded ? "minus" : "plus") + ".gif";
}

proto._itemImage_onclick = function()
{
	CNUtil.findJSObject(Util.eventTarget(Event.current())).itemImage_onclick();
}

proto.itemImage_onclick = function()
{
	var itemDiv = this.getItemDiv(Util.eventTarget(Event.current()));
	this._toggleExpand(itemDiv, true);
}
proto._toggleExpand = function(itemDiv, userAction)
{
	var node = navigationParent(itemDiv);
	
	var expanded = node.expanded = !node.expanded;
	//this.changeChildrenDisplay(node, node.expanded);
	var contDiv = node.lastChild;
	if(contDiv.className != "contDiv") return;
	
	if(userAction && CNFormManager.vista)
	{
		if(expanded)
		{
			contDiv.style.display = "block";
			var h = contDiv.offsetHeight;
			contDiv.style.overflow = "hidden";
			contDiv.style.height = "1px";
			var anim = new AnimResize(contDiv, contDiv.offsetWidth, h);
			Animator.start(anim);
			anim.onend = function()
			{
				contDiv.style.height = "auto";
				contDiv.style.overflow = "";
			}
		}
		else
		{
			contDiv.style.overflow = "hidden";
			var anim = new AnimResize(contDiv, contDiv.offsetWidth, 1);
			Animator.start(anim);
			anim.onend = function()
			{
				contDiv.style.height = "auto";
				contDiv.style.overflow = "";
				contDiv.style.display = "none";					
			}
		}
	}
	else
	{
		contDiv.style.display = expanded ? "block" : "none";
	}

	var prefix;
	if(CNFormManager.vista) prefix = "hover-";
	else prefix = "simple-";

	itemDiv.children[0].src = CNFormManager.themeImagesPath + prefix + (node.expanded ? "minus" : "plus") + ".gif";
}

proto._itemDiv_onclick = function()
{
	CNUtil.findJSObject(Util.eventTarget(Event.current())).itemDiv_onclick();
}
proto.itemDiv_onclick = function()
{
	var itemDiv = this.getClickableItemDiv(Util.eventTarget(Event.current()));
	if(itemDiv == null || navigationParent(itemDiv).disabled || this.formManager._loading
	|| this.formManager.isNavigationDisabled()) return;

	if(itemDiv._isFolder)
	{
		this._toggleExpand(itemDiv, true);
	}
	else
	{
		this.selectItemDiv(itemDiv);
		
		var selectedForm;
		var id = navigationParent(itemDiv)._id;
		if(!id || itemDiv == this.selectedItem && id == this.formManager._currentFormID) return;
		this.selectedForm = id;
		this._formSelected = true;
		
		if(this._quickExpand) {
			this.collapse();
			var self = this;
			// Gives small pause to be able to finish animation smoothly.
			setTimeout(function() {
				self.onnodeselected({});
			}, 50);
		} else {
			this.onnodeselected({});
		}
	}
}

Util.mixin(proto, NavigationCollapseMixin);

proto = null;



/*
	v. 1.0
*/
function CN_iconnavigation() {
	this.formManager = null;

	this.disabler = null;
	this._disabled = false;

	this._structure = {}; // Keeps only 1st level (permanently visible) items.
	this._modify = {};

	this._popups = [];
	this._activeItems = [];

	this._selectedID = null;
}

var proto = CN_iconnavigation.prototype;

proto.createElement = function(node, parentElement) {
	var l = document.createElement("div");
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;

	l.className = "cn_iconnavigation";
	Event.add(l, "resize", this, this._l_onresize)

	this._init(node);	

	return l;
}
proto._l_onresize = function() {
	if(this._container.offsetHeight < 20 || this.element.offsetHeight < 20) return;
	this._container.style.height = this.element.offsetHeight - 10 + "px";
	if(this._pinButton && this._container.scrollHeight > this._container.offsetHeight) {
		Util.removeClass(this._pinButton, "iconnavigation_noscroll");
	} else {
		Util.addClass(this._pinButton, "iconnavigation_noscroll");
	}
}


proto.unload = function() {
	this._unloadCollapseMixin();
	this._structure = null;
	this._deleted = true;
	this.panels = null;
}

proto.loadData = function(node) {
	this._loadModify(node, this.element);

	if(CNFormManager.currentThemeName == "blue") {
		if(!this._canExpandCollapse) this._canExpandCollapse = node.getAttribute("canExpandCollapse") == "true";
		else this._canExpandCollapse = node.getAttribute("canExpandCollapse") != "false";

		var attr = node.getAttribute("collapsed");
		if(attr) {
			if(attr == "true") this.collapse(true);
			else this.expand(true);
		}

		this._updateCollapseElements();
	}
}

proto._loadModify = function(node, parentElement) {
	var childNodes = Util.xmlSelectNodes(node, "node");
	var childCount = childNodes.length;
	for(var i = 0; i < childCount; i++) {
		var subNode = childNodes[i];

		var attr = subNode.getAttribute("id");
		if(!attr) {
			Util.assert("navigation/modify/node without id");
			continue;
		}
		var id = String(attr);

		var item = this._structure[id];
		var attrs = Util.xmlAttributesToJson(subNode);
		if(item) {
			this._applyModify(item, attrs);
		} else {
			var modify = this._modify[id];
			if(modify) modify = Util.mixin(modify, attrs);
			else this._modify[id] = attrs; 
		}
	}
}
proto._applyModify = function(item, modify) {
	item.style.display = modify['visible'] != 'false' ? '' : 'none';
	var disabled = item.disabled = modify['enabled'] == 'false';
	if(modify['clickable']) item._clickable = modify['clickable'] == "true";
	Util.toggleClass(item, "cn_iconnavigation_item_disabled", disabled);
}

proto.storeData = function(xmldoc) {
	var fragment = xmldoc.createDocumentFragment();

	this._storeCollasedState(fragment);

	if(this._formSelected) {
		var node = xmldoc.createElement("navigation");
		node.setAttribute("form", this._selectedID);
		fragment.appendChild(node);
		this._formSelected = false;
	}

	return fragment;
}

// public API.
proto.isValid = function() {
	return true;
}

// public API.
proto.selectFormNode = function(id) {
	this._selectItemById(id);
}
proto._selectItemById = function(id) {
	if(this._selectedID == id) return;
	var selected = this._structure[this._selectedID];
	if(selected) {
		Util.removeClass(selected, "cn_iconnavigation_item_selected")
	}

	this._selectedID = id;

	var item = this._structure[id];
	if(!item) return;
	Util.addClass(item, "cn_iconnavigation_item_selected");
}

// Properties. ========================================================
proto.set_disabled = function(value) {
	value = Util.parseBoolean(value);
	if(this._disabled == value) return;
	this._disabled = value;

	this._set_disabled();
}
proto._set_disabled = function() {
	this.element.className = this._disabled ? "cn_iconnavigation cn_navigation_disabled" : "cn_iconnavigation";
}

// Element functions. ===================================================
proto._init = function(node) {
	this.element.style.userSelect = "none";

	this._canExpandCollapse = node.getAttribute("canExpandCollapse") != "false";

	this.buildElements(node);
}

proto.buildElements = function(node) {
	this.disabler = Util.createElement("div");
	this.disabler.style.cssText = "position: absolute; background: white; z-index: 1000; opacity: 0.5; width: 100%; height: 100%; visibility: hidden; ";

	this._container = Util.createElement("div", "container");
	this.element.appendChild(this._container);

	var nodes = Util.xmlSelectNodes(node, "node");

	var count = nodes.length;
	for(var i = 0; i < count; i++) this._buildTopItem(nodes[i], i)

	this._buildCollapseElements();

	this._set_disabled();
}


proto._buildTopItem = function(node) {
	var div = this._buildItem(Util.xmlNodeToJson(node), 0);
	this._container.appendChild(div);
}
proto._buildItem = function(node, level) {
	var id = node.attributes['id'],
		modify;

	if(id !== undefined) {
		modify = this._modify[id];
		if(modify && level > 0 && modify['visible'] == 'false') {
			return null; // Completely skip rendering of the item for levels > 0.
		}
	}

	var div = Util.createElement("div", "cn_iconnavigation_item");
	div.style.userSelect = "none";
	div._level = level;
	var imgDiv = Util.createElement("div", "icon_div");

	var img = Util.createElement("img");
	imgDiv.appendChild(img);
	div.appendChild(imgDiv);

	var textDiv = Util.createElement("div", "text_div");
	div.appendChild(textDiv)

	var attr = node.attributes["img"];
	if(attr) {
		img.src = attr;
	}
	else img.style.display = "none";

	textDiv.textContent = String(node.attributes["caption"]);

	Event.add(div, "mouseenter", this, this._item_mouseenter);
	Event.add(div, "mouseleave", this, this._item_mouseleave);
	Event.add(div, "click", this, this._item_click);

	var subNodes = node.children;
	if(subNodes.length > 0) {
		// The historical stylesheet draws the folder affordance on this class.
		// IE's old inline/zoom layout happened to expose it inconsistently;
		// standards browsers need the semantic folder class explicitly.
		Util.addClass(div, "cn_iconnavigation_folder");
		var plusMinus = Util.createElement("img", "cn_iconnavigation_plusMinus");
		plusMinus.src =	CNFormManager.themeImagesPath + "nav-plus.gif";
		div.appendChild(plusMinus);

		div._subNodesJson = subNodes;
		if(node.attributes["clickable"] == "true") div._clickable = true;
	}

	if(id !== undefined) {
		 if(level == 0) this._structure[id] = div; // Only first level is in structure.
		 div._id = id;
	}

	if(this._selectedID === id) {
		Util.addClass(div, "cn_iconnavigation_item_selected");
	}
	if(modify) {
		this._applyModify(div, modify);
	}

	return div;
}

proto._item_mouseenter = function(event) {
	if(this._animating) return; // True only when collapsing is animated.
	event = Event.normalize(event) || Event.current();
	var target = event && event.target;
	var div = Util.findByClassName(target, "cn_iconnavigation_item");
	if(!div) return;
	Util.addClass(div, "cn_iconnavigation_item_hover");
	if(this._showTO) clearTimeout(this._showTO);
	if(this._popupsTO) clearTimeout(this._popupsTO);
	var self = this;
	if(Util.arrayIndexOf(this._activeItems, div) == -1) {
		this._hidePopups(div._level);
	} else if(this._popups[div._level] && Util.getStyle(this._popups[div._level], "display") != "none") {
		return;
	}
	if(div._subNodesJson) {
		this._showTO = setTimeout(function(){ self._showPopup(div); }, Animator.animating() ? 250 : 0); // no _animating is set while quick expanding.
	}
}
proto._item_mouseleave = function(event) {
	event = Event.normalize(event) || Event.current();
	var target = event && event.target;
	var relatedTarget = event && (event.relatedTarget || Event.current().relatedTarget);
	var div = Util.findByClassName(target, "cn_iconnavigation_item"),
		popup = Util.findByClassName(relatedTarget, 'cn_iconnavigation_popup');
	if(!div) return;

	if(popup != null && popup._level >= div._level) return;
	this._unhoverItem(div);
	this._hidePopups(div._level);
}
proto._item_click = function(event) {
	event = Event.normalize(event) || Event.current();
	var target = event && event.target;
	var item = Util.findByClassName(target, "cn_iconnavigation_item");
	if(item == null || this._disabled || item.disabled || this.formManager._loading || this.formManager.isNavigationDisabled()) return;

	if(item._subNodesJson && !item._clickable) return;

	this._hidePopups(0);

	var selectedForm;
	var id = item._id;
	if(!id || id == this._selectedID && id == this.formManager._currentFormID) return;
	this._selectItemById(id);
	this._formSelected = true;

	if(this._quickExpand) {
		this.collapse();
		var self = this;
		// Gives small pause to be able to finish animation smoothly.
		setTimeout(function() { this.formManager.postData(self.element); }, 50);
	} else {
		this.formManager.postData(this.element);
	}
}

proto._unhoverItem = function(div) {
	Util.removeClass(div, "cn_iconnavigation_item_hover");
	var item = this._activeItems[div._level];
	if(item == div) this._activeItems[div._level] = null;
}
proto._hidePopups = function(toLevel) {
	for(var i = this._popups.length - 1; i >= toLevel; i--) {
		this._popups[i].style.display = "none";
		var item = this._activeItems[i];
		if(item) this._unhoverItem(item);
	}
	if(!this._popupVisible()) {
		Event.del(document.body, "keydown", this, this._body_keydown);
	}
}

proto._popupVisible = function() {
	// Return true if first level is visible.
	return this._popups[0] && Util.getStyle(this._popups[0], "display") != "none";
}
proto._visibleLevel = function() {
	for(var i = this._popups.length - 1; i >= 0; i--) {
		if(Util.getStyle(this._popups[i], "display") != "none") return i;
	}
	return -1;
}

proto._showPopup = function(div) {
	var nodes = div._subNodesJson;
	if(!nodes) return;

	var level = div._level,
		popup = this._popups[level];

	if(!this._popupVisible()) {
		Event.add(document.body, "keydown", this, this._body_keydown);
	}

	// create bg if none
	if(!popup) popup = this._createPopup(level);
	this._popupDiv = this._createPopupItems(popup, div._subNodesJson, level);
	this._layoutPopupTo(popup, div);

	this._activeItems[div._level] = div;
}
proto._body_keydown = function(event) {
	event = Event.normalize(event) || Event.current();
	if(event && event.key == "Escape") {
		this._hidePopups(this._visibleLevel());
	}
}
proto._createPopup = function(level) {
	Util.assert(function(){ return !this._popups[level]; }, this);
	var popup = this._popups[level] = Util.createElement("div", "cn_iconnavigation_popup");
	popup._level = level;
	this._createPopupBG(popup);
	document.body.appendChild(popup);

	Event.add(popup, "mouseenter", this, this._popup_mouseenter);
	Event.add(popup, "mouseleave", this, this._popup_mouseleave);
	return popup;
}
proto._popup_mouseenter = function() {
	if(this._popupsTO) clearTimeout(this._popupsTO);
	if(this._quickExpandLeaveTO) clearTimeout(this._quickExpandLeaveTO);
}
proto._popup_mouseleave = function(event) {
	event = Event.normalize(event) || Event.current();
	var target = event && event.target,
		relatedTarget = event && event.relatedTarget,
		popup = Util.findByClassName(target, 'cn_iconnavigation_popup'),
		toPopup = Util.findByClassName(relatedTarget, 'cn_iconnavigation_popup');
	if(!popup || toPopup) return;

	var self = this;
	this._popupsTO = setTimeout(function() {
		self._hidePopups(popup._level);

		if(self._quickExpand && !self._popupVisible()) self._quickExpandStartLeaveTO();
	}, 250);
}


proto._createPopupBG = function(popup) {
	var tip = CNFormManager.themeImagesPath;
	// Render the historical nine-slice frame with ordinary CSS backgrounds.
	var table = Util.createElement("table", "popupBG");
	table.cellSpacing = 0;
	table.cellPadding = 0;
	table.style.border = "0";
	table.style.width = "100%";
	table.style.height = "100%";

	var tbody = Util.createElement("tbody");
	table.appendChild(tbody);

	var makeCell = function(row, column, image, repeat, width, height, className) {
		var cell = Util.createElement("td", className || null);
		if(image) {
			cell.style.backgroundImage = "url('" + tip + image + "')";
			cell.style.backgroundRepeat = repeat || "no-repeat";
		}
		if(width) cell.style.width = width;
		if(height) cell.style.height = height;
		row.appendChild(cell);
		return cell;
	};

	var row = Util.createElement("tr");
	makeCell(row, 0, "nav-popup-bg_02.png", "no-repeat", "15px", "14px");
	makeCell(row, 1, "nav-popup-bg_03.png", "repeat-x", "100%");
	makeCell(row, 2, "nav-popup-bg_05.png", "no-repeat", "16px", "14px");
	tbody.appendChild(row);

	row = Util.createElement("tr");
	makeCell(row, 0, "nav-popup-bg_07.png", "repeat-y", null, "100%");
	makeCell(row, 1, null, null, null, null, "popupContentArea");
	makeCell(row, 2, "nav-popup-bg_09.png", "repeat-y");
	tbody.appendChild(row);

	row = Util.createElement("tr");
	makeCell(row, 0, "nav-popup-bg_19.png", "no-repeat", "15px", "18px");
	makeCell(row, 1, "nav-popup-bg_20.png", "repeat-x");
	makeCell(row, 2, "nav-popup-bg_22.png", "no-repeat", "16px", "18px");
	tbody.appendChild(row);

	popup.appendChild(table);

	var arrow = Util.createElement("img");
	arrow.style.cssText = "width: 12px; height: 19px; position: absolute; top: 0; left: -9px;";
	arrow.src = tip + "nav-popup-bg_12.png";
	popup.appendChild(arrow);

	arrow = Util.createElement("img");
	arrow.style.cssText = "width: 14px; height: 21px; position: absolute; top: 0; left: -9px;";
	arrow.src = tip + "nav-popup-bg_15.png";
	popup.appendChild(arrow);
}
proto._createPopupItems = function(popup, subNodesJson, level) {
	if(popup.lastChild.className == "cn_iconnavigation_popup_items") {
		popup.removeChild(popup.lastChild);
	}
	var div = Util.createElement("div", "cn_iconnavigation_popup_items");
	popup.appendChild(div);

	var inner = Util.createElement("div", "cn_iconnavigation_popup_inner");
	div.appendChild(inner);

	inner.style.width = this._iconWidth * this._iconsInRow + "px"; // Some max value.

	level++;

	for(var i = 0; i < subNodesJson.length; i++) {
		var node = subNodesJson[i];
		var item = this._buildItem(node, level);
		if(item !== null) inner.appendChild(item);
	}
}
proto._iconWidth = 125,
proto._iconsInRow = 5;

proto._calcIconsInRow = function(popup) {
	var cont = popup.lastChild,
	inner = cont.firstChild,
	icons = inner.childNodes;
	if(icons.length == 0) return 0;
	var y = icons[0].offsetTop;

	for(var i = 0; i < icons.length; i++) {
		if(icons[i].offsetTop != y) return i;
	}
	return icons.length;
}


// NOTE: pixel values are for blue theme.
// TODO: somehow move pixel values to theme.
proto._layoutPopupTo = function(popup, div) {
	var xy = Util.findAbsolutePos(div),
		arrowL = popup.children[1],
		arrowR = popup.children[2],
		offsetY = 0,
		offsetX = 14,
		x,
		y,
		cont = popup.lastChild,
		inner = cont.firstChild,
		cs = Util.getComputedStyle(cont),
		paddingW = parseInt(cs.paddingLeft) + parseInt(cs.paddingRight),
		paddingH = parseInt(cs.paddingTop) + parseInt(cs.paddingBottom);

	if(div.offsetHeight > 30) {
		offsetY = 24;
	} else if (div.offsetHeight < 24 && inner.childNodes.length > 6) {
		offsetY = -17;
	} else {
		offsetY = -8;
	}

	y = xy.y + offsetY,

	popup.style.zIndex = top.__ontopZ++;
	popup.style.visibility = "hidden";
	popup.style.display = "block";

	if(inner.childNodes.length < this._iconsInRow) {
		// IE used `display:inline` + `zoom:1` to make this container shrink
		// around its children. Standards browsers need an explicit width or
		// the inline-block items wrap into a single column.
		var columns = Math.max(1, inner.childNodes.length);
		inner.style.display = "block";
		inner.style.width = this._iconWidth * columns + "px";
	}

	var w = inner.scrollWidth + paddingW;
	var h = inner.scrollHeight + paddingH;
	var paddingRight = 5;
	var right,
		applyScrolling = false,
		topDown = true;
	// Put it on left or on right?
	if(document.body.clientWidth - (xy.x + div.offsetWidth) > document.body.clientWidth / 2) {
		// Right.
		x = xy.x + div.offsetWidth - offsetX;
		// Can we fit.
		if(x + w + CNFormManager.scrollBarSize > document.body.clientWidth) {
			w = document.body.clientWidth - x - CNFormManager.scrollBarSize - paddingRight;
			applyScrolling = true;
		}
		right = true;
	} else {
		// Left.
		x = xy.x - w + offsetX * 2;
		if(x < 4) {
			w = xy.x + offsetX;
			x = 4;
			applyScrolling = true;
		}
		right = false;
	}

	if(y + h >= document.body.clientHeight) { // Can't fit down.
		// Put it on bottom or on top?
		if(document.body.clientHeight - (xy.y + offsetY) > document.body.clientHeight / 2) {
			// Bottom (top-down).
			applyScrolling = true;
			h = document.body.clientHeight - y;
		} else {
			// Top (bottom-top).
		    y = xy.y + div.offsetHeight - h - offsetY;
		    if(y < 4) {
		        y = 4;
		        h = xy.y + div.offsetHeight - offsetY;
		        applyScrolling = true;
		    }
		    topDown = false;
		}
	}

	if(applyScrolling) {
		inner.style.overflow = "hidden";

		//if(inner.scrollHeight > inner.clientHeight || inner.scrollWidth > inner.clientWidth)

		w += CNFormManager.scrollBarSize + paddingRight;
		inner.style.overflow = "auto";
		inner.style.height = h - CNFormManager.scrollBarSize + "px";
		popup.style.width = w + "px";
		inner.style.width = w - paddingW - paddingRight + "px";
	}

/*	var realWidth = this._iconWidth * this._calcIconsInRow(popup); // Need to recalc scrollbar size additions again...
	if(inner.clientWidth > realWidth) {
		w = realWidth + paddingW;
	}*/

	popup.style.left = x + "px";
	popup.style.top = y + "px";
	popup.style.width = w + "px";
	popup.style.height = h + "px";

	var selectedArrow;
 	if(right) {
		arrowL.style.display = "block";
		arrowR.style.display = "none";
		selectedArrow = arrowL;
	} else {
		arrowR.style.display = "block";
		arrowL.style.display = "none";
		arrowR.style.left = w - 8 + "px";
		selectedArrow = arrowR
	}

	var arrowY;
	if(topDown) {
		arrowY = 20;
	} else {
		arrowY = h - selectedArrow.offsetHeight - 20;
	}
	if(arrowY + selectedArrow.offsetHeight + 15 >= h) arrowY = 10;
	selectedArrow.style.top = arrowY + "px";

	var zoom = .75;
	if(inner.childNodes.length < 30) {
		Animator.start(new AnimZoom(popup, zoom * 100, 100, !right, !right));
	}
	popup.style.visibility = "visible";
}

Util.mixin(proto, NavigationCollapseMixin);


proto = null;

/*
	v. 2.0
	+ vista.
	+ DIV rendering.
*/
var Tooltip =
{
	x: 0,
	y: 0,
	popup: null,
	element: null,
	_shadow: null,

	// 18 == typical mouse pointer height.
	popupYOffset: 18,
	popupXOffset: 4,

	buildElement: function()
	{
		this.popup = Util.createElement("div", "tooltipPopup");
		if(CNFormManager.vista) {
			this.popup.appendChild(document.createElement("span"));
			this.popup.style.boxShadow = "2px 2px 4px rgba(0,0,0,.3)";
		}
		document.body.appendChild(this.popup);
	},
	destroy: function()
	{
		this.hide();
		Util.removeElement(this.popup);
		this.popup = null;
	},

	set: function(l, tipText)
	{
		if(tipText && !l.tipText) Tooltip.attach(l, tipText);
		else l.tipText = tipText;
		
		if(this.element == l && this.popup && this.popup.style.visibility != "hidden")
		{
			if(tipText) this.show(); // Refresh.
			else this.hide();
		}
	},

	attach: function(l, tipText)
	{
		var enter = l.tagName == "AREA" ? "mouseover" : "mouseenter";
		var leave = l.tagName == "AREA" ? "mouseout" : "mouseleave";
		Event.add(l, enter, this, this._element_onmouseenter);
		Event.add(l, leave, this, this._element_onmouseleave);
		if(tipText) l.tipText = tipText;
	},
	detach: function(l)
	{
		this.hide();
		var enter = l.tagName == "AREA" ? "mouseover" : "mouseenter";
		var leave = l.tagName == "AREA" ? "mouseout" : "mouseleave";
		Event.del(l, enter, this, this._element_onmouseenter);
		Event.del(l, leave, this, this._element_onmouseleave);
		l.tipText = null;
	},

	_element_onmouseenter: function()
	{
		var l = Util.eventTarget();
		Tooltip.forceOnElement(l, true);
	},

	forceOnElement: function(l, useEvent)
	{
		if(!this.popup || !l.tipText) return;
		if(this.element) this.hide();
		var timeout = parseInt(Util.getStyle(l, "xl--tooltip-delay"), 10);
		if(useEvent && !timeout) timeout = 500; // Default.

		Tooltip.element = l;
		if(useEvent)
		{
			Tooltip.x = Event.current().clientX + window.pageXOffset + Tooltip.popupXOffset;
			Tooltip.y = Event.current().clientY + window.pageYOffset + Tooltip.popupYOffset;
		}
		else
		{
			var xy = CNUtil.findAbsolutePos(l);
			Tooltip.x = xy.x;
			Tooltip.y = xy.y + l.offsetHeight;
		}
		
		Event.add(l, "mousemove", this, this._element_onmousemove);		

		if(timeout > 0) Tooltip.showTimeout = setTimeout(function(){ Tooltip.show(); }, timeout);
		else Tooltip.show();
	},

	_element_onmouseleave: function()
	{
		Tooltip.hide();
	},
	
	_element_onmousemove: function()
	{
		Tooltip.x = Event.current().clientX + window.pageXOffset + Tooltip.popupXOffset;
		Tooltip.y = Event.current().clientY + window.pageYOffset + Tooltip.popupYOffset;
		if(Tooltip.popupMoving)
		{
			var xy = Tooltip.correctXY(Tooltip.popup, Tooltip.x, Tooltip.y);
			Tooltip.popup.style.left = xy.x + "px";
			Tooltip.popup.style.top = xy.y + "px";
			
		}
	},

	show: function()
	{
		if(!this.popup || !this.element) return;
		if(this.element.offsetWidth == 0 && this.element.offsetHeight == 0) { // FWUI-1025
			this.hide();
			return;
		}
		
		var popup = this.popup;

		if(!popup || !popup.style) return;
		
		popup.style.visibility = "hidden";
		popup.style.display = "block";

		if(CNFormManager.vista) popup.style.width = "500px";

		if(CNFormManager.vista) popup.lastChild.innerHTML = this.element.tipText;
		else popup.innerHTML = this.element.tipText;
		
		if(CNFormManager.vista) 
		{
			popup.style.width = popup.lastChild.offsetWidth + 10 + "px";
			popup.style.height = popup.lastChild.offsetHeight + 5 + "px";
		}

		var xy = this.correctXY(popup, this.x, this.y);
		popup.style.left = xy.x + "px";
		popup.style.top = xy.y + "px";
		
		popup.style.zIndex = top.__ontopZ++;
	
		this.popupMoving = Util.getStyle(this.element, "xl--tooltip-position") != "still";
		var duration = parseInt(Util.getStyle(this.element, "xl--blend-duration"), 10);
		if(!duration) duration = 300;
		popup.style.transition = "opacity " + duration + "ms";
		popup.style.opacity = "0";
		popup.style.visibility = "visible";
		var shownPopup = popup;
		setTimeout(function(){ shownPopup.style.opacity = "1"; }, 0);

	},

	correctXY: function(popup, x, y)
	{
		var b = y + popup.offsetHeight + 4 - window.pageYOffset; // 4 == shadow
		var r = x + popup.offsetWidth + 4 - window.pageXOffset; 
	
		if(r > window.innerWidth) x = x - r + window.innerWidth;
		if(b > window.innerHeight) y = y - b + window.innerHeight;
	
		if(x < 0) x = 0;
		if(y < 0) y = 0;
		return {x: x, y: y};
	},
	
	hide: function()
	{
		if(this.showTimeout) 
		{
			clearTimeout(this.showTimeout);
			this.showTimeout = null;
		}
		if(!this.popup) {
			return;
		}
		
		this.popup.style.visibility = "hidden";
		
		if(this.popupMoving) this.popupMoving = false;
		if(this.element) {
			Event.del(this.element, "mousemove", this, this._element_onmousemove);
			this.element = null;
		}
	}
}

/*
	NOTE: twostate/pushed not supported for standard items.
	v. 2.0.2
*/
function PopupMenu(parentElement, position)
{
	this.index = 0;

	if(!position) position = "afterbegin";
	this.createElement(parentElement, position);
	
	this._activeItem = null;
	this._currentTO = null;
	PopupMenu._menus.push(this);
}
if(!top.__ontopZ) top.__ontopZ = 10000;

PopupMenu._menus = [];
PopupMenu.activeMenus = [];
PopupMenu.hideMenus = function(ev)
{
	//CNFormManager._trace("PopupMenu.hideMenus");
	for(var i = PopupMenu.activeMenus.length - 1; i >= 0; i--)
	{
		PopupMenu.activeMenus[i].hide(true, ev);
	}
}
PopupMenu.resetKeydown = function(ev)
{
	if(Event.keyValue(ev) == 27) PopupMenu.hideMenus(ev);
}
PopupMenu.unload = function()
{
	for(var i = 0; i < PopupMenu._menus.length; i++)
	{
		PopupMenu._menus[i].destroy();
	}
	PopupMenu._menus = null;
}
PopupMenu._document_onmousedown = function(ev) {
	//CNFormManager._trace("PopupMenu._document_onmousedown");
	PopupMenu.hideMenus(ev);
}

PopupMenu._handlerSet = false;
PopupMenu.setDocumentHandler = function()
{
	if(PopupMenu._handlerSet) return; // Avoid double event handler, FWUI-1288
	//CNFormManager._trace("PopupMenu.setDocumentHandler");
	PopupMenu._handlerSet = true;
	Event.nativeAdd(document.body, "mousedown", this._document_onmousedown);
	Event.nativeAdd(document.body, "keydown", PopupMenu.resetKeydown);
}
PopupMenu._detachBodyHandlers = function()
{
	if(!PopupMenu._handlerSet) return;
	//CNFormManager._trace("PopupMenu._detachBodyHandlers");
	PopupMenu._handlerSet = false;
	Event.nativeDel(document.body, "mousedown", this._document_onmousedown);
	Event.nativeDel(document.body, "keydown", PopupMenu.resetKeydown);
}
PopupMenu._removeMenu = function(menu)
{
	menu.hide();
	for(var i = 0; i < PopupMenu._menus.length; i++)
	{
		if(PopupMenu._menus[i] == menu) 
		{
			PopupMenu._menus.splice(i, 1);
			break;
		}
	}
}

var proto = PopupMenu.prototype;

// Events. ==================================
proto.onxlmenuhide = function(){}
proto.onmenuclick = function(){}


// Main stuff. ================================
proto.createElement = function(parentElement, position)
{
	var l = document.createElement("div");
	if(position == "afterbegin") parentElement.insertBefore(l, parentElement.firstChild);
	else if(position == "beforeend") parentElement.appendChild(l);
	else if(position == "beforebegin") parentElement.parentNode.insertBefore(l, parentElement);
	else if(position == "afterend") parentElement.parentNode.insertBefore(l, parentElement.nextSibling);
	else throw new Error("Unsupported popup menu position: " + position);
	
	this.element = l;
	l.jsObject = this;
	
	l.style.userSelect = "none";
	l.className = "popupMenu_container";

	if(Util.getStyle(l, "xl--left-line") != "false")
	{
		this.leftline = (function(){ var el = document.createElement("div"); el.className = 'leftline'; return el; })();
		this.leftline.style.userSelect = "none";
		l.appendChild(this.leftline);
	}
	
	l.style.boxShadow = "2px 3px 3px rgba(0, 0, 0, .3)";

	Event.add(l, "mouseleave", this, this._element_onmouseleave);

	if(CNFormManager.vista)
	{
		var hover = this._hover = document.createElement("div");
		hover.className = "hoverRect";
		hover.style.position = "absolute";
		hover.style.pointerEvents = "none";
		hover.style.backgroundImage = "url(" + CNFormManager.themeImagesPath + "item-gradient-5.gif)";
		hover.style.opacity = "0.3";
		hover.style.borderRadius = "5px";
		hover.style.visibility = "hidden";
		this.element.appendChild(hover);
	}
}

proto.destroy = function()
{
	this.hide();
	this.leftline = null;
	if(this.element)
	{
		if(this.element.shadow) 
		{
			this.element.shadow.destroy();
			this.element.shadow = null;
		}
		this.element.jsObject = null;
		this.element.remove();
		this.element = null;
	}
}

proto.createSubmenu = function(text, img)
{
	return this.createSubmenuEx(text, img).submenu;
}

proto.createSubmenuEx = function(text, img)
{
	var l = this.createItem(text, img, false, false);
	var arImg = (function(){ var el = document.createElement("img"); el.width = '7'; el.height = '7'; el.className = 'submenuIMG'; return el; })();
	l.style.userSelect = "none";
	l.appendChild(arImg);
	arImg.src = CNFormManager.neutralImagesPath + 'ar-right-1.gif'
	arImg.style.position = "absolute";
	arImg.style.right = "7px";
	arImg.style.top = (l.offsetHeight - 7) / 2 + "px";
	var submenu = new PopupMenu(this.element.parentElement);
	l._submenu = submenu.element;

	return {submenu: submenu, item: l};
}

proto.createItem = function(text, img)
{
	var l = document.createElement("div");
	l.style.userSelect = "none";
	this.element.appendChild(l);
	
	l._data = {
		index: this.index++,
		img: img
	}

	l.className = "item";
	var imgelcont = document.createElement("span");
	l.appendChild(imgelcont);
	
	imgelcont.className = "leftItem"
	imgelcont.style.userSelect = "none";

	if(img)
	{
		var imgel = document.createElement("img");
		imgel.style.userSelect = "none";
		imgelcont.appendChild(imgel);
	
		imgel.className = 'menuItemImg';
		imgel.src = img;
	} 

/*	if(twostate)
	{
		imgelcont.className = isPushed ? "leftItemChecked" : "leftItemUnchecked";
	}*/

	var textel = (function(){ var el = document.createElement("span"); el.className = 'text'; return el; })();
	textel.style.userSelect = "none";
	l.appendChild(textel);
	
	textel.innerHTML = text;
		
	//this.setCheckSign(l);

	Event.add(l, "mouseenter", this, this._item_mouseover);
	Event.add(l, "mouseleave", this, this._item_mouseout);
	Event.add(l, "mousedown", this, this._item_mousedown);

	return l;
}
{
	// NOTE: functionality is just enough for bedplanner's bigIcon menus.
	proto.createBigIconItem = function(data) {
		if(!this._lastBigIconCont) {
			this._lastBigIconCont = (function(){ var el = document.createElement("div"); el.className = 'bigIconCont'; return el; })();
			this.element.appendChild(this._lastBigIconCont);
		}

		var l = document.createElement("div");
		l.style.userSelect = "none";
		this._lastBigIconCont.appendChild(l);
		Tooltip.attach(l, data.text);

		l._data = data;
		data.index = this.index++;

		l.className = "bigIconItem";
		l.style.userSelect = "none";

		var imgel = document.createElement("img");
		imgel.style.userSelect = "none";
		imgel.src = data.img;
		l.appendChild(imgel);

		Event.add(l, "mouseenter", this, this._bigItem_mouseenter);
		Event.add(l, "mouseleave", this, this._bigItem_mouseleave);
		Event.add(l, "mousedown", this, this._bigItem_mousedown);

		if(data.pushed) {
			this.pushItem(l);
		}

		return l;
	}
	proto._bigItem_mouseenter = function(ev) {
		Util.addClass(ev.currentTarget || Util.findByClassName(Util.eventTarget(ev), "bigIconItem"), "hover");
	}
	proto._bigItem_mouseleave = function(ev) {
		Util.removeClass(ev.currentTarget || Util.findByClassName(Util.eventTarget(ev), "bigIconItem"), "hover");
	}
	proto._bigItem_mousedown = function(ev) {
		var l = ev.currentTarget || Util.findByClassName(Util.eventTarget(ev), "bigIconItem");
		if(!l || l.disabled) return;

		Util.removeClass(l, "hover");

		if(l._data.radio) this.pushItem(l);
		else if(l._data.twoState) this.togglePushItem(l);

		PopupMenu.hideMenus(ev);

		if(l._data.callback) {
			var menuEvent = {data: l._data, target: l};
			l._data.callback[1].call(l._data.callback[0], menuEvent);
		}
		CNUtil.cancelEvent(ev);
	}
	proto.pushItem = function(item) {
		Util.addClass(item, "pushed");
		item._data.pushed = true;
		if(item._data.radio) {
			var divs = this.element.getElementsByTagName("div");
			for(var i = 0; i < divs.length; i++) {
				var div = divs[i];
				if(div != item && div._data && div._data.radio == item._data.radio) {
					this.unpushItem(div);
				}
			}
		}
	}
	proto.unpushItem = function(item) {
		Util.removeClass(item, "pushed");
		item._data.pushed = false;
	}
	proto.togglePushItem = function(item) {
		if(item._data.twoState) {
			item._data.pushed
				? this.unpushItem(item)
				: this.pushItem(item);
		}
	}
	proto.createBigHR = function() {
		var l = (function(){ var el = document.createElement("div"); el.className = 'bigHR'; return el; })();
		l.style.userSelect = "none";
		this.element.appendChild(l);
		this._lastBigIconCont = null;
		return l;
	}
	proto.findItem = function(text) {
		var divs = this.element.getElementsByTagName("div");
		for(var i = 0; i < divs.length; i++) {
			var div = divs[i];
			if(div._data && div._data.text == text) {
				return div;
			}
		}
		return null;
	}
}

proto.createHR = function()
{
	var l = (function(){ var el = document.createElement("div"); el.className = 'hr'; return el; })();
	if(CNFormManager.vista)
	{
		l.appendChild(document.createElement("div"));
	}
	l.style.userSelect = "none";
	l.style.width = this.element.clientWidth - 30 + "px";
	this.element.appendChild(l);
	return l;
}
	
proto.putPushed = function(l, val)
{
/*	if(typeof val == "string") val = val == "true";
	if(val == l.isPushed) return;
	l.isPushed = val;
	
	l.children[0].className = l.isPushed ? "leftItemChecked" : "leftItemUnchecked";
	this.setCheckSign(l);*/
}

proto.setCheckSign = function(l)
{
/*	if(l.twostate && !l.img)
	{
		var checksign = Util.getStyle(l.parentElement, "xl--check-sign");
		// l.children[0] -> imgelcont.
		l.children[0].textContent = l.isPushed ? (checksign ? checksign : '') : '';
	}*/
}

proto.show = function(x, y, subMenu)
{
	//CNFormManager._trace("popupmenu.show id=" + this.element.id + ", x: " + x + ", y: " + y + ", subMenu: " + subMenu);

	if(!subMenu) PopupMenu.hideMenus();

	this.element.style.visibility = "hidden";
	//this.element.style.display = "block";
	this.element.style.zIndex = ++top.__ontopZ;
	
	if(x != null && y != null)
	{
		CNUtil.posPopup(this.element, x, y);
	}	
	if(CNFormManager.vista)
	{
		this.element.style.opacity = "0";
	}
	// NOTE: moved style change here as it needed for new shadow.htc version.
	this.element.style.visibility = "inherit";
	if(this.element.shadow) this.element.shadow.show();

	this._correctItemsWidth();
	if(this.leftline) this.leftline.style.height = this.element.clientHeight - 2 + "px";
	
	if(CNFormManager.vista)
	{
		this.element.style.transition = "opacity .3s";
		this.element.style.opacity = "1";
	}


	PopupMenu.activeMenus.push(this);
	// If first menu, set handlers.
	if(PopupMenu.activeMenus.length == 1) this.setDocumentHandlerTO();
}

proto.setDocumentHandlerTO = function()
{
	setTimeout(function(){ PopupMenu.setDocumentHandler(); }, 0);
}

proto._correctItemsWidth = function()
{
	var count = this.element.children.length;
	var width = 0;
	for(var i = 0; i < count; i++)
	{
		var l = this.element.children[i];
		if(l.className != "item") continue;
		width = Math.max(l.offsetWidth, width);
	}
	
	if(CNFormManager.vista)
	{
		for(var i = 0; i < count; i++)
		{
			var l = this.element.children[i];
			if(l.className == "item" || l.className == "hr")
				if(l.offsetWidth != width) l.style.width = width + "px";
		}
	}
	else
	{
		for(var i = 0; i < count; i++)
		{
			var l = this.element.children[i];
			if(l.className != "item") continue;		
			if(l.offsetWidth != width) l.style.width = width + "px";
		}
	}
}

proto.hide = function(force, ev)
{
	// Autohide self issue workaround. Now if menu is going to show self on mousedown, it 
	// callers can mark the event to keep it open.
	if(!this.element) return;
	ev = ev || Event.current();
	if(ev && ev.clientFrameworkKeepOpenFor == this.element) return;

	//CNFormManager._trace("hide id=" + this.element.id + ", force: " + force);

	if(this.element.style.display != "none" && force === true 
	|| (ev && !(Util.eventTarget(ev) && this.element.contains(Util.eventTarget(ev)))))
	{
		if(CNFormManager.vista) this.element.style.opacity = "1";

		if(this.element.shadow) this.element.shadow.hide();
		this.element.style.visibility = "hidden";
		
		if(CNFormManager.vista) this.element.style.opacity = "0";
		

		var ev = {};
		this.onxlmenuhide(ev);
	}

	// ISSUE: context-menu.log - when menu is hidden by destroying/loading the menu with the same id, menu wasn't
	// removed from activeMenus, causing _detachBodyHandlers to be never called.
	// Remove this menu from active menus even if menu is hidden.
	for(var i = 0; i < PopupMenu.activeMenus.length; i++)
	{
		if(PopupMenu.activeMenus[i] == this)
		{
			PopupMenu.activeMenus.splice(i, 1);
			break;
		}
	}
	if(PopupMenu.activeMenus.length == 0) {
		setTimeout(function(){ if(PopupMenu.activeMenus.length == 0) PopupMenu._detachBodyHandlers(); }, 0);
	}
}


// Event handlers. ========================================
proto._item_mousedown = function(ev)
{
	this.item_mousedown(ev);
}
proto.item_mousedown = function(ev)
{
	var l = ev.currentTarget || CNUtil.findByClassName(Util.eventTarget(ev), CNFormManager.vista ? "item" : "item_hover");

	if(!l || l.disabled) return;

	//if(l.twostate) l.isPushed = !l.isPushed

	if(l._submenu)
	{
		var x = this.element.offsetLeft + this.element.offsetWidth;
		var y = this.element.offsetTop + l.offsetTop - 1;
		this._showSubmenu(l._submenu, x, y);
	}
	else
	{
		l.className = "item";

		PopupMenu.hideMenus(ev);
	
		var menuEvent = {xlindex: l._data.index, target: l};
		if(l.onmenuclick) l.onmenuclick(menuEvent);
		if(l._data.callback) {
			l._data.callback[1].call(l._data.callback[0], menuEvent);
		}
	
		//if(cmdid && xlcc) xlcc.fire({target: element, cmdid: cmdid, param: param, index: index})
	}	
	CNUtil.cancelEvent(ev);
}

proto._setShowSubmenuTO = function(submenu, x, y)
{
	var obj = this;
	if(this._currentTO) clearTimeout(this._currentTO);
	this._currentTO = setTimeout(function(){ obj._showSubmenu(submenu, x, y); }, 400);
}

proto._showSubmenu = function(submenuID, x, y)
{
	var submenu = submenuID;
	if(!submenu) return;
	if(PopupMenu.activeMenus.length > 0 
	&& PopupMenu.activeMenus[PopupMenu.activeMenus.length - 1] == submenu.jsObject) return;
	
	this._hideSubmenus();
	if(submenu.jsObject) submenu.jsObject.show(x, y, true);
	this._currentTO = null;
}

proto._item_mouseover = function(ev)
{
	this.item_mouseover(ev);
}
proto.item_mouseover = function(ev)
{
	var l = ev.currentTarget || CNUtil.findByClassName(Util.eventTarget(ev), "item");	
	if(!l || l.disabled || this._activeItem == l) return;
	if(this._activeItem) this._unhoverItem(this._activeItem);
	this._activeItem = l;	

	if(CNFormManager.vista)
	{
		this._hover.style.top = l.offsetTop + "px";
		this._hover.style.width = l.offsetWidth - 1 + "px";
		this._hover.style.height = l.offsetHeight - 1 + "px";
		this._hover.style.visibility = "inherit";
	}
	else l.className = "item_hover";
	if(l._submenu) 		
	{
		var x = this.element.offsetLeft + this.element.offsetWidth;
		var y = this.element.offsetTop + l.offsetTop - 1;
		this._setShowSubmenuTO(l._submenu, x, y);
	}
	CNUtil.cancelEvent(ev);
}

proto._item_mouseout = function(ev)
{
	this.item_mouseout(ev);
}
proto.item_mouseout = function(ev)
{
	var l = ev.currentTarget || CNUtil.findByClassName(Util.eventTarget(ev), "item");
	if(!l || l.disabled) return;

	if(l._submenu && (!this.element.contains(ev.relatedTarget)
	|| ev.relatedTarget == this.element)) return;
	
	this._unhoverItem(l);
	this._activeItem = null;
	
	CNUtil.cancelEvent(ev);
}
proto._unhoverItem = function(l)
{
	if(CNFormManager.vista) this._hover.style.visibility = "hidden";
	else l.className = "item";
	if(l._submenu) this._setHideSubmenusTO();
}

proto._setHideSubmenusTO = function()
{
	var obj = this;
	if(this._currentTO) clearTimeout(this._currentTO);
	this._currentTO = setTimeout(function(){ obj._hideSubmenus(); }, 400);
}

proto._hideSubmenus = function()
{
	this._currentTO = null;
	// Hide all menus down to current menu.
	for(var i = PopupMenu.activeMenus.length - 1; i >= 0; i--)
	{
		var menu = PopupMenu.activeMenus[i];
		if(menu == this) break;
		menu.hide(true);
	}
}


proto._element_onmouseleave = function(ev)
{
	this.element_onmouseleave(ev);
}
proto.element_onmouseleave = function(ev)
{
	var activeMenu = null;
	if(PopupMenu.activeMenus.length > 0) activeMenu = PopupMenu.activeMenus[PopupMenu.activeMenus.length - 1];
	
	if(activeMenu && activeMenu.element && activeMenu.element.contains(ev.relatedTarget)) 
	{
		if(this._currentTO) 
		{
			clearTimeout(this._currentTO);
			this._currentTO = null;
		}
		return;
	}
	if(this._activeItem) 
	{
		this._unhoverItem(this._activeItem);	
		this._activeItem = null;
	}
}

proto.removeMenuTree = function()
{
	this._walkAndRemoveMenuTree(this.element);
}
proto._walkAndRemoveMenuTree = function(l)
{
	var children = l.children;
	for(var i = 0; i < children.length; i++)
	{
		var child = children[i];
		if(child._submenu)
		{
			this._walkAndRemoveMenuTree(child._submenu);
		}
	}
	PopupMenu._removeMenu(l.jsObject);
	l.jsObject.destroy();
}

/*
	NOTE: requires destroy call.
	v. 2.0.1 
	+ support for body based attachable shadow.
*/
function Shadow(element, shadowautoshow, precreateShadow)
{
	this.element = element;
	if(this.element && !this.element.shadow) element.shadow = this;
	
	this.hshadow = null;
	this.vshadow = null;
	this.created = false;

	this.shadowautoshow = shadowautoshow;
	this.precreateShadow = precreateShadow;

	if(this.shadowautoshow || this.precreateShadow) this.createShadow();
}
var proto = Shadow.prototype;

proto.destroy = function()
{
	if(this.hshadow)
	{
		Util.removeElement(this.hshadow);
		Util.removeElement(this.vshadow);
		this.vshadow = null;
		this.hshadow = null;
	}
	if(this.element && this.element.shadow == this) this.element.shadow = null;
	this.element = null;	
}

proto.createShadow = function()
{
	if(this.created) return;

	var shadowOpacity = "0.3";
	var pixelRadius = "2";
	this.hshadow = document.createElement("div");
	this.vshadow = document.createElement("div");

	if(this.element)
	{
		shadowOpacity = Util.getStyle(this.element, "xl--shadow-opacity");
		if(!shadowOpacity) shadowOpacity = "0.3";
	
		pixelRadius = Util.getStyle(this.element, "xl--shadow-pixel-radius");
		if(!pixelRadius) pixelRadius = "2";

		this.element.parentNode.insertBefore(this.hshadow, this.element); // Added to the same parent.
		this.element.parentNode.insertBefore(this.vshadow, this.element); // Added to the same parent.	
	}
	else
	{
		document.body.appendChild(this.hshadow);
		document.body.appendChild(this.vshadow);		
	}	

	this.hshadow.style.position = "absolute";
	this.vshadow.style.position = "absolute";

	this.hshadow.style.height = "3px";
	this.hshadow.style.overflow = "hidden";

	if(this.element && this.shadowautoshow) 
	{
		this.syncPosition();	
	}
	else 
	{
		this.hshadow.style.visibility = "hidden";
		// Avoid scrolling.
		this.hshadow.style.width = "1px";
		this.hshadow.style.top = "0px"; 
		this.hshadow.style.left = "0px";
	}

	this.hshadow.style.background = "rgba(0, 0, 0, " + shadowOpacity + ")";

	this.vshadow.style.width = "3px";
	this.vshadow.style.overflow = "hidden";
	if(this.element && this.shadowautoshow) 
	{
		this.syncPosition();
	}
	else 
	{
		this.vshadow.style.visibility = "hidden";
		// Avoid scrolling.
		this.vshadow.style.height = "1px";
		this.vshadow.style.top = "0px";
		this.vshadow.style.left = "0px";
	}
	
	if(this.element && !this.shadowautoshow) this.syncPosition();
	
	this.vshadow.style.background = "rgba(0, 0, 0, " + shadowOpacity + ")";

	this.hshadow.style.userSelect = "none";

	this.created = true;
}

proto.show = function()
{
	if(!this.created) this.createShadow();

	if(this.element) this.syncPosition();
	this.hshadow.style.visibility = "visible";
	this.vshadow.style.visibility = "visible";
	this.hshadow.style.display = this.vshadow.style.display = "block";
	this.hshadow.style.zIndex = this.vshadow.style.zIndex = this.element ? Util.getComputedStyle(this.element).zIndex : "";
}

proto.attach = function(l)
{
	this.element = l;
	this.element.shadow = this;
	this.syncPosition();
}

proto.detach = function()
{
	if(!this.element) return;
	this.hide();
	this.element.shadow = null;
	this.element = null;
}

proto.syncPosition = function()
{
	if(Util.getComputedStyle(this.element).display == "none" 
	|| Util.getComputedStyle(this.element).visibility == "hidden"
	|| !this.element.offsetWidth) return;

	var off = Util.getStyle(this.element, "xl--shadow-offset");
	if(!off && off !== 0) off = 2;
	else off = parseInt(off, 10);

	this.hshadow.style.top = (this.element.offsetHeight + this.element.offsetTop - 5 + off) + "px";
	this.hshadow.style.left = (this.element.offsetLeft + 2) + "px";
	this.hshadow.style.width = Math.max(1, this.element.offsetWidth - 5 + off) + "px";

	this.vshadow.style.top = (this.element.offsetTop + 2) + "px";
	this.vshadow.style.left = (this.element.offsetLeft + this.element.offsetWidth - 5 + off) + "px";
	var h = this.element.offsetHeight - 5 + off;
	this.vshadow.style.height = (h > 0 ? h : 1) + "px";
}

proto.hide = function()
{
	if(!this.vshadow) return;
	
	this.vshadow.style.display = "none";
	this.hshadow.style.display = "none";
}
/*
	v. 0.25 send client uniqueID on login
	v. 0.24
	+ anim
	+ initial release
*/
function CN_logincontrol_pre()
{
	this._newPasswordCanceled = false;
	this._lockMode = false;
	this._processingPE = false;
	this._salt = null;
}
CN_logincontrol_pre.loginImage = false;

var proto = CN_logincontrol_pre.prototype;

proto.createElement = function(node, parentElement)
{
	var l = (function(){ var el = document.createElement("div"); el.className = 'cn_logincontrol'; return el; })();
	parentElement.appendChild(l);
	
	this.element = l;
	l.jsObject = this;
	
	this._buildContent();
	
	if(node.getAttribute("lock") == "true") 
	{
		CNFormManager.getBaseFormManager().pauseAutoLockTimer();
		//CNFormManager.getBaseFormManager().resumeHeartBeatTimer();
		this._lockScreen(node);
	}
	
	return l;
} 

proto._elements = function(root)
{
	var result = {};
	var nodes = root.querySelectorAll("[id]");
	for(var i = 0; i < nodes.length; i++) result[nodes[i].id] = nodes[i];
	return result;
}

proto._buildContent = function()
{
	$("__loginChrome").style.display = "block";
	var img = $("__loginImage");
	if(img) img.style.display = CN_logincontrol_pre.loginImage ? "block" : "none";
	
	var html = '<div class="div1">\
	<div id="bottomLoginBottomDiv2"\
		style="background: url(' + CNFormManager.themeImagesPath + 'login-3-3.gif); display: block; ">\
		<table class="table1">\
		<tr>\
		<td><b>New Password</b></td>\
		<td colspan=2><input id="newPassword__" type=password class="width100"></td>\
		</tr>\
		<tr>\
		<td><b>Re-Enter Password</b></td>\
		<td><input id="reenterPassword__" type=password class="width100"></td>\
		<td align=right>\
			<input \
				type=submit id="okChangeButton__" class="button" value="OK"\
				>\
			<input \
				type=submit id="cancelChangeButton__" class="button" value="Cancel"\
				>\
		</td>\
		</tr>\
		</table>\
	</div>\
	<div id="topLoginBottomDiv" style="background: url(\'' + CNFormManager.themeImagesPath + 'login-3-3.gif\'); ">\
		<table class="table2">\
		<tr>\
		<td><b>User</b></td>\
		<td>\
		    <input id="userTextBox__" type=text>\
		</td>\
		<td width=1></td>\
		<td><b>Password</b></td>\
		<td>\
		    <input id="passwordTextBox__" type=password>\
		</td>\
		<td>\
			<input \
				type=submit id="loginButton__" tabIndex="4" class="button" \
				>\
		</td></tr>\
		<tr id="locationTR__">\
			<td><b>Location</b></td><td colspan="4" id="locationTD__"></td></tr>\
		</table>\
	</div>\
	<div class="div3">\
		<div style="background: url(\'' + CNFormManager.themeImagesPath + 'login-3-2.gif\'); " class="div4">\
			<div id="lockImg__" style="background: url(' + CNFormManager.themeImagesPath + 'lock-1.png) center / contain no-repeat; "></div>\
			<div class="div5">' + CNFormManager.strings['loginCaption'] + '</div>\
		</div>\
	</div>\
	<div id="loginLogoAnimDiv__" style="background: url(' + CNFormManager.themeImagesPath + 'login-3-1.png) center / 100% 100% no-repeat;">\
		<div class="div6">\
			<div style="display: inline-block; width: 90px; height: 145px; background: url(\'' + CNFormManager.strings['loginLogo'] + '\') center / 100% 100% no-repeat; "></div>\
		</div>\
	</div>\
	<div id="div7" class="div7" style="background: url(' + CNFormManager.themeImagesPath + 'login-right-panel-1.png) center / 100% 100% no-repeat; ">\
			<img src="g/siteLogo.gif" class="img1" onload="this.style.visibility=\'inherit\'; ">\
	</div>\
</div>';
	this.element.innerHTML = html;
	var controls = this._elements(this.element);
	Event.add(controls.okChangeButton__, "click", this, this.changePasswordButtonClick);
	Event.add(controls.cancelChangeButton__, "click", this, this.cancelPasswordButtonClick);
	Event.add(controls.loginButton__, "click", this, this.loginButtonClick);

	this._showLoginScreen();
}

proto.loadData = function(node)
{
	if(node.getAttribute("passwordExpireDays")) this._processPasswordExpiry(node);
	this._salt = node.getAttribute("salt");
	
	var message = Util.xmlSelectSingleNode(node, "message");
	if(message) {
		this._showMessage(message);
	}
}
proto._showMessage = function(node) {
	//redHeader
	var redHeader = this._redHeader = $('__si_formRedHeaderBG').cloneNode(true);
	redHeader.style.left = "-2px";
	redHeader.style.width = "620px";

	this.element.firstElementChild.appendChild(redHeader);
	redHeader.className = "messageRedHeader";

	var div = document.createElement("div");
	this.element.firstElementChild.appendChild(div);
	div.className = "messageDiv";
	div.innerHTML = Util.xmlInnerString(node);

	redHeader.style.height = div.offsetHeight + 40 + "px";

	var obj = this;
	setTimeout(function() {
		obj._redHeader.style.display = "block";
		var toY = -(div.offsetHeight); 
		Animator.start(new AnimMove(obj._redHeader, 0, toY),
			new AnimMove(div, 0, toY));
	}, 1000);
}

proto.storeData = function(xmldoc)
{
	if(this._lockMode)
	{
		var node = xmldoc.createElement("unlock");
		node.setAttribute("name", this._loginUser);
		node.setAttribute("pass", this._encrypt(this._loginPass));
		this._loginUser = null;
		this._loginPass = null;
		return node;
	}
	else if(this._newPassword)
	{
		var node = xmldoc.createElement("newPassword");
		node.setAttribute("canceled", "false");
		node.setAttribute("pass", this._newPassword);
		this._newPassword = null;
		return node;
	}
	else if(this._newPasswordCanceled)
	{
		var node = xmldoc.createElement("newPassword");
		node.setAttribute("canceled", "true");
		this._newPasswordCanceled = false;
		return node;
	}
	else
	{
		var fragment = xmldoc.createDocumentFragment();
		var node = xmldoc.createElement("loginEvent");
		node.setAttribute("name", this._loginUser);
		node.setAttribute("pass", this._encrypt(this._loginPass));
		fragment.appendChild(node);
				
		this._uniqueID = this.formManager._fetchUniqueID();
		
		node = xmldoc.createElement("uniqueID");
		node.setAttribute("value", this._uniqueID);
		fragment.appendChild(node);
		
		var rootEl = this.formManager._getStoredLocationsXML(true);
		if(rootEl) 
		{
			if(this._selectLocationCombo) 
			{
				var storedNodes = Util.xmlSelectNodes(rootEl, "location");
				
				var ix = this._selectLocationCombo.get_selectedIndex();
				
				if(ix >= storedNodes.length) ix = -1; 
				rootEl.setAttribute("selection", ix);
			}
			fragment.appendChild(rootEl);
		}
		this._loginUser = null;
		this._loginPass = null;
		return fragment;
	}
}

proto._encrypt = function(data) {
	if(!this._salt) return data;
	return Util.SHA1.compute(data + this._salt, "hex");
}

proto.unload = function()
{
	$("__loginChrome").style.display = "none";
	if(this._selectLocationCombo) CNFormManager.destroyJSObject(this._selectLocationCombo);	
	CNFormManager.getBaseFormManager()._autoLockShutDown = false;
	CNFormManager.getBaseFormManager()._heartBeatShutDown = false;
	
	var timeoutHeartBeat = CNFormManager.getBaseFormManager()._heartBeatTime;
	CNFormManager.getBaseFormManager()._heartBeatTime = CNFormManager.getBaseFormManager()._heartBeatTO = 0;
	CNFormManager.getBaseFormManager()._heartBeatPaused = false;
	CNFormManager.getBaseFormManager()._startHeartBeatTimer(timeoutHeartBeat);
	
	var timeout = CNFormManager.getBaseFormManager()._autoLockTime;
	CNFormManager.getBaseFormManager()._autoLockTime = CNFormManager.getBaseFormManager()._autoLockTO = 0;
	CNFormManager.getBaseFormManager()._autoLockPaused = false;
	
	CNFormManager.getBaseFormManager()._startAutoLockTimer(timeout);
}


proto._showLoginScreen = function()
{
	var all = this._elements(this.element);
	
	all.userTextBox__.tabIndex = 1;
	all.passwordTextBox__.tabIndex = 2;
	all.userTextBox__.disabled = all.passwordTextBox__.disabled 
		= all.loginButton__.disabled = all.topLoginBottomDiv.disabled = false;
	all.userTextBox__.value = all.passwordTextBox__.value = "";
	all.loginButton__.tabIndex = 4;
	all.lockImg__.style.display = 'none';

	all.loginButton__.value = "Login";
	
	all.bottomLoginBottomDiv2.style.display = "none";
	
	try{ all.userTextBox__.focus(); } catch(e){}
	
	try 
	{
		var storedRoot = this.formManager._getStoredLocationsXML();
		var storedNodes = Util.xmlSelectNodes(storedRoot, "location");
		if(storedNodes.length > 0) 
		{							  
			this._showLocationCombo(storedNodes);
		}
	}
	catch(e)
	{}


	Event.add(this.element, "keypress", this, this._element_onkeypress);

	Animator.start(new AnimMove(all.loginLogoAnimDiv__, 0, 0),
					new AnimMove(all.div7, 524, 0),
					new AnimMove(all.topLoginBottomDiv, all.topLoginBottomDiv.offsetLeft, 62));
}

proto._element_onkeypress = function(ev)
{
	this.element_onkeypress(ev);
}
proto.element_onkeypress = function(ev)
{
	if(Event.keyValue(ev) == 13 && !this._processingPE)
	{
		CNUtil.cancelEvent(ev);
		this.loginButtonClick();
	}
}


proto._createSelectLocationCombo = function(all)
{
	var td = all.locationTD__;
	
	this._selectLocationCombo = new CN_combobox();
	var options = [];

	var comboEl = this._selectLocationCombo.createElement(options, all.locationTD__);
	this._selectLocationCombo.set_tabIndex(3);
	comboEl.style.width = "270px";
}

proto._showLocationCombo = function(storedNodes)
{
	var all = this._elements(this.element);
	var table = all.topLoginBottomDiv.children[0];
	if(!this._selectLocationCombo) this._createSelectLocationCombo(this._elements(table));	
	
	table.style.top = Util.getStyle(table, "xl--with-location-top");
	table.style.left = Util.getStyle(table, "xl--with-location-left");
	this._elements(table).locationTR__.style.display = "block";

	this._fillSelectLocationCombo(storedNodes);
}

proto._fillSelectLocationCombo = function(storedNodes)
{
	var options = [];
	for(var i = 0; i < storedNodes.length; i++)
	{
		var option = {text: Util.xmlText(storedNodes[i])};
		options.push(option);
	}
	
	options.push({text: "<Click here to select another location after login>"});

	this._selectLocationCombo.initData(options);
	this._selectLocationCombo.set_selectedIndex(0, true);
}

proto._hideLocationCombo = function()
{
	var all = this._elements(this.element);
	var table = all.topLoginBottomDiv.children[0];
	table.style.top = null;
	table.style.left = null;
	this._elements(table).locationTR__.style.display = "none";
}

proto.loginButtonClick = function()
{
	var all = this._elements(this.element);
	if(!all.userTextBox__.value)
	{
		all.userTextBox__.style.borderColor = "red";
		return;
	}
	all.userTextBox__.style.borderColor = "";

	this._loginUnlock(all.userTextBox__.value, all.passwordTextBox__.value);
}

proto._loginUnlock = function(user, pass)
{
	this._loginUser = user;
	this._loginPass = pass;
	this.formManager.postData(this.element);
}

proto._processPasswordExpiry = function(passwordExpiryNode)
{
	this._processingPE = true;
	var days = passwordExpiryNode.getAttribute("passwordExpireDays");

	if(document.activeElement && document.activeElement.blur) document.activeElement.blur();

	if(days > 0) {
		this._forcePasswordExpire = false;
		this.formManager._showYesNoDialog("Password expire", "<b>Your password will expire in " + days + " day(s). Do you wish to change your password now?</b>",
								[this, "_processPasswordExpiry2"]);
	} else {
		this._forcePasswordExpire = true;
		this.formManager._showOKDialog("Password expire", "<b>Your password expired " + -(days)  + " day(s) ago. You must change your password now.</b>",
								[this, "_processPasswordExpiry2"]);
	}

}

proto._processPasswordExpiry2 = function(dialog, cancel)
{
	if(!cancel || this._forcePasswordExpire) // Yes.
	{
		var all = this._elements(this.element);
		all.newPassword__.value = all.reenterPassword__.value = "";

		all.userTextBox__.disabled = all.passwordTextBox__.disabled 
			= all.loginButton__.disabled = all.topLoginBottomDiv.disabled = true;
		var bottomLoginBottomDiv2 = all.bottomLoginBottomDiv2;
		if(this._selectLocationCombo) this._selectLocationCombo.set_disabled(true);
		
		bottomLoginBottomDiv2.style.display = "block";

		all.cancelChangeButton__.style.display = this._forcePasswordExpire ? "none" : "";
	}
	else // No.
	{
		this._newPasswordCanceled = true;
		this.formManager.postData(this.element);
	}
}

proto.changePasswordButtonClick = function()
{
	var all = this._elements(this.element);
	if(!all.newPassword__.value)
	{
		all.newPassword__.style.borderColor = "red";
		return;
	}
	else if(!all.reenterPassword__.value)
	{
		all.reenterPassword__.style.borderColor = "red";
		return;
	}
	all.newPassword__.style.borderColor = "";
	all.reenterPassword__.style.borderColor = "";
	if(all.newPassword__.value != all.reenterPassword__.value)
	{
		alert("Your password entries didn't match.");
		return;
	}

	this._newPassword = all.newPassword__.value;
	this.formManager.postData(this.element);
}

proto.cancelPasswordButtonClick = function()
{
	this._newPasswordCanceled = true;
	this.formManager.postData(this.element);
}

proto._lockScreen = function(loginNode, message)
{
	var all = this._elements(this.element);
	
	all.userTextBox__.tabIndex = 1;
	all.passwordTextBox__.tabIndex = 2;
	all.userTextBox__.disabled = all.passwordTextBox__.disabled 
		= all.loginButton__.disabled = all.topLoginBottomDiv.disabled = false;
	all.userTextBox__.value = all.passwordTextBox__.value = "";
	all.loginButton__.tabIndex = 4;
	all.lockImg__.style.display = 'block';

	all.loginButton__.value = "Unlock";
	
	all.bottomLoginBottomDiv2.style.display = "none";
	
	var table = all.topLoginBottomDiv.children[0];
	this._elements(table).locationTR__.style.display = "none";
	
	try{ all.userTextBox__.focus(); } catch(e){}
	
	this._lockMode = true;
}

proto = null;

/*
	v. 2.0.1
*/
function CN_logincontrol_vista()
{
	this._lockMode = false;
	this._jsObjects = [];
	this._disabled = false;
	this._salt = "";
}
var proto = CN_logincontrol_vista.prototype;

CN_logincontrol_vista.loginImage = false;

proto._createActionImage = function(black)
{
	var img;
	if(black)
	{
		img = document.createElement("span");
		img.style.display = "inline-block";
		img.style.width = "22px";
		img.style.height = "22px";
		img.style.backgroundImage = "url(" + CNFormManager.themeImagesPath + "square-button-set.gif)";
		img.style.backgroundRepeat = "no-repeat";
		img.style.backgroundPosition = "0px 0px";
		Event.nativeAdd(img, "mouseenter", function() { if(!img.disabled) img.style.backgroundPosition = "-22px 0px"; });
		Event.nativeAdd(img, "mouseleave", function() { img.style.backgroundPosition = "0px 0px"; });
		Event.nativeAdd(img, "mousedown", function() { if(!img.disabled) img.style.backgroundPosition = "-44px 0px"; });
		Event.nativeAdd(img, "mouseup", function() { if(!img.disabled) img.style.backgroundPosition = "-22px 0px"; });
	}
	else
	{
		img = document.createElement("img");
		img.src = CNFormManager.themeImagesPath + "round-button.gif";
		Event.nativeAdd(img, "mouseenter", function() { if(!img.disabled) img.src = CNFormManager.themeImagesPath + "hover-round-button.gif"; });
		Event.nativeAdd(img, "mouseleave", function() { img.src = CNFormManager.themeImagesPath + "round-button.gif"; });
		Event.nativeAdd(img, "mousedown", function() { if(!img.disabled) img.src = CNFormManager.themeImagesPath + "down-round-button.gif"; });
		Event.nativeAdd(img, "mouseup", function() { if(!img.disabled) img.src = CNFormManager.themeImagesPath + "hover-round-button.gif"; });
	}
	return img;
}

proto.createElement = function(node, parentElement)
{
	var l = (function(){ var el = document.createElement("div"); el.className = 'cn_logincontrol'; return el; })();
	parentElement.appendChild(l);
	
	this.element = l;
	l.jsObject = this;
	
	this._buildContent();
	
	this._lockMode = node.getAttribute("lock") == "true";
	
	this._showLoginScreen();	
	
	return l;
} 

proto._buildContent = function()
{
	$("__loginChrome").style.display = "block";

	var img = $("__loginImage");
	if(img) img.style.display = CN_logincontrol_vista.loginImage ? "block" : "none";
	
	var outerDiv = (function(){ var el = document.createElement("div"); el.className = 'outerDiv'; return el; })(); // Anchor div.
	this.element.appendChild(outerDiv);
	
	var frameCont = (function(){ var el = document.createElement("div"); el.className = 'frameCont'; return el; })();
	outerDiv.appendChild(frameCont);
	
	frameCont.innerHTML = $("__plainBG").innerHTML;
	var frame = frameCont.firstElementChild;
	frame.style.visibility = "hidden";	
	frame.style.opacity = "0";

	this._contentDiv = (function(){ var el = document.createElement("div"); el.className = 'contentDiv'; return el; })();
	frameCont.appendChild(this._contentDiv);
	this._contentDiv.style.visibility = "hidden";

	var loginContentDiv = (function(){ var el = document.createElement("div"); el.className = 'loginContentDiv'; return el; })();
	this._contentDiv.appendChild(loginContentDiv);

	var focusDiv = (function(){ var el = document.createElement("span"); el.tabIndex = '1'; el.style.width = '1px'; el.style.overflow = 'hidden'; return el; })();
	loginContentDiv.appendChild(focusDiv);	
	
	this._focusDiv = focusDiv;
	
	this._lockDiv = (function(){ var el = document.createElement("div"); el.className = 'lockDiv'; return el; })();
	loginContentDiv.appendChild(this._lockDiv);
	
	this._userBox = (function(){ var el = document.createElement("input"); el.type = 'text'; el.className = 'loginBox untouched'; el.tabIndex = '2'; return el; })();
	this._userBox._isEmpty = true;
	this._userBox.value = "User";
	loginContentDiv.appendChild(this._userBox);
	VistaSupport.attachToTextBox(this._userBox);
	Event.add(this._userBox, "focus", this, this._userBox_onfocus);
	Event.add(this._userBox, "blur", this, this._userBox_onblur);
	Event.add(this._userBox, "keypress", this, this._userBox_onkeypress);
	
	this._fakePasswordBox = (function(){ var el = document.createElement("input"); el.type = 'text'; el.className = 'passwordBox untouched'; el.tabIndex = '3'; return el; })();
	this._fakePasswordBox.value = "Password";
	loginContentDiv.appendChild(this._fakePasswordBox);
	VistaSupport.attachToTextBox(this._fakePasswordBox);
	Event.add(this._fakePasswordBox, "focus", this, this._fakePasswordBox_onfocus);
	
	this._passwordBox = (function(){ var el = document.createElement("input"); el.type = 'password'; el.className = 'passwordBox'; el.tabIndex = '3'; return el; })();
	this._passwordBox.style.display = "none";
	loginContentDiv.appendChild(this._passwordBox);
	VistaSupport.attachToTextBox(this._passwordBox);
	Event.add(this._passwordBox, "blur", this, this._passwordBox_onblur);

	var img;
	if(CNFormManager.subTheme == "black") {
		img = this._createActionImage(true);

		var siteLogo = document.getElementById("__siteLogo");
		siteLogo.style.width = "1px";
		siteLogo.style.backgroundSize = "contain";
		siteLogo.style.objectFit = "contain"; // Reset logo back to image size.
	} else {
		img = this._createActionImage(false);
	}
	
	img.tabIndex = 4; // After locations combo.
	img.className = "imgButton";
	loginContentDiv.appendChild(img);
	Event.add(img, "click", this, this._img_onclick);
	this._imgButton = img;
	
	if(CNFormManager.strings['loginCaption']) {
		$('__loginLabel').innerHTML = $('__loginLabelShade').innerHTML = CNFormManager.strings['loginCaption'];
	}
	if(CNFormManager.strings['loginLogo']) {
		var loginLogo = $('__loginLogoIMG');
		if(loginLogo.tagName == "IMG") loginLogo.src = CNFormManager.strings['loginLogo'];
		else loginLogo.style.backgroundImage = "url(" + CNFormManager.strings['loginLogo'] + ")";
	}
	
	Event.add(this.element, "keypress", this, this._element_onkeypress);	
}

proto.set_disabled = function(value)
{
	if(value == this._disabled) return;
	this._disabled = value;
	
	this._userBox.readOnly = this._fakePasswordBox.readOnly = this._passwordBox.readOnly = value;
	if(this._selectLocationCombo) this._selectLocationCombo.set_disabled(value);
	this._imgButton.disabled = value;
}

proto._showLoginScreen = function()
{
	if(this._lockMode)
	{
		this._lockDiv.style.display = "inline";
	}
	else
	{	
		var stored = false;
		try 
		{
			var storedRoot = this.formManager._getStoredLocationsXML();
			var storedNodes = Util.xmlSelectNodes(storedRoot, "location");
			if(storedNodes.length > 0) 
			{							  
				this._showLocationCombo(storedNodes);
				this.element.className = "cn_logincontrol cn_logincontrol_big";
				stored = true;
			}
		}
		catch(e){}
		if(!stored) this.element.className += " cn_logincontrol_no_stored";
	}	
}

// Actually shows and animates control.
proto.validateLoading = function()
{
	var frameCont = this.element.firstElementChild.firstElementChild;
	var self = this;
	//this._contentDiv
	setTimeout(function()
	{
		self._contentDiv.style.visibility = "inherit";
		
		var frame = frameCont.firstElementChild;
		frame.style.opacity = "0";
		frame.style.visibility = "inherit";
		frame.style.transition = "opacity .5s";
		frame.style.opacity = "1";	
		self._focusDiv.focus();
		AnimVistaFadeResize(frameCont, 60, 10);	
		
		if(CNFormManager.subTheme == "black") {		
			setTimeout(function() {
				var siteLogo = document.getElementById("__siteLogo");
				if(siteLogo) {
					var w = siteLogo.offsetWidth,
						h = siteLogo.offsetHeight;
					siteLogo.style.width = w + "px";
					siteLogo.style.height = h + "px";
					siteLogo.style.backgroundSize = "100% 100%";
					siteLogo.style.objectFit = "fill";
					
					Animator.start(new AnimResize(siteLogo, w / 2.5, h / 2.5));
				}
			}, 3000);
		}
	}, 0);
}

proto._createSelectLocationCombo = function()
{
	this._selectLocationCombo = new CN_combobox();
	this._jsObjects.push(this._selectLocationCombo);

	var comboEl = this._selectLocationCombo.createElement(Util.wrapIntoNode({}), this._contentDiv);
	this._selectLocationCombo.set_tabIndex(3);
}

proto._showLocationCombo = function(storedNodes)
{
	if(!this._selectLocationCombo) this._createSelectLocationCombo();	
	this._fillSelectLocationCombo(storedNodes);
}

proto._fillSelectLocationCombo = function(storedNodes)
{
	var options = [];
	for(var i = 0; i < storedNodes.length; i++)
	{
		var option = {text: Util.xmlText(storedNodes[i])};
		options.push(option);
	}
	
	options.push({text: "<Not listed>"});

	this._selectLocationCombo.initData(options);
	this._selectLocationCombo.set_selectedIndex(0, true);
}

proto._img_onclick = function()
{
	this.loginButtonClick();
}
proto._userBox_onfocus = function(ev)
{
	var box = Util.eventTarget(ev);
	var jso = Util.dispatchObject();
	if(jso._disabled || !box._isEmpty) return;
	box._emptyValue = box.value;
	box.value = "";
	box.select();
	Util.removeClass(box, "untouched");
}
proto._userBox_onkeypress = function(ev)
{
	var jso = Util.dispatchObject();
	if(jso._disabled) return;
	
	var box = Util.eventTarget(ev);	
	box._isEmpty = false;
}
proto._userBox_onblur = function(ev)
{
	var jso = Util.dispatchObject();
	if(jso._disabled) return;

	var box = Util.eventTarget(ev);
	if(box.value == "") 
	{	
		box.value = box._emptyValue;
		box.className += " untouched";
		box._isEmpty = true;
	}
	else box._isEmpty = false;
}
proto._fakePasswordBox_onfocus = function(ev)
{
	var jso = Util.dispatchObject();
	if(jso._disabled) return;
	
	var box = Util.eventTarget(ev);
	jso._passwordBox.style.display = "inline";
	jso._passwordBox.focus();
	jso._passwordBox.select();
	box.style.display = "none";
}
proto._passwordBox_onblur = function(ev)
{
	var jso = Util.dispatchObject();
	if(jso._disabled) return;
	
	var box = Util.eventTarget(ev);
	if(box.value == "")
	{
		jso._fakePasswordBox.style.display = "inline";
		box.style.display = "none";		
	}
}

proto.loadData = function(node)
{
	this._salt = node.getAttribute("salt");

	var message = Util.xmlSelectSingleNode(node, "message");
	if(message) {
		this._showMessage(message);
	}
}

proto._showMessage = function(node) {
	//redHeader
	var redHeader = this._redHeader = $(CNFormManager.subTheme == "black" ? '__vistaFormRedHeaderBG' : '__si_formRedHeaderBG').cloneNode(true);
	this.element.firstElementChild.appendChild(redHeader);
	redHeader.className = "messageRedHeader";

	var div = document.createElement("div");
	this.element.firstElementChild.appendChild(div);
	div.className = "messageDiv";
	div.innerHTML = Util.xmlInnerString(node);

	var obj = this;
	setTimeout(function() {
		obj._redHeader.style.display = "block";
		div.style.visibility = "inherit";
		Animator.start(new AnimMove(obj._redHeader, obj._redHeader.offsetLeft, -div.offsetHeight - 10), 
			new AnimMove(div, 0, -div.offsetHeight));
	}, 1000);

}

proto.storeData = function(xmldoc)
{
	if(this._lockMode)
	{
		var node = xmldoc.createElement("unlock");
		node.setAttribute("name", this._userBox.value);
		node.setAttribute("pass", this._encrypt(this._passwordBox.value));
		
		return node;
	}

	var fragment = xmldoc.createDocumentFragment();
	var node = xmldoc.createElement("loginEvent");
	node.setAttribute("name", this._userBox.value);
//	node.setAttribute("pass", this._passwordBox.value);
	node.setAttribute("pass", this._encrypt(this._passwordBox.value));

	fragment.appendChild(node);

	var rootEl = this.formManager._getStoredLocationsXML(true);
	if(rootEl) 
	{
		if(this._selectLocationCombo) 
		{
			var storedNodes = Util.xmlSelectNodes(rootEl, "location");
			
			var ix = this._selectLocationCombo.get_selectedIndex();
			
			if(ix >= storedNodes.length) ix = -1; 
			rootEl.setAttribute("selection", ix);
		}
		fragment.appendChild(rootEl);
	}
	return fragment;
}

proto._encrypt = function(data) {
	if(!this._salt) return data;
	return Util.SHA1.compute(data + this._salt);
}

proto.unload = function()
{
	$("__loginChrome").style.display = "none";
	CNFormManager.destroyJSObjects(this._jsObjects);
	
	this.formManager.restartAutoLock();
}


proto._element_onkeypress = function(ev)
{
	this.element_onkeypress(ev);
}
proto.element_onkeypress = function(ev)
{
	if(Event.keyValue(ev) != 13) return;
	CNUtil.cancelEvent(ev);
	this.loginButtonClick();
}

proto.loginButtonClick = function()
{
	if(this._disabled) return;
	if(!this._userBox.value || this._userBox._isEmpty)
	{
		this._userBox.style.borderColor = "red";
		return;
	}
	this._userBox.style.borderColor = "";
	this.formManager.postData(this.element);
}
proto = null;

/* PRIVATE INTERVAL RECONSTRUCTION; not original source. Module: logincontrol_newblue.js; official bundle offsets 285071-297198. */
function CN_logincontrol_newblue() {
  this._newPasswordCanceled = false;
  this._lockMode = false;
  this._salt = null;
  this._disabled = false
}
CN_logincontrol_newblue.loginImage = true;
CN_logincontrol_newblue.createLoginChrome = function() {
  if ($("__loginChrome")) {
    return
  }
  var placeholder = $("cn_globalPlaceholder");
  var chrome = Util.createElement("div", "loginChrome", {id: "__loginChrome"});
  var center = Util.createElement("div", "loginCenter", {id: "__loginCenter"});
  var left = Util.createElement("div", "loginCenterLeft", {id: "__loginCenterLeft"});
  var separator = Util.createElement("div", "loginCenterLeftSeparator", {id: "__loginCenterLeftSeparator"});
  var separatorImage = Util.createElement("img", "loginCenterSeparatorImage", {src: "themes/new-blue/g/separator.png"});
  var bottomLogo = Util.createElement("img", "loginImsLogo", {src: "themes/new-blue/g/logo-bottom.png"});
  separator.appendChild(separatorImage);
  center.appendChild(left);
  center.appendChild(separator);
  chrome.appendChild(center);
  chrome.appendChild(bottomLogo);
  placeholder.insertBefore(chrome, placeholder.firstChild);
  CN_logincontrol_newblue.layoutChrome();
  Event.nativeAdd(window, "resize", CN_logincontrol_newblue.layoutChrome);
  $("__si_form").style.overflow = "hidden"
};
CN_logincontrol_newblue.destroyLoginChrome = function() {
  var a = $("__loginChrome");
  if (a) {
    Event.nativeDel(window, "resize", CN_logincontrol_newblue.layoutChrome);
    Util.removeElement(a);
    $("__si_form").style.overflow = ""
  }
};
CN_logincontrol_newblue.layoutChrome = function() {
  var a = $("__loginCenter");
  var b = $("__si_form");
  b.style.top = a.style.top = (document.body.clientHeight - a.offsetHeight) / 2 + "px"
};
var proto = CN_logincontrol_newblue.prototype;
proto.createElement = function(c, b) {
  var a = Util.createElement("div", "cn_logincontrol_newblue");
  b.appendChild(a);
  this.element = a;
  a.jsObject = this;
  this._lockMode = c.getAttribute("lock") == "true";
  CNFormManager.getBaseFormManager().pauseAutoLockTimer();
  this._buildContent();
  return a
};
proto._createInputBox = function(c, a, e, d) {
  var b = {};
  b.cont = Util.createElement("div", "loginInputBox");
  var background = Util.createElement("img", "loginBoxBG", {src: "themes/new-blue/g/login-login-bg.png"});
  var hint = Util.createElement("div", "loginBoxHint");
  hint.textContent = c;
  b.input = Util.createElement("input", "loginBox" + (d ? " withButton" : ""));
  b.input.type = a;
  if (e) b.input.id = e;
  b.cont.appendChild(background);
  b.cont.appendChild(hint);
  b.cont.appendChild(b.input);
  if (d) {
    b.button = VistaSupport.createImageSetButton("login-password-arrow-set.png", 25, 25, 0);
    b.button.className = "loginButton";
    b.cont.appendChild(b.button)
  }
  Event.add(b.cont, "mouseup", this, this.inputBox_mousedown);
  Event.add(b.input, "keyup", this, this.inputBox_handlekey);
  Event.add(b.input, "keydown", this, this.inputBox_handlekey);
  Event.add(b.input, "blur", this, this.inputBox_handlekey);
  return b
};
proto.inputBox_mousedown = function(c) {
  c = Event.normalize(c) || Event.current();
  Util.cancelEvent(c);
  var b = Util.findByClassName(c && c.target, "loginInputBox");
  if (!b || Util.hasClass(b, "disabled")) {
    return
  }
  var a = b.getElementsByTagName("input")[0];
  a.select();
  a.focus()
};
proto.inputBox_handlekey = function(c) {
  c = Event.normalize(c) || Event.current();
  var b = c && c.target;
  var a = Util.findByClassName(b, "loginInputBox");
  if (Util.hasClass(a, "disabled")) {
    return
  }
  a.children[1].style.visibility = b.value.length || c.type == "keydown" ? "hidden" : ""
};
proto._buildContent = function() {
  if (this._lockMode) {
    this.formManager.enforceDialog()
  }
  CN_logincontrol_newblue.createLoginChrome();
  CN_logincontrol_newblue.loginImage ? this.displaySiteLogo(true) : this.displaySiteLogo(false);
  var container = Util.createElement("div", "container");
  var loginArea = Util.createElement("div", "loginArea");
  var label = Util.createElement("div", "label", {id: "__loginLabel"});
  label.textContent = "MAXIMS";
  loginArea.appendChild(label);
  container.appendChild(loginArea);
  this.element.appendChild(container);
  var a = this._cont = this.element.lastChild;
  var f = this._loginArea = a.firstChild;
  var b = this._login = this._createInputBox("Login", "text");
  f.appendChild(b.cont);
  setTimeout(function() {
    b.input.focus()
  }, 0);
  var d = this._password = this._createInputBox("Password", "password", false, true);
  Util.addClass(d.cont, "passwordDiv");
  f.appendChild(d.cont);
  var c = $("__loginLabel");
  Event.add(d.button, "mouseup", this, this.login_button_click);
  Event.add(d.input, "keypress", this, this.password_keypress);
  if (this._lockMode) {
    var e = this._unlockLabel = Util.createElement("div", "loginLockedLabel");
    e.appendChild(Util.createElement("img", null, {src: "themes/new-blue/g/login-lock.png"}));
    e.appendChild(document.createTextNode(" Application is Locked "));
    $("__loginCenter").appendChild(e);
    this._layoutLockMode();
    Event.add(window, "resize", this, this._layoutLockMode)
  }
};
proto._layoutLockMode = function(a) {
  this._cont.style.top = $("__loginCenter").offsetTop + "px"
};
proto.password_keypress = function(a) {
  if (Event.keyValue(a) == 13) {
    this.login_button_click()
  }
};
proto.set_disabled = function(a) {
  if (a) {
    Util.addClass(this._loginArea, "disabled");
    this._disableBox(this._login);
    this._disableBox(this._password);
    if (this._changePass1) {
      this._disableBox(this._changePass1);
      this._disableBox(this._changePass2)
    }
  } else {
    Util.removeClass(this._loginArea, "disabled");
    this._enableBox(this._login);
    this._enableBox(this._password);
    if (this._changePass1) {
      this._enableBox(this._changePass1);
      this._enableBox(this._changePass2)
    }
  }
  this._disabled = a
};
proto.displaySiteLogo = function(c) {
  var a = $("__loginCenterLeft");
  if (a) a.style.display = "none";
};
proto.login_button_click = function(b) {
  if (b) {
    Util.cancelEvent(b)
  }
  var a = this._login.input;
  var c = this._password.input;
  if (!a.value) {
    Util.addClass(a, "error");
    return
  }
  Util.removeClass(a, "error");
  this.displaySiteLogo(false);
  this.formManager.postData(this.element)
};
proto.loadData = function(b) {
  this._salt = b.getAttribute("salt");
  var a = Util.xmlSelectSingleNode(b, "message");
  if (a) {
    this.displaySiteLogo(true);
    this._showMessage(a)
  }
  if (!this._lockMode) {
    if (b.getAttribute("passwordExpireDays") != null) {
      this.displaySiteLogo(false);
      this._processPasswordExpiry(b)
    }
  }
};
proto.validateLoading = function() {
  if (!this._lockMode) {
    this._tryToShowLocationCombo()
  }
};
proto._tryToShowLocationCombo = function() {
  var b = this.formManager._getStoredLocationsXML(true),
    a;
  if (b) {
    a = Util.xmlSelectNodes(b, "location")
  }
  if (b && a.length > 0) {
    this._showLocationCombo(a)
  } else {
    this._hideLocationCombo()
  }
};
proto._createChangePassword = function() {
  if (this._changeCont) {
    return
  }
  var c = this._changeCont = Util.createElement("div", "changePasswordContainer");
  var title = Util.createElement("div");
  title.textContent = "Change Password";
  c.appendChild(title);
  c.appendChild(Util.createElement("img", null, {src: "themes/new-blue/g/login-vert-line.png"}));
  c.appendChild(Util.createElement("div", "changeNote"));
  c.appendChild(Util.createElement("div", "changeArea"));
  this._cont.appendChild(c);
  var b = c.lastChild;
  var label1 = Util.createElement("div", "changeLabel");
  label1.textContent = "Password";
  b.appendChild(label1);
  this._changePass1 = this._createInputBox("", "password");
  b.appendChild(this._changePass1.cont);
  b.appendChild(Util.createElement("br"));
  var label2 = Util.createElement("div", "changeLabel");
  label2.textContent = "Re-Enter Password";
  b.appendChild(label2);
  this._changePass2 = this._createInputBox("", "password", false, true);
  b.appendChild(this._changePass2.cont);
  Event.add(this._changePass2.button, "mouseup", this, this._changePass_button_click);
  Event.add(this._changePass2.input, "keypress", this, this._changePass_input_keypress);
  if (this._disabled) {
    this.set_disabled(this._disabled)
  }
};
proto._showChangePassword = function(c, b) {
  this._createChangePassword();
  if (c) {
    this._disableBox(this._login);
    this._disableBox(this._password);
    Util.addClass(this._loginArea, "disabled");
    if (this._selectLocationCombo) {
      this._selectLocationCombo.set_disabled(true)
    }
  }
  if (b) {
    var a = this._changeCont.children[2];
    a.innerHTML = b;
    a.style.display = "block"
  }
  setTimeout(Util.bind(this, function() {
    var d = new AnimMove(this._loginArea, null, 100, true);
    d.onend = Util.bind(this, function() {
      this._changeCont.style.display = "block"
    });
    Animator.start(d)
  }), 0)
};
proto._disableBox = function(a) {
  a.input.disabled = true;
  Util.addClass(a.cont, "disabled")
};
proto._enableBox = function(a) {
  a.input.disabled = false;
  Util.removeClass(a.cont, "disabled")
};
proto._hideChangePassword = function() {
  if (this._changeCont) {
    Util.removeClass(this._loginArea, "disabled");
    this._enableBox(this._login);
    this._enableBox(this._password);
    if (this._selectLocationCombo) {
      this._selectLocationCombo.set_disabled(false)
    }
    this._changeCont.style.display = "";
    var a = new AnimMove(this._loginArea, null, 186, true);
    Animator.start(a)
  }
};
proto._processPasswordExpiry = function(a) {
  var b = a.getAttribute("passwordExpireDays");
  if (b == "") {
    this._hideChangePassword()
  } else {
    document.body.focus();
    if (b > 0) {
      this._forcePasswordExpire = false;
      this.formManager._showYesNoDialog("Password expire", "Your password will expire in " + b + " day(s).<br/> Do you wish to change your password now?", [this, "_processPasswordExpiry2"])
    } else {
      this._forcePasswordExpire = true;
      this._showChangePassword(true, "Your password expires today.<br/>You must change your password now.")
    }
  }
};
proto._processPasswordExpiry2 = function(a, b) {
  if (!b) {
    this._showChangePassword(false)
  } else {
    this._newPasswordCanceled = true;
    this.formManager.postData(this.element)
  }
};
proto._changePass_button_click = function(a) {
  if (a) {
    Util.cancelEvent(a)
  }
  Util.toggleClass(this._changePass1.input, "error", !this._changePass1.input.value);
  Util.toggleClass(this._changePass2.input, "error", !this._changePass2.input.value);
  if (!this._changePass1.input.value || !this._changePass2.input.value) {
    return
  }
  if (this._changePass1.input.value && (this._changePass1.input.value != this._changePass2.input.value)) {
    alert("Your password entries don't match.");
    return
  }
  this._newPassword = this._changePass1.input.value;
  this.formManager.postData(this.element)
};
proto._changePass_input_keypress = function(a) {
  if (Event.keyValue(a) == 13) {
    this._changePass_button_click()
  }
};
proto.cancelPasswordButtonClick = function() {
  this._newPasswordCanceled = true;
  this.formManager.postData(this.element)
};
proto._showLocationCombo = function(a) {
  if (!this._selectLocationCombo) {
    this._createSelectLocationCombo()
  }
  this._fillSelectLocationCombo(a)
};
proto._createSelectLocationCombo = function() {
  var a = this._selectLocationCont = Util.createElement("div", "location");
  this._loginArea.appendChild(a);
  var locationLabel = Util.createElement("div", "locationLabel");
  locationLabel.textContent = "Location";
  a.appendChild(locationLabel);
  var d = Util.createElement("div", "loginInputBox");
  d.appendChild(Util.createElement("img", "loginBoxBG", {src: "themes/new-blue/g/login-login-bg.png"}));
  a.appendChild(d);
  this._selectLocationCombo = new CN_combobox();
  var b = [];
  var c = this._selectLocationCombo.createElement(b, d);
  this._selectLocationCombo.set_tabIndex(3);
};
proto._fillSelectLocationCombo = function(c) {
  var a = [];
  for (var b = 0; b < c.length; b++) {
    var d = {
      text: Util.xmlText(c[b])
    };
    a.push(d)
  }
  a.push({
    text: "<Not listed>"
  });
  this._selectLocationCombo.initData(a);
  this._selectLocationCombo.set_selectedIndex(0, true)
};
proto._hideLocationCombo = function() {
  if (this._selectLocationCombo) {
    if (this._selectLocationCombo) {
      CNFormManager.destroyJSObject(this._selectLocationCombo)
    }
    this._selectLocationCombo = null;
    Util.removeElement(this._selectLocationCont);
    this._selectLocationCont = null
  }
};
proto._showMessage = function(a) {
  var b = typeof a == "object" ? Util.xmlText(a) : a;
  if (b) {
    if (!this._errorContainer) {
      this._errorContainer = Util.createElement("div", "errorContainer");
      $("__loginCenter").appendChild(this._errorContainer)
    }
    this._errorContainer.innerHTML = b;
    this._errorContainer.style.display = ""
  } else {
    if (this._errorContainer) {
      this._errorContainer.style.display = "none"
    }
  }
};
proto.storeData = function(a) {
  if (this._lockMode) {
    var f = a.createElement("unlock");
    f.setAttribute("name", this._login.input.value);
    f.setAttribute("pass", this._encrypt(this._password.input.value));
    return f
  } else {
    if (this._newPassword) {
      var f = a.createElement("newPassword");
      f.setAttribute("canceled", "false");
      f.setAttribute("pass", this._newPassword);
      this._newPassword = null;
      return f
    } else {
      if (this._newPasswordCanceled) {
        var f = a.createElement("newPassword");
        f.setAttribute("canceled", "true");
        this._newPasswordCanceled = false;
        return f
      } else {
        var c = a.createDocumentFragment();
        var f = a.createElement("loginEvent");
        f.setAttribute("name", this._login.input.value);
        f.setAttribute("pass", this._encrypt(this._password.input.value));
        c.appendChild(f);
        var e = this.formManager._getStoredLocationsXML(true);
        if (e) {
          if (this._selectLocationCombo) {
            var d = Util.xmlSelectNodes(e, "location");
            var b = this._selectLocationCombo.get_selectedIndex();
            if (b >= d.length) {
              b = -1
            }
            e.setAttribute("selection", b)
          }
          c.appendChild(e)
        }
        return c
      }
    }
  }
};
proto._encrypt = function(a) {
  if (!this._salt) {
    return a
  }
  return Util.SHA1.compute(a + this._salt, "hex")
};
proto.unload = function() {
  if (this._selectLocationCombo) {
    CNFormManager.destroyJSObject(this._selectLocationCombo)
  }
  if (this._unlockLabel) {
    Util.removeElement(this._unlockLabel);
    this._unlockLabel = null
  }
  if (this._errorContainer) {
    Util.removeElement(this._errorContainer);
    this._errorContainer = null
  }
  CN_logincontrol_newblue.destroyLoginChrome();
  this.formManager.deforceDialog();
  CNFormManager.getBaseFormManager().resumeAutoLockTimer()
};
proto = null;

/*
	v. 0.2
	+ initial release
*/
function CN_selectrolecontrol()
{
}
var proto = CN_selectrolecontrol.prototype;

proto.createElement = function(node, parentElement)
{
	var l = (function(){ var el = document.createElement("div"); el.className = 'cn_selectrolecontrol'; return el; })();
	parentElement.appendChild(l);
	
	this.element = l;
	l.jsObject = this;
	
	this._buildContent();
	this._showSelectRoleScreen(node);

	return l;
} 

proto._buildContent = function()
{
	var html = '<table width=100% height=100% border=0 cellpadding=0 cellspacing=0>\
<tr height=60><td>\
<table width=100% border=0 cellpadding=0 cellspacing=0>\
<tr>\
<td rowspan=3 nowrap=true style="width: 93px; background: url(\'' + CNFormManager.themeImagesPath + 'login-2_01.gif\'); ">\
<div style="display: inline-block; margin-left: 18px; width: 47px; height: 75px; background: url(\'' + CNFormManager.strings['loginLogo'] + '\') center / 100% 100% no-repeat; "></div>\
</td>\
<td background="' + CNFormManager.themeImagesPath + 'login-2_02.gif" width=100% height=11></td>\
<td><img src="' + CNFormManager.themeImagesPath + 'login-2_03.gif" width=14 height=11></td>\
</tr>\
<tr>\
<td background="' + CNFormManager.themeImagesPath + 'login-2_04.gif" width=100% height=58 class="td1">\
<table width=100% border=0 cellspacing=0 cellpadding=0>\
<tr>\
<td>\
<h1>' + CNFormManager.strings['loginCaption'] + '</h1>\
</td>\
<td align=right></td>\
<td width=40></td>\
</tr>\
</table>\
</td>\
<td><img src="' + CNFormManager.themeImagesPath + 'login-2_05.gif" width=14 height=58></td>\
</tr>\
<tr>\
<td background="' + CNFormManager.themeImagesPath + 'login-2_06.gif" width=100% height=13></td>\
<td><img src="' + CNFormManager.themeImagesPath + 'login-2_07.gif" width=14 height=13></td>\
</tr>\
</table>\
</td></tr>\
<tr><td valign=top height=100%>\
<table width=100% height=100% border=0 cellpadding=0 cellspacing=0>\
<tr>\
<td width=12>\
<img src="' + CNFormManager.themeImagesPath + 'bg-1-2_01.gif" width=12 height=12></td>\
<td width=100% background="' + CNFormManager.themeImagesPath + 'bg-1-2_02.gif"></td>\
<td width=12>\
<img src="' + CNFormManager.themeImagesPath + 'bg-1-2_03.gif" width=12 height=12></td>\
</tr>\
<tr>\
<td background="' + CNFormManager.themeImagesPath + 'bg-1-2_04.gif"></td>\
<td bgcolor=white valign=top height=100%>\
<table width=100% height=100% cellspacing=0 cellpadding=0 border=0>\
<tr valign=middle><td align=left>\
<span class="span1">\
<img align=absmiddle src="' + CNFormManager.themeImagesPath + 'role-logo-2.gif">\
</span>\
<span class="span2">\
<span class="span3">\
<h1 id="selectScreenTitle_"></h1>\
</span>\
</span>\
</td>\
</tr>\
<tr height=1>\
<td align=center><img src="' + CNFormManager.themeImagesPath + 'hline-1.gif" width=100% height=1><br><br></td>\
</tr>\
<tr>\
<td valign=middle align=center height=100%>\
<div id="rolesDiv">\
<table class="table1" cellspacing=0 cellpadding=0>\
<tr>\
<td width=12><img src="' + CNFormManager.themeImagesPath + 'role-2_01.gif"></td>\
<td class="td2"\
><img src="' + CNFormManager.themeImagesPath + 'role-icon-1-1.gif" class="img2"\
><img src="' + CNFormManager.themeImagesPath + 'role-2_02.gif" class="img3"\
><div class="div1"></div></td>\
<td width=12><img src="' + CNFormManager.themeImagesPath + 'role-2_03.gif"></td>\
</tr>\
</table>\
</div>\
</td></tr>\
<tr><td align=center>\
<img src="' + CNFormManager.themeImagesPath + 'bottom-line-3.gif" width=90% height=15>\
</td></tr>\
</table>\
</td>\
<td background="' + CNFormManager.themeImagesPath + 'bg-1-2_06.gif"></td>\
</tr>\
<tr>\
<td>\
<img src="' + CNFormManager.themeImagesPath + 'bg-1-2_07.gif" width=12 height=14></td>\
<td background="' + CNFormManager.themeImagesPath + 'bg-1-2_08.gif"></td>\
<td>\
<img src="' + CNFormManager.themeImagesPath + 'bg-1-2_09.gif" width=12 height=14></td>\
</tr>\
</table>\
</td></tr>\
</table>';
	this.element.innerHTML = html;
}

proto.loadData = function(node)
{
}

proto.storeData = function(xmldoc)
{
	this.formManager._showDisabler(true, false);
	var fragment = xmldoc.createDocumentFragment();
	var node = xmldoc.createElement("selectRoleEvent");
	fragment.appendChild(node);
	node.setAttribute("roleID", this._selectScreenID);
	
	var rootEl = this.formManager._getStoredLocationsXML(true);
	if(rootEl) 
	{
		fragment.appendChild(rootEl);
	}
	return fragment;
}

proto._showSelectRoleScreen = function(selectRoleNode)
{
	this._showSelectScreen(selectRoleNode, 'Please select a role', 'role', 260)
}

proto._showSelectScreen = function(selectScreenNode, title, nodeName, buttonWidth)
{
	document.title = title;
	this.element.querySelector("#selectScreenTitle_").textContent = title;
	
	var div = this.element.querySelector("#rolesDiv");
	var template = div.children[0];
	
	div.style.width = buttonWidth + "px";
	
	var messageNode = Util.xmlSelectSingleNode(selectScreenNode, "message");
	if(messageNode)
	{
		alert(Util.xmlText(messageNode));
	}
	else
	{
		var children = div.children;
		var count = children.length - 1;
		for(var i = 0; i < count; i++)
		{
			children[children.length - 1].remove();
		}

		var roleNodes = Util.xmlSelectNodes(selectScreenNode, nodeName);
		var count = roleNodes.length;
		for(var i = 0; i < count; i++)
		{
			var roleNode = roleNodes[i];
			
			var table = template.cloneNode(true);
			div.appendChild(table);
			var textDiv = table.getElementsByTagName("div")[0];
			textDiv.textContent = String(Util.xmlText(roleNode));
			table._id = String(roleNode.getAttribute("id"));
			table.style.display = "block";
			Event.add(table, "mouseenter", this, this._table_onmouseenter);
			Event.add(table, "mouseleave", this, this._table_onmouseleave);
			Event.add(table, "click", this, this._table_onclick);
		}
	}
}

proto._table_onmouseenter = function(ev)
{
	Util.eventTarget(ev).style.opacity = "0.7";
}

proto._table_onmouseleave = function(ev)
{
	Util.eventTarget(ev).style.opacity = "";
}

proto._table_onclick = function(ev)
{
	this.roleTableClick(ev);
}

/*
proto._showSelectLocationScreen = function(selectLocationNode)
{
	this._showSelectScreen(selectLocationNode, 'Please select a location', 'location', 360)
	
	this._screen = "selectLocation";
}
*/

proto.roleTableClick = function(ev)
{
	var table = CNUtil.findTag(Util.eventTarget(ev), "TABLE");
	this._selectScreenID = table._id;
	this.formManager.postData(this.element);
}

/*
{
	this.loadForm("<events><selectLocationEvent id=\"" + this._filterAttribute(this._selectScreenID) 
		+ "\"/></events>", "_finishHideDisabler");
}
*/
/*
	v. 2.0.1
	+ vista
*/
function CN_selectrole()
{
	this._lockMode = false;
	this._jsObjects = [];
}
var proto = CN_selectrole.prototype;

proto._createActionImage = function(black)
{
	var img;
	if(black)
	{
		img = document.createElement("span");
		img.style.display = "inline-block";
		img.style.width = "22px";
		img.style.height = "22px";
		img.style.backgroundImage = "url(" + CNFormManager.themeImagesPath + "square-button-set.gif)";
		img.style.backgroundRepeat = "no-repeat";
		img.style.backgroundPosition = "0px 0px";
		Event.nativeAdd(img, "mouseenter", function() { if(!img.disabled) img.style.backgroundPosition = "-22px 0px"; });
		Event.nativeAdd(img, "mouseleave", function() { img.style.backgroundPosition = "0px 0px"; });
		Event.nativeAdd(img, "mousedown", function() { if(!img.disabled) img.style.backgroundPosition = "-44px 0px"; });
		Event.nativeAdd(img, "mouseup", function() { if(!img.disabled) img.style.backgroundPosition = "-22px 0px"; });
	}
	else
	{
		img = document.createElement("img");
		img.src = CNFormManager.themeImagesPath + "round-button.gif";
		Event.nativeAdd(img, "mouseenter", function() { if(!img.disabled) img.src = CNFormManager.themeImagesPath + "hover-round-button.gif"; });
		Event.nativeAdd(img, "mouseleave", function() { img.src = CNFormManager.themeImagesPath + "round-button.gif"; });
		Event.nativeAdd(img, "mousedown", function() { if(!img.disabled) img.src = CNFormManager.themeImagesPath + "down-round-button.gif"; });
		Event.nativeAdd(img, "mouseup", function() { if(!img.disabled) img.src = CNFormManager.themeImagesPath + "hover-round-button.gif"; });
	}
	return img;
}

proto.createElement = function(node, parentElement)
{
	var l = (function(){ var el = document.createElement("div"); el.className = 'cn_selectrole'; return el; })();
	parentElement.appendChild(l);
	
	this.element = l;
	l.jsObject = this;
	
	this._buildContent(node);
	this._show();	
	
	return l;
} 

proto._buildContent = function(node)
{
	$("__loginChrome").style.display = "block";
	
	var outerDiv = (function(){ var el = document.createElement("div"); el.className = 'outerDiv'; return el; })(); // Anchor div.
	this.element.appendChild(outerDiv);
	
	var frameCont = (function(){ var el = document.createElement("div"); el.className = 'frameCont'; return el; })();
	outerDiv.appendChild(frameCont);
	
	frameCont.innerHTML = $("__plainBG").innerHTML;
	var frame = frameCont.firstElementChild;
	frame.style.visibility = "hidden";
	
	this._contentDiv = (function(){ var el = document.createElement("div"); el.className = 'contentDiv'; return el; })();
	frameCont.appendChild(this._contentDiv);

	this._showCombo(node);
	
	var img;
	if(CNFormManager.subTheme == "black") {
		img = this._createActionImage(true);

		var siteLogo = $("__siteLogo");
		siteLogo.style.width = "34px";
		siteLogo.style.height = "37px";	
		siteLogo.style.backgroundSize = "100% 100%";
		siteLogo.style.objectFit = "fill";
	} else {
		img = this._createActionImage(false);
	}

	img.tabIndex = 4; // After locations combo.
	img.className = "imgButton";
	this._contentDiv.appendChild(img);
	Event.add(img, "click", this, this._img_onclick);
	
	var logoDiv = (function(){ var el = document.createElement("div"); el.className = 'selectRoleLogo'; return el; })();
	this._contentDiv.appendChild(logoDiv);
	
	
	
	Event.add(this.element, "keypress", this, this._element_onkeypress);	
	
	var messageNode = Util.xmlSelectSingleNode(node, "message");
	if(messageNode) alert(Util.xmlText(messageNode));
}

proto._show = function()
{
	var frameCont = this.element.firstElementChild.firstElementChild;

	var frame = frameCont.firstElementChild;
	frame.style.opacity = "0";
	frame.style.visibility = "inherit";
	frame.style.transition = "opacity .5s";
	frame.style.opacity = "1";	
	AnimVistaFadeResize(frameCont, 50, 15);	
	this._combo.element.focus();
}

proto._img_onclick = function()
{
	this._send();
}

proto._send = function()
{
	if(this._combo.get_selectedIndex() == 0)
	{
		alert("Please select role");
		return;
	}
	this.formManager.postData(this.element);
}

proto.loadData = function(node)
{
}

proto.storeData = function(xmldoc)
{
	var fragment = xmldoc.createDocumentFragment();
	var node = xmldoc.createElement("selectRoleEvent");
	fragment.appendChild(node);
	node.setAttribute("roleID", this._combo.getValue());
	
	var rootEl = this.formManager._getStoredLocationsXML(true);
	if(rootEl) 
	{
		fragment.appendChild(rootEl);
	}
	return fragment;
}

proto.unload = function()
{
	$("__loginChrome").style.display = "none";
	CNFormManager.destroyJSObjects(this._jsObjects);
}


proto._element_onkeypress = function(ev)
{
	if(Event.keyValue(ev) != 13) return;
	Util.cancelEvent(ev);
	this._send();
}

proto._showCombo = function(node)
{
	this._combo = new CN_combobox();
	this._jsObjects.push(this._combo);

	var comboEl = this._combo.createElement(Util.wrapIntoNode({}), this._contentDiv);
	this._combo.set_tabIndex(3);

	var nodes = Util.xmlSelectNodes(node, "role");
	var options = [];
	options.push({html: "<i class='comboValue'>Please select role</i>"});

	for(var i = 0; i < nodes.length; i++)
	{
		var node = nodes[i];
		var option = {text: String(Util.xmlText(node)), value: String(node.getAttribute("id"))};
		options.push(option);
	}
	
	this._combo.initData(options);
	this._combo.set_selectedIndex(0, true);
}
proto = null;


/*
	REVISIT: rendering
	v. 2.0.0
	+ vista
*/
function CNPopupCalendar(preBuild)
{
	this.preBuild = preBuild;
	this.monthes = CNPopupCalendar.months;
	this.days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
	this.table = null;
	this.header = null;
	this.selectedDayTD = null;
	this.selectedDay = 1;
	this._date = null;
	this.waitForComponentsCount = 2;
	
	this.popup = null;
	this.popupBody = null;
	this.popupWindow = null;
	
	this._title = "Please select the date";
	
	this.usWeekToEu = CNPopupCalendar.usWeekToEu;
}
var proto = CNPopupCalendar.prototype;
CNPopupCalendar.months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
CNPopupCalendar.usWeekToEu = [6, 0, 1, 2, 3, 4, 5];

CNPopupCalendar._visibleCalendars = [];
	

// Events. =======================================
proto.onxlresult = function(ev){}
proto.onxlchange = function(ev){}

CNPopupCalendar.createDefaultCalendar = function()
{
	if(CNPopupCalendar.defaultInstance)
	{
		alert("ASSERT: CNPopupCalendar.defaultInstance");
		return;
	}
	var l = CNPopupCalendar.defaultInstance = new CNPopupCalendar();
	l.createElement();
}
CNPopupCalendar.destroyDefaultCalendar = function()
{
	var instance = CNPopupCalendar.defaultInstance;
	if(instance._combobox) CNFormManager.destroyJSObject(instance._combobox);
	if(instance.element.shadow) instance.element.shadow.destroy();
	CNFormManager.destroyJSObject(instance);
	CNPopupCalendar.defaultInstance = null;
}

// NOTE: autocreation.
// Default calendar is created explicitly by the form lifecycle.

// Main. =========================================
proto._elements = function(root)
{
	var result = {};
	var nodes = root.querySelectorAll("[id]");
	for(var i = 0; i < nodes.length; i++) result[nodes[i].id] = nodes[i];
	return result;
}

proto.createElement = function()
{
	var l;
	if(CNFormManager.vista)
	{
		l = CNDialogManager.createVistaDialog(this._title);
	}
	else
	{
		l = CNDialogManager.createDialog(this._title);
	}
	
	if(l.shadow)
	{
		l.shadow.destroy();
		l.style.boxShadow = "2px 3px 3px rgba(0, 0, 0, .3)";
	}
	l.className = l.className + " cn_popupcalendar";
	this.element = l;
	l.jsObject = this;
	
	l.style.userSelect = "none";

	this.buildElement();
	return l;
}


// If coordinates are omitted, anchor to the current event target.
proto.show = function(param, scrollElement, x, y)
{
	var body = document.body;
	if(!scrollElement) scrollElement = body;
	
	if(!param) param = new Date();

	if(typeof param == "object") // Date
	{
		this.set_date(param);
	}
	else if(typeof param == "string")
	{
		var ar = param.split(/[.\/]/);
		if(ar.length == 3) 
		{
			var year = ar[2] * 1;
			if(year > 50 && year < 100) 
			{
				year += 1900;
			}
			if(year < 50) year += 2000;
			this.set_date(new Date(year, ar[1] - 1, ar[0]));
		}
	}

	var doOffset = true;
	if(x == null || y == null)
	{
		doOffset = false;
		x = 0; 
		y = 0;
	 	var anchor = Util.eventTarget(Event.current()) || document.activeElement;
		if(anchor)
		{
			var xy = CNUtil.findAbsolutePos(anchor, this.element.parentElement);
			x = xy.x;
			y = xy.y + anchor.offsetHeight;
		}
	}

	this.element.style.left = x + "px";
	this.element.style.top = y + "px";
	
	this.element.style.zIndex = top.__ontopZ++;

	CNDialogManager.showPopupDialog(this.element);

	// TODO: Move to CNDialogManager?

	var b = y + this.element.offsetHeight
	var r = x + this.element.offsetWidth

	if(doOffset)
	{
		x += scrollElement.scrollLeft;
		y += scrollElement.scrollTop;
	}

	if(r > body.clientWidth) 
	{
		x = x - r + body.clientWidth - 4; // 4 = shadowWidth
	}
	if(b > body.clientHeight) 
	{
		y = y - b + body.clientHeight - 4; // 4 = shadowWidth
	}
	if(x < 0) x = 0;
	if(y < 0) y = 0;

	this.element.style.left = x + "px";
	this.element.style.top = y + "px";
	if(this.element.shadow) this.element.shadow.syncPosition();
}

proto.hide = function(cancel, force)
{
	CNDialogManager.hideDialog(this.element);
	if(!cancel) 
	{
		var ev = {};
		ev.date = this.get_date();
		if(this.onxlresult) this.onxlresult(ev);
	}
}

proto.updateToDate = function()
{
	var all = this._elements(this.element);
	// TODO
	var month = this._date.getMonth();
	this._combobox.set_selectedIndex(month, true); // true == doNotFireEvent.
	var year = all.yearSelect.value = this._date.getFullYear();
	this.selectedDay = this._date.getDate();
	this.fillDays(month, year);
}

proto.buildElement = function()
{
	var contents = CNDialogManager.getContents(this.element);
	var html = "<table id=topControls width=100% border=0 cellpadding=0 cellspacing=0>\
					<tr><td width=1%><button id=prevMonthButton class=arrows10>3</button>\
					<td width=34%>&nbsp;</td>\
					<td align=right width=100 nowrap id=monthTD>&nbsp;</td>\
					<td width=1 nowrap></td>\
					<td width=1% align=right id=yearTD></td>\
					<td><table border=0 cellpadding=0 cellspacing=0>\
					<tr><td><button id=yearUpButton class=arrows7>5</button></td></tr>\
					<tr><td><button id=yearDownButton class=arrows7>6</button></td></tr></table>\
					<td width=35%>&nbsp;</td>\
					</td><td width=1% align=right><button id=nextMonthButton class=arrows10>4</button></td>\
					</tr></table>";
	
	var template = document.createElement("template");
	template.innerHTML = html;
	contents.appendChild(template.content);

	if(this._date == null) this._date = new Date();

	var all = this._elements(contents);

	var combobox = this._combobox = new CN_combobox();
	var options = [];
	for(var i = 0; i < 12; i++)
	{
		var option = {text: this.monthes[i]};
		options[options.length] = option;
	}

	all.monthTD.style.position = "relative";
	var combo = combobox.createElement(options, all.monthTD);

	combobox.onchange = this._monthSelect_onchange;

	var year = this._date.getFullYear();
	var yearSelect = document.createElement("input");
	yearSelect.type = "text";
	yearSelect.maxLength = 4;
	yearSelect.id = "yearSelect";
	yearSelect.value = year;
	all.yearTD.appendChild(yearSelect);
	all.yearSelect = yearSelect;
		
	Event.add(all.prevMonthButton, "click", this, this._prevMonthButton_onclick);
	Event.add(all.prevMonthButton, "dblclick", this, this._prevMonthButton_onclick);
	
	Event.add(all.nextMonthButton, "click", this, this._nextMonthButton_onclick);
	Event.add(all.nextMonthButton, "dblclick", this, this._nextMonthButton_onclick);

	Event.add(all.yearUpButton, "click", this, this._yearUpButton_onclick);
	Event.add(all.yearUpButton, "dblclick", this, this._yearUpButton_onclick);
	
	Event.add(all.yearDownButton, "click", this, this._yearDownButton_onclick);
	Event.add(all.yearDownButton, "dblclick", this, this._yearDownButton_onclick);

	Event.add(all.yearSelect, "focus", this, this._yearSelect_onfocus);
	Event.add(all.yearSelect, "keypress", this, this._yearSelect_onkeypress);
	Event.add(all.yearSelect, "keyup", this, this._yearSelect_onkeyup);

	var table = (function(){ var el = document.createElement("table"); el.style.userSelect = "none"; el.id = 'daysTable'; el.border = '1'; el.frame = 'void'; el.rules = 'cols'; el.cellPadding = '0'; el.cellSpacing = '0'; return el; })();
	var header = this.header = table.insertRow();
	header.id = "header";
	for(var td = 0; td < 7; td++)
	{
		var cell = header.insertCell();
		cell.style.userSelect = "none";
		var span = (function(){ var el = document.createElement("span"); el.style.userSelect = "none"; return el; })();
		cell.appendChild(span);
		span.textContent = this.days[td];
	}
	
	for(var tr = 0; tr < 6; tr++)
	{
		var row = table.insertRow();
		row.style.userSelect = "none";
		for(var td = 0; td < 7; td++)
		{
			var cell = row.insertCell();
			cell.style.userSelect = "none";
			cell.textContent = " ";
		}
	}
	contents.appendChild(table);

	Event.add(table, "mouseover", this, this._table_onmouseover);
	Event.add(table, "mouseout", this, this._table_onmouseout);
	Event.add(table, "click", this, this._table_onclick);
	//this.updateToDate();

}

proto.fillDays = function(month, year)
{
	var date = new Date();
	date.setFullYear(year);

	// NOTE: set date before month or the month can be shifted.
	var dayCount = 1;
	date.setDate(dayCount);
	date.setMonth(month);

	var table = this.element.querySelector("#daysTable");
	var lastDayCell;
	for(var tr = 0; tr < 6; tr++)
	{
		var row = table.rows[tr + 1];
		date.setDate(dayCount);
		var firstOnWeek = this.usWeekToEu[date.getDay()];
		for(var td = 0; td < 7; td++)
		{
			var cell = row.cells[td];
			date.setDate(dayCount);
			if(td < firstOnWeek || date.getMonth() != month || dayCount > 31)  
			{
				cell.textContent = " ";
				cell.className = "empty";
			}
			else 
			{
				cell.textContent = dayCount;
				lastDayCell = cell;
				if(dayCount == this.selectedDay) 
				{
					this.selectDayTD(cell);
				}	
				else cell.className = "";

				dayCount++;
			}
		}
	}
	if(dayCount - 1 < this.selectedDay && lastDayCell) 
	{
		this.selectDayTD(lastDayCell);
	}	
}

proto.selectDayTD = function(l)
{
	if(this.selectedDayTD != null) this.selectedDayTD.className = this.selectedDayTD.__className = "";
	l.className = l.__className = "pushed";
	this.selectedDayTD = l;
	var day = l.textContent * 1;
	if(this.selectedDay != day)
	{
		this.selectedDay = day;
		this.fire_onxlchange();
	}
}

proto.fillChange = function()
{
	this._isDirty = true;
	var all = this._elements(this.element);
	this.fillDays(this._combobox.get_selectedIndex(), all.yearSelect.value);
	this.fire_onxlchange();
}

proto.fire_onxlchange = function()
{
	var ev = {target: this};
	if(this.onxlchange) this.onxlchange(ev);
}


// Event handlers. =======================
proto._yearUpButton_onclick = function(ev)
{
	var jsObject = this;
	var all = jsObject._elements(jsObject.element);
	all.yearSelect.value = all.yearSelect.value * 1 + 1;
	jsObject.fillChange();
}

proto._yearDownButton_onclick = function(ev)
{
	var jsObject = this;
	var all = jsObject._elements(jsObject.element);
	all.yearSelect.value = all.yearSelect.value * 1 - 1;
	jsObject.fillChange();
}

proto._nextMonthButton_onclick = function(ev)
{
	var jsObject = this;
	if(jsObject._combobox.get_selectedIndex() == 11)
	{
		jsObject._combobox.set_selectedIndex(0, true);
		jsObject.element.querySelector("#yearSelect").value++;
	}
	else
	{
		jsObject._combobox.set_selectedIndex(jsObject._combobox.get_selectedIndex() + 1, true);
	}
	jsObject.fillChange();
}

proto._prevMonthButton_onclick = function(ev)
{
	var jsObject = this;
	if(jsObject._combobox.get_selectedIndex() == 0)
	{
		jsObject._combobox.set_selectedIndex(11, true);
		jsObject.element.querySelector("#yearSelect").value--;
	}
	else
	{
		jsObject._combobox.set_selectedIndex(jsObject._combobox.get_selectedIndex() - 1, true);
	}
	jsObject.fillChange();
}

proto._table_onmouseover = function(ev)
{
	var l = Util.eventTarget(ev);
	if(l.tagName != "TD" || l.parentElement == this.header || l.className == "empty") return;
	l.__className = l.className;
	l.className = "hover";
}

proto._table_onmouseout = function(ev)
{
	var l = Util.eventTarget(ev);
	if(l.tagName != "TD" || l.parentElement == this.header || l.className == "empty") return;
	l.className = l.__className;
}

proto._table_onclick = function(ev)
{
	var l = Util.eventTarget(ev);
	if(l.tagName != "TD" || l.parentElement == this.header || l.className == "empty") return;
	var jsObject = this;
	jsObject.selectDayTD(l);
	jsObject.hide();
}

proto._monthSelect_onchange = function()
{
	// Executed in combobox context.
	var jsObject = CNUtil.findJSObject(this.element.parentElement);

	if(jsObject._disabled) return;

	var all = jsObject._elements(jsObject.element);
	jsObject._isDirty = true;
	jsObject.fillDays(this.get_selectedIndex(), all.yearSelect.value);
	jsObject.fire_onxlchange();
}

proto._yearSelect_onkeyup = function(ev)
{
	var jsObject = this;
	jsObject.fillChange();
	return true;
}

proto._yearSelect_onkeypress = function(ev)
{
	var l = Util.eventTarget(ev);
	var code = Event.keyValue(ev);
	if(code == 0) return;
	var charx = String.fromCharCode(code);
	if(charx < "0" || charx > "9") return Util.cancelEvent(ev);
	return true;
}

proto._yearSelect_onfocus = function(ev)
{
	Util.eventTarget(ev).select();
}


// Util. ===================================
proto.zeroPad = function(str)
{
	if(String(str).length == 1)	return "0" + str;
	return str;
}


// Properties. ==============================
proto.set_title = function(value)
{
	this._title = value;
	this.captionDiv.textContent = this._title;
}

proto.set_date = function(value)
{
	if(value != null && (this._isDirty || this._date == null || value.getTime() != this._date.getTime()))
	{
		this._date = value;
		this._isDirty = false;
		this.updateToDate();
	}
}

proto.get_date = function()
{
	var all = this._elements(this.element);
	this._date = new Date(all.yearSelect.value, this._combobox.get_selectedIndex(), this.selectedDay);
	return this._date;
}

// In EU format, i.e. dd.mm.yyyy
proto.get_dateString = function()
{
	return this.zeroPad(this._date.getDate()) + "/" + this.zeroPad(this._date.getMonth() + 1) + "/" + this._date.getFullYear();
}

/*
	v. 0.1 - initial release.
*/
function CN_search() {
}
var proto = CN_search.prototype;

proto.createElement = function(node, parentElement) {
	var l = document.createElement("div");
	l.className = "cn_search";
	parentElement.appendChild(l);
	l.jsObject = this;
	this.element = l;

	var box = this._box = document.createElement("input");
	box.type = "text";
	box.tabIndex = -1;
	l.appendChild(box);

	Event.add(box, "focus", this, this._box_focus);
	Event.add(box, "blur", this, this._box_blur);
	Event.add(box, "keydown", this, this._box_keydown);
	Event.add(box, "mousedown", this, this._box_mousedown);

	this._standBy();

	return l;
}

proto.loadData = function(node) {
	if(this._box == document.activeElement) {
		var list = Util.xmlSelectSingleNode(node, "list");
		var items = Util.xmlSelectNodes(node, "list/i");
		this._loadListItems(items);
	}
}

proto.storeData = function(xmldoc) {
	return null;
}

proto.set_disabled = function(disabled) {
	this._disabled = disabled;
	this._box.readOnly = disabled;
	if(disabled) {
		this._standBy();
		Util.addClass(this.element, "disabled");
	}
	else {
		Util.removeClass(this.element, "disabled");
	}
}

proto._standBy = function() {
	this._hidePopup();
	if(this._keyTimeout) clearTimeout(this._keyTimeout);
	this._box.value = "Type to search";
	this._box.className = "";
}
proto._focused = function() {
	this._box.value = "";
	this._box.className = "focused";
}

proto._box_mousedown = function(ev) {
	if(this._disabled) {
		Util.cancelEvent(ev);
	}
}

proto._box_focus = function(ev) {
	if(this._disabled) {
		Util.cancelEvent(ev);
		return;
	}
	if(this._box.className == "") {
		this._focused();
	} else if(this._box.value != "") {
		this._lightPostData();
	}
	//} else if(this.popup && this.popup.children.length > 0) {
	//	this._showPopup();
	//}
}

proto._box_blur = function(ev) {
	if(this._box.value == "") {
		this._standBy();
	}
}

proto._box_keydown = function(ev) {
	if(this._keyTimeout) clearTimeout(this._keyTimeout);
	if(ev.key == "Enter") {
		this._submit();
	} else if(ev.key != "ArrowDown" && ev.key != "ArrowUp") {
		var obj = this;
		if(this._box.value != this._lastValue) {
			this._lastValue = this._box.value;
			this._hidePopup();
			this._keyTimeout = setTimeout(function(){ obj._lightPostData; }, 500);
		}
	}
}
proto._lightPostData = function(ev) {
	var val = Util.trim(this._box.value);
	if(val != "") {
		this.formManager.lightPostData("<search id='" + this.elementID + "' liveText='" + Util.escapeAttr(val) + "'/>");
	}

}

proto._submit = function() {
	var val = Util.trim(this._box.value);
	if(val != "" || this._activeOption) {
		var attr = "";
		if(this._activeOption && this._activeOption._id) attr = " iID='" + Util.escapeAttr(this._activeOption._id) + "'"

		this.formManager.postData("<search id='" + Util.escapeAttr(this.elementID) + "' text='" + Util.escapeAttr(val) + "'" + attr + "/>");
	}
	this._hidePopup();	
}

proto._loadListItems = function(items) {
	if(this.popup) {
		this.popup.innerHTML = "";
		this._hidePopup();
	}
	if(items.length == 0) {
		// Hide popup.

	} else {
		// Update popup.

		if(!this.popup) this._createPopup();

		var xy = Util.findAbsolutePos(this._box);
		var maxHeight = Math.max(200, document.body.clientHeight - xy.y) - 8; // 4 paddings+shadow;
		var maxItems = Math.floor(maxHeight / 48);

		var length = items.length;
		for(var i = 0; i < length && i < maxItems; i++) {
			var itemNode = items[i];
			this._createOption(itemNode.getAttribute("id"), itemNode.getAttribute("title"), Util.xmlText(itemNode), itemNode.getAttribute("img"));
		}

		// Show/resize popup.
		this._showPopup();
	}
}

proto._showPopup = function() {
	this.popup.style.visibility = "hidden";
	this.popup.style.display = "block";

	var xy = Util.findAbsolutePos(this._box);

	this.popup.style.width = "";

	var w = Math.max(this._box.offsetWidth, this.popup.offsetWidth);
	CNUtil.posPopup(this.popup, xy.x + this._box.offsetWidth - w, xy.y + this._box.offsetHeight);
	this.popup.style.width = w + "px";
	
	this.popup.style.zIndex = top.__ontopZ++;

	this.popup.style.visibility = "visible";
	if(this.popup.shadow) this.popup.shadow.show();

	this._selectedOptionIx = -1;
	
	Event.add(this._box, "keydown", this, this._popupVisible_box_keydown);
	Event.add(document.body, "mousedown", this, this._popupVisible_document_mousedown);
}
proto._popupVisible_box_keydown = function(ev) {
	if(ev.key == "ArrowUp") { // Up
		if(this._selectedOptionIx == -1) this._selectedOptionIx = this.popup.childNodes.length - 1;
		else if(--this._selectedOptionIx < 0) {
			this._selectedOptionIx = -1;
			this._unhoverOption();
			//this._box.value = this._lastValue;
			return;
		}
		this._hoverOptionByKey();
	} else if(ev.key == "ArrowDown") { // Down
		if(this._selectedOptionIx == -1) this._selectedOptionIx = 0;
		else if(++this._selectedOptionIx >= this.popup.childNodes.length) {
			this._selectedOptionIx = -1;
			this._unhoverOption();
			//this._box.value = this._lastValue;
			return;
		}
		this._hoverOptionByKey();
	} else if(ev.key == "Escape") { // Esc
		this._hidePopup();
		Util.cancelEvent(ev);
	}
}
proto._hoverOptionByKey = function() {
	var option = this.popup.childNodes[this._selectedOptionIx];
	this._hoverOption(option);
	//this._box.value = option.children[1].textContent;
}

proto._popupVisible_document_mousedown = function(ev) {
	if(!this.popup.contains(ev.target)) this._hidePopup();
}
proto._hidePopup = function() {
	if(!this.popup) return;
	if(this.popup.shadow) this.popup.shadow.hide();
	this.popup.style.display = "none";
	this._unhoverOption();
	Event.del(this._box, "keydown", this, this._popupVisible_box_keydown);
	Event.del(document.body, "mousedown", this, this._popupVisible_document_mousedown);
}

proto._createPopup = function() {
	var popup = this.popup = document.createElement("div");
	popup.style.userSelect = "none";
	popup.className = "cn_comboboxPopup cn_search_popup";
	document.body.appendChild(this.popup);

	new Shadow(this.popup, false, true);	

	Event.add(popup, "mouseover", this, this._popup_mouseover);
	Event.add(popup, "mouseout", this, this._popup_mouseout);
	Event.add(popup, "mousedown", this, this._popup_click);
}

proto._createOption = function(id, title, text, imgUrl) {
	var option = Util.createElement("div", "xlcombooption");
	option.style.userSelect = "none";
	if(id) option._id = String(id);

	var imgDiv = document.createElement("div");
	imgDiv.style.userSelect = "none";
	imgDiv.className = "imgDiv";
	option.appendChild(imgDiv);

	var titleDiv = document.createElement("div");
	titleDiv.className = "titleDiv";
	titleDiv.style.userSelect = "none";
	option.appendChild(titleDiv);

	var descriptionDiv = document.createElement("div");
	descriptionDiv.className = "descriptionDiv";
	descriptionDiv.style.userSelect = "none";
	option.appendChild(descriptionDiv);

	if(!title) {
		titleDiv.innerHTML = String(text);
	} else {
		titleDiv.innerHTML = String(title);
		descriptionDiv.innerHTML = String(text);
	}

	if(imgUrl) {
		var img = Util.createElement("img", "img");
		img.src = String(imgUrl);
		img.style.userSelect = "none";
		imgDiv.appendChild(img);
	} //else {
	//	imgDiv.style.display = "none";
	//}

	this.popup.appendChild(option);
	return option;
}
proto._hoverOption = function(option) {
	this._unhoverOption();
	this._activeOption = option;
	Util.addClass(this._activeOption, "hover");
}

proto._unhoverOption = function() {
	if(!this._activeOption) return;
	Util.removeClass(this._activeOption, "hover");
	this._activeOption = null;
}

proto._popup_mouseover = function(ev) {
	if(ev.target.className == "xlcombooption") {
		this._hoverOption(ev.target);
	}
}
proto._popup_mouseout = function(ev) {
	if(ev.target.className == "xlcombooption" && !ev.target.contains(ev.relatedTarget)) {
		this._unhoverOption();
	}
}
proto._popup_click = function(ev) {
	var option = Util.findByClassName(ev.target, "xlcombooption");
	if(!option) return;
	this._activeOption = option;

	Util.cancelEvent(ev);
	this._submit();
}

proto = null;

/*
	v. 2.0.3
	+ handleEvent based event handlers.
	+ vista focus support.
*/
function CN_button()
{
	this.formManager = null;
	this._disabled = false;
	this.validator = true;
	this.initiateUpload = false; // Used by formManager.
}
var proto = CN_button.plainThemeProto = {};
var vproto = CN_button.vistaThemeProto = {};

CN_button.setTheme = function(themeName)
{
	this._deinitVista();
	if(CNFormManager.vista) 
	{
		this.prototype = this.vistaThemeProto;
		this._initVista();
	}
	else 
	{
		this.prototype = this.plainThemeProto;
	}
}

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("button");
	parentElement.appendChild(l);

	this.clicked = false;
	
	this.element = l;
	l.jsObject = this;

	l.className = "cn_button";

	var span = document.createElement("span");
	l.appendChild(span);
	
	Event.add(l, "mouseenter", this, _CN_button_onmouseenter);
	Event.add(l, "mouseleave", this, _CN_button_onmouseleave);
	Event.add(l, "mousedown", this, this._onmousedown);
	Event.add(l, "click", this, _CN_button_onclick);
	Event.add(l, "keypress", this, CNUtil.cancelBubble);
	
	if(node.getAttribute("validator") == "false") this.validator = false;
	
	return l;
}

proto._onmousedown = function()
{
    if(Event.current().button != 0) return;
	
	var jso = CNUtil.dispatchObject();
	if(jso && jso.formManager) jso.formManager.waitForButtonClick();	
}

function _CN_button_onmouseenter()
{
	var l = Util.findByClassName(Util.eventTarget(), "cn_button");
	if(!l) return;
	
	var color = Util.getStyle(l, "xl--hover-border-color");
	if(color) l.style.borderColor = color;

	//if(CNFormManager.currentThemeName == "blue") 
	l.style.textDecoration = "underline";
} 

function _CN_button_onmouseleave()
{
	var l = Util.findByClassName(Util.eventTarget(), "cn_button");
	if(!l) return;

	l.style.borderColor = "";
	//if(CNFormManager.currentThemeName == "blue") 
	l.style.textDecoration = "";
} 

function _CN_button_onclick()
{
	if(CNFormManager.vista) _CN_button_onmouseleave();
	var jso = Util.dispatchObject();
	if(jso) jso.doClick();
} 

proto.doClick = vproto.doClick = function()
{
	if(this.clicked
	|| this._disabled || this.element.disabled
	|| Util.getStyle(this.element, "display") == "none" 
	|| Util.getStyle(this.element, "visibility") == "hidden") return false;

	if(this.formManager) this.formManager.waitForButtonClick();

	try
	{
		this.element.focus();
	}
	catch(e){}
	this.clicked = true;
	if(this.formManager)
	{
		this.formManager.buttonClicked();	
		if(!this.formManager.postData(this.element))
		{
			// Reset button state on validation error.
			this.clicked = false;
			//CNUtil.cancelEvent();
		}
	}
	return true;
}

proto.loadData = vproto.loadData = function(node)
{
   	var attr = node.getAttribute("tooltip");
	if(attr != null) 
	{
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
		
		this._handleDisabledState();
	}

	var backgroundColor = node.getAttribute("backgroundColor");
	if(backgroundColor)
	{	
		this.element.style.backgroundColor = backgroundColor;	
		this.element.style.borderColor = "#316AC5";		
	}
	else
	{
		this.element.style.backgroundColor = "";	
		this.element.style.borderColor = "";	
	}
	
	var textColor = node.getAttribute("textColor");
	if(textColor)
	{
		var textSpan = this._getTextElement();
		textSpan.style.color = textColor;				
	}
	else
	{
		var textSpan = this._getTextElement();
		textSpan.style.color = "#000000";
	}	
	
	this._setImage(node);
	var textAttr = node.getAttribute("value");
	if(textAttr) 
	{
		var textSpan = this._getTextElement();
		var lastNode = textSpan.lastChild;
		if(lastNode && lastNode.nodeType == 3) lastNode.data = String(textAttr);
		else textSpan.appendChild(document.createTextNode(String(textAttr)));
		
		
		
		if(CNFormManager.vista) 
		{
			textSpan.style.paddingTop = Math.max(this.element.offsetHeight - textSpan.offsetHeight, 0) / 2 + 2;
		}	
	}
	
	this.initiateUpload = node.getAttribute("uploads") == "true";
}

proto._setImage = vproto._setImage = function(node)
{
	var attr = node.getAttribute("img");
	if(attr === null) return;
	this._setImageCore(String(attr), node.getAttribute("imgWidth"), node.getAttribute("imgHeight"));
}

proto._setImageCore = vproto._setImageCore = function(src, width, height, align)
{
	var textEl = this._getTextElement();
	var imgEl = textEl.firstChild;
	if(src == "")
	{
		if(imgEl && imgEl.tagName == "IMG") textEl.removeChild(imgEl);
	}
	else
	{
		if(imgEl && imgEl.tagName == "IMG") 
		{
			imgEl.src = src;
		}
		else
		{
			imgEl = document.createElement("img");
			imgEl.align = "absmiddle";
			textEl.insertBefore(imgEl, textEl.firstChild);
			textEl.style.lineHeight = "100%";
			//imgEl.style.marginRight = 4;
			imgEl.src = src;
		}
		
		if(width) imgEl.style.width = width + "px";
		if(height) imgEl.style.height = height + "px";
	}
}




proto._getTextElement = function()
{
	return this.element.firstChild;
}

proto.validateLoading = vproto.validateLoading = function()
{
	if(this.formManager.defaultButton == this 
		&& this.formManager.changeFocus
		&& Util.getStyle(this.element, "visibility") != "hidden")
	{
		try
		{
			this.element.focus();
		}
		catch(ex)
		{
		}
	}
}

proto.storeData = vproto.storeData = function(xmldoc)
{
	// NOTE: button stores itself only if it's clicked.
	if(!this.clicked) return;
	this.clicked = false;

	var node = xmldoc.createElement("button");
	return node;
}

proto.set_disabled = function(value)
{
	this._disabled = this.element.disabled = value;
	this._handleDisabledState();
}

proto._handleDisabledState = function()
{
	if(this.element.tipText || this.element.tipText == "")
	{
		if(this._disabled)
		{
			// Make transparent layer.
			if(!this._tooltipLayer)
			{
				this._tooltipLayer = document.createElement("div");
				this._tooltipLayer.style.cssText = "background: white; opacity: 0; position: absolute; top: 0; left: 0; width: 100%; height: 100px";
				this.element.appendChild(this._tooltipLayer);
				Tooltip.attach(this._tooltipLayer, this.element.tipText);
			}
			else
			{
				this._tooltipLayer.style.display = "block";
				this._tooltipLayer.tipText = this.element.tipText;
			}
		}
		else if(this._tooltipLayer) this._tooltipLayer.style.display = "none";
	}
}

CN_button._deinitVista = function()
{
	CN_button._buttonTemplate = null;
}

CN_button._initVista = function()
{
	CN_button._buttonTemplate = $("__vistaButtonTemplate");
}


vproto.createElement = function(node, parentElement)
{
	var l = CN_button._buttonTemplate.cloneNode(true);
	parentElement.appendChild(l);

	this.clicked = false;
	
	this.element = l;
	l.jsObject = this;

	if(node.getAttribute("validator") == "false") this.validator = false;

	Event.add(l, "mouseenter", this, this.button_onmouseenter);
	Event.add(l, "mouseleave", this, this.button_onmouseleave);
	Event.add(l, "mousedown", this, this.button_onmousedown);
	Event.add(l, "mouseup", this, this.button_onmouseup);
	Event.add(l, "click", this, this.button_onclick);
	Event.add(l, "keypress", this, this.button_onkeypress);
	return l;
}

vproto._getTextElement = function()
{
	return this.element.lastChild;
}

vproto.button_onmouseenter = function()
{
	if(this._disabled) return;
	var frame = this.element.firstChild;

	if(ThemeNonCSSStyles.animateButtons) {

	}
	this.element.className = "cn_button cn_button_hover";
	frame.children[2].firstChild.src = 
		frame.children[3].firstChild.src = CNFormManager.themeImagesPath + "hover-button-bg.gif";
	if(ThemeNonCSSStyles.animateButtons) {
	}
}

vproto.button_onmouseleave = function()
{
	if(this._disabled) return;
	var frame = this.element.firstChild;

	this.element.className = "cn_button";
	frame.children[2].firstChild.src = 
	frame.children[3].firstChild.src = CNFormManager.themeImagesPath + "button-bg.gif";

}

vproto.button_onmousedown = function()
{
	if(this._disabled || Event.current().button != 0) return;
	if(this.formManager) this.formManager.waitForButtonClick();

	var frame = this.element.firstChild;
	if(ThemeNonCSSStyles.animateButtons) {

	}
	this.element.className = "cn_button cn_button_down";
	frame.children[2].firstChild.src = 
		frame.children[3].firstChild.src = CNFormManager.themeImagesPath + "down-button-bg.gif";
	if(ThemeNonCSSStyles.animateButtons) {
	}
}

vproto.button_onmouseup = function()
{
	if(this._disabled || Event.current().button != 0) return;
	this.button_onmouseenter();
}

vproto.button_onclick = function()
{
	if(this._disabled) return;
	_CN_button_onclick();
}
vproto.button_onkeypress = function()
{
	if(this._disabled || (Event.keyValue(Event.current())) != 13) return;
	_CN_button_onclick();
}

vproto._handleDisabledState = Util.nop;


vproto.set_disabled = function(val)
{
	this._disabled = val;
	var frame = this.element.firstChild;

	if(val)
	{
		this.element.className = "cn_button cn_button_disabled";
		frame.children[2].firstChild.src = 
			frame.children[3].firstChild.src = CNFormManager.themeImagesPath + "disabled-button-bg.gif";
	}
	else
	{
		this.element.className = "cn_button";
		frame.children[2].firstChild.src = 
			frame.children[3].firstChild.src = CNFormManager.themeImagesPath + "button-bg.gif";
	}
}
vproto.focus = function()
{
	var bgImg = this.element.firstChild.children[3].firstChild;
	bgImg.focus();
	
}
vproto.set_tabIndex = function(ti)
{
	var bgImg = this.element.firstChild.children[3].firstChild;
	bgImg.tabIndex = ti;
	
	if(ti > 0)
	{
		if(!this._focusAttached)
		{
			this._focusAttached = true;
			Event.add(bgImg, "focus", this, this._bgIMG_onfocus);
			Event.add(bgImg, "blur", this, this._bgIMG_onblur);
		}
	}
	else
	{
		if(this._focusAttached)
		{
			this._focusAttached = false;
			Event.del(bgImg, "focus", this, this._bgIMG_onfocus);
			Event.del(bgImg, "blur", this, this._bgIMG_onblur);
		}
	}
}
vproto._bgIMG_onfocus = function()
{
	var b = Util.findByClassName(Util.eventTarget(), "cn_button");
	b.firstChild.children[1].firstChild.style.background = "#47D6FA";
}
vproto._bgIMG_onblur = function()
{
	var b = Util.findByClassName(Util.eventTarget(), "cn_button");
	b.firstChild.children[1].firstChild.style.background = "";
}

/*function AnimVistaButtonFadeout(l)
{
	this.l = l;
	this._from = [0xA7D9F5, 0xBEE6FD, 0xD9F0FC, 0xEAF6FD]
	this._to = [0xCFCFCF, 0xDDDDDD, 0xEBEBEB, 0xF2F2F2]
}
AnimVistaButtonFadeout.prototype = new AnimVistaFadeoutBase();
AnimVistaButtonFadeout.prototype.apply = function(ar)
{
	this.l.colors.value = "0% #" + ar[0].toString(16) + ",50% #" + ar[1].toString(16) + ",50% #" + ar[2].toString(16) + ", 100% #" + ar[3].toString(16);
}*/


/*
	#1036-4 - _isDirty moved to element, _isDirty is sent with onchange event, TAB doesn't set _isDirty
	v. 2.0.19
	+ FWUI-1027, also vista css changes.
	+ shared attachable shadow for all vista combos
	+ combo template rewritten: pre-rendered images now used for borders.
	+ numerous grid related state fixes.
*/
function CN_combobox()
{
	this.formManager = null;
	this.activeOption = null;
	// One global popup for single mode, current active popup for mutable mode.
	this.popup = null;

	this.optionTags = null;
	this.valueToIndexMap = [];

	this.popupOpened = false;

	this.disabler = null;
	
	this._disabled = false;
	// NOTE: _isDirty, _selectedIndex and _value are stored in element.
	//this._value = null;
	this._canBeEmpty = false;
	this._autoPostBack = false;
	this.doNotFocus = false;
	this._searchable = false;
	this._livesearch = false;
	this._minNumberOfChars = 0;
	this._doSearch = false;
	this._inGrid = false;
	this._tooltip = null;
	this.supportsRequired = true;
	this._typedSelectTimout = 1 * 1000; // One second.
	this._lastTypeStamp = 0;
	this._maxPopupItems = -1;
	
	this._popupInited = false;
}
if(!top.__ontopZ) top.__ontopZ = 10000;
var proto = CN_combobox.plainThemeProto = {};

CN_combobox.setTheme = function(themeName)
{
	this._deinitVista();
	if(CNFormManager.vista) 
	{
		this.prototype = this.vistaThemeProto;
		this._initVista();
	}
	else 
	{
		this.prototype = this.plainThemeProto;
	}
}

CN_combobox.makeOptions = function(array)
{
	for(var i = 0; i < array.length; i++)
	{
		Util.wrapIntoNode(array[i]);
	}
	return array;
}

CN_combobox.currentCombobox = null;
CN_combobox.pendingCombobox = null;

CN_combobox._initVista = function()
{
	this._template = $("__vistaComboboxTemplate");
	this._sharedShadow = new Shadow(null, false, true); 
}

CN_combobox._deinitVista = function()
{
	this._template = null;
	if(this._sharedShadow)
	{
		this._sharedShadow.destroy();
		this._sharedShadow = null;
	}
}


// Public events.
proto.onchange = function(){}
proto.oncheckreadonly = function(){ return false; }
proto._ingrid_getContextMenuData = function()
{
	// this == combobox
	if(CNUtil.eventTarget())
	{
		var comboEl = CNUtil.findElement(CNUtil.eventTarget());
		var gridEl = CNUtil.findElement(comboEl.parentNode);
		//var gridJSO = gridEl.jsObject;
		
		return {menuID: gridEl._menuID, targetID: gridEl.id};
	}
	CNUtil.assert("Invalid context for _ingrid_getContextMenuData()");
	return null;
}

proto.createElement = function(node, parentElement)
{
	var l = this.createElementOnly(node, null, true);
	parentElement.appendChild(l);
	
	this._precreatePopup();

	this.initData(node);

	if(!this._inGrid) this.set_disabled();

	return l;
} 

proto._preinit = function(node, inGrid)
{
	if(inGrid !== null) 
	{
		this._inGrid = inGrid;
		if(inGrid) this.getContextMenuData = this._ingrid_getContextMenuData;
	}

	var isNotArray = !(node instanceof Array) && !(node instanceof Object);
	if(isNotArray)
	{
		var attr = node.getAttribute("searchable");
		if(attr == "true") 
		{
			this._searchable = true;
			attr = node.getAttribute("minNumberOfChars");
			if(attr) this._minNumberOfChars = parseInt(attr, 10);
			attr = node.getAttribute("livesearch");
			if(attr) this._livesearch = true;
		}
	
		attr = node.getAttribute("maxPopupItems");
		if(attr) 
		{
			this._maxPopupItems = parseInt(attr, 10);
		}
	}
}

proto._setCommonOptions = function(node)
{
	var attr;
	if(this._searchable)
	{
		 this._canBeEmpty = true;
	}
	else
	{
		attr = node.getAttribute("canBeEmpty");
		this._canBeEmpty = attr == "true";
	}

	if(this._canBeEmpty) 
	{
		if(this.element) {
			this.element._selectedIndex = -1;
			this.element._isDirty = false;
		}
	}
	else
	{
		if(this.element) this.element._selectedIndex = 0;
	}
			
	attr = node.getAttribute("autoPostBack");
	this._autoPostBack = attr == "true";
}	


proto.createElementOnly = function(node, inGrid, assignElement)
{
	this._preinit(node, inGrid);

	var l = Util.createElementFromHTML("<table cellpadding=0 cellspacing=0 border=0>");
	var tr = l.insertRow();
	tr.vAlign = "middle";
	var td0 = tr.insertCell();
	td0.style.paddingLeft = "1px";
	td0.style.display = "none";
	td0.style.width = "16px";

	var td1 = tr.insertCell();
	td1.className = "xlcomboTD1";

	if(assignElement) this.element = l;
	
	if(this._searchable)
	{
		this._td15 = tr.insertCell();
		this._td15.className = "xlcomboTD15";
		this._td15.width = 10;
	}

	var td2 = tr.insertCell();
	td2.className = "xlcomboTD2";
	this._td2 = td2;
	
	l.className = "cn_combobox";
	l._isComboBox = true;
	
	l.jsObject = this;
	if(!this._searchable && !this.doNotFocus) l.tabIndex = -1;
	
	if(this.doNotFocus) 
	{
		l.style.userSelect = "none";
		td1.style.userSelect = "none";
	}

	var isNotArray = !(node instanceof Array) && !(node instanceof Object);
	if(isNotArray) this._setCommonOptions(node);

	if(this._searchable)
	{
		var inputElement = Util.createElementFromHTML("<input type='text' value='' class=xlcomboinput>");
		l.rows[0].cells[1].appendChild(inputElement);
		
		this._setTextInputEvents(inputElement);
		
		var img = document.createElement("img");
		this._td15.appendChild(img);
		
		if (this._livesearch)
			img.src = CNFormManager.neutralImagesPath + "livesearch.png";
		else
			img.src = CNFormManager.neutralImagesPath + "question-1.gif";
		
		this._td15.style.cursor = "hand";
		
		Event.add(img, "click", this, this._img_onclick);
		
		if (this._livesearch)
			this._standBy();
	}
	else
	{
		var textSpan = Util.createElementFromHTML("<div style='overflow: hidden; '>");
		textSpan.style.userSelect = "none";
		l.rows[0].cells[1].appendChild(textSpan);
	}

	var td2 = this._td2;
	td2.textContent = "6";
	td2.style.userSelect = "none";

	Event.add(l, "mouseenter", this, this._element_onmouseenter);
	Event.add(l, "mouseleave", this, this._element_onmouseleave);
	//if(this._searchable) // <- forced because of 918 and 927 conflict
	Event.add(l, "resize", this, this._element_onresize);
	Event.add(l, "keydown", this, this._element_onkeydown);

	var el = l;
	if(this._searchable) el = td2; // Button.

	Event.add(el, "mousedown", this, this._element_onmousedown);
	Event.add(el, "dblclick", this, this._element_onmousedown);

	return l;
}
proto._setTextInputEvents = function(inputElement)
{
	Event.add(inputElement, "focusin", this, this._inputElement_onbeforeactivate);
	Event.add(inputElement, "blur", this, this._inputElement_ondeactivate);
	Event.add(inputElement, "keypress", this, this._inputElement_onkeypress);
	Event.add(inputElement, "change", this, this._inputElement_onchange);
	Event.add(inputElement, "keydown", this, this._inputElement_onkeydown);
	Event.add(inputElement, "keyup", this, this._inputElement_onkeyup);
}

proto._lightPostData = function() 
{
	var textBox = this._getTextInput();	
	var val = Util.trim(textBox.value);
	if(val != "" && this._minNumberOfChars != "" && val.length >= this._minNumberOfChars) 
	{	
		var img = this._td15.getElementsByTagName("img")[0];
		this._td15.removeChild(img);

		img = document.createElement("img");
		this._td15.appendChild(img);
		img.src = CNFormManager.neutralImagesPath + "searching.gif";
	
		this.formManager.lightPostData("<combobox value='" + Util.escapeAttr(val) + "' search='" + this._livesearch + "' id='" + this.elementID + "'/>");
	}
	else
	{
		// Reset popup.
		if(this.popup)
		{
			this.popup.innerHTML = "";
			this._popupInited = false;
		}
		
		var img = this._td15.getElementsByTagName("img")[0];
		this._td15.removeChild(img);

		img = document.createElement("img");
		this._td15.appendChild(img);
		img.src = CNFormManager.neutralImagesPath + "livesearch.png";	
	}
}

proto._focused = function() 
{
	var textBox = this._getTextInput();	
	textBox.value = "";	
}

proto._inputElement_onblur = function()
{
	CNUtil.dispatchObject().inputElement_onblur();
}

proto.inputElement_onblur = function() 
{
	var textBox = this._getTextInput();	
	if(textBox.value == "") 
	{
		this._standBy();
	}
}

proto._standBy = function() 
{
	var textBox = this._getTextInput();	
	this.hidePopup();
	if(this._keyTimeout) clearTimeout(this._keyTimeout);	
}

proto._element_onresize = function()
{
	CNUtil.dispatchObject().element_onresize();
}
proto.element_onresize = function()
{
	if(!this.element) return;
	if (this.element.rows.length == 0 || this.element.rows[0].cells.length == 0) return;	
	
	var cell0 = this.element.rows[0].cells[1];	
	var textBox = cell0.children[0];
	var w = cell0.clientWidth - 4;
	if(w > 0) textBox.style.width = w + "px";
}

proto.loadData = function(node)
{
	this.initData(node);

	var valueSet = false;
	if(this._searchable)
	{
		var attr = node.getAttribute("value")
		if(attr != null)
		{
			this.set_textValue(String(attr));
			valueSet = true;
		}
		else this.element._value = "";
	}
	
	if(!valueSet)
	{
		var ix = parseInt(node.getAttribute("selection"));
		if(!isNaN(ix)) 
		{
			this.set_selectedIndex(ix);
			if(this.element) this.element._isDirty = false;
		}
	}
	
	if(node.getAttribute("opened") == "true") 
	{
		CN_combobox.pendingCombobox = this;
		setTimeout(this._showPopup, 0);
	}
	
	var attr = node.getAttribute("tooltip");
	if(attr != null)
	{
		this._tooltip = String(attr);
		if(this.element.tipText) this.element.tipText = this._tooltip;
		else Tooltip.attach(this.element, this._tooltip);
	}	
	
	if (this._livesearch)
	{
		var img = this._td15.getElementsByTagName("img")[0];
		this._td15.removeChild(img);

		img = document.createElement("img");
		this._td15.appendChild(img);
		img.src = CNFormManager.neutralImagesPath + "livesearch.png";		
	}	
}

proto.get_textValue = function()
{
	if(!this._searchable) Util.assert("get_textValue() called for non-searchable");
	return this._getTextInput().value;
}

proto.set_textValue = function(value)
{
	if(!this._searchable) Util.assert("set_textValue() called for non-searchable");
	this.element._value = this._getTextInput().value = value;
	this.element._selectedIndex = -2;
}

proto.storeData = function(xmldoc)
{
	if(this.element && !this.element._isDirty) return null;
	
	var node = xmldoc.createElement("combobox");
	
	if(this._searchable && this._getTextInput().value == "") node.setAttribute("selection", "-1");
	else if(this.element._selectedIndex == -2) node.setAttribute("value", this.get_textValue());
	else node.setAttribute("selection", this.element._selectedIndex);
	
	if(this._doSearch) node.setAttribute("search", "true");

	if(this.element) this.element._isDirty = false;
	this._doSearch = false;

	return node;
}

proto.get_disabled = function()
{
	return this._disabled;
}
proto.set_disabled = function(value)
{
	this._disabled = value;
	var l = this.element;

	var cell1 = l.rows[0].cells[1];
	if(this._disabled)
	{
		this.set_tabIndex(-1, true);
		l.style.borderColor = "#dddddd";
		cell1.style.borderColor = "#dddddd";
		var bg = Util.getStyle(this.element, "xl--disabled-background")
		if(this._searchable) 
		{
			var box = cell1.children[0];
			if(!box._color) box.style.color = "#888888";
			box.readOnly = this._disabled;
			box.style.background = bg;
			this._td15.style.display = "none";
			this._hideValidationTooltip();
		}
		if(this._td15) this._td15.style.background = bg;
		cell1.style.backgroundColor = bg;
		this._td2.style.backgroundColor = bg;
	}
	else
	{
		if(this._tabIndex) this.set_tabIndex(this._tabIndex);
		l.style.borderColor = "";
		l.rows[0].cells[1].style.borderColor = "";
		if(this._td15) this._td15.style.background = "";
		if(this._searchable) 
		{
			var box = cell1.children[0];
			if(!box._color) box.style.color = "";
			box.readOnly = this._disabled;
			box.style.background = "";
			this._td15.style.display = "block";
		}
		cell1.style.backgroundColor = "";
		this._td2.style.backgroundColor = "";
		l.style.backgroundColor = "";
	}
}

proto.set_selectedIndex = function(val, doNotFireEvent)
{
	val = val * 1;
	if(this.element._selectedIndex == val) return;
	this.element._selectedIndex = val;
	if(this.element) this.element._isDirty = true;
	this._set_selectedIndex(doNotFireEvent);
}
proto.get_selectedIndex = function()
{
	return this.element._selectedIndex;
}

proto._getTextElement = function()
{
	return this.element.rows[0].cells[1].children[0];
}
proto._getTextInput = function()
{
	return this.element.rows[0].cells[1].children[0];
}

proto._set_selectedIndex = function(doNotFireEvent, force)
{
	if(this.element._selectedIndex === undefined && !force) return;
	
	var textElement = this._getTextElement();	

	if(!this.optionTags || this.optionTags.length == 0) 
	{
		if(this._searchable) textElement.value = "";
		else textElement.textContent = "";
		return;
	}

	var textDiv = textElement;
	var html = this.getHTMLByIndex(this.element._selectedIndex);
	if(html) 
	{
		if(this._searchable) textElement.children[0].value = html;
		else 
		{
			if(html == "") html = "&nbsp";
			textElement.innerHTML = html;
		}
	}
	else
	{
		var text = this.getTextByIndex(this.element._selectedIndex);

		textDiv.style.width = "1px";
		textDiv.style.overflow = "hidden";
		textDiv.textContent = text;
		
		//if(this._searchable)  <- forced because of 918 and 927 conflict
		//{
			var w = textElement.parentElement.clientWidth;
			if(w > 5) textDiv.style.width = (w - 4) + "px";
			else textDiv.style.width = "100%"; // 993
		//}
		//else textDiv.style.width = "auto";
	}
	
	this.element._value = this.getValueByIndex(this.element._selectedIndex);
	
	var valueElement = textDiv;

	var tag = this.optionTags[this.element._selectedIndex];
	if(tag) 
	{
		var attr = tag.getAttribute("textColor");

		if(attr) valueElement._color = valueElement.style.color = String(attr);
		else 
		{
			valueElement.style.color = "";
			valueElement._color = null;
		}

		attr = tag.getAttribute("img");
		if(attr) 
		{
			var td0 = this.element.rows[0].cells[0];
			var img = td0.firstChild;
			if(!img)
			{
				img = document.createElement("img");
				td0.appendChild(img);
			}
			
			img.src = String(attr);
			td0.style.display = "block";
		}
		else 
		{			
			this.element.rows[0].cells[0].style.display = "none";
		}
	}
	else
	{
		valueElement.style.color = "";
		this.element.rows[0].cells[0].style.display = "none";
	}
	
	if(!doNotFireEvent) this.fireChangedEvent();
}

proto.set_value = function(val)
{
	if(this.element._value == val) return;
	this.element._value = val;
	this._set_value();
}
proto.getValue = function()
{
	return this.element._value;
}
proto._set_value = function()
{
	var ix = this.valueToIndexMap[this.element._value];
	if(ix == undefined) ix = -1;
	this.element._selectedIndex = ix;
	this._set_selectedIndex();
}

proto.initData = function(data)
{
	if(data == null) return;
	
	var options = null;
	var clearOptions = false;
	// In standards browsers XML Elements are also instanceof Object.  Keep
	// XML response nodes on the XML path so their <option> children are read.
	var isXMLNode = data && data.nodeType != null && typeof data.getAttribute == "function";
	if(data instanceof Array || (data instanceof Object && !isXMLNode)) options = CN_combobox.makeOptions(data);
	else 
	{
		var attr = data.getAttribute("imgW");
		if(attr) this._item_imgW = parseInt(attr, 10);
	
		var attr = data.getAttribute("imgH");
		if(attr) this._item_imgH = parseInt(attr, 10);

		options = Util.xmlSelectNodes(data, "option");
		if(options.length == 0)
		{
			var nooptions = Util.xmlSelectSingleNode(data, "nooptions");
			if(nooptions != null) 
			{
				clearOptions = true;
				options = [];
				var text;
				if(!this._searchable) text = " ";
				else text = "";
				this.element._value = null;
				this.valueToIndexMap = [];
				if(this._searchable) this._getTextInput().value = text;
			if(!CNFormManager.vista) this.element.rows[0].cells[0].style.display = "none"; // ?				
				this.element._selectedIndex = -1;
			}
		}
	}

	if(!options || (options.length == 0 && !clearOptions)) return;

	this._optionCount = options.length;

	// Reset popup.
	if(this.popup)
	{
		this.popup.innerHTML = "";
		this._popupInited = false;
	}
	
	this.optionTags = options;

	this.initOptions();

	// Grid version doesn't contain element.
	if(this.element)
	{
		if(this.element._value != null) this._set_value(); 
		else this._set_selectedIndex(true, true);
	}
}		

proto.initOptions = function()
{
	var count = this.optionTags.length;
	for(var i = 0; i < count; i++)
	{
		var value = this.optionTags[i].getAttribute("value");
		if(!value) value = i; // Auto-index.*/
		this.valueToIndexMap[String(value)] = i;
	}
}


proto._precreatePopup = function()
{
	if(this._popupPrecreated) return;
	this._popupPrecreated = true;
	this.popup = document.createElement("div");
	this.popup.className = "cn_comboboxPopup";
	this.popup._isPopup = true;
	document.body.appendChild(this.popup);
}

proto.createPopup = function()
{
	if(this._popupInited) return;
	this._popupInited = true;
	
	this._precreatePopup();

	if(this._canBeEmpty)
	{
		var option = this.createOption(" ", "", -1);
		this.popup.appendChild(option);
	}

	if(this.optionTags)
	{
		var count = this.optionTags.length;
		for(var ix = 0; ix < count; ix++)
		{
			var optionTag = this.optionTags[ix];
			var value = optionTag.getAttribute("value");
			if(!value) value = ix; // Auto-index.*/
	
			var text = String(optionTag.getAttribute("text"));
			text = text == "" ? " " : text; // !!
			
			var imgUrl = null;
			var attr = optionTag.getAttribute("img");
			if(attr) imgUrl = String(attr);
			
			var option = this.createOption(text, value, ix, imgUrl, optionTag);

			attr = optionTag.getAttribute("textColor");
			if(attr) option.style.color = String(attr);
			
			this.popup.appendChild(option);

			// Used by WYSIWYG.
			var style = optionTag.style;
			if(style) option.style.cssText += "; " + style;

			var html = optionTag.getAttribute("html");
			if(html) option.innerHTML = html;
		}
	}
		
	this.popup.style.overflow = "auto";
	
	//if(CNFormManager.vista) new Shadow(this.popup, false, true);
	
	Event.add(this.popup, "click", this, this._popup_onclick);
	Event.add(this.popup, "mouseover", this, this._popup_onmouseover);
	Event.add(this.popup, "mouseout", this, this._popup_onmouseout);
	Event.add(this.popup, "mousedown", this, this._popup_onmousedown);
	Event.add(this.popup, "contextmenu", this, this._popup_oncontextmenu);
	Event.add(this.popup, "wheel", this, CNUtil.cancelBubble);
}

proto.createOption = function(text, value, index, imgUrl, optionTag)
{
	var option = Util.createElementFromHTML("<div class=xlcombooption style=\"padding: 1px; position: relative; display: inline-block; white-space: nowrap; \">");
	option.style.userSelect = "none";

	option.textContent = text;

	if(imgUrl)
	{
		// Some standards-browser responses provide an image URL without the
		// optional XML option node. Keep the image usable in that case.
		if(!optionTag) optionTag = { getAttribute: function(){ return null; } };
		var img = Util.createElementFromHTML("<img align=absmiddle style=\"margin-right: 4px; \">");
		
		var wAttr = optionTag.getAttribute("imgW");
		if(wAttr) img.width = parseInt(wAttr, 10);
		else if(this._item_imgW) img.width = this._item_imgW;
		
		var hAttr = optionTag.getAttribute("imgH");
		if(hAttr) img.height = parseInt(wAttr, 10);
		else if(this._item_imgH) img.height = this._item_imgH;
		
		option.insertBefore(img, option.firstChild);
		img.style.userSelect = "none";
		img.src = imgUrl;
	}

	option.value = value;
	option.index = index;
	
	return option;
}

proto.getTextByIndex = function(ix)
{
	if(!this.optionTags || isNaN(ix) || ix < 0 || ix >= this.optionTags.length || !this.optionTags[ix]) return "";
	return String(this.optionTags[ix].getAttribute("text"));
}

proto.getHTMLByIndex = function(ix)
{
	if(!this.optionTags || isNaN(ix) || ix < 0 || ix >= this.optionTags.length || !this.optionTags[ix]) return "";
	var attr = this.optionTags[ix].getAttribute("html");
	return attr ? String(attr) : null;
}

proto.getValueByIndex = function(ix)
{
	if(!this.optionTags || isNaN(ix) || ix < 0 || ix >= this.optionTags.length || !this.optionTags[ix]) return null;
	var value = this.optionTags[ix].getAttribute("value");
	if(value === null) return String(ix);
	return String(value);
}

proto.findTag = function(l, tag)
{
	while(l != null && l.tagName != tag) l = l.parentElement;
	return l;
}

// Event handlers.
proto._element_onmouseenter = function()
{
	var jsObject = CNUtil.eventTarget().jsObject;
	if(jsObject && jsObject.element_onmouseenter) jsObject.element_onmouseenter();
}

proto.element_onmouseenter = function()
{
	if(this._disabled || this.oncheckreadonly() || this.popupOpened && this.element && this.element.contains(CNUtil.eventTarget())) return;
	this.hoverBox(CNUtil.eventTarget());
}

proto._element_onmouseleave = function()
{
	var jsObject = CNUtil.eventTarget().jsObject;
	if(jsObject && jsObject.element_onmouseleave) jsObject.element_onmouseleave();
}

proto.element_onmouseleave = function()
{
	if(this._disabled || this.oncheckreadonly() || this.popupOpened && this.element && this.element.contains(CNUtil.eventTarget())) return;
	var l = CNUtil.eventTarget();
	if(this._searchable && this.element && document.activeElement == this._getTextInput()
	&& this.element.contains(l)) return;
	this.unhoverBox(l);
}

proto._element_onmousedown = function()
{
	if(Event.current().button != 0 && Event.current().button != 1) return;
	CNUtil.findJSObject(CNUtil.eventTarget()).element_onmousedown();
}

proto.element_onmousedown = function()
{
	if(this._disabled || this.oncheckreadonly() 
	|| (Event.current().type == "mousedown" && Event.current().button != 0 && Event.current().button != 1)) return;
	if(this._searchable && this._canBeEmpty && !this._optionCount) return;
	if(this._searchable && CNUtil.eventTarget().tagName == "INPUT") return;

	if(this.doNotFocus) 
	{
		CNUtil.eventTarget().style.userSelect = "none"; // Hack, but works.
		Util.cancelEvent();
	}	

	var l = CNUtil.eventTarget();
	while(l && !l._isComboBox) l = l.parentElement;
	
	if(this.popupOpened) 
	{
		CNUtil.cancelBubble();
		if(this.element == l) 
		{
			this.hidePopup(true);
			this.hoverBox(this.element);
			return; // Click on the same button.
		}
		else if(this._inGrid)
		{
			this.hidePopup(); // grid combo.
		}
	}
	else if(this._inGrid && this.element && this.element != l) // grid combo => force unhover.
	{
		this.unhoverBox(this.element, true); 
	}

	this.element = l;

	if(!this.doNotFocus) this.element.focus();
	this._pressBox();

	var obj = this;
	setTimeout(function(){ obj.showPopup(l); } , 0);
}
proto._pressBox = function()
{
	this.hoverBox(this.element);
}

proto._popup_onmousedown = function()
{
	CNUtil.cancelBubble();
}

proto._popup_onclick = function()
{
	if(CN_combobox.currentCombobox) CN_combobox.currentCombobox.popup_onclick();
}

proto.popup_onclick = function()
{
	var l = CNUtil.findByClassName(CNUtil.eventTarget(), "xlcombooption");
	if(!l || !this.popup.contains(l) || !Util.hasClass(l, "xlcombooption")) return;
	this.hidePopup();
	this.selectOption(l);
}

proto._popup_onmouseover = function()
{
	if(CN_combobox.currentCombobox) CN_combobox.currentCombobox.popup_onmouseover();
}

proto.popup_onmouseover = function()
{
	var l = CNUtil.findByClassName(CNUtil.eventTarget(), "xlcombooption");
	if(!l || !this.popup.contains(l) || !Util.hasClass(l, "xlcombooption")) return;
	this.hoverOption(l);
}

proto._popup_onmouseout = function()
{
	if(CN_combobox.currentCombobox) CN_combobox.currentCombobox.popup_onmouseout();
}

proto.popup_onmouseout = function()
{
	var l = CNUtil.findByClassName(CNUtil.eventTarget(), "xlcombooption");
	if(!l || !this.popup.contains(l) || !Util.hasClass(l, "xlcombooption")) return;
	this.unhoverOption();
}

proto._element_onkeydown = function()
{
	//CNFormManager._trace("combo _element_onkeydown")
	if(CNFormManager.getActiveFormManager().nonInteractive) return;
	CNUtil.dispatchObject().element_onkeydown();
}
proto.element_onkeydown = function()
{
	//CNFormManager._trace("combo element_onkeydown")
	var code = Event.keyValue(Event.current());
	if(this.popupOpened)
	{
		this.popup_onkeydown();
	}
	else if(!this._searchable)
	{
		this.createPopup(); // Ensure popup created.
		if(code == 40)
		{
			CN_combobox.currentCombobox = this;
			this.showPopup();
			CNUtil.cancelEvent();
		}
		else if(code != 9)
		{
			this._processTypedWord(code, true);
		}
	} else if(this._inGrid && Event.keyValue(Event.current()) == 9) {
		CN_grid.proxyTabKeyDown();
	}
}

proto.popup_onkeydown = function()
{
	if(!this.popup) return;
	var code = Event.keyValue(Event.current());
	switch(code)
	{
		case 27: this.hidePopup(); break;
		case 38: // Up
			if(this.activeOption)
			{
				if(this.activeOption.previousSibling) this.hoverOption(this.activeOption.previousSibling);
			}
			else if(this.popup.children.length > 0) 
			{
				this.hoverOption(this.popup.children[this.popup.children.length - 1]);
			}
			break;
		case 40:
			if(this.activeOption)
			{
				if(this.activeOption.nextSibling) this.hoverOption(this.activeOption.nextSibling);
			}
			else if(this.popup.children.length > 0) 
			{
				this.hoverOption(this.popup.children[0]);
			}
			break;
		case 13: 
			if(this.activeOption) 
			{
				this.selectOption(this.activeOption);
				this.hidePopup();
			}
			break;
		default:
			this._processTypedWord(code, false);
	}
	if(Event.current().preventDefault) Event.current().preventDefault();
	Event.cancel(Event.current());
}


proto._processTypedWord = function(code, select)
{
	if(this._disabled) return;
	
	var now = new Date().getTime();
	if(!this._currentTypedWord 
	|| this._lastTypeStamp + this._typedSelectTimout <= now)
	{
		this._currentTypedWord = "";
	}
	this._lastTypeStamp = now;

	var ch = String.fromCharCode(code).toLowerCase();
	this._currentTypedWord += ch;
	
	var children = this.popup.children;
	if(!children) children = this.popup.document.body.children; // Fall back for answerbox.
	var selectNext = 0;
	if(this._currentTypedWord.length == 1)
	{
		// Check for other available options starting with the same char.
		var ix = this.element._selectedIndex;
		if(this._canBeEmpty) ix++;
		if(ix != -1)
		{
			var currentOption;
			
			if(select) currentOption = children[ix];
			else currentOption = this.activeOption;
			
			if(!currentOption) return;

			var text = currentOption.textContent;
			if(text.length > 0)
			{
				text = text.toLowerCase().charAt(0);
				if(text == this._currentTypedWord) 
				{
					selectNext = currentOption.index + 1;
					if(this._canBeEmpty) selectNext++;
				}
			}
		}
	}
	
	var count = children.length;
	for(var i = selectNext; i < count; i++)
	{
		var child = children[i];
		if(child.textContent.toLowerCase().indexOf(this._currentTypedWord) == 0)
		{
			if(select) this.selectOption(child);
			else this.hoverOption(child);
			break;
		}
	}
}


proto._document_onmousedown = function()
{
	if(CN_combobox.currentCombobox) CN_combobox.currentCombobox.document_onmousedown();
}

proto.document_onmousedown = function()
{
	this.closing = true;
	this.hidePopup();
	CNUtil.cancelBubble();
	CN_combobox.currentCombobox = null;
}

proto._getTD3 = function(l)
{
	return l.rows[0].cells[this._searchable ? 3 : 2];
}

proto.hoverBox = function(l)
{
	// NOTE: do not set this.element here.
	// this.element = l; 
	var buttonElement = this._getTD3(l);
	l.style.borderColor = buttonElement.style.borderColor 
		= Util.getStyle(l, "xl--hover-border-color");
	buttonElement.style.backgroundColor = Util.getStyle(buttonElement, "xl--hover-background-color");
}
proto.unhoverBox = function(l)
{
	if(!l) l = this.element;
	if(!l) return;
	var buttonElement = this._getTD3(l);
	l.style.borderColor = buttonElement.style.borderColor = "";
	buttonElement.style.backgroundColor = "";
	}

proto._showPopup = function()
{
	if(!CN_combobox.pendingCombobox) return;
	CN_combobox.currentCombobox = CN_combobox.pendingCombobox;
	CN_combobox.pendingCombobox = null;
	CN_combobox.currentCombobox.showPopup();
}

proto.showPopup = function(element)
{
	if((!this.optionTags || this.optionTags.length == 0) && !this._canBeEmpty) return;
	if(element) this.element = element;

	if(CN_combobox.currentCombobox) {
		CN_combobox.currentCombobox.hidePopup(); // Force hide, as combobox can be non-selectable.
	}

	CN_combobox.currentCombobox = this;
	this.createPopup();

	this.popupOpened = true;
	this.popup.scrollTop = this.popup.scrollLeft = 0;

	var ix = this.element._selectedIndex;
	if(this._canBeEmpty) ix++;

	this.popup.style.zIndex = top.__ontopZ++;
	
	var xy = CNUtil.findAbsolutePos(this.element, null, false, true);
	xy.y += CNFormManager.vista ? 21 : this.element.offsetHeight;
	
	var popupWidth = Math.max(this.element.offsetWidth, 50);
	this.popup.style.width = popupWidth + "px";
	this.popup.style.overflowY = "auto";
	this.popup.style.visibility = "hidden";
	this.popup.style.display = "block";
	
	var maxHeight;
	if(this._maxPopupItems > 0)
	{
		this.popup.style.height = "auto";
		if(this.optionTags)
		{
			var avgItemHeight = this.popup.scrollHeight / (this.optionTags.length + (this._canBeEmpty ? 1 : 0));
			maxHeight = this._maxPopupItems * avgItemHeight + 3; // Border/padding.
		}
		else
		{
			maxHeight = 20;
		}
	}
	else maxHeight = parseInt(Util.getStyle(this.element, "xl--popup-max-height"));

	if(this.popup.offsetHeight >= maxHeight) this.popup.style.height = maxHeight + "px";
	else this.popup.style.height = "auto";
	
	CNUtil.posPopup(this.popup, xy.x, xy.y);
	
//	if(this.popup.scrollHeight <= this.popup.offsetHeight) this.popup.style.overflowY = "hidden"; // COMMENTED: due to the #1027

	if(CNFormManager.vista)
	{
		var h = this.popup.offsetHeight;
		if(ThemeNonCSSStyles.animateDropdowns) {
			this.popup.style.height = "1px";
		}
		this.popup.style.visibility = "visible";
		
		CN_combobox._sharedShadow.attach(this.popup);
		CN_combobox._sharedShadow.show();
		
		if(ThemeNonCSSStyles.animateDropdowns) {
			Animator.start(new AnimResize(this.popup, this.popup.offsetWidth, h, 0));
		}
	}
	else this.popup.style.visibility = "visible";
	if(ix !== undefined)
	{
		this.unhoverOption();
		this.activeOption = this.popup.children[ix];
		this.hoverOption(this.activeOption);
	}
	
	Event.add(document, "mousedown", document, this._document_onmousedown);
	Event.add(document, "wheel", document, this._document_onmousedown);
	
	if(this._searchable) this._getTextInput().focus();
	else if(!this.doNotFocus) this.element.focus();
}
proto.focus = function() { // #1036-3
	if(this._searchable) this._getTextInput().focus();
	else if(!this.doNotFocus) this.element.focus();
}
proto.hidePopup = function(doNotUnhover)
{
	this.popupOpened = false;

	this.unhoverOption();
	
	if(this.popup) 
	{
		this.popup.style.display = "none";
		if(this.popup.shadow) 
		{
			this.popup.shadow.detach();
		}
	}

	Event.del(document, "mousedown", document, this._document_onmousedown);
	Event.del(document, "wheel", document, this._document_onmousedown);
	
	if(!doNotUnhover && !(!this._inGrid && this._searchable && this.element && document.activeElement == this._getTextInput())) 
	{
		this.unhoverBox(this.element);	
	}
	if(CN_combobox.currentCombobox == this) CN_combobox.currentCombobox = null;
}
proto.hoverOption = function(l)
{
	if(!this.element) {
		Util.assert("!this.element");
		return;
	}
	
	this.unhoverOption();
	if(!l) return;
	
	var margin = (this.popup.offsetHeight - this.popup.clientHeight) / 2;
	if(l.offsetTop < this.popup.scrollTop) this.popup.scrollTop = l.offsetTop + margin;
	else if(l.offsetTop + l.offsetHeight - this.popup.scrollTop >= this.popup.clientHeight)
		this.popup.scrollTop = l.offsetTop + l.offsetHeight - this.popup.clientHeight + margin;
	
	l.style.background = Util.getStyle(this.element, "xl--option-hover-background");
	l.style.color = Util.getStyle(this.element, "xl--option-hover-color");
	Util.addClass(l, "cn_combobox_option_active");
	
	this.activeOption = l;
}
proto.unhoverOption = function()
{
	if(!this.activeOption) return;
	this.activeOption.style.background = "";
	this.activeOption.style.color = "";
	Util.removeClass(this.activeOption, "cn_combobox_option_active");
	
	this.activeOption = null;
}
proto.selectOption = function(l)
{
	if(this.element._selectedIndex == l.index) return;
	this._hideValidationTooltip();
	this.set_selectedIndex(l.index);
	
	if(!this._inGrid && this._autoPostBack) 
	{
		this.formManager.postData(this.element);
	}
}
proto._hideValidationTooltip = function()
{
	if(!this._tooltip || this._tooltip.length == 0) Tooltip.detach(this.element);
	else this.element.tipText = this._tooltip;
}

proto.fireChangedEvent = function(propertyChange)
{
	var index = this.element._selectedIndex;
	if(this.element._value == "") index = -2;
	var ev = {value: this.element._value, selectedIndex: index, sender: this, isDirty: this.element._isDirty};
	if(this.onchange) this.onchange(ev);
}

proto._popup_oncontextmenu = function()
{
	CNUtil.cancelEvent();
}

proto._inputElement_onkeypress = function()
{
	CNUtil.dispatchObject().inputElement_onkeypress();
}
proto.inputElement_onkeypress = function()
{
	if(Event.keyValue(Event.current()) == 13)
	{
		if(this._searchable) 
		{
			this.unhoverOption();
			CNUtil.cancelEvent();
			this._doSubmit(true); 
		}
	}
}

proto.textToIndex = function(text)
{
	if(!this.optionTags) return -1;
	for(var i  = 0; i < this.optionTags.length; i++)
	{
		if(text == this.optionTags[i].getAttribute("text")) return i;
	}
	return -1;
}

proto._inputElement_onkeyup = function()
{
	CNUtil.dispatchObject().inputElement_onkeyup();
}
proto.inputElement_onkeyup = function()
{
	// Only for searchable.
	var textBox = this._getTextInput();
	
	var ix = this.textToIndex(textBox.value);
	if(ix == -1)
	{
		textBox.style.color = "";
		textBox._color = null;
	}
	else
	{
		var tag = this.optionTags[ix];
		var attr = tag.getAttribute("textColor");
		if(attr) textBox._color = textBox.style.color = String(attr);
	}
}

proto._inputElement_onkeydown = function()
{
	CNUtil.dispatchObject().inputElement_onkeydown();
}
proto.inputElement_onkeydown = function()
{
	var code = Event.keyValue(Event.current());
	if(code == 40 && !this.popupOpened)
	{
		this.createPopup(); // Ensure popup created.
		CN_combobox.currentCombobox = this;
		this.showPopup();
		CNUtil.cancelEvent();
	}
	else if(code != 9) // Ignore TAB. #1036-4
	{
		this.element._isDirty = true;
		this.element._selectedIndex = -2;
		
		if (this._livesearch)
		{	
			if(this._keyTimeout) clearTimeout(this._keyTimeout);
			if(code == 13) 
			{
						
			}
			else if(code == 27)
			{
				this.hidePopup();
			}
			else if((code >= 48 && code <= 90) || code == 8) 
			{
				var obj = this;								
				this.hidePopup();

				this._keyTimeout = setTimeout(function(){ obj._lightPostData(); }, 500);
			}
		}	
	}
}

proto._inputElement_ondeactivate = function()
{
	CNUtil.dispatchObject().inputElement_ondeactivate();
}
proto.inputElement_ondeactivate = function()
{
	var to = Event.current().relatedTarget;
	if(to && this.element.contains(to)) return;
	var box = this._getTextInput();
	if(this._autoPostBack && this.element._isDirty && box.value.length > 0) 
	{
		this._doSubmit(false); 
	}
}
proto._inputElement_onbeforeactivate = function()
{
	CNUtil.dispatchObject().inputElement_onbeforeactivate();
}
proto.inputElement_onbeforeactivate = function()
{
	if(this._disabled) 
	{
		CNUtil.cancelEvent();
		return;
	}
	
	if(this._inGrid)
	{
		var l = CNUtil.eventTarget();
		while(l && !l._isComboBox) l = l.parentElement;
		this.element = l;
	}
	
	this._getTextInput().readOnly = this.oncheckreadonly();
}

proto._img_onclick = function()
{
	CNUtil.dispatchObject().img_onclick();
}
proto.img_onclick = function()
{
	if(!this._searchable || this._disabled) return;
	this._doSubmit(true);	
}


proto._inputElement_onchange = function()
{
	CNUtil.dispatchObject().inputElement_onchange();
}
proto.inputElement_onchange = function()
{
	this._doSubmit(false, true);
}

// Searchable only method.
proto._doSubmit = function(force, doNotPost)
{
	if(this.oncheckreadonly()) return false;
	
	// Find element for grid combo.
	var l = CNUtil.eventTarget();
	while(l && !l._isComboBox) l = l.parentElement;

	this.element = l; 

	var text = this.getTextByIndex(this.element._selectedIndex);
	var box = this._getTextInput();
	var value = box.value;

	if(!force && text == value) return false;
	
	if(this.element._selectedIndex == -2 || this.element._selectedIndex == -1 || text != value)
	{
		this.element._value = value;
		this.element._selectedIndex = -2;
	}
	
	if(this.element._value && this.element._value.length >= this._minNumberOfChars)
	{
		if(force) this.element._isDirty = true;
		this._doSearch = force;

		this._hideValidationTooltip();

		if(!doNotPost)
		{
			this.fireChangedEvent();
			if(this.formManager) this.formManager.postData(this.element);
		}
		return true;
	}
	else
	{
		Tooltip.attach(this.element, "Please enter at least " + this._minNumberOfChars + " character" + 
			(this._minNumberOfChars == 1 ? "" : "s") + " to search upon");
		Tooltip.forceOnElement(this.element);
		return false;
	}
}

proto.set_tabIndex = function(ti, temporary)
{
	if(!temporary) this._tabIndex = ti;
	if(this._searchable) this._getTextInput().tabIndex = ti;
	else this.element.tabIndex = ti;
}


var vproto = CN_combobox.vistaThemeProto = CNUtil.cloneObject(proto);
vproto.createElementOnly = function(node, inGrid, assignElement)
{
	this._preinit(node, inGrid);

	var l = CN_combobox._template.cloneNode(true);
	l.id = "";
	
	var clickable;

	if(this._searchable)
	{
		var img = VistaSupport.createImageButton("searchable-icon.gif", 20, 20);
		img.className = "searchButtonIMG";
		l.insertBefore(img, l.lastChild);
		
		var input = Util.createElementFromHTML("<input type='text'>");
		input.className = "comboTextInput";
		l.lastChild.appendChild(input);
		Event.add(input, "focus", this, this._input_onfocus);
		Event.add(input, "focusout", this, this._input_ondeactivate);
		//Event.add(input, "mousedown", this, Util.cancelBubble);
		//Event.add(input, "dblclick", this, Util.cancelBubble);
		this._setTextInputEvents(input);
		
		Event.add(img, "click", this, this._img_onclick);

		clickable = l.lastChild; // Note: right button is hidden by text div, and we can't move button on top.
	}
	else
	{
		var div = document.createElement("div");
		div.className = "comboTextDiv"
		l.lastChild.appendChild(div)
		l.lastChild.className = "comboTextDiv comboTextContDiv";
		clickable = l;
	}
	
	if(assignElement) this.element = l;
	l._isComboBox = true;
	l.jsObject = this;
	if(!this._searchable && !this.doNotFocus) l.tabIndex = -1;
	
	var isNotArray = !(node instanceof Array) && !(node instanceof Object);
	if(isNotArray) this._setCommonOptions(node);

	Event.add(l, "mouseenter", this, this._element_onmouseenter);
	Event.add(l, "mouseleave", this, this._element_onmouseleave);
	Event.add(l, "keydown", this, this._element_onkeydown);
	
	Event.add(clickable, "mousedown", this, this._element_onmousedown);
	Event.add(clickable, "dblclick", this, this._element_onmousedown);

	return l;
}

vproto.hoverBox = function(l, imgSrc)
{
	var inner = l.children[0];
	l.className = "cn_combobox cn_combobox_hover";
	if(imgSrc) inner.firstChild.style.backgroundImage = "url(" + CNFormManager.themeImagesPath + imgSrc + ")";
	else inner.firstChild.style.backgroundImage = "";
}

vproto.unhoverBox = function(l)
{
	if(l.className == "cn_combobox") return;
	var inner = l.children[0];
	inner.firstChild.style.backgroundImage = "";	
	l.className = "cn_combobox";
}

vproto._input_onfocus = function()
{
	var js = CNUtil.dispatchObject();
	if(!js || js._disabled || js.popupOpened || js.oncheckreadonly()) return;
	js.hoverBox(js.element);
}

vproto._input_ondeactivate = function()
{
	var js = CNUtil.dispatchObject();
	if(!js || js._disabled || js.popupOpened || js.oncheckreadonly()
		|| js.element.contains(Event.current().relatedTarget)) return;
	js.unhoverBox(js.element, true);
}

vproto._pressBox = function()
{
	this.hoverBox(this.element, "press-drop-down.gif");
}

vproto._getTextElement = function()
{
	return this.element.lastChild;
}
vproto._getTextInput = function()
{
	return this.element.lastChild.lastChild;
}

vproto._set_selectedIndex = function(doNotFireEvent, force)
{
	if(this.element._selectedIndex === undefined && !force) return;
	
	var textElement = this.element.lastChild;

	if(!this.optionTags || this.optionTags.length == 0) 
	{
		if(this._searchable) textElement.firstChild.value = "";
		else textElement.textContent = "";
		return;
	}
	
	var ix = this.element._selectedIndex;
	var img = textElement.firstChild;
	
	var html = this.getHTMLByIndex(ix);
	if(html) 
	{
		if(this._searchable) textElement.children[0].value = html;
		else 
		{
			if(html == "") html = "&nbsp";
			textElement.innerHTML = html;
		}
	}
	else
	{
		var text = this.getTextByIndex(ix);
		if(!text) text = "";
		if(this._searchable) 
		{
			if(img && img._isComboImg) textElement.firstChild.nextSibling.value = text;
			else textElement.firstChild.value = text;
		}
		else textElement.textContent = text;
	}
	
	this.element._value = this.getValueByIndex(ix);
	
	var valueElement = this._searchable ? textElement.children[0] : textElement;
	//var valueElement = textElement;

	var tag = this.optionTags[ix];
	if(tag) 
	{
		var attr = tag.getAttribute("textColor");

		if(attr) valueElement._color = valueElement.style.color = String(attr);
		else 
		{
			valueElement.style.color = "";
			valueElement._color = null;
		}

		attr = tag.getAttribute("img");
		if(attr) 
		{
			if(!img || img.tagName != "IMG")
			{
				img = document.createElement("img");
				img.className = "inlineComboIMG";
				img._isComboImg = true;
				textElement.insertBefore(img, textElement.firstChild);
			}
			
			img.src = String(attr);
		}
		else 
		{			
			if(img && img._isComboImg) Util.removeElement(img);
		}
	}
	else
	{
		valueElement.style.color = "";
		if(img && img._isComboImg) Util.removeElement(img);
	}
	
	if(!doNotFireEvent) this.fireChangedEvent();
}
vproto.set_disabled = function(value)
{
	this._disabled = value;
	if(value)
	{
		this.set_tabIndex(-1, true);
		this.element.className = "cn_combobox cn_combobox_disabled";
		if(this._searchable) this._getTextInput().readOnly = true;
		else this.element.firstChild.style.backgroundColor = "#F4F4F4";
	}
	else
	{
		if(this._tabIndex) this.set_tabIndex(this._tabIndex);
		this.element.className = "cn_combobox";
		if(this._searchable) this._getTextInput().readOnly = false;
		else this.element.firstChild.style.backgroundColor = "";
	}
}

/*
	v. 2.0
*/	
function CN_label(){}
var proto = CN_label.prototype;

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);

	// Cross-reference.
	this.element = l;
	l.jsObject = this;

	var style = node.getAttribute("style");
	if(style) l.className = "cn_label_" + String(style);
	else l.className = "cn_label";
	
	var attr = node.getAttribute("size");
	if(attr != null && attr != "small")
	{
		if(attr == "medium") l.style.fontSize = "11.25pt";
		else if(attr == "large") l.style.fontSize = "14.25pt";
	}
	
	return l;
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("text");
	if(attr != null) this.element.textContent = String(attr);
	
	attr = node.getAttribute("textColor");
	if(attr != null) {
		this.element.style.color = String(attr);
		this._textColorSet = true;
	} else if(attr == "") {
		this._textColorSet = false;
	}	

	attr = node.getAttribute("tooltip");
	if(attr && attr != "") 
	{
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
	}
	else
	{
		Tooltip.detach(this.element);
	}
}

proto.set_disabled = function(val)
{
	// Ignore.
}

proto.layout = function() {
	// The dark-header class is a theme concern, not an IE-only
	// runtime-style operation.  Inline textColor still wins over the class.
	Util.setDarkHeaderControlClass(this.element, this.formManager);
}

// Keep the historical method name for callers that explicitly selected the
// black sub-theme, but make it standards-based as well.
proto._layoutForBlack = proto.layout;
/*
	v. 2.0.1
*/
function CN_imagebutton()
{
	this._disabled = false;
	this._srcE = "";
	this._srcD = "";
	this.validator = true;
	this.initiateUpload = false;
}
var proto = CN_imagebutton.plainThemeProto = {};
var vproto = CN_imagebutton.vistaThemeProto = Util.cloneObject(CN_button.vistaThemeProto);

CN_imagebutton.setTheme = function(themeName)
{
	if(CNFormManager.vista) this.prototype = this.vistaThemeProto;
	else this.prototype = this.plainThemeProto;
}

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("button");
	parentElement.appendChild(l);
	l.className = "cn_button";
	
	var img = document.createElement("img");
	l.appendChild(img);
	
	this._srcE = String(node.getAttribute("srcE"));
	this._srcD = String(node.getAttribute("srcD"));
	
	img.src = this._srcE;

	this.clicked = false;
	
	this.element = l;
	l.jsObject = this;

	img.className = "cn_imagebutton";

	Event.add(l, "click", this, _CN_button_onclick);
	Event.add(l, "mouseenter", this, _CN_button_onmouseenter);
	Event.add(l, "mouseleave", this, _CN_button_onmouseleave);
	Event.add(l, "keypress", this, CNUtil.cancelBubble);

	if(node.getAttribute("validator") == "false") this.validator = false;
	
	return l;
}

proto.doClick = CN_button.plainThemeProto.doClick;

proto.loadData = function(node)
{
	var attr = node.getAttribute("tooltip");
	if(attr != null) 
	{
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
		this._handleDisabledState();
	}

	attr = node.getAttribute("srcE");
	if(attr)
	{
		this._srcE = String(attr);
		if(!this._disabled) this.element.firstChild.src = this._srcE;
	}	

	attr = node.getAttribute("srcD");
	if(attr)
	{
		this._srcD = String(attr);
		if(this._disabled) this.element.firstChild.src = this._srcD;
	}
	
	this.initiateUpload = node.getAttribute("uploads") == "true";
}

proto.validateLoading = vproto.validateLoading = function()
{
	if(CNFormManager.vista) 
	{
		var textSpan = this._getTextElement();
		textSpan.style.paddingTop = Math.max(this.element.offsetHeight - textSpan.offsetHeight, 0) / 2 + 2;
	}	

	if(this.formManager.defaultButton == this
		&& this.formManager.changeFocus
		&& Util.getStyle(this.element, "visibility") != "hidden")
	{
		try
		{
			this.element.focus();
		}
		catch(ex)
		{
		}
	}
}

proto.storeData = vproto.storeData = function(xmldoc)
{
	// NOTE: button stores itself only if it's clicked.
	if(!this.clicked) return;
	this.clicked = false;

	var node = xmldoc.createElement("imagebutton");
	return node;
}

// Properties. ======================
proto.set_disabled = function(val)
{
	if(val == this._disabled) return;
	this._disabled = val;
	if(val) this.element.children[0].src = this._srcD;
	else this.element.children[0].src = this._srcE;
	this.element.disabled = val;
	
	this._handleDisabledState();
}
proto._handleDisabledState = CN_button.plainThemeProto._handleDisabledState;


vproto._button_createElement = vproto.createElement;
vproto.createElement = function(node, parentElement)
{
	var l = this._button_createElement(node, parentElement);
	this._srcE = String(node.getAttribute("srcE"));
	this._srcD = String(node.getAttribute("srcD"));
	this._setImageCore(this._srcE);
	return l;
}

vproto._button_set_disabled = vproto.set_disabled;
vproto.set_disabled = function(val)
{
	this._button_set_disabled(val);
	if(this._srcD) this._setImageCore(val ? this._srcD : this._srcE);
}
/*
	# 1081 - autoPostBack
	v. 2.0
	CURRENTLY only sync mode implemented
	one global uploadPostFrame
	every FM has _uploadFormIframe
	every uploadbox creates file input element in _uploadFormIframe
	_uploadFormIframe submitted when form posted, form data sent after _uploadFormIframe loads server response
	_uploadFormIframe destroyed when form controls are destroyed.
	
	LATER async mode can be added
	add per-FM uploadPostFrame
	add global progress bars showing uploading + warning if browser closed
*/
function CN_uploadbox()
{
	this._isDirty = false;
	this._isDirty_filePosted = false;
	this._disabled = false;
	
	this._button = null;
	this._input = null;
	this._autoPostBack = false;
	this._uploadOnSelection = false;

	this._checkBox = null;
	this._showOverwrite = false;	
	this._overwriteOnUpload = false;
	this._enabledOverwriteOnUpload = true;
	
}
CN_uploadbox._overwriteOnUpload = false;
CN_uploadbox._uploadPostFrame = null;
CN_uploadbox._uploadFormFrame = null;
CN_uploadbox._counter = 0;
CN_uploadbox._activeUploadBox = null;
CN_uploadbox._activeCallback = null;
CN_uploadbox.ensurePostIframeCreated = function()
{
	if(CN_uploadbox._uploadPostFrame == null)
	{
		// Theme independent permanent iframe.
		var iframe = CN_uploadbox._uploadPostFrame = (function(){ var el = document.createElement("iframe"); el.name = 'uploadPostFrame'; return el; })();
		iframe.className = "cn_uploadbox_hiddenIframe";
		document.body.appendChild(iframe);
	}
	return CN_uploadbox._uploadPostFrame;
}

// NOTE: Called by formmanager.
CN_uploadbox.handleUpload = function(fm, xmldata, callback)
{
	if(!fm._uploadFormIframe) 
	{
		fm[callback]();
		return;
	}
	
	CN_uploadbox._activeCallback = callback;
	
	var shouldUpload = false;
	var form = fm._uploadFormIframe.contentWindow.document.body.firstChild;
	var els = form.elements;
	for(var i = 0; i < els.length; i++)
	{
		if(els[i].value.length > 0) 
		{
			shouldUpload = true;
			break;
		}
	}
	
	if(!shouldUpload) 
	{
		fm[callback]();
		return;
	}

	var iframe = CN_uploadbox._uploadPostFrame;
	if(fm._uploadDebug)
	{
		iframe.style.width = "600px";
		iframe.style.height = "80px";
		iframe.style.display = "block";
	}
	else
	{
		iframe.style.display = "none";
	}
	
	form.action = fm._uploadURL;

	Event.nativeAdd(CN_uploadbox._uploadPostFrame, "load", CN_uploadbox._postIframe_onload);

	form.submit();
}
CN_uploadbox._postIframe_onload = function()
{
	Event.nativeDel(CN_uploadbox._uploadPostFrame, "load", CN_uploadbox._postIframe_onload);

	var fm = CNFormManager.getActiveFormManager();
	var form = fm._uploadFormIframe.contentWindow.document.body.firstChild;
	form.reset();

	var callback = CN_uploadbox._activeCallback;
	CN_uploadbox._activeCallback = null;
	fm[callback]();
}

// Called by formmanager on form clean up.
CN_uploadbox.deleteForm = function(fm)
{
	if(!fm._uploadFormIframe) return;
	fm._uploadFormIframe.remove();
	fm._uploadFormIframe = null;
}

var proto = CN_uploadbox.prototype;
proto.unload = function()
{
	CN_uploadbox._activeUploadBox = null;
	this._input = null; // Don't delete input as file post can be in process.
	CNFormManager.destroyJSObject(this._button);
	this._button = null;
}

proto._initializeForm = function()
{
	var iframe = this.formManager._uploadFormIframe;
	if(iframe == null)
	{
		CN_uploadbox.ensurePostIframeCreated();

		this.formManager._uploadBoxes = [];
		var iframe = this.formManager._uploadFormIframe = document.createElement('iframe');
		iframe.className = "cn_uploadbox_hiddenIframe";
		document.body.appendChild(iframe);

	}
	var win = iframe.contentWindow;
	var doc = win.document;	
	
	this.formManager._uploadBoxes.push(this);
	if(doc.body) 
	{
		CN_uploadbox._uploadFormIframe_onload();
	}
	else 
	{
		if(!win._eventAttached) 
		{
			win._eventAttached = true;
			Event.nativeAdd(win, "load", CN_uploadbox._uploadFormIframe_onload);
		}
	}
}
CN_uploadbox._uploadFormIframe_onload = function()
{
	var fm = CNFormManager.getActiveFormManager();
	var win = fm._uploadFormIframe.contentWindow;
	var doc = win.document;
	
	var form = doc.body.firstChild;
	if(!form)
	{
		form = (function(){ var el = doc.createElement("form"); el.method = 'post'; el.target = 'uploadPostFrame'; el.enctype = 'multipart/form-data'; return el; })();
		doc.body.appendChild(form);
	}

	for(var i = 0; i < fm._uploadBoxes.length; i++)
	{
		fm._uploadBoxes[i]._formCreatedCallback(form);
	}
	fm._uploadBoxes = [];

	Event.nativeDel(win, "load", CN_uploadbox._uploadFormIframe_onload);
}


proto.createElement = function(node, parentElement)
{
	var l = (function(){ var el = document.createElement("div"); el.className = 'cn_uploadbox'; return el; })();
	parentElement.appendChild(l);
	
	this.element = l;
	l.jsObject = this;
	
	this._autoPostBack = node.getAttribute("autoPostBack") == "true";
	this.initiateUpload = node.getAttribute("uploadOnSelection") == "true";
	if(this.initiateUpload) this._autoPostBack = true; // Force autopostback.
	this._showOverwrite = node.getAttribute("showOverwrite") == "true";
	CN_uploadbox._overwriteOnUpload = false; 
	
	this._buildContent();

	return l;
} 

proto._buildContent = function()
{
	var jso = this;
	this._initializeForm();

	this._box = document.createElement("input");
	this._box.type = "text";
	Event.add(this._box, "focus", this, this._box_onfocus);
	Event.add(this._box, "keydown", this, this._box_onkeydown);
	this.element.appendChild(this._box);

	if(CNFormManager.vista) VistaSupport.attachToTextBox(this._box);

	this._button = new CN_button();
	this._button.elementID = "button" + CN_uploadbox._counter++;
	var b = this._button.createElement(Util.wrapIntoNode({}), this.element);
	this._button.loadData(Util.wrapIntoNode({value: "Browse..."}));
	b.onclick = this._b_onclick;
	
	if(this._showOverwrite)
	{	
		var br = document.createElement("br");
		this.element.appendChild(br);

		this._checkBox = new CN_checkbox();
		this._checkBox.elementID = "chk" + CN_uploadbox._counter++;
		var c = this._checkBox.createElement(Util.wrapIntoNode({text: "Overwrite imported file"}), this.element);
		c.onclick = this._checkBox_onclick;		
		this.element.appendChild(c);
	}
}
proto._formCreatedCallback = function(form)
{
	this._input = (function(){ var el = form.ownerDocument.createElement("input"); el.type = 'file'; return el; })();
	Event.add(this._input, "change", this, this._input_onchange);
	this._input._cn_uploadbox_id = this.elementID;
	form.appendChild(this._input);
	
	this._input1 = form.ownerDocument.createElement("input");
	this._input1.type = "hidden";
	this._input1.name = "uniqueID";
	this._input1.value = CNFormManager.getBaseFormManager()._uniqueID;
	form.appendChild(this._input1);
	
	this._input2 = form.ownerDocument.createElement("input");
	this._input2.type = "hidden";
	this._input2.name = "overwrite";
	this._input2.value = CN_uploadbox._overwriteOnUpload;
	form.appendChild(this._input2);
}
proto.layout = function()
{
	if(Util.getStyle(this._button.element, "width") == "auto") return;
	var realW = this.element.offsetWidth == 0 ? parseInt(Util.getStyle(this.element, "width"), 10) : this.element.offsetWidth;
	var bW = parseInt(Util.getStyle(this._button.element, "width"), 10)
	var w = realW - bW - 6;
	this._box.style.width = Math.max(10, w) + "px";
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("tooltip");
	if(attr) 
	{
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
	}

	this._isDirty = false;
	this._isDirty_filePosted = false;
	
	attr = node.getAttribute("textColor");
	if(attr !== null) 
	{
		this._box.style.color = String(attr);
	}
	
	attr = node.getAttribute("overwriteOnUpload");
	if(attr) 
	{
		this._overwriteOnUpload = attr == "true";
		CN_uploadbox._overwriteOnUpload = this._overwriteOnUpload;		
		this._checkBox.set_checked(attr == "true");
	}
	else
	{
		if (this._showOverwrite)
			this._checkBox.set_checked(false);
	}
	
	attr = node.getAttribute("enabledOverwriteOnUpload");
	if(attr) 
	{
		this._enabledOverwriteOnUpload = attr == "true";
		this._checkBox.set_disabled(!this._enabledOverwriteOnUpload);
	}
	else
	{
		if (this._showOverwrite)	
			this._checkBox.set_disabled(false);
	}
}

proto.validateLoading = function()
{
	if(this._img) 
	{
		this._img.style.display = "none";
		this._box.style.visibility = "inherit";
	}
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty || !this._input.value) return;

	var node = xmldoc.createElement("uploadbox");
	node.setAttribute("localPath", this._input.value);
	node.setAttribute("uniqueID",  CNFormManager.getBaseFormManager()._uniqueID);	
	node.setAttribute("overwrite", CN_uploadbox._overwriteOnUpload);	

	if(!this.formManager.initiateUpload)
	{
		if(!this._autoPostBack || !this._isDirty_filePosted) return; // Do not send anything if not autopostback or filePosted flag already sent.
		
		// Postback just with filepath, but no file is sent.
		// Control is still dirty.
		node.setAttribute("filePosted", "false");
		this._isDirty_filePosted = false;
		return node;
	}
	
	this._isDirty = false;	
	this._input.name = this.elementID;	
	
	if(!this._img)
	{
		this._img = document.createElement("img");
		this._img.className = "progressIMG";
		this._img.style.width = this._box.offsetWidth + "px";
		this._img.style.height = "16px";
		this._img.src = "g/und-progress-bar-1.gif";
		this.element.appendChild(this._img);
	}
	else this._img.style.display = "block";
		
	this._box.style.visibility = "hidden";
	this._box.value = "";	
	
	return node;
}

proto.set_disabled = function(val)
{
	this._disabled = this._box.disabled = val;
	this._button.set_disabled(val);

	if(CNFormManager.vista)	this.element.className = val ? "cn_uploadbox cn_uploadbox_disabled" : "cn_uploadbox";
	else this._box.style.backgroundColor = val ? Util.getStyle(this.element, "xl--disabled-background") : ""
}

proto._b_onclick = function(ev)
{
	var jso = Util.findByClassName(Util.eventTarget(ev), "cn_uploadbox").jsObject;
	if(jso._disabled) return;
	CN_uploadbox._activeUploadBox = jso;
	jso._input.click();
}

proto._checkBox_onclick = function(ev)
{
	var jso = Util.findByClassName(Util.eventTarget(ev), "cn_uploadbox").jsObject;
	if(jso._disabled) return;
	CN_uploadbox._activeUploadBox = jso;
	CN_uploadbox._overwriteOnUpload = jso._checkBox.get_checked();
}

proto._input_onchange = function(ev)
{
	var jso = this;
	CN_uploadbox._activeUploadBox = null;
	jso._isDirty = true;
	jso._isDirty_filePosted = true;
	jso._box.value = jso._input.value;
	jso._input1.value = CNFormManager.getBaseFormManager()._uniqueID;
	jso._input2.value = CN_uploadbox._overwriteOnUpload;
	
	if(jso._autoPostBack) jso.formManager.postData(jso.element);
}

proto._box_onfocus = function(ev)
{
	Util.eventTarget(ev).select();
}

proto._box_onkeydown = function(ev)
{
	var jso = Util.dispatchObject();
	if(Event.keyValue(ev) == 8 || Event.keyValue(ev) == 46)
	{
		jso._box.value = "";
		var newInput = jso._input.cloneNode(true);
		jso._input.parentNode.replaceChild(newInput, jso._input);
		jso._input = newInput;
		Event.add(newInput, "change", jso, jso._input_onchange);
	}
	Util.cancelEvent(ev);
}

/*
	v. 2.0.2
*/
function CN_textbox()
{
	this._isDirty = false;
	this._disabled = false;
	this._maxLength = -1;
	this._tabIndex = -1;
	this._tooltip = null;
	this._casing = null;

	this.supportsRequired = true;
	this._canBeEmpty = true;
}
var proto = CN_textbox.prototype;

proto.createElement = function(node, parentElement)
{
	var l;
	var multiLine = false;
	
	if(node.getAttribute("multiLine") == "true") 
	{
		l = document.createElement("textarea");
		Event.add(l, "keypress", this, Util.cancelBubble);
		multiLine = true;
	}
	else l = (function() { var el = document.createElement("input"); el.type = 'text'; return el; })();
	
	var attr = node.getAttribute("maxLength");
	if(attr) 
	{
		if(multiLine)
		{
			this._maxLength = parseInt(attr, 10);
			Event.add(l, "paste", this, this._element_onpaste);
		}
		else
		{
			l.maxLength = parseInt(attr, 10);
		}
	}

	Event.add(l, "keypress", this, this._element_onkeypress);
	Event.add(l, "select", this, this._element_onselect);

	if(node.getAttribute("hasBorder") == "false") { 
		l.style.borderWidth = 0;
		l.style.background = "transparent";
	}
	else if(CNFormManager.vista)
	{
		VistaSupport.attachToTextBox(l);
	}
	
	if(node.getAttribute("password") == "true") l.type = "password";
	
	var attr = node.getAttribute("casing");
	
	if(attr)
	{
		this._casing = String(attr);
		if(attr == "upper") l.style.textTransform = "uppercase";
		else if(attr == "lower") l.style.textTransform = "lowercase";
	}

	parentElement.appendChild(l);
	
	attr = node.getAttribute("validationString");
	if(attr) this.validationString = String(attr);

	attr = node.getAttribute("align");
	if(attr) l.style.textAlign = String(attr);

	this.element = l;
	l.jsObject = this;

	l.className = "cn_textbox";
	Event.add(l, "change", this, this._input_onchange);
	
	attr = node.getAttribute("canBeEmpty");
	if(attr) this._canBeEmpty = attr == "true";

	attr = node.getAttribute("mask");
	if(attr) this._setMask(String(attr));
	
	return l;
} 

/*
 * # => \w
 * 9 => \d
 * . => \.
 */
proto._setMask = function(mask) {
	this._maskRE = new RegExp('^' + mask.replace(/#/g, '[a-z]').replace(/9/g, '\\d').replace(/\./g, '\\.') + '$', "i");	

	Event.add(this.element, "focusout", this, this._box_onfocusout);
	Event.add(this.element, "focusin", this, this._box_onactivate);	
}

proto.isValid = function() {
	var value = this.element.value;
	if(this._disabled || !this._maskRE || value.replace(/\s+/, "") == "" && this._canBeEmpty) return true;

	var valid = this._maskRE.test(value);

	if(!valid) this.element.style.borderColor = "red";

	return valid;
}

proto._input_onchange = function()
{
	Util.eventTarget().jsObject._isDirty = true;
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("tooltip");
	if(attr) 
	{
		this._tooltip = String(attr);
		
		//loadData() is called after set_disabled()
		//If control is not disabled (Edit mode) do not attach tooltip
		if(this._disabled)
		{
			if(!this.element.tipText) {
				Tooltip.attach(this.element, String(attr));
			}
			else {
				this.element.tipText = String(attr);
			}
		}
	}
	//Framework send attr first time only and when attr change
	//If attr not being sent but thete is an tooltip, if control is disabled(View mode) then set tooltip back
	else
	{
		if (this._disabled)
		{
			if(this._tooltip)
			{
				Tooltip.attach(this.element, this._tooltip);
			}
		}
	}
	
	var attr = node.getAttribute("value");
	if(attr != null) this.element.value = String(attr);
	this._isDirty = false;
	
	attr = node.getAttribute("textColor");
	if(attr !== null) this.element.style.color = String(attr);
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty || !this.isValid()) return null;
	
	var hasSelection = document.activeElement == this.element;
	var selectedText = hasSelection ? this.element.value.slice(this.element.selectionStart, this.element.selectionEnd) : "";

	if(!this.element.id) 
	{
		this.element.style.background = "red";
		alert("No id for textbox.");
		return;
	}

	this._isDirty = false;

	var node = xmldoc.createElement("textbox");
	var value = this.element.value;
	if(this._casing)
	{
		if(this._casing == "lower") value = value.toLowerCase();
		else if(this._casing == "upper") value = value.toUpperCase();
	}
	node.textContent = value;
	if(selectedText.length > 0) node.setAttribute("selectedText", selectedText);
	
	return node;
}

proto.set_tabIndex = function(ti)
{
	this._tabIndex = ti;
	this.element.tabIndex = ti;
}

proto.set_disabled = function(val)
{
	if(val)	this.element.tabIndex = -1;
	else if(this._tabIndex) this.element.tabIndex = this._tabIndex;
	//Remove tooltip if control not disabled(Edit mode)
	if(!val) Tooltip.detach(this.element);		
	this._disabled = val;
	CNFormManager._trace("set_disabled : " + val);
	this.element.readOnly = val;
	if(CNFormManager.vista) this.element.className = val ? "cn_textbox cn_textbox_disabled" : "cn_textbox";
	else this.element.style.backgroundColor = val ? Util.getStyle(this.element, "xl--disabled-background") : ""
}

proto._element_onkeypress = function()
{
	CNUtil.dispatchObject().element_onkeypress();
}
proto.element_onkeypress = function()
{
	if(this._disabled) return;
	this._isDirty = true;
	if(this._maxLength > 0 && this.element.value.length - (this.element.selectionEnd - this.element.selectionStart) >= this._maxLength)
	{
		CNUtil.cancelEvent();
	}
}

proto._element_onpaste = function()
{
	CNUtil.dispatchObject().element_onpaste();
}
proto.element_onpaste = function()
{
	var ev = Event.current();
	var text = ev.clipboardData && ev.clipboardData.getData("text");
	if(text == null) return;
	this._isDirty = true;
	var box = this.element;
	var start = box.selectionStart;
	var end = box.selectionEnd;
	var available = this._maxLength - (box.value.length - (end - start));
	if(text.length > available)
	{
		CNUtil.cancelEvent(ev);
		box.setRangeText(text.substr(0, Math.max(0, available)), start, end, "end");
		this._isDirty = true;
	}
}

proto._element_onselect = function()
{
	var jso = CNUtil.dispatchObject();
	if(jso._disabled) return;
	jso._isDirty = true;
}

proto._box_onfocusout = function()
{
	var jsObject = Util.eventTarget().jsObject;
	jsObject.isValid();
}

proto._box_onactivate = function()
{
	Util.eventTarget().style.borderColor = "";
}

/*
	#1042 - _validateLength
	v. 2.0.1
*/
function CN_intbox()
{
	this.formManager = null;
	this.validationString = null;
	
	this.maxLength = 9;
	this._canBeEmpty = true;
	this._precision = 10;
	this._scale = 2;
	this._allowSign = false;

	this.isReady = false;

	this.validCharsRegex = null;
	this.regex = null;

	this._isDirty = false;
	this.doNotShowErrorMessage = true;
	this._autoPostBack = false;
	this._disabled = false;	
	this._readOnly = false;
	this._tagName = "intbox";

	this.supportsRequired = true;
}
var proto = CN_intbox.prototype;

// Events. ================================
proto.onchange = function(ev)
{
	if(this._autoPostBack) this.formManager.postData(this.element);
}

// ICNControl. =============================
proto.isValid = function()
{
	if(this._disabled) return true;
	var value = this.element.value;
	var valid = value.match(/^([-+])?\d+$/) != null || (value.replace(/\s+/, "") == "" && this._canBeEmpty);
	if(valid) valid = value.length <= this.maxLength || value.length == this.maxLength + 1 && value.match(/^[+-]/);
	if(!valid) this.element.style.borderColor = "red";
	return valid;
}

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("input");
	l.type = 'text';
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;

	l.className = "cn_textbox";

	var attr = node.getAttribute("maxLength");
	if(attr) this.maxLength = parseInt(attr, 10);

	var attr = node.getAttribute("allowSign");
	if(attr && attr == "true") this._allowSign = true;

	attr = node.getAttribute("canBeEmpty");
	if(attr) this._canBeEmpty = attr == "true";

	attr = node.getAttribute("validationString");
	if(attr) 
	{
		this.validationString = String(attr);
		this.doNotShowErrorMessage = false;
	}
	
	attr = node.getAttribute("autoPostBack");
	if(attr) this._autoPostBack = attr == "true";

	this.validCharsRegex = this._allowSign ? /[0-9+\-]/ : /[0-9]/;
	this.regex = this._allowSign ? /^(\+|\-)?\d+$/ : /^\d+$/;

	this.buildElement();

	this.isReady = true;
	
	return l;
}

proto.buildElement = function()
{
	var box = this.element;
//	if(this.maxLength > 0) box.maxLength = this.maxLength;
	Event.add(box, "keypress", this, this._box_onkeypress);
	Event.add(box, "paste", this, this._box_onpaste);
	Event.add(box, "change", this, this._box_onchange);	
	Event.add(box, "focusout", this, this._box_onfocusout);
	Event.add(box, "focusin", this, this._box_onactivate);	
	
	if(CNFormManager.vista) VistaSupport.attachToTextBox(box);
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("tooltip");
	if(attr) 
	{
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
	}

	var attr = node.getAttribute("value");
	if(attr != null) this.element.value = String(attr);

	attr = node.getAttribute("readOnly");
	if(attr) 
	{
		this._readOnly = attr == "true";
		this._set_disabled();		
	}

	attr = node.getAttribute("textColor");
	if(attr !== null) this.element.style.color = String(attr);

	this._isDirty = false;
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty || !this.isValid()) return null;
	this._isDirty = false;

	var node = xmldoc.createElement(this._tagName);
	node.setAttribute("value", this.element.value.replace('+', ''));
	return node;
}


proto.fireChangedEvent = function()
{
	var ev = {target: this.element};
	if(this.onchange) this.onchange(ev);
}


proto.set_tabIndex = function(ti)
{
	this._tabIndex = ti;
	this._set_tabIndex(ti);
}
proto._set_tabIndex = function(ti)
{
	this.element.tabIndex = ti;
}

proto.set_disabled = function(val)
{
	if(val) this._set_tabIndex(-1);
	else if(this._tabIndex) this._set_tabIndex(this._tabIndex);
	this._disabled = val
	this._set_disabled();
}
proto._set_disabled = function()
{
	var disable = this.element.readOnly = this._disabled || this._readOnly;
	if(CNFormManager.vista) this.element.className = disable ? "cn_textbox cn_textbox_disabled" : "cn_textbox";
	else this.element.style.backgroundColor =  disable ? Util.getStyle(this.element, "xl--disabled-background") : "";
}

// Event handlers. ========================
proto._box_onkeypress = function() {
	var code = (Event.keyValue(Event.current()));
	if(code == 0) return;
	var jsObject = Util.eventTarget().jsObject;
	if(code == 13)
	{
		if(this._autoPostBack) {
			Util.cancelEvent();
			jsObject.fireChangedEvent();
		}
		return;
	}
	if(Event.current().ctrlKey || Event.current().metaKey || Event.current().altKey) return;
	var charx = Event.current().key && Event.current().key.length == 1 ? Event.current().key : String.fromCharCode(code);
	var validChar = charx.match(jsObject.validCharsRegex) != null;
	if(!validChar || !jsObject._validateLength(charx)) Util.cancelEvent(Event.current());
}
proto._validateLength = function(typedChar) { // #1042 - refactor length validation.
	var maxLength = this.maxLength;
	if(this._allowSign && this.element.value.length == this.maxLength) {
		if(this.element.value.match(/[+-]/) == null) return typedChar.match(/[+-]/) != null;	
		else return typedChar.match(/\d/) != null;	// Allow only digits if sign exists.
	}
	else if(this.element.value.length >= this.maxLength) return false;

	return true;
}

proto._box_onchange = function()
{
	var jsObject = Util.eventTarget().jsObject;
	jsObject.fireChangedEvent();	
	jsObject._isDirty = true;
}

proto._box_onfocusout = function()
{
	var jsObject = Util.eventTarget().jsObject;
	jsObject.isValid();
}

proto._box_onactivate = function()
{
	Util.eventTarget().style.borderColor = "";
}

proto._box_onpaste = function() {
	var ev = Event.current();
	var box = Util.eventTarget(ev);
	var jso = box.jsObject;
	var text = ev.clipboardData && ev.clipboardData.getData("text");
	if(text == null) return;
	Util.cancelEvent(ev);
	var start = box.selectionStart;
	var end = box.selectionEnd;
	var available = jso.maxLength - (box.value.length - (end - start));
	var buf = [];
	for(var i = 0; i < text.length && buf.length < available; i++) {
		var ch = text.charAt(i);
		if(ch.match(jso.validCharsRegex) != null) buf.push(ch);
	}
	box.setRangeText(buf.join(""), start, end, "end");
	if(buf.length) jso._isDirty = true;
}

/*
	v. 2.0
	#1042 - _validateLength
	NOTE: derives from intbox.
*/
function CN_decimalbox()
{
	this.formManager = null;
	this.validationString = "Invalid Decimal";
	
	this.maxLength = 0;
	this._canBeEmpty = true;
	this._precision = 10;
	this._scale = 2;
	this._allowSign = false;

	this.isReady = false;

	this.validCharsRegex = null;
	this.regex = null;

	this._isDirty = false;
	this.doNotShowErrorMessage = true;
	this._autoPostBack = false;
	this._disabled = false;	
	this._readOnly = false;
	this._tagName = "decimalbox";
	
	this.supportsRequired = true;
}
var proto = CN_decimalbox.prototype = CNUtil.cloneObject(CN_intbox.prototype);

// ICNControl. =============================
proto.isValid = function()
{
	if(this._disabled) return true;
	var value = this.element.value;
	if(value.replace(/\s+/, "") == "" && this._canBeEmpty) return true;
	var valid = value.match(this.regex) != null;
	if(!valid) this.element.style.borderColor = "red";
	return valid;
}

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("input");
	l.type = 'text';
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;

	l.className = "cn_textbox";

	var attr = node.getAttribute("maxLength");
	if(attr) this.maxLength = parseInt(attr, 10);

	var attr = node.getAttribute("allowSign");
	if(attr && attr == "true") this._allowSign = true;

	attr = node.getAttribute("precision");
	if(attr) this._precision = parseInt(attr, 10);
	
	attr = node.getAttribute("scale");
	if(attr) this._scale = parseInt(attr, 10);
	
	attr = node.getAttribute("canBeEmpty");
	if(attr) this._canBeEmpty = attr == "true";

	attr = node.getAttribute("validationString");
	if(attr) 
	{
		this.validationString = String(attr);
		this.doNotShowErrorMessage = false;
	}

	attr = node.getAttribute("autoPostBack");
	if(attr) this._autoPostBack = attr == "true";

	this.validCharsRegex = this._allowSign ? /[0-9+\-.]/ : /[0-9.]/;	
	
	var decDigits = this._precision - this._scale;
	var plusMinus = this._allowSign ? "(\\+|\\-)?" : "";
	var str = "^" + plusMinus + "(\\d{1," + decDigits + "}(\\.|\\,)\\d{1," + this._scale + "}|"
							// .00
							+ "(\\.|\\,)\\d{1," + this._scale + "}|"
							// 00
							+ "\\d{1," + decDigits + "})$";
	this.regex = new RegExp(str);

	this.buildElement();

	this.isReady = true;
	
	return l;
}
proto._validateLength = function(typedChar) { // #1042 - disable int box max length behavior in decimal.
	return true; // Rely on box.maxLength.
}

/*
	v. 0.38
	+ ...
	- nonInteractive.
	+ focus/space key support.
	+ theme support.
	v. 0.21
	+ autoPostBack.
*/
var CN_checkbox = function()
{
	this.formManager = null;
	this.isReady = false;

	this._disabled = false;
	this._checked = null;
	this._isDirty = false;
	this._autoPostBack = false;
}
var proto = CN_checkbox.prototype;

// Events. =================
proto.onchange = function()
{
	if(this._autoPostBack) this.formManager.postData(this.element);
}


// Main stuff. ==================
proto.createElement = function(node, parentElement)
{
	var l = document.createElement("span");
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;

	l.className = "cn_checkbox";

	Event.add(l, "mouseenter", this, this._element_onmouseenter);
	Event.add(l, "mouseleave", this, this._element_onmouseleave);
	Event.add(l, "mousedown", this, this._element_onmousedown);
	Event.add(l, "dblclick", this, this._element_onmousedown);
	Event.add(l, "keydown", this, this._element_onkeydown);

	this.buildElement(node);  
	this.isReady = true;
	
	this._set_checked();
	
	return l;
}

proto.layout = function()
{
	Util.setDarkHeaderControlClass(this.element, this.formManager);
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("checked");
	if(attr) this.set_checked(attr == "true");

	attr = node.getAttribute("tooltip");
	if(attr) 
	{
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
	}

	this._isDirty = false;
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty) return null;
	this._isDirty = false;
	
	var node = xmldoc.createElement("checkbox");
	node.setAttribute("checked", String(this._checked));
	return node;
}

proto.buildElement = function(node)
{
	var checkElement = document.createElement("img");
	checkElement.width = 13;
	checkElement.height = 13;
	checkElement.align = 'absmiddle';
	this.element.appendChild(checkElement);
	checkElement.style.userSelect = "none";

	var textAttr = node.getAttribute("text");
	if(textAttr)
	{
		var textElement = document.createElement("span");
		textElement.className = 'textSpan';
		textElement.style.userSelect = "none";
		textElement.innerHTML = String(textAttr);
		this.element.appendChild(textElement);
	}
	
	if(node.getAttribute("bold") != "false") this.element.style.fontWeight = "bold";	
	
	var attr = node.getAttribute("autoPostBack");
	if(attr) this._autoPostBack = attr == "true";
}

// Event handlers. ======================
proto._element_onkeydown = function()
{
	CNUtil.dispatchObject().element_onkeydown();
}
proto.element_onkeydown = function()
{
	if(this._disabled) return;
	if((Event.keyValue(Event.current())) == 32)
	{
		this.set_checked(!this.get_checked(), false);
		this.fireChangedEvent();
		this._isDirty = true;
		Util.cancelEvent(Event.current());
	}
}

proto._element_onmouseenter = function()
{
	var jsObject = CNUtil.dispatchObject();
	if(jsObject._disabled) return;
	var l = jsObject.element;
	if(Event.current().relatedTarget && Event.current().relatedTarget.isConnected === false) return; // Filter deleted vista trans images.
	jsObject._set_checked(true, true);
}
proto._element_onmouseleave = function()
{
	var jsObject = CNUtil.dispatchObject();
	if(jsObject._disabled) return;
	var l = jsObject.element;
	jsObject._set_checked(false, true);
}
proto._element_onmousedown = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	if(jsObject._disabled) return;
	
	jsObject.element.focus();

	jsObject.set_checked(!jsObject.get_checked(), true, true);
	jsObject.fireChangedEvent();
	jsObject._isDirty = true;
}
proto.fireChangedEvent = function()
{
	var ev = {};
	ev.checked = this._checked;
	this.onchange();
}


// Properties. =========================
proto.set_disabled = function(val)
{
	this._disabled = Util.parseBoolean(val);
	if(this.isReady) this._set_disabled();
}
proto._set_disabled = function()
{ 
	this._set_checked();
	if(this._disabled) this._set_tabIndex(-1);
	else if(this._tabIndex) this._set_tabIndex(this._tabIndex);
}

proto.set_tabIndex = function(ti)
{
	this._tabIndex = ti;
	this._set_tabIndex(ti);
}

proto._set_tabIndex = function(ti)
{
	this.element.tabIndex = ti;
}

proto.set_checked = function(val, hover, userAction)
{
	val = Util.parseBoolean(val);
	if(this._checked == val) return;
	this._checked = val;
	if(this.isReady) this._set_checked(hover, userAction, true);
}
proto._set_checked = function(hover, userAction, checkedChanged)
{
	var img;
	if(this._disabled)
		img = this._checked ? "checkedDisabledCheckbox.gif" : "uncheckedDisabledCheckbox.gif";
	else if(hover)
		img = this._checked ? "checkedHoverCheckbox.gif" : "uncheckedHoverCheckbox.gif";
	else
		img = this._checked ? "checkedCheckbox.gif" : "uncheckedCheckbox.gif";

	//CNFormManager._trace("debug", "setChecked hover: " + hover + " checked: " + this._checked);
	if((userAction || hover) && CNFormManager.vista) 
	{
		VistaSupport.imageTrans(this.element.children[0], CNFormManager.themeImagesPath + img, checkedChanged);
	}
	else this.element.children[0].src = CNFormManager.themeImagesPath + img;
}
proto.get_checked = function()
{
	return this._checked;
}

/*
	v. 2.0.2
	+ calendar closed on set_disabled(true)
	+ calendar onxlresult + datebox ref is nulled on xlresult.
*/
function CN_datebox()
{
	this._dateValidationString = "Invalid Date";
	
	this._dayValidationString = "Invalid Day";
	this._monthValidationString = "Invalid Month";
	this._yearValidationString = "Invalid Year";
	
	this._timeValidationString = "Invalid Time";
	this.validationString = this._dateValidationString;
	this.supportsRequired = true;
	
	this._isDirty = false;
	this._textBox = null;	
	
	this._dateBox = null;
	this._timeCell = null;
	this._dayBox = null;
	this._monthBox = null;
	this._yearBox = null;
	
	this._canBeEmpty = false;
	this.isBuilt = false;
	this._autoPostBack = false;	
	this._doTime = false;
	this._focusInside = false; // Focus moves from date to time box.
	this._lastValidValue = "";
	this._lastValidTime = "";
	this.supportsRequired = true;
	this._minValue = null;
	this._maxValue = null;
	
	this.directlyAssignEvents = true;
}
var proto = CN_datebox.prototype;

// Events. ================================
proto.onchange = function(ev)
{
	if(this._autoPostBack && this.isValid())
	{
		//CNUtil.cancelEvent(); - 04.11.05 commented as no way to tab out from control on change/postback.
		this.formManager.postData(this.element);
	}
	
	
	if(Event.keyValue(Event.current()) != 9) return;
	var jso = CNUtil.dispatchObject();
	CNUtil.cancelEvent();
//	CNFormManager._trace("jso._timeBox.select();");
	jso._timeBox.select();
}

proto.createElement = function(node, parentElement)
{
	var l = Util.createElementFromHTML("<table cellpadding=0 cellspacing=0>");
	if(parentElement) parentElement.appendChild(l);
	
	this.element = l;
	l.jsObject = this;
	
	l.className = "cn_datebox";

	this._doTime = node.getAttribute("time") == "true";

	var tr = l.insertRow();
	
	this._dateBox = tr.insertCell();
	this._dateBox.className = "dateBox";
	
	//this._dateBox = this._dateBox;
	
	if(this._doTime) this._timeCell = tr.insertCell();
	var td2 = tr.insertCell();	
	
	this._textBox = Util.createElementFromHTML("<input type=text>");	
	this._textBox.style.verticalAlign = "middle";
	this._textBox.maxLength = this._doTime ? 16 : 10;	
	//this._dateBox.appendChild(this._textBox);
	
	//Day	
	this._dayBox = Util.createElementFromHTML("<input type=text maxlength=2 style='width: 15px; padding-left: 1px; '>");
	this._dateBox.appendChild(this._dayBox);
	this._dateBox.appendChild(document.createTextNode("/"));
	
	//Month
	this._monthBox = Util.createElementFromHTML("<input type=text maxlength=2 style='width: 14px; '>");
	this._dateBox.appendChild(this._monthBox);
	this._dateBox.appendChild(document.createTextNode("/"));
	
	//Year
	this._yearBox = Util.createElementFromHTML("<input type=text maxlength=4 style='width: 28px; '>");
	this._dateBox.appendChild(this._yearBox);
		
	//this._dayBox._maxValue = 31;
	//this._monthBox._maxValue = 12;	
	
	
		
	var attr = node.getAttribute("autoPostBack");
	if(attr) this._autoPostBack = attr == "true";

	if(this._doTime)
	{		
		//Show border right on date TD
		//this._dateBox.style.borderRight = "1px";	
		//this._dateBox.style.borderRightStyle = "solid"
		
		Event.add(this._textBox, "keydown", this, this._textBox_onkeypress);
		
		//this._timeCell.style.width = "38px";
		
		var timeNode = node.cloneNode(true);
		timeNode.setAttribute("autoPostBack", this._autoPostBack ? "true" : "false");
		
		this._doTime = true;
		this._timeBox = new CN_timebox();
		this._timeBox._dateBox = this;
		this._timeBox._isValid = this._timeBox.isValid;
		this._timeBox.isValid = this._timeBox_isValid;
		
		this._timeBox.__input_onactivate = this._timeBox._input_onactivate;
		this._timeBox._input_onactivate = this._timeBox_input_onactivate;

		this._timeBox.createElement(timeNode, this._timeCell);
		this._timeBox.element.style.width = "100%";
		this._timeBox.element.style.height = this._textBox.offsetHeight + "px";
		
		//this._textBox.style.borderRight = "0px";				
		
		this._timeBox.element.style.borderColor = "#ffffff"
		this._timeBox.element.style.paddingTop = "1px";
		
		this._timeBox.onchange = this._timeBox_onchange;
		
//		Event.add(this.element, "blur", this, this._element_ondeactivate);
	}

	Event.add(this.element, "blur", this, this._element_ondeactivate);
	Event.add(this.element, "focusout", this, this._element_onfocusout);
	
	var button;
	
	if(CNFormManager.vista)
	{
		button = VistaSupport.createImageButton("datebox-button.gif", 21, 21);
		button.style.verticalAlign = "middle";
		VistaSupport.attachToTextBox(this._textBox);
	}
	else
	{
		button = Util.createElementFromHTML("<button>");
		var img = Util.createElementFromHTML("<img>");
		img.src = CNFormManager.themeImagesPath + "calendar-2.gif";
		button.appendChild(img);
	}
	button.tabIndex = -1;	

	td2.className = "buttonTD";
	td2.appendChild(button);
	//button.tabIndex = -1;
	this._button = button;
	
	Event.add(button, "mouseenter", this, _CN_button_onmouseenter);
	Event.add(button, "mouseleave", this, _CN_button_onmouseleave);
	Event.add(button, "click", this, this._button_onclick);

	Event.add(this._textBox, "change", this, this._textbox_onchange);
	Event.add(this._textBox, "focusout", this, this._textbox_onfocusout);
	Event.add(this._textBox, "focus", this, this._textbox_onactivate);
	
	
	Event.add(this._dayBox, "keydown", this, this._box_onkeyup);
	Event.add(this._monthBox, "keydown", this, this._box_onkeyup);
	Event.add(this._yearBox, "keydown", this, this._box_onkeyup);	
	
	Event.add(this._dayBox, "keyup", this, this._box_onkeyup);
	Event.add(this._monthBox, "keyup", this, this._box_onkeyup);
	Event.add(this._yearBox, "keyup", this, this._box_onkeyup);
	
	Event.add(this._dayBox, "change", this, this._textbox_onchange);
	Event.add(this._dayBox, "focusout", this, this._textbox_onfocusout);
	Event.add(this._dayBox, "focus", this, this._textbox_onactivate);
	Event.add(this._dayBox, "focus", this, this._box_onfocus);
	
	Event.add(this._monthBox, "change", this, this._textbox_onchange);
	Event.add(this._monthBox, "focusout", this, this._textbox_onfocusout);
	Event.add(this._monthBox, "focus", this, this._textbox_onactivate);
	Event.add(this._monthBox, "focus", this, this._box_onfocus);
	
	Event.add(this._yearBox, "change", this, this._textbox_onchange);
	Event.add(this._yearBox, "focusout", this, this._textbox_onfocusout);
	Event.add(this._yearBox, "focus", this, this._textbox_onactivate);
	Event.add(this._yearBox, "focus", this, this._box_onfocus);
	
	var attr = node.getAttribute("canBeEmpty");
	if(attr == "true") this._canBeEmpty = true;
	
	attr = node.getAttribute("validationString");
	if(attr) this._dateValidationString = this._timeValidationString = this.validationString = String(attr);

	Event.add(l, "keypress", this, this._element_onkeypress);

	this.isBuilt = true;
	
	return l;
} 

proto._element_onkeypress = function()
{
	var jso = Util.dispatchObject();
	if(jso._disabled) return;
	var code = Event.keyValue(Event.current());
	var charx = String.fromCharCode(code).toLowerCase();
	if(charx == "t")
	{
		var now = new Date();
			
		jso._dayBox.value = jso._zeroPad(now.getDate());
		jso._monthBox.value = jso._zeroPad(now.getMonth() + 1);
		jso._yearBox.value = now.getYear();
			
		jso._isDirty = true;
		Util.cancelEvent();

		if(!this._doTime) 
			jso._fireChangedEvent();
		else
			jso._timeBox.select();		
	}
	if(charx == "d")
	{
		jso._dayBox.value = "";
		jso._monthBox.value = "";
		jso._yearBox.value = "";
			
		jso._isDirty = true;
		Util.cancelEvent();

		if(!this._doTime) 
			jso._fireChangedEvent();
		else
			jso._timeBox.select();		
	}
	else
	{
		if((charx < "0" || charx > "9") && code != 13)
		{
			CNUtil.cancelEvent();
			return;
		}	
	}
}

// Private methods. =================================
proto._tryNextField = function(box)
{
	if(box.value.length == box.maxLength && box.selectionStart == box.selectionEnd && box.selectionEnd == box.value.length)
	{
		this._moveToNextField(box);
	} 
}

proto._moveToNextField = function(box)
{
	var boxes = this.element.getElementsByTagName("input");
	if(box == boxes[0]) boxes[1].focus();
	else if(box == boxes[1]) boxes[2].focus();
}

proto._moveToPreviousField = function(box)
{
	var boxes = this.element.getElementsByTagName("input");
	if(box == boxes[2]) boxes[1].focus();
	else if(box == boxes[1]) boxes[0].focus();
}

proto._checkLeftRight = function(box, code)
{
	
	if(code == 37) // Left
	{
		if(box.selectionStart == 0 && box.selectionEnd == 0) 
		{
			this._moveToPreviousField(box);		
			return true;
		}
	}
	else if(code == 39) // Right
	{
		if(box.selectionStart == box.value.length && box.selectionEnd == box.value.length) 
		{
			this._moveToNextField(box);
			return true;
		}
	}
	return false;
}

proto._box_onfocus = function()
{
	var box = CNUtil.eventTarget();
	box.select();
}

proto._box_onkeyup = function()
{
	CNUtil.dispatchObject().box_onkeyup();
}
proto.box_onkeyup = function()
{
	if(this._disabled) return;
	var box = CNUtil.eventTarget();
	
	var code = Event.keyValue(Event.current());

	if(Event.current().type == "keydown")
	{
		if(this._checkLeftRight(box, code)) return;
		var value = parseInt(box.value, 10);
		if(!isNaN(value))
		{
			if(code == 38 && (!box._maxValue || value < box._maxValue)) // Up.
			{
				box.value = value + 1;
				this._isDirty = true;
			}
			else if(code == 40 && value > 1) // Down.
			{
				box.value = value - 1;
				this._isDirty = true;				
			}
		}
		
		if(code == 9 && this._inGrid) {
			//	else if(box == boxes[1]) boxes[2].focus();		
			var boxes = this.element.getElementsByTagName("input");
			if(box == boxes[2]) {
				CN_grid.proxyTabKeyDown();
				return;
			}
		}
	}

	var charx = String.fromCharCode(code);
	if(code == 46) return;
	if((charx < "0" || charx > "9") && (code < 96 || code > 105) || code == 13) 
	{
		var newVal = box.value.replace(/\D/g, '');
		if(newVal != box.value)
		{
			box.value = newVal;
			this._isDirty = true;
		}
		return;
	} 

	if(Event.current().type == "keydown") this._tryNextField(box);
}


// Works in +time mode only.
proto._textBox_onkeypress = function()
{
	if(Event.keyValue(Event.current()) != 9) return;
	var jso = CNUtil.dispatchObject();
	CNUtil.cancelEvent();
//	CNFormManager._trace("jso._timeBox.select();");
	jso._timeBox.select();
}

proto._element_ondeactivate = function()
{
	var jso = CNUtil.dispatchObject();
	if(jso instanceof CN_timebox) jso = jso._dateBox;
	var calendar = CNPopupCalendar.defaultInstance;
	if(calendar.element.contains(Event.current().relatedTarget)) { // FWUI-994 
		Util.cancelEvent(Event.current());
		return;
	}
	if(jso.element.contains(Event.current().relatedTarget)) {
		return;
	}
	if(jso._isDirty) jso._fireChangedEvent();
//	if(jso.onfocusout) jso.onfocusout();
}

proto._element_onfocusout = function() {
	var jso = CNUtil.dispatchObject();
	if(jso instanceof CN_timebox) jso = jso._dateBox;
	var calendar = CNPopupCalendar.defaultInstance;
	if(calendar.element.contains(Event.current().relatedTarget)) { // FWUI-994 
		Util.cancelEvent(Event.current());
		return;
	}
	if(jso.element.contains(Event.current().relatedTarget)) {
		return;
	}
	if(jso.onfocusout) jso.onfocusout();
}

proto._timeBox_onchange = function()
{
	var jso = CNUtil.dispatchObject();
	jso._dateBox._isDirty = true;
	jso._dateBox._fireChangedEvent();
}

proto._timeBox_input_onactivate = function()
{
	var jso = CNUtil.dispatchObject();
	jso.__input_onactivate();	
	jso._dateBox._timeCell.className = "timeCell";	
}

proto._timeBox_isValid = function()
{
	// this == timeBox
	var jso = CNUtil.dispatchObject();
	if(!this._isValid(true))
	{
		jso._dateBox._timeCell.className = "timeCellError";	
		//this._dateBox._textBox.style.borderColor = "red";
		//this.element.style.borderColor = "red";
		return false;
	}
	
	jso._dateBox._timeCell.className = "timeCell";	
	return true;
}

proto._fireChangedEvent = function()
{
	var ev = {target: this.element};
	if(this.onchange) this.onchange(ev);
}


proto.resetValue = function(node)
{
	this._isDirty = false;
	if(this._doTime) this._timeBox.set_value(this._lastValidTime);
	this._populateDate(this._lastValidValue);
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("value");
	if(attr != null) 
	{
		var value = this._lastValidValue = String(attr);
		if(this._doTime)
		{
			var dateTime = this.getReadableDateTime(value);			
			
			this._lastValidValue = dateTime[0];
			this._populateDate(dateTime[0]);
			
			this._lastValidTime = dateTime[1];
			this._timeBox.set_value(this._lastValidTime);
		}
		else 
		{
			this._populateDate(value);
		}
		
	}
	attr = node.getAttribute("minvalue");
	if(attr) this._minValue = this._parseDate(String(attr));
	attr = node.getAttribute("maxvalue");
	if(attr) this._maxValue = this._parseDate(String(attr));

	var attr = node.getAttribute("tooltip");
	if(attr) 
	{
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
	}
	else
		Tooltip.detach(this.element);
	

	this._isDirty = false;
}

proto.getReadableDateTime = function(value)
{
	var time = "";
	var date = "";
	if(value.length > 0)
	{
		var ar = value.match(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})/);
		if(ar != null)
		{
			date = ar[3] + "/" + ar[2] + "/" + ar[1];
			time = ar[4] + ":" + ar[5];
		}
		else {
			alert("ASSERT: can't parse date/time value: " + value); 
			return null;
		}
	}
	return [date, time];
}

proto._populateDate = function(value)
{
	if(value.length > 0)
	{
		var ar = value.match(/^(\d{1,2})[\/\.\-](\d{1,2})[\/\.\-](\d{4})$/);
		if(ar != null)
		{
			this._dayBox.value = ar[1];
			this._monthBox.value = ar[2];
			this._yearBox.value = ar[3];
		}
	}
	else
	{
		this._dayBox.value = "";
		this._monthBox.value = "";
		this._yearBox.value = "";
	}
}

proto._parseDate = function(str)
{
	var ar = str.match(/^(\d{4})(\d{2})(\d{2})(?:(\d{2})(\d{2}))?/);
	if(!ar) return null;
	if(ar[5] != '') 
	{
		return new Date(parseInt(ar[1], 10), parseInt(ar[2], 10) - 1, parseInt(ar[3], 10), parseInt(ar[4], 10), parseInt(ar[5], 10));
	}
	else if(ar[3] != '') 
	{
		return new Date(parseInt(ar[1], 10), parseInt(ar[2], 10) - 1, parseInt(ar[3], 10));
	}
	return null;
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty || !this.isValid()) return null;
	
	if(!this.element.id) 
	{
		this.element.style.background = "red";
		alert("No id for textbox.");
		return;
	}
	
	this._isDirty = false;

	var node = xmldoc.createElement("datebox");

	var value = this.get_value();

	if(this._doTime)
	{
		node.setAttribute("time", "true");
	}
	
	node.setAttribute("value", value);
	return node;
}

proto._button_onclick = function()
{
	CNUtil.findJSObject(CNUtil.eventTarget()).button_onclick();
}
proto.button_onclick = function()
{
	var calendar = CNPopupCalendar.defaultInstance;

	calendar.__activeCN_datebox = this;
	calendar.onxlresult = this._calendar_onxlresult;

	var xy = CNUtil.findAbsolutePos(CNUtil.eventTarget());
	
	var x = xy.x;
	var y = xy.y + CNUtil.eventTarget().offsetHeight;
	if(this.isValid(true) && 
		this._dayBox.value.replace(/\s+/, "") != "" && 
			this._monthBox.value.replace(/\s+/, "") != "" && 
				this._yearBox.value.replace(/\s+/, "") != "") 
	{
		var value = "";
		if(!isNaN(parseInt(this._dayBox.value, 10))) value += this._dayBox.value;
		value += "/";
		if(!isNaN(parseInt(this._monthBox.value, 10))) value += this._monthBox.value;
		value += "/";
		if(!isNaN(parseInt(this._yearBox.value, 10))) value += this._yearBox.value;
		
		calendar.show(value, null, x, y);		
	}
	else calendar.show(null, null, x, y);
	
	CNUtil.cancelBubble();
}

proto._calendar_onxlresult = function()
{
	this.__activeCN_datebox.calendar_onxlresult(this);
}
proto.calendar_onxlresult = function(calendar)
{
	this._textBox.value = calendar.get_dateString();	
	var date = calendar.get_dateString().match(/^(\d{1,2})[\/\.\-](\d{1,2})[\/\.\-](\d{4})$/);
	if(date)
	{		
		this._dayBox.value = date[1];
		this._monthBox.value = date[2];
		this._yearBox.value = date[3];
		
		this._dayBox.style.borderColor = "";
		this._monthBox.style.borderColor = "";
		this._yearBox.style.borderColor = "";
	}

	if(this._doTime) 
		this._timeBox.element.style.borderColor = "";
	
	this._isDirty = true;
	this._valid = true;
	this.select();	

	if(!this._doTime || this._timeBox.get_value().length > 0) 
		this._fireChangedEvent();

	calendar.onxlresult = calendar.__activeCN_datebox = null;
}

proto._textbox_onchange = function()
{
	var jsObject = CNUtil.findJSObject(CNUtil.eventTarget())
	if(jsObject instanceof CN_timebox) jsObject = jsObject._dateBox;
	jsObject._isDirty = true;
	if(jsObject._focusInside) 
	{
		jsObject._focusInside = false;
	}
//	else
//	{
//		jsObject._fireChangedEvent();
//	}
}

proto._textbox_onfocusout = function()
{
	CNUtil.findJSObject(CNUtil.eventTarget()).textbox_onfocusout();	
}
proto.textbox_onfocusout = function()
{
	if(this._doTime)
	{
		this._focusInside = Event.current().relatedTarget != null && this.element.contains(Event.current().relatedTarget);
	}
	
	if(this._disabled) return;
	this._valid = this.isValid();
}

proto._textbox_onactivate = function()
{
	var jsObject = CNUtil.dispatchObject();
	if(jsObject._disabled)
	{
		CNUtil.cancelEvent();
		return;
	}

	// Reset the date box style to default
	jsObject._dateBox.className = "dateBox";
	if(jsObject._doTime)
	{	
		if(!jsObject._timeBox._isValid(true)) {
			jsObject._timeCell.className = "timeCellError";
		} 
		else {
			jsObject._timeCell.className = "timeCell";
		}		
	}
}

/*proto.validateValue = function(value) {

}*/

proto.isValid = function(doNotHighlite)
{
	if(this._disabled) 
		return true;

	//Reset to default CSS
	this._resetToDefault();
	
	var date = null;	
	
	var valid = false;
	var timeBoxIsValid = false;
	
	this.validationString = "";
	this._storedValue = "";
	
	var day = parseInt(this._dayBox.value, 10);
	var month = parseInt(this._monthBox.value, 10);
	var year = parseInt(this._yearBox.value, 10);
	
	var isDateEmpty = isNaN(day) && isNaN(month) && isNaN(year);
	if(!this._doTime) {
		timeBoxIsValid = true;
	}
	
	if(isDateEmpty && this._canBeEmpty && 
		(!this._doTime || this._timeBox.get_value() == "")) 
	{
		valid = true;
		timeBoxIsValid = true;
	}
	else
	{
		day = (String(day)).match(/^(\d{1,2})$/);		
		month = (String(month)).match(/^(\d{1,2})$/);		
		year = (String(year)).match(/^(\d{4})$/);		
		
		if ((day != null && (parseInt(day[0], 10)) >= 1 && parseInt(day[0], 10) <= 31) &&
				(month != null && (parseInt(month[0], 10)) >= 1 && parseInt(month[0], 10) <= 12) &&			
					(year!= null &&  (parseInt(year[0], 10)) > 1800)) 
		{
			valid = true
		}
		
		if(day != null && month != null && year != null && valid)
		{	
			day.splice(0, 1);
			month.splice(0, 1);
			year.splice(0, 1);
			
			date = new Date(year, month -1, day);				
			valid = date.getDate() == day[0] && date.getMonth() + 1 == month[0] && date.getFullYear() == year[0];			
			this._storedValue = year[0] + this._zeroPad(month[0]) + this._zeroPad(day[0]);
		}
		
		if(!valid) {
			this.validationString = this._dateValidationString;			
		}
		
		if(this._doTime)
		{
			timeBoxIsValid = this._timeBox._isValid(true);						
			if(timeBoxIsValid && valid) 
			{
				var timeValue = this._timeBox.get_value();
				if (timeValue != "")
				{	
					timeBoxIsValid	= true;			
					var ar = timeValue.split(':');
					if(valid && parseInt(ar[0]) != ""  && parseInt(ar[1]) != "") 
					{
						date = new Date(date.getFullYear(), date.getMonth(), date.getDate(), parseInt(ar[0]), parseInt(ar[1]));
					}
				}
				else
				{
					timeBoxIsValid = false;
				}
			}
			
			if(!timeBoxIsValid)
			{
				this.validationString += this._timeValidationString;
			}
		}
	}
	
	if(date)
	{
		if(valid && timeBoxIsValid && this._minValue) 
		{
			if (this._minValue.getTime() > date.getTime())
			{
				valid = false;				
			}
		}
		if(valid && timeBoxIsValid && this._maxValue) 
		{
			if(this._maxValue.getTime() < date.getTime())
			{
				valid = false
			}
		}	

		if(!valid)	
			this.validationString = this._dateValidationString;
	}

	if(!doNotHighlite && (!valid || !timeBoxIsValid)) 
	{	
		if (!valid)
		{
			this._dateBox.className = "dateBoxError";			
		}	
				
		if(this._doTime)
		{
			if (!timeBoxIsValid) 
			{
				this._timeCell.className = "timeCellError";						
			}
		}
	}	

	return valid && timeBoxIsValid;
}

proto._resetToDefault = function()
{
	this._dateBox.className = "dateBox";	
	if(this._doTime)	
		this._timeCell.className = "timeCell";					
}

proto._zeroPad = function(val)
{
	var str = String(val);
	if(str.length < 2) str = "0" + val;
	return str;
}

proto.set_tabIndex = function(ti)
{
	this._tabIndex = ti;
	this._set_tabIndex(ti);
}
proto._set_tabIndex = function(ti)
{
	this._dayBox.tabIndex = ti;
	this._monthBox.tabIndex = ti;
	this._yearBox.tabIndex = ti;
	this._button.tabIndex = ti;
	if(this._doTime) this._timeBox.set_tabIndex(ti);
}

proto.set_disabled = function(val)
{
	this._disabled = val;

	if(val) this._set_tabIndex(-1);
	else if(this._tabIndex) this._set_tabIndex(this._tabIndex);

	if(this.isBuilt) this._set_disabled();
}
proto._set_disabled = function()
{ 
	this._dayBox.readOnly = this._disabled;
	this._monthBox.readOnly = this._disabled;
	this._yearBox.readOnly = this._disabled;
	
	this._button.disabled = this._disabled;

	//if(this._doTime) this._timeBox.set_disabled(this._disabled);
	if(CNFormManager.vista)
	{
		this.element.className = this._disabled ? "cn_datebox cn_datebox_disabled" : "cn_datebox";
		this._button.src = CNFormManager.themeImagesPath + (this._disabled ? "disabled-datebox-button.gif" : "datebox-button.gif");
	}
	else
	{		
		this._dayBox.style.borderColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-border-color") : "";
		this._dayBox.style.backgroundColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-background") : ""		
		this._monthBox.style.borderColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-border-color") : "";
		this._monthBox.style.backgroundColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-background") : ""		
		this._yearBox.style.borderColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-border-color") : "";
		this._yearBox.style.backgroundColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-background") : ""				
		this._dateBox.style.borderColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-border-color") : "";
		this._dateBox.style.backgroundColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-background") : ""		
		if(this._doTime)
		{
			this._timeCell.style.borderColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-border-color") : "";
			this._timeCell.style.backgroundColor = this._disabled ? Util.getStyle(this.element, "xl--disabled-background") : ""		
			this._timeBox.set_disabled(this._disabled);
			this._timeBox.element.style.border = "0px";			
		}
	}
	if(this._disabled) {
		var calendar = CNPopupCalendar.defaultInstance;
		if(calendar.__activeCN_datebox == this) {
			calendar.onxlresult = null;
			calendar.__activeCN_datebox = null;
			calendar.hide();
		}
	}
}
proto.unload = function() {
	var calendar = CNPopupCalendar.defaultInstance;
	if(calendar && calendar.__activeCN_datebox == this) {
		calendar.onxlresult = null;
		calendar.__activeCN_datebox = null;
		calendar.hide();
	}
}

// Used by grid api.
proto.set_readOnly = function(val)
{
}

proto.get_readOnly = function(val)
{
	return false;
}
proto.set_value = function(val)
{
	this.loadData(Util.wrapIntoNode({value: val}))
}
proto.get_value = function()
{
	var value = "";
	if(!isNaN(parseInt(this._dayBox.value, 10))) value += this._dayBox.value;
	value += "/";
	if(!isNaN(parseInt(this._monthBox.value, 10))) value += this._monthBox.value;
	value += "/";
	if(!isNaN(parseInt(this._yearBox.value, 10))) value += this._yearBox.value;
	
	if(value == "//") return "";
	
	this._storedValue = this._yearBox.value + this._zeroPad(this._monthBox.value) + this._zeroPad(this._dayBox.value);
	
	if(this._doTime)
	{
		if(this._storedValue)
		{
			var timeValue = this._timeBox.get_value();
			if(timeValue && timeValue != "")
			{
				var ar = timeValue.split(':');
				value = this._storedValue + this._zeroPad(ar[0]) + this._zeroPad(ar[1]);
			}
			else 
				value = this._storedValue
		}
		else
			value = "";
	}

	return value;
}

proto.blur = function(val)
{
}

proto.select = function()
{
	this._textBox.select();
}

proto.focus = function()
{
	this._dayBox.focus();
	//var textBox = this._textBox;
}
proto.onfocusout = function(){}
proto.onkeypress = function(){}


/*
	v. 2.0.1
*/
function CN_timebox()
{
	this.formManager = null;
	// Flag grid to directly assign events.
	this.directlyAssignEvents = true;
	this.validationString = "Invalid Time";

	this._isDirty = false;
	this._textBox = null;
	this._canBeEmpty = false;

	this.hours = null;
	this.minutes = null;
	this.isBuilt = false;
	
	this.activeInput = null;
	this.focusIn = false;
	
	this.canceling = false;
	this.defaultValue = null;
	
	this._disabled = false;
	this._value = "";
	this._readOnly = false;
	this._autoPostBack = false;
	this._lastValidValue = null;

	this.supportsRequired = true;
	this.dontCancelBlur = false; // Set by grid/datetimebox to allow grid validation instead of internal time hooks.
}

var proto = CN_timebox.prototype;

// Available public events.
proto.onchange = function()
{
	if(this._autoPostBack) 
	{
		this.formManager.postData(this.element);
	}	
}

proto.onfocusout = function(){}
proto.onkeypress = function(){}

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("span");
	// NOTE: can be called from grid w/o parentElement and node.
	if(parentElement) parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;
	
	l.className = "cn_timebox";

	Event.add(l, "mousedown", this, this._element_onmousedown);
	Event.add(l, "keydown", this, this._element_onkeydown);
	Event.add(l, "keyup", this, this._element_onkeyup);
	Event.add(l, "focusout", this, this._element_onfocusout);

	this.hours = document.createElement("input");
	this.hours.type = "text";
	this.hours.maxLength = 2;
	this.hours.style.textAlign = "right";
	this.hours.style.paddingRight = "1px";

	Event.add(this.hours, "focus", this, this._input_onfocus);
	Event.add(this.hours, "focusout", this, this._input_onblur);
	Event.add(this.hours, "focusin", this, this._input_onactivate);	
	Event.add(this.hours, "mousedown", this, this._input_onmousedown);
	Event.add(this.hours, "change", this, this._textbox_onchange);
	
	this.element.appendChild(this.hours);

	var divider = document.createElement("span");
	divider.className = 'divider';
	divider.textContent = ":";
	this.element.appendChild(divider);

	this.minutes = document.createElement("input");
	this.minutes.type = 'text';
	this.minutes.maxLength = 2;

	Event.add(this.minutes, "focus", this, this._input_onfocus);
	Event.add(this.minutes, "focusout", this, this._input_onblur);	
	Event.add(this.minutes, "focusin", this, this._input_onactivate);	
	Event.add(this.minutes, "mousedown", this, this._input_onmousedown);
	Event.add(this.minutes, "change", this, this._textbox_onchange);
	
	this.element.appendChild(this.minutes);
	this.isBuilt = true;

	if(node)
	{
		var attr = node.getAttribute("canBeEmpty");
		if(attr == "true") this._canBeEmpty = true;

		attr = node.getAttribute("validationString");
		if(attr) this.validationString = String(attr);

		attr = node.getAttribute("autoPostBack");
		if(attr) this._autoPostBack = attr == "true";
	}

	if(CNFormManager.vista) VistaSupport.attachToJSCNBox(this);

	if(this._value) this._set_value();
	this._set_readOnly();
	this._set_disabled();
	
	return l;
} 

proto.loadData = function(node)
{
	var attr = node.getAttribute("tooltip");
	if(attr) 
	{
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
	}

	var attr = node.getAttribute("value");
	if(attr != null) 
	{
		this._lastValidValue = String(attr);
		this.set_value(this._lastValidValue);
	}
	this._isDirty = false;
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty) return null;
	this._isDirty = false;
	
	var node = xmldoc.createElement("timebox");
	node.setAttribute("value", this.get_value());
	return node;
}

proto.resetValue = function()
{
	this._isDirty = false;
	this.set_value(this._lastValidValue);
}

proto.isValid = function(doNotHilite)
{
	if(this._disabled) return true;
	var valid = this.validateValue(this.get_value(), this._canBeEmpty);
	if(!valid && !doNotHilite)
	{
		this.element.style.borderColor = "red";
	}
	return valid;
}


proto.set_disabled = function(val)
{
	this._disabled = val;

	if(val) this._set_tabIndex(-1);
	else if(this._tabIndex) this._set_tabIndex(this._tabIndex);

	if(this.isBuilt) this._set_disabled();
}

proto._set_disabled = function()
{ 
	var val = this._disabled || this._readOnly;
	this.hours.readOnly = this.minutes.readOnly = val;
	if(CNFormManager.vista)
	{
		this.element.className = val ? "cn_timebox cn_timebox_disabled" : "cn_timebox";
	}
	else
	{
		this.element.style.borderColor = val ? Util.getStyle(this.element, "xl--disabled-border-color") : "";
		this.element.style.backgroundColor =
		this.hours.style.backgroundColor = 
			this.minutes.style.backgroundColor = val ? Util.getStyle(this.element, "xl--disabled-background") : "";
	}
}

proto.set_value = function(value)
{
	this._value = String(value);
	if(this._value.replace(/\s+/, "") == "") this._value = "";
	if(this.isBuilt) this._set_value();
}
proto._set_value = function()
{
	var ar = this._value.split(":");
	if(ar.length == 2)
	{
		this.hours.value = ar[0];
		this.minutes.value = ar[1];
	}
	else
	{
		this.hours.value = this.minutes.value = "";
	}
	this.defaultValue = this.get_value();
}
proto.get_value = function()
{
	if(!this.isBuilt) return this._value;
	this._value = this.hours.value + ":" + this.minutes.value;
	if(this._value.replace(/\s+/, "") == ":") this._value = "";
	return this._value;
}

proto.set_readOnly = function(value)
{
	this._readOnly = Util.parseBoolean(value);
	if(!this.isBuilt) return;
	this._set_readOnly();
}
proto._set_readOnly = function()
{
	this.hours.readOnly = this.minutes.readOnly = this._readOnly || this._disabled;
	this.hours.style.backgroundColor = 
		this.minutes.style.backgroundColor = this._disabled || this._readOnly ? Util.getStyle(this.element, "xl--disabled-background") : "";
}
proto.get_readOnly = function()
{
	return this._readOnly;
}

proto.set_canBeEmpty = function(val)
{
	this._canBeEmpty = Util.parseBoolean(val);
}

proto._input_onactivate = function()
{
	var element = CNUtil.findElement(Util.eventTarget());
	if(element.jsObject._disabled) return;
	element.style.borderColor = "";
}

proto._input_onfocus = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	if(jsObject._disabled || jsObject._readOnly) return;

	Util.cancelBubble(Event.current());
	
	if(jsObject.focusIn)
	{
		jsObject.focusIn = false;
		return;
	}

	jsObject.activeInput = Util.eventTarget();
	if(!jsObject._readOnly) 
	{
//		CNFormManager._trace("timebox _input_onfocus select()");
		jsObject.activeInput.select();
	}	
}

proto._input_onblur = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	jsObject.input_onblur();
}

proto.input_onblur = function()
{
	if(this._disabled) return;
	
	if(this.focusIn)
	{
		this.focusIn = false;
		Util.cancelBubble(Event.current());
		return;
	}
	if(this.canceling)
	{
		this.set_value(this.defaultValue);
		this.canceling = false;
		this.activeInput = null;
		return;
	}
	if(this.element_onblur())
	{
		if(this.get_value() != this.defaultValue)
		{
			this._isDirty = true;
			this._fireChangeEvent();
			
			this.defaultValue = this.get_value();
		}
		this.activeInput = null;
	}
}

proto._fireChangeEvent = function()
{
	var ev = {target: this.element};
	if(this.onchange) this.onchange(ev);
}

proto.element_onblur = function()
{
	return this.isValid();
}


proto._input_onmousedown = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	if(jsObject._disabled) return;
	
	if(jsObject.activeInput != null && jsObject.activeInput != Util.eventTarget()) 
	{	
		jsObject.focusIn = true;
	}
}

proto.select = function()
{
	if(!this._readOnly) 
	{	
		this.hours.select();
	}
}

proto.focus = function()
{
//	CNFormManager._trace("timebox focus()");
	if(this._readOnly) this.element.focus();
	this.focusIn = false;
}

proto.blur = function()
{
}

proto._element_onmousedown = function()
{
	Util.cancelBubble(Event.current());
}

proto._element_onkeydown = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	jsObject.element_onkeydown();
}

proto.element_onkeydown = function()
{
	if(this._disabled) return;
	
	var code = (Event.keyValue(Event.current()));

	if(code == 9) // Tab.
	{
		if(!Event.current().shiftKey && this.activeInput == this.hours) 
		{
			this.focusIn = true;
			this.minutes.focus();
			CNUtil.cancelEvent();
		}
		else if(!Event.current().shiftKey && !this.isValid())
		{
			if(!this.dontCancelBlur) CNUtil.cancelEvent();
			return;
		}
		// else proceed with default tab behavior.
		else
		{
			if(this._grid) this._grid.processTab();
			return;
		}
	}
	else if(code == 8) // Backspace
	{
		if(this.activeInput == this.minutes && Util.eventTarget().value.length == 0)
		{
			this.focusIn = true;
//			CNFormManager._trace("timebox hours.focus()");
			this.hours.focus();
		}
	}
	else if(code == 27) // Esc
	{
		if(this.activeInput) 
		{
			this.canceling = true;
			this.activeInput.blur();
		}
	}
	else if(code == 13)
	{
		// Pass to formmanager.
		if(this.onkeypress) this.onkeypress(); // Pass to grid.
	}
	else if((code < 48 || code > 57) && (code < 96 || code > 105))
	{
		CNUtil.cancelEvent();

		if(!this._readOnly && String.fromCharCode((Event.keyValue(Event.current()))).toLowerCase() == "n")
		{
			var now = new Date();
			this.hours.value = this._zeroPad(now.getHours());
			this.minutes.value = this._zeroPad(now.getMinutes());
			this._isDirty = true;
		}
	}
	else
	{
		this.focusIn = false;
	}
	// 48 - 57 / 96 - 105
}

proto._element_onkeyup = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	jsObject.element_onkeyup();
}

proto.element_onkeyup = function()
{
	if(this._disabled || !this.activeInput) return;
	
	var code = (Event.keyValue(Event.current()));
	if(code != 9 && code != 8 && this.activeInput == this.hours && this.activeInput.value.length >= 2)
	{
		this.focusIn = true;
//		CNFormManager._trace("timebox minutes.focus()");
		this.minutes.focus();
	}
	if(code == 8) // Backspace.
	{
		if(this.activeInput == this.minutes && Util.eventTarget().value.length == 0)
		{
			this.focusIn = true;
//			CNFormManager._trace("timebox hours.focus()");
			this.hours.focus();
		}
	}
	else if(code == 13) // Enter.
	{
		this._fireChangeEvent();
	}
}

proto._textbox_onchange = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	if(jsObject._disabled) return;
	jsObject._isDirty = true;
}

proto._element_onfocusout = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	if(jsObject._disabled) return;
	jsObject.onfocusout();
}

proto.validateValue = function(value, canBeEmpty)
{
	if(value.replace(/\s+/g, "") == ":" && canBeEmpty) return true;
	var ar = value.split(":");
	return ar.length == 2 && ar[0].length > 0 && ar[0] * 1 >= 0 && ar[0] * 1 <= 23
			&& ar[1].length > 1 && ar[1] * 1 >= 0 && ar[1] * 1 <= 59
			|| (value.replace(/\s+/, "") == "" && canBeEmpty);
}

proto.set_tabIndex = function(ti)
{
	this._tabIndex = ti;
	this._set_tabIndex(ti);
}

proto._set_tabIndex = function(ti)
{
	this.hours.tabIndex = ti;
	this.minutes.tabIndex = ti;
}

proto._zeroPad = CN_datebox.prototype._zeroPad;

/*
	v. 0.25
	+ theme support.
*/

function CN_panel(){}
var proto = CN_panel.prototype;

proto.doNotDisable = true;

proto.createElement = function(node, parentElement)
{
	var type = String(node.getAttribute("type"));
	var vista = CNFormManager.vista;
	var l;
	if(type == "MiniBox") l = CN_panel_buildMiniBoxPanel(parentElement);
	else if(vista)
	{
		if(type == "Dark") l = $('__vistaDarkPanel').cloneNode(true);
		else if(type == "White") l = $('__vistaWhitePanel').cloneNode(true);
		l.id = "";

		parentElement.appendChild(l);
	}
	else
	{
		l = document.createElement("div");
		parentElement.appendChild(l);
		if(type == "Dark") l.innerHTML = CN_panel_buildDarkPanel();
		else if(type == "White") l.innerHTML  = CN_panel_buildWhitePanel();
	}
	
	this.element = l;
	l.style.zIndex = -2;
	l.jsObject = this;

	return l;
}

proto.loadData = function(node) {
	var textEl = Util.findById(this.element, "__panel_text");

	var attr = node.getAttribute("text");
	if(attr) {
		textEl.textContent = String(attr);
	}

	attr = node.getAttribute("img");
	if(attr != null) {
		var img = textEl.parentNode.firstChild;
		if(img && img.className == "panelImg") {
			img.parentNode.removeChild(img);
			img = null;
		}

	    if(attr == "") {
	    	Util.removeClass(textEl, "withImage");
		} else {
			Util.addClass(textEl, "withImage");
			var img = document.createElement("img");
			img.className = "panelImg";
			img.src = String(attr);
			textEl.parentNode.insertBefore(img, textEl.parentNode.firstChild);
		}
	}
}


function CN_panel_buildDarkPanel()
{
	var suffix = CNFormManager.getBaseFormManager().isTabbed ? '-tabbed' : '';
	return '<table class="darkPanel" align=top width=100% border=0 cellpadding=0 cellspacing=0>\
		<tr><td><img src="' + CNFormManager.themeImagesPath + 'win-header-5' + suffix + '_01.gif" width=12 height=45></td>\
		<td width=100% background="' + CNFormManager.themeImagesPath + 'win-header-5' + suffix + '_02.gif">\
		<h2 id="__panel_text"></h2>\
		</td>\
		<td><img src="' + CNFormManager.themeImagesPath + 'win-header-5' + suffix + '_03.gif" width=12 height=45></td></tr>\
		</table>';
}

function CN_panel_buildWhitePanel()
{
	return '<table class="whitePanel" align=top width=100% border=0 cellpadding=0 cellspacing=0>\
			<tr><td><img src="' + CNFormManager.themeImagesPath + 'win-header-3_01.gif" width=12 height=45></td>\
			<td valign=top width=100% background="' + CNFormManager.themeImagesPath + 'win-header-3_02.gif">\
			<br><h5 id="__panel_text"></h5>\
			</td>\
			<td><img src="' + CNFormManager.themeImagesPath + 'win-header-3_03.gif" width=12 height=45></td></tr>\
			</table>';
}

function CN_panel_buildMiniBoxPanel(l)
{
	if(CNFormManager.vista)
	{
		var panel = $('__vistaMinibox').cloneNode(true);
		panel.id = "";
		l.appendChild(panel);
		return panel;
	}
	else
	{
		var table = Util.createElementFromHTML("<table width=100% height=100% border=0 cellpadding=0 cellspacing=0 class=smallMiniWindow2>");
		l.appendChild(table);
		
		var tbody = document.createElement('tbody');
		table.appendChild(tbody);
	
		// Header.
		var tr = document.createElement('tr');
		tbody.appendChild(tr);
		var td = Util.createElementFromHTML("<td height=16 width=12 nowrap>");
		tr.appendChild(td);
		var td1 = td;
			
		var td2 = Util.createElementFromHTML("<td width=100%>");
		tr.appendChild(td2);
	
		var h5 = Util.createElement("h5", "", {id: "__panel_text"});
		td2.appendChild(h5);
		td2.style.paddingTop = "4px";
		var td = Util.createElementFromHTML("<td width=12 nowrap>");
		tr.appendChild(td);
		
		var td12 = td;
	
		// Content.
		var tr = Util.createElementFromHTML("<tr valign=top>");
		tbody.appendChild(tr);
	
		var td5 = Util.createElement("td", "", {colSpan: 3, id: "contentTD", style: "position: relative;", height: "100%", width: "100%"});
		tr.appendChild(td5);
		td5.innerHTML = '<div style="overflow: hidden; width: 1px; height: 1px; "></div>';
	
		td1.style.background = "url(" + CNFormManager.themeImagesPath + "win-4_01.gif)";
		td12.style.background = "url(" + CNFormManager.themeImagesPath + "win-4_03.gif)";
		td2.style.background = "url(" + CNFormManager.themeImagesPath + "win-4_02.gif) repeat-x";

		return table;
	}
}

/*
	v. 2.0
*/	
function CN_horizontalline(){}
var proto = CN_horizontalline.prototype;

proto.doNotDisable = true;

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;

	var type = String(node.getAttribute("type"));
	if(type == "Footer") l.innerHTML = CN_horizontalline_buildFooter();
	else if(type == "Solid") l.innerHTML = CN_horizontalline_buildSolid();
	else if(type == "Gradient") l.innerHTML = CN_horizontalline_buildGradient();

	return l;
}

function CN_horizontalline_buildFooter()
{
	return '<img src="' + CNFormManager.themeImagesPath + 'bottom-line-1.gif" style="width: 100%; height: 9px; ">';
}

function CN_horizontalline_buildSolid()
{
	return '<div class="ims_horizontal_line" style="height:1px; width: 100%; "></div>';
}

function CN_horizontalline_buildGradient()
{
	return '<div class="ims_horizontal_line2" style="height:1px; width: 100%; "></div>';
}


/*
	v. 0.37
	+ ...
	+ space key checks items.
	+ tabIndex support for items.
	v. 0.32
	+ theme support.
	v 0.22
	+ autoPostBack.
	+ item enabled attribute support.
*/
var CN_radiobox = function()
{
	this.isReady = false;

	this.items = null;
	this.selectedItem = null;

	this._disabled = false;
	this._selectedIndex = -1;
	
	this._isDirty = false;
	this._autoPostBack = false;
}
var proto = CN_radiobox.prototype;

// Events. ================
proto.onchange = function(ev)
{
	if(this._autoPostBack) this.formManager.postData(this.element);
}

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("span");
	parentElement.appendChild(l);
	
	this.element = l;
	l.jsObject = this;

	l.style.userSelect = "none";
	l.className = "cn_radiobox";
	l.style.display = "inline-block"; // # 1148

	this.buildElements(node);
	this.isReady = true;
	
	if(node.getAttribute("autoPostBack") == "true") this._autoPostBack = true;
	
	this._set_disabled();
	
	return l;
}

proto.onControlCreated = function()
{
	this.element.style.position = "static";
}

proto.layout = function()
{
	var formManager = this.formManager;
	if(!this.items) return;
	for(var i = 0; i < this.items.length; i++)
		Util.setDarkHeaderControlClass(this.items[i], formManager);
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("selection");
	if(attr) this.set_selectedIndex(parseInt(attr));

	var itemNodes = Util.xmlSelectNodes(node, "item");
	var count = itemNodes.length;
	for(var i = 0; i < count; i++)
	{
		var itemNode = itemNodes[i];
		var item = this.items[i];
		if(!item)
		{
			alert("ASSERT: no item found for radiobox data <item>.")
			break;
		}
		var attr = itemNode.getAttribute("enabled");
		if(attr) this.set_disabledItem(item, attr != "true");
		
		attr = itemNode.getAttribute("visible");
		if(attr) item.style.visibility = attr == "true" ? "inherit" : "hidden";
		
		attr = itemNode.getAttribute("text");
		if(attr) item.children[1].innerHTML = String(attr);
	}
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty) return null;
	this._isDirty = false;

	var node = xmldoc.createElement("radiobox");
	node.setAttribute("selection", this._selectedIndex);
	return node;
}


proto.buildElements = function(node)
{
	this.items = [];
	var itemNodes = Util.xmlSelectNodes(node, "item");
	var count = itemNodes.length;
	for(var i = 0; i < count; i++)
	{
		this.buildElement(itemNodes[i], i);
	}
}

proto.buildElement = function(item, ix)
{
	var itemElement = document.createElement("span");
	this.element.appendChild(itemElement);
	
	itemElement.className = "radioItem"
	itemElement.style.position = "absolute";	
	
	this.items[this.items.length] = itemElement;
	
	itemElement.index = ix;
	itemElement.style.userSelect = "none";
	itemElement.jsObject = {};
	
	//var checkElement = Util.createElementFromHTML("<span class=checkSpan>")
	var checkElement = Util.createElementFromHTML("<img width=16 height=16 align=middle>");
	itemElement.appendChild(checkElement);
	checkElement.style.userSelect = "none";
	
	var checked = ix == this._selectedIndex;
	if(checked) this.setSelectedItem(itemElement)
	else this.setItemChecked(itemElement, false);
	
	var attr = item.getAttribute("text");
	if(attr)
	{
		var textElement = Util.createElementFromHTML("<span class=textSpan>")
		itemElement.appendChild(textElement);
		textElement.style.userSelect = "none";
		textElement.innerHTML = String(attr);
	}
	
	if(item.getAttribute("bold") == "true") itemElement.style.fontWeight = "bold";

	var anchor = item.getAttribute("anchor");
    var parentLM = this.element.parentNode._layoutManager;
    var layoutManager =  parentLM ? parentLM : this.formManager._layoutManager;
	if(anchor && layoutManager) 
	{
		layoutManager.processNewControl(itemElement, parseInt(anchor, 2), item, this.element);
	}
	else {
//		setTimeout(function() { // IE doesn't position checkbox items in deep container in dialog for some reason when container has no layout yet.
			CNUtil.setLocation(itemElement, item);  // # 1148
//		}, 0);
	}

	
	var attr = item.getAttribute("tabIndex");
	if(attr) 
	{
		itemElement.tabIndex = itemElement._tabIndex = parseInt(attr, 10);
	}
	
	Event.add(itemElement, "mouseenter", this, this._item_onmouseenter);
	Event.add(itemElement, "mouseleave", this, this._item_onmouseleave);
	Event.add(itemElement, "mousedown", this, this._item_onmousedown);
	Event.add(itemElement, "dblclick", this, this._item_onmousedown);
	Event.add(itemElement, "keydown", this, this._item_onkeydown);
}

CN_radiobox.findItem = function(l)
{
	// The standards theme adds state classes such as
	// `control_on_darkHeader` to the item.  Match the radioItem token rather
	// than requiring the old IE-era exact className string.
	while(l && !Util.hasClass(l, "radioItem")) l = l.parentElement || l.parentNode;
	return l;
}

proto.setSelectedItem = function(item, userAction)
{
	this.unsetSelectedItem(userAction);
	this.setItemChecked(item, true, userAction);
	this._selectedIndex = item.index;
	this.selectedItem = item;
}

proto.unsetSelectedItem = function(userAction)
{ 
	if(this.selectedItem != null) 
	{
		this.setItemChecked(this.selectedItem, false, false, userAction);
		this._selectedIndex = -1;
		this.selectedItem = null;
	}
}

// 161 - empty, 163 - bold empty, 164 - checked, 165 - double checked.
proto.setItemChecked = function(item, checked, hover, userAction)
{
	var checkedChanged = item.checked != checked;
	item.checked = checked;

	var img;
	if(this._disabled || item._disabled) img = checked ? "radioboxDisabledChecked.gif" : "radioboxDisabledUnchecked.gif";
	else if(hover) img = checked ? "radioboxHoverChecked.gif" : "radioboxHoverUnchecked.gif";
	else img = checked ? "radioboxChecked.gif" : "radioboxUnchecked.gif";

	if((hover || userAction) && CNFormManager.vista) 
	{
		VistaSupport.imageTrans(item.children[0], CNFormManager.themeImagesPath + img, checkedChanged);
	}
	else item.children[0].src = CNFormManager.themeImagesPath + img;
}

proto.fireChangedEvent = function(item)
{
	var ev = {};
	ev.item = item;
	ev.checked = item.checked;
	ev.selectedIndex = item.index;
	
	//Focus
	item.focus();	
	
	if(this.onchange) this.onchange(ev);
}


// Properties. ================================
proto.set_disabled = function(val)
{
	this._disabled = val;
	
	if(this.isReady) this._set_disabled();
}
proto._set_disabled = function()
{ 
	var color = this._disabled ? Util.getStyle(this.element, "xl--disabled-color") : "";
	var count = this.items.length;
	for(var i = 0; i < count; i++)
	{
		var item = this.items[i];

		if(this._disabled) item.tabIndex = -1;
		else if(item._tabIndex) item.tabIndex = item._tabIndex;

		if(!item._disabled) 
		{
			item.style.color = color;
			this.setItemChecked(item, item.checked);
		}
	}
}

proto.set_disabledItem = function(item, disabled)
{
	var color = disabled ? Util.getStyle(this.element, "xl--disabled-color") : "";
	item.style.color = color;
	item._disabled = disabled;
	this.setItemChecked(item, item.checked);	
}

proto.set_selectedIndex = function(val)
{
	if(this._selectedIndex == val) return;
	this._selectedIndex = val;
	if(this.isReady) this._set_selectedIndex();
}
proto._set_selectedIndex = function()
{
	var item = null;
	if(this._selectedIndex > -1 && this._selectedIndex < this.items.length) item = this.items[this._selectedIndex];
	this.unsetSelectedItem();
	if(item) this.setSelectedItem(item);
}

// Event handlers. ===============================
proto._item_onmouseenter = function()
{
	var item = CN_radiobox.findItem(Util.eventTarget());
	if(!item) return;
	var box = item.parentElement || item.parentNode;
	if(!box || !box.jsObject) return;
	var jsObject = box.jsObject;
	if(jsObject._disabled || item._disabled) return;
	jsObject.setItemChecked(item, item.checked, true, true);
}
proto._item_onmouseleave = function()
{
	var item = CN_radiobox.findItem(Util.eventTarget());
	if(!item) return;
	var box = item.parentElement || item.parentNode;
	if(!box || !box.jsObject) return;
	var jsObject = box.jsObject;
	if(jsObject._disabled || item._disabled) return;
	jsObject.setItemChecked(item, item.checked, false, true);	
}
proto._item_onmousedown = function()
{
	var item = CN_radiobox.findItem(Util.eventTarget());
	if(!item) return;
	var box = item.parentElement || item.parentNode;
	if(!box || !box.jsObject) return;
	var jsObject = box.jsObject;
	if(jsObject._disabled || item._disabled) return;

	if(item != jsObject.selectedItem)
	{
		jsObject.setSelectedItem(item, true);
		jsObject.fireChangedEvent(item);
		jsObject._isDirty = true;
	}
}
proto._item_onkeydown = function()
{
	if((Event.keyValue(Event.current())) == 32)
	{
		var item = CN_radiobox.findItem(Util.eventTarget());
		if(!item) return;
		var box = item.parentElement || item.parentNode;
		if(!box || !box.jsObject) return;
		var jsObject = box.jsObject;
		jsObject._item_onmousedown();
	}
}

/*
	v. 0.21
	+ autoSize.
	v. 0.2	
	+ theme support.
	v. 0.1
*/
function CN_picture()
{
	this._autoSize = false;
}
var proto = CN_picture.prototype;

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);

	var img = document.createElement("img");
	l.appendChild(img);
	
	this.element = l;
	l.jsObject = this;
	
	this.element.style.overflow = "hidden";
	this._autoSize = node.getAttribute("autoSize") == "true";
	if(this._autoSize)
	{
		img.style.width = "100%";
		img.style.height = "100%";
	}

	return l;
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("src");
	if(attr) this.element.children[0].src = String(attr);
	
	if(!this._autoSize && this.element.offsetWidth > 32 && this.element.offsetHeight > 32)
	{
		this.element.style.overflow = "auto";
	}
}

/*
	v. 2.0
*/
function CN_wavplayer()
{
	this.player = null;
	this._wav = null;
	this.paused = false;
	this.playButton = null;
	this.stopProbeTimeout = null;
}
var proto = CN_wavplayer.prototype;


proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;

	l.className = "cn_wavplayer";
	
	l.style.whiteSpace = "nowrap";

	this.buildElements();
	if(!window.XLWavPlayers) window.XLWavPlayers = [];
	window.XLWavPlayers[window.XLWavPlayers.length] = l;
	
	return l;
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("src");
	if(attr) 
	{
		this._wav = String(attr);
	}
	else 
	{
		this.set_disabled(true);
	}
}

proto.unload = function()
{
	for(var i = 0; i < window.XLWavPlayers.length; i++)
	{
		if(window.XLWavPlayers[i] == this.element)
		{
			window.XLWavPlayers.splice(i, 1);
			break;
		}
	}

	this.player = null;
	this.playButton = null;
}

proto.buildElements = function()
{
	var player = Util.createElement("audio", "wmpObject", {controls: false});
	player.style.display = "none";
	this.element.appendChild(player);
	this.player = player;
		
	if(CNFormManager.vista)
	{
		var node = Util.wrapIntoNode({});
		var playButton = new CN_button();
		playButton.elementID = this.elementID + "_button1";
		var stopButton = new CN_button();
		stopButton.elementID = this.elementID + "_button2";

		var b1 = playButton.createElement(node, this.element);
		var b2 = stopButton.createElement(node, this.element);
		b1.style.width = b2.style.width = "50%";
		//b1.style.height = b2.style.height = "100%";
		b1.style.position = b2.style.position = "relative";
		b1.style.display = b2.style.display = "inline";
		b1.style.fontFamily = b2.style.fontFamily = "webdings";
		b1.style.fontSize = b2.style.fontSize = "15px";
		b1.style.lineHeight = "19px";
		b2.style.lineHeight = "12px";
		playButton.loadData(Util.wrapIntoNode({value: "4"}));
		stopButton.loadData(Util.wrapIntoNode({value: "<"}));
		Event.add(b1, "click", this, this._playButton_onclick);
		Event.add(b2, "click", this, this._stopButton_onclick);
		this.playButton = playButton;
		this.stopButton = stopButton;
	}
	else
	{
		var playButton = this.createButton();
		this.element.appendChild(playButton);
		playButton.textContent = "4";
		playButton.lineHeight = "19px";
		Event.add(playButton, "click", this, this._playButton_onclick);
		this.playButton = playButton;
	
		var stopButton = this.createButton();
		this.element.appendChild(stopButton);
		Event.add(stopButton, "click", this, this._stopButton_onclick);
		stopButton.innerHTML = "&lt;";
		stopButton.style.fontSize = "16px";
	}
}

proto.createButton = function()
{
	return Util.createElement("button", "", {style: "font-family: sans-serif; font-size: 15px; width: 50%; height: 100%; overflow: hidden; color: #000077;"});
}

proto._playButton_onclick = function()
{
	Util.findByClassName(Event.current().target, "cn_wavplayer").jsObject.playButton_onclick();
}	
proto.playButton_onclick = function()
{
	if(this.element.disabled || !this._wav) return;
	if(this.player.paused || this.player.ended)
	{
		this.player.autoplay = false;
		this.player.src = this._wav;
		this.player.play();
	
		if(CNFormManager.vista) this.playButton.loadData(Util.wrapIntoNode({value: ";"}));
		else this.playButton.textContent = ";";

		for(var i = 0; i < window.XLWavPlayers.length; i++)
		{
			var p = window.XLWavPlayers[i];
			if(p != this.element)
			{
				p.__disabled = p.disabled;
				p.disabled = true;
			}
		}

		var obj = this;
		this.stopProbeTimeout = setTimeout(function(){ obj.stopProbe(); }, 50);
	}
	else if(this.paused)
	{
		if(CNFormManager.vista) this.playButton.loadData(Util.wrapIntoNode({value: ";"}));
		else this.playButton.textContent = ";";
		this.player.play();
		this.paused = false;
	}
	else
	{
		if(CNFormManager.vista) this.playButton.loadData(Util.wrapIntoNode({value: "4"}));
		else this.playButton.textContent = "4";
		this.player.pause();
		this.paused = true;
	}
}

proto._stopButton_onclick = function()
{
	Util.findByClassName(Event.current().target, "cn_wavplayer").jsObject.stopButton_onclick();
}
proto.stopButton_onclick = function()
{
	if(this.element.disabled) return;
	this.finishPlay();
}

proto.finishPlay = function()
{
	if(this.stopProbeTimeout != null) clearTimeout(this.stopProbeTimeout);
	try
	{
		this.player.pause();
		this.player.currentTime = 0;
	}
	catch(ex){}
	this.paused = false;

	if(CNFormManager.vista) this.playButton.loadData(Util.wrapIntoNode({value: "4"}));
	else this.playButton.textContent = "4";

	for(var i = 0; i < window.XLWavPlayers.length; i++)
	{
		var p = window.XLWavPlayers[i];
		if(p != this.element && p.__disabled != null) 
		{
			p.disabled = p.__disabled;
		}
	}
}

proto.stopProbe = function()
{
	if(this.player.paused || this.player.ended)
	{
		this.finishPlay();
	}
	else 
	{
		var obj = this;
		setTimeout(function(){ obj.stopProbe(); }, 50);
	}
	this.stopProbeTimeout = null;
}

proto.set_disabled = function(val)
{
	if(!this._wav) val = true;
	this.element.disabled = val;
	if(CNFormManager.vista)
	{
		this.playButton.set_disabled(val);
		this.stopButton.set_disabled(val);
	}
}
/*
	v. 2.0
*/
function CN_link()
{
	this._disabled = false;
	this.initiateUpload = false; // Used by formManager.	
}
var proto = CN_link.prototype;

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("a");
	l.className = "cn_link";
	l.href = "#";
	parentElement.appendChild(l);
	
	var img = document.createElement("img");
	l.appendChild(img);
	img.src = CNFormManager.themeImagesPath + "arrow-3.gif";
	img.align = "absmiddle";
	
	var text = document.createElement("span");
	l.appendChild(text);

	this.clicked = false;
	
	this.element = l;
	l.jsObject = this;

	var attr = node.getAttribute("value");
	if(attr) text.textContent = String(attr);
	Event.add(l, "click", this, CNUtil.cancelEvent);
	Event.add(l, "click", this, _CN_button_onclick);
	
	return l;
}

proto.doClick = CN_button.plainThemeProto.doClick;

proto.loadData = function(node)
{
	var attr = node.getAttribute("tooltip");
	if(attr) 
	{
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
	}
	this.initiateUpload = node.getAttribute("uploads") == "true";
}

proto.storeData = function(xmldoc)
{
	if(!this.clicked) return;
	this.clicked = false;

	var node = xmldoc.createElement("link");
	return node;
}

proto.set_disabled = function(value)
{
	this._disabled = value;
	this.element.className = value ? "cn_link cn_link_disabled" : "cn_link";
}

/*
	v. 2.0.1
	+ vista support.
	+ ...
	+ dragDrop events.
	+ tooltips.
	+ nonodes.
	+ modified disabling.
	+ checkbox fix.
	v. 0.3
	+ nodes drag-n-drop reordering.
	+ addNode/deleteNode.
	+ inplace rename node.
	v. 0.2
	+ theme support.
	v.0.12
	+ scroll restore fixed.
	+ derived from tree.htc.
*/
function CN_tree()
{
	this.formManager = null;
	this._showRootLines = true;
	this._showLines = true;
	this._selectExpands = true;
	this._showPlus = true;
	this._collectChanges = true;
	this.changedNodesDoc = null;
	this.changedFragment = null;

	this.childType = null;

	this.isReady = false;
	
	this.nodeDivTemplate = null;
	this.nodeTypes = [];
	
	this.lineImg_Width = 19;
	this.lineImg_Height = 20;
	
	this._disabled = false;
	this._readOnly = false;
	this.selectedNodeDiv = null;
	this._selectedNodeIndex = "";
	this._expandLevel = -1;
	
	this._selectionDirty = false;
	this._checkboxDirty = false;

	this._autoPostBack = false;
	this._autoPostBackForCheckBoxes = false;

	this.typeAttributes = ["checkBox", "collapsedImage", "selectedImage", "expandedImage"];

	this.ix_lineSpan = 0;
	this.ix_plusMinusSpan = 1;
	this.ix_checkBoxSpan = 2;
	this.ix_iconImg = 3;
	this.ix_textSpan = 4;

	this.state_default = 0;
	this.state_selected = 1;
	this.state_expanded = 2;
	this.state_expandedSelected = 3;
	
	this.allowNodeDrag = false;
	this._mouseButtonPressed = false;
	this._dragging = false;
	this._dragged = null;
	this._dragTargetPos = -1;
	
	this._newNodeIndex = -100;
	
	this._allowClearSelection = false;	
	this._doPostbackOnEditEnd = false;
	this._vista = CNFormManager.vista; // Speed up variable access.
	
	this.supportsRequired = true;
}

var proto = CN_tree.prototype;
proto._typedSelectTimout = 1 * 1000; // One second.
proto._lastTypeStamp = 0;

// Events. ===========================================
proto.onselectedindexchange = function(ev)
{
	this._selectionDirty = true;

	if(!this._autoPostBack) return;
	
	this.formManager.postData(this.element);
}

proto.onexpandcollapse = function(ev){}

proto.oncheck = function(ev)
{
	if(!this._autoPostBackForCheckBoxes) return;
	
	this.formManager.postData(this.element);	
}

// ev = {reorderedNodeDiv}
proto.onnodereordered = function(ev)
{
	var newIndex = this.getDottedIndex(ev.reorderedNodeDiv);
	if(this._selectedNodeIndex == newIndex) return; // Moved to the same pos.

	var node = this.changedNodesDoc.createElement("treenodedropped");
	node.setAttribute("node", this._selectedNodeIndex);
	this._selectedNodeIndex = newIndex;
	node.setAttribute("newIndex", this._selectedNodeIndex);
	this.changedFragment.appendChild(node);
	
	if(this._autoPostBack && !this._pending_onselectedindexchangeEV) this.formManager.postData(this.element);
}

proto.onnoderenamed = function(ev)
{
	if(!this._doPostbackOnEditEnd) return;
	this._doPostbackOnEditEnd = false;

	var node = this.changedNodesDoc.createElement("treenodeedited");
	node.setAttribute("node", this.getDottedIndex(ev.nodeDiv));
	node.setAttribute("text", ev.nodeDiv.node.getAttribute("text"));
	this.changedFragment.appendChild(node);
	
	if(this._autoPostBack && !this._pending_onselectedindexchangeEV) this.formManager.postData(this.element);
}


// ev = {draggedNodeDiv, dragTarget, dragTargetPos}
// dragTargetPos = 0: insert as previous sibling, 1: insert as next sibling, 2: insert as child.
proto.onnodereorderallowed = function(ev)
{
	// 1. check for resort in the same parent.
	if(ev.dragTargetPos == 0 || ev.dragTargetPos == 1)
	{
		var parentCont = ev.draggedNodeDiv.parentElement;
		var targetCont = ev.dragTarget.parentElement;
		if(parentCont == targetCont) 
		{
			return ev.draggedNodeDiv._allowSort;
		}
	}
	// 2. check for parent change.
	var dropToType = ev.draggedNodeDiv._dropToType;
	if(!dropToType || dropToType.length == 0) 
	{
		return false;
	}

	var dropType = "";
	if(ev.dragTargetPos == 0 || ev.dragTargetPos == 1) 
	{	
		var newParentNode = ev.dragTarget.parentElement.previousSibling;
		if(!newParentNode) 
		{
			dropType = "0"; // Root.
		}
		else
		{
			dropType = newParentNode._dropType;
		}
	}
	else 
	{
		dropType = ev.dragTarget._dropType;
	}
	
	if(dropType == "") return false;

	return dropToType[dropType] ? true : false;
}


// Main. ===================================
proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);

	l.className = "cn_tree";
	
	this.element = l;
	l.jsObject = this;

	var attr = node.getAttribute("autoPostBack");
	if(attr) this._autoPostBack = attr == "true";
	
	attr = node.getAttribute("autoPostBackForCheckBoxes");
	if(attr) this._autoPostBackForCheckBoxes = attr == "true";
	var content = Util.createElementFromHTML('<div id="content" style="width: 100%; height: 100%; overflow: auto; ">');
	l.appendChild(content);
	Event.add(content, "mousedown", this, this._content_onmousedown);
	this._content = content;
	
	//this.disabler = Util.createElementFromHTML('<div style="position: absolute; background: white; z-index: 1000; filter: alpha(opacity=50); width: 100%; height: 100%; visibility: hidden; top: 0px; left: 0px; ">');
	//l.appendChild(this.disabler);

	this.buildElement(node);
	
	Event.add(l, "keydown", this, this._element_onkeydown);
	
	if(CNFormManager.vista)
	{
		this._hover = VistaSupport.createHover('item-gradient-5.gif', 30);
		this._hover.strokecolor = "#D8F0FA";
		this._select = VistaSupport.createHover('item-gradient-5.gif', 30);
	}
	
	return l;
}

proto.storeData = function(xmldoc)
{
	var data = null;
	var selectionData = null;
	
	var nodes = Util.xmlSelectNodes(this.changedFragment, "*");
	if(nodes.length > 0)
	{
		data = this.changedFragment.cloneNode(true);
		
		// Make it clean.
		this.changedFragment = this.changedNodesDoc.createDocumentFragment();
	}

	if(this._selectionDirty && this._selectedNodeIndex !== null)
	{
		selectionData = xmldoc.createElement("treeview");
		selectionData.setAttribute("selection", this._selectedNodeIndex);
	}

	var fragment = xmldoc.createDocumentFragment();
	if(data) fragment.appendChild(data);
	if(selectionData) fragment.appendChild(selectionData);

	this._selectionDirty = false;
	
	return fragment;
}

proto.loadData = function(node)
{
	if(this._dragging) return;

	this._selectionDirty = false;
	
	var attr = node.getAttribute("readOnly");
	if(attr) this.set_readOnly(attr == "true");

	var nodes = Util.xmlSelectNodes(node, "node");
	var count = nodes.length;

	if(nodes.length > 0 || Util.xmlSelectSingleNode(node, "nonodes"))	
	{
		if(CNFormManager.vista)
		{
			Util.removeElement(this._hover);
			Util.removeElement(this._select);
			if(this._hoverPM) Util.removeElement(this._hoverPM);
		}
		
		this.selectedNodeDiv = null;
		this._selectedNodeIndex = "";
		this.element.children["content"].innerHTML = "";
	}

	if(nodes.length > 0)
	{
		this.buildNodes(nodes, this.element.children["content"], 0, this._rootType);
	}
	
	attr = node.getAttribute("allowClearSelection");
	if(attr) this._allowClearSelection = attr == "true";

	attr = node.getAttribute("selection");
	if(attr) 
	{
		this._setTimeout_set_selectedNodeIndex(String(attr));
	}
	
	attr = node.getAttribute("dragDrop");
	if(attr) this.allowNodeDrag = attr == "true";
	
	if(node.getAttribute("beginEdit") == "true" && 	this.selectedNodeDiv)
	{
		this.beginEditLabel(this.selectedNodeDiv);
		this._doPostbackOnEditEnd = true;
	}
}

proto._setTimeout_set_selectedNodeIndex = function(value)
{
	var obj = this;
	obj._selectedNodeIndex = ""; 
	obj.set_selectedNodeIndex(value);
}

proto.buildElement = function(node)
{
	if(this.isReady) return;
	
	this._set_disabled();

	//var attr = node.getAttribute("collectChanges");
	//if(attr) this._collectChanges = attr == "true";

	if(this._collectChanges) 
	{
		this.changedNodesDoc = Util.createXMLDocument();
		this.changedFragment = this.changedNodesDoc.createDocumentFragment();
	}

	attr = node.getAttribute("showRootLines");
	if(attr) this._showRootLines = attr == "true";

	attr = node.getAttribute("showLines");
	if(attr) this._showLines = attr == "true";

	attr = node.getAttribute("selectExpands");
	if(attr) this._selectExpands = attr == "true";

	attr = node.getAttribute("showPlus");
	if(attr) this._showPlus = attr == "true";
	
	this.nodeDivTemplate = this.prebuildNodeTemplate();

	this.initializeNodeTypes(node);
	
	attr = node.getAttribute("childType");
	if(attr) this.childType = String(attr);

	var rootType = {};
	if(this.childType) 
	{
		var type = this.nodeTypes[this.childType];
		if(type) rootType = type.typeObject;
	}
	this._rootType = this.getOverridenTypeObject(rootType, node);
	if(node.getAttribute("checkBoxes")) 
	{
		this._rootType.checkBox = this.nodeTypes["__folder"].checkBox = "true";
	}
	
	Event.add(this.element, "mouseleave", this, this._element_onmouseleave);
	Event.add(this.element, "mouseup", this, this._element_onmouseup);

	this.isReady = true;
	
	this._set_expandLevel();
	this._set_selectedNodeIndex();
}

proto.initializeNodeTypes = function(node)
{
	var types = Util.xmlSelectNodes(node, "nodetype");
	var count = types.length;
	for(var i = 0; i < count; i++)
	{
		var typeNode = types[i];
		var typeObject = this.getOverridenTypeObject({}, typeNode);
		this.nodeTypes[String(typeNode.getAttribute("type"))] = typeObject;
	}
	
	// Built-in type.
	this.nodeTypes["__folder"] = {}//{collapsedImage: CNFormManager.themeImagesPath + "fold.gif", expandedImage: CNFormManager.themeImagesPath + "openfold.gif"};
}

proto.getOverridenTypeObject = function(typeObj, l)
{
	var result = null;
	for(var i = 0; i < this.typeAttributes.length; i++)
	{
		var attrName = this.typeAttributes[i];
		var attr = null;
		if(l instanceof Object) attr = l[attrName];
		else attr = l.getAttribute(attrName);
		if(attr != null)
		{
			if(result == null) result = this.cloneObject(typeObj);
			result[attrName] = String(attr);
		}
	}
	if(result == null) return typeObj;
	return result;
}

proto.buildNodes = function(nodes, parent, level, nodeType)
{
	if(!nodes) return;
	var nodesCount = nodes.length;
	for(var i = 0; i < nodesCount; i++)
	{
		this.buildNode(nodes[i], parent, level, i, nodeType);
	}
}

// NOTE: it's faster to always build all elements, even making theem invisible but without IDs, than
// optionally build with IDs specified.
proto.prebuildNodeTemplate = function()
{
	var nodeDiv = Util.createElementFromHTML("<div class=nodeDiv>");
	nodeDiv.isNodeDiv = true;
	
	var lineSpan = Util.createElementFromHTML("<span class=lineSpan>"); // 0 
	nodeDiv.appendChild(lineSpan);
	
	var pmSpan = Util.createElementFromHTML("<span class=plusMinusSpan>") // 1 
	nodeDiv.appendChild(pmSpan);
	
	var checkBoxSpan = Util.createElementFromHTML("<span class=checkBoxSpan>"); // 2 

	Event.add(checkBoxSpan, "click", this, this._checkBoxSpan_onclick);
	//Event.add(checkBoxSpan, "mousedown", this, CNUtil.cancelBubble);
	Event.add(checkBoxSpan, "dblclick", this, this._checkBoxSpan_onclick);	
	Event.add(checkBoxSpan, "mouseenter", this, this._checkBoxSpan_onmouseenter);
	Event.add(checkBoxSpan, "mouseleave", this, this._checkBoxSpan_onmouseleave);	
	nodeDiv.appendChild(checkBoxSpan);

	var icon = Util.createElementFromHTML("<img align=absmiddle class=iconImg>"); // 3 
	Event.add(icon, "mousedown", this, this._icon_textSpan_onclick);
	Event.add(icon, "dblclick", this, this._icon_textSpan_ondblclick);
	Event.add(icon, "mouseenter", this, this._icon_textSpan_onmouseenter);
	Event.add(icon, "mouseleave", this, this._icon_textSpan_onmouseleave);
	nodeDiv.appendChild(icon);
	
	var text = Util.createElementFromHTML("<span class=textSpan>"); // 4
	Event.add(text, "mousedown", this, this._icon_textSpan_onclick);
	Event.add(text, "dblclick", this, this._icon_textSpan_ondblclick);
	Event.add(text, "mouseenter", this, this._icon_textSpan_onmouseenter);
	Event.add(text, "mouseleave", this, this._icon_textSpan_onmouseleave);
	nodeDiv.appendChild(text);
	
	return nodeDiv;
}

proto.buildNode = function(node, parent, level, index, nodeType)
{
	var nodeDiv = this.nodeDivTemplate.cloneNode(true);
	
	nodeDiv.nodeIndex = index;
	node.setAttribute("nodeIndex", index);
	
	nodeDiv.node = node; // Watch for circular refs!
	nodeDiv.nodeLevel = level;
	node.setAttribute("nodeLevel", level);

	var tooltipAttr = node.getAttribute("tooltip");
	if(tooltipAttr) Tooltip.attach(nodeDiv, String(tooltipAttr));

	var children = nodeDiv.children;

	var disabled = false;
	if(node.getAttribute("enabled") == "false") disabled = nodeDiv.disabled = true; 
	
	var attr = node.getAttribute("dropType");
	if(attr && attr != "0") nodeDiv._dropType = String(attr);
	
	attr = node.getAttribute("dropToType");
	if(attr)
	{
		var ar = attr.split(/\s*,\s*/);
		var dropToTypeAr = [];
		for(var i = 0; i < ar.length; i++)
		{
			dropToTypeAr[ar[i]] = true;
		}
		nodeDiv._dropToType = dropToTypeAr;
	}
	
	// Default is true.
	nodeDiv._allowSort = node.getAttribute("allowSort") != "false";
	
	
	var attr = node.getAttribute("textColor");
	if(attr) children[this.ix_textSpan].style.color = attr;
	
	var realType = nodeType;

	var type = node.getAttribute("type");
	if(type)
	{
		var type = this.nodeTypes[String(type)];
		if(type) realType = this.getOverridenTypeObject(realType, type);
	} 
	//else if(node.childNodes.length > 0)
	//{
	//	realType = this.nodeTypes["__folder"];
	//}
	
	realType = this.getOverridenTypeObject(realType, node);
	nodeDiv.type = realType;
	
	this.buildLine(nodeDiv, node, children[this.ix_lineSpan], level);
	this.buildPM(node, children[this.ix_plusMinusSpan], level);

	var checkBoxSpan = children[this.ix_checkBoxSpan];

	var attr = node.getAttribute("checkBoxVisible");
	
	if(realType.checkBox == "true" && attr != "false"
	|| !realType.checkBox && attr == "true") 
	{
		if(this._vista)
		{
			var img = document.createElement("img");
			checkBoxSpan.appendChild(img);
			this._set_checked(img, disabled, this.isChecked(node), false, false, false);
		}
		else
			checkBoxSpan.innerHTML = this.isChecked(node) ? "&#254;" : "&#111";
	}
	else checkBoxSpan.style.display = "none";

	children[this.ix_textSpan].textContent = String(node.getAttribute("text"));
	
	parent.appendChild(nodeDiv);
	
	var childNodeType = nodeType;
	var childType = node.getAttribute("childType");
	if(childType)
	{
		var type = this.nodeTypes[String(childType)];
		// NOTE: completely new type, based on chilttype name.
		if(type) childNodeType = type.typeObject;
	}

	var expanded = this.isExpanded(node);
	this.updateImageToState(nodeDiv, expanded ? this.state_expanded : this.state_default);

	var subNodes = Util.xmlSelectNodes(node, "node");
	if(subNodes.length > 0) 
	{
		var containerDiv = this._createNodeContainer(parent);
		parent.appendChild(containerDiv);
		if(expanded) this.buildNodes(subNodes, containerDiv, level + 1, childNodeType);
		else 
		{
			containerDiv.style.display = "none";
			containerDiv.storedNodes = subNodes;
			containerDiv.storedType = childNodeType;
		}
	}

	parent.nodesBuilt = true;
	parent.storedNodes = null;
	
	return nodeDiv;
}

proto._set_checked = function(l, disabled, checked, hover, userAction, checkedChanged)
{
	var img;
	if(disabled)
		img = checked ? "checkedDisabledCheckbox.gif" : "uncheckedDisabledCheckbox.gif";
	else if(hover)
		img = checked ? "checkedHoverCheckbox.gif" : "uncheckedHoverCheckbox.gif";
	else
		img = checked ? "checkedCheckbox.gif" : "uncheckedCheckbox.gif";

	if(userAction || hover) 
	{
		VistaSupport.imageTrans(l, CNFormManager.themeImagesPath + img, checkedChanged);
	}
	else l.src = CNFormManager.themeImagesPath + img;
}

proto._createNodeContainer = function(parent)
{
	var containerDiv = Util.createElementFromHTML("<div class=treeContainerDiv>");
	containerDiv.style.userSelect = "none";
	containerDiv.isNodeContainer = true;
	return containerDiv;
}

proto._rebuildLine = function(nodeDiv)
{
	var lineSpan = nodeDiv.children[this.ix_lineSpan];
	var count = lineSpan.children.length;
	for(var i = count - 1; i >= 0; i--)
	{
		Util.removeElement(lineSpan.children[i]);
	}

	this.buildLine(nodeDiv, nodeDiv.node, lineSpan, parseInt(nodeDiv.node.getAttribute("nodeLevel"), 10));
}

proto._rebuildPM = function(nodeDiv)
{
	var pmSpan = nodeDiv.children[this.ix_plusMinusSpan];
	var count = pmSpan.children.length;
	for(var i = count - 1; i >= 0; i--)
	{
		Util.removeElement(pmSpan.children[i]);
	}

	Event.del(pmSpan, "mousedown", this, this._pmImg_onmousedown);
	Event.del(pmSpan, "dblclick", this, this._pmImg_onmousedown);		
	if(CNFormManager.vista)	Event.del(pmSpan, "mouseenter", this, this._pmImg_onmouseenter);
	this.buildPM(nodeDiv.node, pmSpan, parseInt(nodeDiv.node.getAttribute("nodeLevel"), 10))
}

proto.buildLine = function(nodeDiv, node, lineSpan, level)
{
	if(node.parentNode.tagName == "node")
	{
		var p = node.parentNode;
		while(this.isNode(p) && (p.getAttribute("nodeLevel") * 1 != 0 || this._showRootLines))
		{
			var lineImg = Util.createElementFromHTML("<img align=absmiddle width=" + this.lineImg_Width + " height=" + this.lineImg_Height + ">");
			lineImg._isLineImg = true;
			
			lineSpan.insertBefore(lineImg, lineSpan.firstChild);

			if(this._showLines && this.isNode(p.nextSibling)) lineImg.src = CNFormManager.themeImagesPath + "i.gif";
			else lineImg.src = CNFormManager.themeImagesPath + "white.gif";

			p = p.parentNode;
		}
	}
}

proto.buildPM = function(node, pmSpan, level)
{
	var pmImg = Util.createElementFromHTML("<img align=absmiddle width=" + this.lineImg_Width + " height=" + this.lineImg_Height + ">");
	pmSpan.appendChild(pmImg);

	var img = pmSpan.basePMImg = "";

	if(this._showPlus && (level > 0 || this._showRootLines == true))
	{
		if(this._showLines)
		{
			if(this.isNode(node.nextSibling)) 
			{
				if(!this.isNode(node.previousSibling) && !this.isNode(node.parentNode)) img = "f";
				else img = "t";
			}
			else if(this.isNode(node.previousSibling) || this.isNode(node.parentNode)) img = "l";
			else img = "r";
			
			pmSpan.basePMImg = img;
		}

		if(node.childNodes.length > 0)
		{
			if(this.isExpanded(node)) img += "minus";
			else img += "plus";
			
			// NOTE: it's important to remove all events in rebuildPM.
			Event.add(pmSpan, "mousedown", this, this._pmImg_onmousedown);
			Event.add(pmSpan, "dblclick", this, this._pmImg_onmousedown);		
			if(CNFormManager.vista)	Event.add(pmSpan, "mouseenter", this, this._pmImg_onmouseenter);
		}

		if(img.length == 0) img = "white";

		pmImg.src = CNFormManager.themeImagesPath + img + ".gif";
	}
	else
	{
		pmImg.style.display = "none";
	}
}

proto._syncHover = function(l, hover)
{
	l.style.position = "relative";
	l.appendChild(hover);
	hover.style.width = (l.offsetWidth + 2) + "px";
	hover.style.height = l.offsetHeight + "px";
	hover.style.visibility = "inherit";
}

proto.hoverNodeDiv = function(l)
{
	if(CNFormManager.vista)
	{
		this._syncHover(l.children[this.ix_textSpan], this._hover);
	}
	else if(this.selectedNodeDiv != l) l.className = "nodeDivOver";
}

proto.unhoverNodeDiv = function(l)
{
	if(CNFormManager.vista)
	{
		this._hover.style.visibility = "hidden";
		// Can't make static as node can be hovered.
		//l.children[this.ix_textSpan].style.position = "static"; 
	}
	else
	{
		if(this.selectedNodeDiv != l) l.className = "nodeDiv";
		else l.className = "nodeDivSelected";
	}
}

proto.selectNodeDiv = function(l, userClick)
{
	if(!l || this.selectedNodeDiv == l) return;
	var oldTreeNodeIndex = "";
	oldTreeNodeIndex = this._selectedNodeIndex;
	
	this.unselectNodeDiv();

	if(CNFormManager.vista)
	{
		this._syncHover(l.children[this.ix_textSpan], this._select);
	}
	else l.className = "nodeDivSelected";
	this.selectedNodeDiv = l;
	this._selectedNodeIndex = this.getDottedIndex(l);
	
	this.updateImage(l);
	
	if(userClick) 
	{
		if(!this._readOnly)
		{
			this._selectionDirty = true;
			
			if(this.onselectedindexchange) 
			{
				if(Event.current() && Event.current().button == 2 && this._autoPostBack)
				{
					// Set context menu to pending mode.
					var fm = CNFormManager.getActiveFormManager();
					fm.contextMenuPending = true;
				}
			
				var ev = {};
				ev.newTreeNodeIndex = this._selectedNodeIndex;
				ev.oldTreeNodeIndex = oldTreeNodeIndex;
				ev.node = l.node;
				ev.nodeDiv = l;

				this._pending_onselectedindexchangeEV = ev;
				Event.add(l, "mouseup", this, this._pending_node_onmouseup);
			}
		}
	}
	else
	{
		this.scrollToSelectedTO();
	}
}

proto._pending_node_onmouseup = function()
{
	var jso = CNUtil.dispatchObject();
	if(jso) jso._handle_onselectedindexchangeTO();
}

proto._handle_onselectedindexchangeTO = function()
{
	if(!this._pending_onselectedindexchangeEV) return;
	Event.del(this._pending_onselectedindexchangeEV.nodeDiv, "mouseup", this, this._pending_node_onmouseup);
	this.onselectedindexchange(this._pending_onselectedindexchangeEV);
	this._pending_onselectedindexchangeEV = null;
}

proto.scrollToSelectedTO = function()
{
	var obj = this;
	setTimeout(function(){ obj.scrollToSelected(); }, 50);
}

proto.updateImage = function(nodeDiv)
{
	var state = this.state_default;
	var expanded = this.isExpanded(nodeDiv.node);
	var selected = nodeDiv == this.selectedNodeDiv;
	if(expanded && selected) state = this.state_expandedSelected;
	else if(expanded) state = this.state_expanded;
	else if(selected) state = this.state_selected;
	this.updateImageToState(nodeDiv, state);
}

proto.updateImageToState = function(nodeDiv, state)
{
	var icon = nodeDiv.children[this.ix_iconImg];
	var type = nodeDiv.type;
	var img;

	if(state == this.state_expandedSelected)
	{
		if(type.expandedImage) img = type.expandedImage;
		else if(type.selectedImage) img = type.selectedImage;
		if(!img) img = type.collapsedImage;
	}
	else if(state == this.state_expanded)
	{
		img = type.expandedImage;
		if(!img) img = type.collapsedImage;
	}
	else if(state == this.state_selected)
	{
		if(!type.expandedImage) img = type.selectedImage;
		else img = type.collapsedImage;
		if(!img) img = type.collapsedImage;
	}
	else if(state == this.state_default) img = type.collapsedImage;

	if(!icon) return;
	
	if(img) 
	{
		icon.src = img;
		icon.style.display = "inline";		
	}
	else icon.style.display = "none";
}

proto.scrollToSelected = function()
{
	var content = this.element.children["content"];
	// Adjust scroll position.
	var xy = CNUtil.findAbsolutePos(this.selectedNodeDiv, content, true);
	content.scrollLeft = xy.x;
	content.scrollTop = xy.y;
}

proto.unselectNodeDiv = function()
{
	if(this.selectedNodeDiv == null) return;
	var l = this.selectedNodeDiv;
	if(CNFormManager.vista) 
	{
		this._select.style.visibility = "hidden";
		//l.children[this.ix_textSpan].style.position = "static";
	}
	else l.className = "nodeDiv";

	this.selectedNodeDiv = null;
	this._selectedNodeIndex = '';
	this.updateImage(l);
}

proto.toggleExpand = function(nodeDiv, userClick)
{
	this.expandCollapse(nodeDiv, !this.isExpanded(nodeDiv.node), userClick);
}

proto.expand = function(nodeDiv)
{
	this.expandCollapse(nodeDiv, true, false);
}

proto.collapse = function(nodeDiv)
{
	this.expandCollapse(nodeDiv, false, false);
}

proto.expandCollapse = function(nodeDiv, expand, userClick)
{
	var cont = nodeDiv.nextSibling;
	if(!cont || !cont.isNodeContainer) return;

	if(!expand && (!cont.nodesBuilt || !this.isExpanded(nodeDiv.node))) return;

	if(!cont.nodesBuilt)
	{
		if(expand) 
		{
			if(CNFormManager.vista && userClick) cont.style.visibility = "hidden";
			cont.style.display = "block";
			this.buildNodes(cont.storedNodes, cont, nodeDiv.nodeLevel + 1, cont.storedType);
		}
	}
	else 
	{
		if(userClick && CNFormManager.vista)
		{
			if(expand) cont.style.display = "block";
			else
			{
				cont.style.overflow = "hidden";
				var anim = new AnimResize(cont, cont.offsetWidth, 1);
				Animator.start(anim);
				anim.onend = function()
				{
					cont.style.height = "auto";
					cont.style.overflow = "";
					cont.style.display = "none";					
				};
			}
		}
		else cont.style.display = expand ? "block" : "none";
	}
	
	if(userClick && expand && CNFormManager.vista)
	{
		var h = cont.offsetHeight;
		cont.style.height = "1px";
		cont.style.overflow = "hidden";
		cont.style.visibility = "visible";
		var anim = new AnimResize(cont, cont.offsetWidth, h);
		Animator.start(anim);
		anim.onend = function()
		{
			cont.style.height = "auto";
			cont.style.overflow = "";
		};
	}

	if(cont.children.length == 0) return;

	var node = nodeDiv.node;
	node.setAttribute("expanded", expand ? "true" : "false");
	
	var pmSpan = nodeDiv.children[this.ix_plusMinusSpan];
	pmSpan.children[0].src = CNFormManager.themeImagesPath + pmSpan.basePMImg 
										+ (expand ? "minus" : "plus") + ".gif";

	this.updateImage(nodeDiv);
										
	var nodeIndex = this.getDottedIndex(nodeDiv);
	
	if(userClick)
	{
		if(this.selectedNodeDiv && cont.contains(this.selectedNodeDiv)) this.selectNodeDiv(nodeDiv, false);
		if(this._collectChanges) this.storeChangedNode(nodeIndex, "node", "expanded", expand, !expand);
	}

	var ev = {};
	ev.treeNodeIndex = nodeIndex;
	ev.node = nodeDiv.node;
	ev.expanded = expand;
	if(this.onexpandcollapse) this.onexpandcollapse(ev);
	
	if(userClick && this._autoPostBack)
	{
		this.formManager.postData(this.element);
	}
}

proto.expandNodes = function(rootNode, level)
{
	if(rootNode.nextSibling.isNodeContainer) this.expandContainers(l.nextSibling, level);
}

proto.expandContainers = function(root, level)
{
	if(level <= 0) return;

	var children = root.children;
	var count = children.length;
	for(var i = 0; i < count; i++)	
	{
		var l = children[i];
		if(l.isNodeDiv) this.expand(l);
		if(l.nextSibling && l.nextSibling.isNodeContainer) this.expandContainers(l.nextSibling, level - 1);
	}
}

proto.getDottedIndex = function(nodeDiv)
{
	return this.getNodeDottedIndex(nodeDiv.node);
}

proto.getNodeDottedIndex = function(p)
{
	var index = "";
	while(p != null && p.tagName == "node")
	{
		index = p.getAttribute("nodeIndex") + (index ? "."  + index : "");
		p = p.parentNode;
	}
	return index;
}

proto.storeChangedNode = function(nodeIndex, tagName, key, value, noStoreValue)
{
	tagName = "tree" + tagName;
	
	var node = Util.xmlSelectSingleNode(this.changedFragment, tagName + "[@node=\"" + nodeIndex + "\"]");
	var store = true;
	if(!node)
	{
		node = this.changedNodesDoc.createElement(tagName);
		node.setAttribute("node", nodeIndex);
		this.changedFragment.appendChild(node);
	}
	else
	{
		var ex = String(node.getAttribute(key));
		if(ex == String(noStoreValue)) store = false;
	}
	if(store) 
	{
		node.setAttribute(key, String(value));
	}
	else 
	{
		node.removeAttribute(key);
		// 1 == index.
		if(node.attributes.length == 1) node.parentNode.removeChild(node);
	}
}

proto.isNode = function(l)
{
	return l && l.tagName == "node";
}

proto.isExpanded = function(n)
{
	return n && String(n.getAttribute("expanded")) == "true";
}

proto.isChecked = function(n)
{
	return n && String(n.getAttribute("checked")) == "true";
}

proto.cloneObject = function(matrix)
{
	var obj = {};
	for(var i in matrix) obj[i] = matrix[i];
	return obj;
}


proto._moveNode = function(dragNodeDiv, dragTarget, dragTargetPos)
{
	if(dragTargetPos == -1 || dragNodeDiv == dragTarget) return;

	var cont = dragNodeDiv.nextSibling;
	if(cont && cont.isNodeContainer && cont.contains(dragTarget)) return;

	this.element.style.overflow = "hidden";
	
	var nodeLevel;
	if(dragTargetPos == 0) 
	{
		dragTarget.parentNode.insertBefore(dragNodeDiv, dragTarget);
		dragTarget.node.parentNode.insertBefore(dragNodeDiv.node, dragTarget.node);
		nodeLevel = parseInt(dragTarget.node.getAttribute("nodeLevel"), 10);
	}
	else if(dragTargetPos == 1) 
	{
		var realDragTarget = dragTarget;
		if(dragTarget.nextSibling && dragTarget.nextSibling.isNodeContainer) realDragTarget = dragTarget.nextSibling;
		realDragTarget.parentNode.insertBefore(dragNodeDiv, realDragTarget.nextSibling);
		dragTarget.node.parentNode.insertBefore(dragNodeDiv.node, dragTarget.node.nextSibling);
		nodeLevel = parseInt(dragTarget.node.getAttribute("nodeLevel"), 10);
	}
	else
	{
		dragTarget.node.appendChild(dragNodeDiv.node);

		var targetCont = dragTarget.nextSibling;
		if(!targetCont || !targetCont.isNodeContainer) 
		{
			targetCont = this._createNodeContainer(parent);
			targetCont.nodesBuilt = true;
			dragTarget.parentNode.insertBefore(targetCont, dragTarget.nextSibling);
			dragTarget.node.setAttribute("expanded", "true");
		}
		else if(!targetCont.nodesBuild)
		{
			this.buildNodes(targetCont.storedNodes, targetCont, dragTarget.nodeLevel + 1, targetCont.storedType);
		}
		targetCont.appendChild(dragNodeDiv);
		nodeLevel = parseInt(dragTarget.node.getAttribute("nodeLevel"), 10) + 1;
	}

	if(cont && cont.isNodeContainer) dragNodeDiv.parentNode.insertBefore(cont, dragNodeDiv.nextSibling);
	dragNodeDiv.node.setAttribute("nodeLevel", nodeLevel);

	this._refreshTree();
	
	if(this.onnodereordered) this.onnodereordered({jsObject: this, reorderedNodeDiv: dragNodeDiv});
	this.element.style.overflow = "";
}

proto._refreshTree = function()
{
	this._rebuildContainer(this.element.children["content"]);
}

proto.beginEditLabel = function(nodeDiv)
{
	if(CNFormManager.vista) 
	{
		Util.removeElement(this._select);
		Util.removeElement(this._hover)
	}

	var span = nodeDiv.children[this.ix_textSpan];
	span.className = "textEditSpan textSpan";

	span.contentEditable = true;
	Event.add(span, "select", this, this._span_onselect);
	Event.add(span, "blur", this, this._span_onblur);
	Event.add(span, "keydown", this, this._span_onkeydown);
	Event.add(span, "keyup", this, this._span_onkeyup);
	Event.add(span, "keypress", this, this._span_onkeypress);

	span.focus();
	var selection = window.getSelection();
	var range = document.createRange();
	range.selectNodeContents(span);
	selection.removeAllRanges();
	selection.addRange(range);
	
	this._currentEditLabel = nodeDiv;
}

proto.endEditLabel = function()
{
	var nodeDiv = this._currentEditLabel;
	if(!nodeDiv) return;
	this._currentEditLabel = null;
	var span = nodeDiv.children[this.ix_textSpan];
	
	Event.del(span, "select", this, this._span_onselect);
	Event.del(span, "blur", this, this._span_onblur);
	Event.del(span, "keydown", this, this._span_onkeydown);
	Event.del(span, "keyup", this, this._span_onkeyup);
	Event.del(span, "keypress", this, this._span_onkeypress);
	span.contentEditable = false;
	span.className = "textSpan";
	
	nodeDiv.node.setAttribute("text", span.textContent);

	if(document.activeElement == span) 
	{
		window.getSelection().removeAllRanges();
	}
	
	if(CNFormManager.vista)
	{
		// Reselect.
		var selected = this.selectedNodeDiv;
		if(selected)
		{
			this.selectedNodeDiv = null;
			this.selectNodeDiv(selected);
		}
	}
	
	
	if(this.onnoderenamed) this.onnoderenamed({jsObject: this, nodeDiv: nodeDiv});
}

proto._span_onselect = function()
{
	// Event cancellation is handled through preventDefault/stopPropagation.
	CNUtil.cancelBubble();
}

proto._span_onblur = function()
{
	CNUtil.dispatchObject().endEditLabel();
}

proto._span_onkeyup = function()
{
	var jsObject = CNUtil.dispatchObject();
	if(jsObject._pasted)
	{
		var span = jsObject._currentEditLabel.children[0];
		span.textContent = span.textContent;
	}
	jsObject._pasted = false;	
}

proto._span_onkeydown = function()
{
	var jsObject = CNUtil.dispatchObject();
	jsObject._pasted = false;
	// Disallow any WYSIWYG commands.
	if(!Event.current().ctrlKey) return;
	switch(Event.keyValue(Event.current()))
	{
		case 86: // V paste
			jsObject._pasted = true;
		case 67: // C copy
		case 88: // X cut
		case 37: // left
		case 38: // up
		case 39: // right
		case 40: // down
		case 36: // home
		case 35: // end
		case 45: // insert
		case 46: // del
			return;
	}
	CNUtil.cancelEvent();
}

proto._span_onkeypress = function()
{
	if(Event.keyValue(Event.current()) ==  13)
	{
		var jsObject = CNUtil.dispatchObject();
		jsObject.endEditLabel();
		CNUtil.cancelEvent();
	}
}

proto._rebuildContainer = function(cont)
{
	var children = cont.children;
	var count = children.length;
	var index = 0;
	for(var i = 0; i < count; i++)
	{
		var child = children[i];
		if(child.isNodeDiv)
		{
			this._rebuildLine(child);
			this._rebuildPM(child);
			child.node.setAttribute("nodeIndex", index);
			child.nodeIndex = index;
			index++;
		}
		else if(child.isNodeContainer && child.nodesBuilt)
		{
			this._rebuildContainer(child);
		}
	}
}

proto.addNode = function(parentNodeDiv, label, img)
{
	// Modify xml data.
	var node = parentNodeDiv.node;
	var newNode = node.ownerDocument.createElement("node");
	newNode.setAttribute("text", label);
	if(img) newNode.setAttribute("collapsedImage", img);
	node.appendChild(newNode);	

	// Modify 
	var cont = parentNodeDiv.nextSibling;
	if(!cont || !cont.isNodeContainer) 
	{
		cont = this._createNodeContainer(parent);
		cont.nodesBuilt = true;
		parentNodeDiv.parentNode.insertBefore(cont, parentNodeDiv.nextSibling);
		node.setAttribute("expanded", "true");
	}

	var nodeDiv = this.buildNode(newNode, cont, parentNodeDiv.nodeLevel + 1, 
								this._newNodeIndex--, this._rootType);
	
	this._refreshTree();
	
	return nodeDiv;
}

proto.deleteNode = function(nodeDiv)
{
	nodeDiv.node.parentNode.removeChild(nodeDiv.node);
	var cont = nodeDiv.nextSibling;
	if(cont && cont.isNodeContainer) Util.removeElement(cont);
	Util.removeElement(nodeDiv);

	this._refreshTree();
}


// Event handlers. ==================================
proto._element_onkeydown = function()
{
	CNUtil.dispatchObject().element_onkeydown();
}
proto.element_onkeydown = function()
{
	this._processTypedWord(Event.keyValue(Event.current()), false);
}

proto._processTypedWord = function(code, select)
{
	if(this._currentEditLabel) return;
	var firstNode = this.element.children["content"].firstChild;
	if(!firstNode) return;
	
	var now = new Date().getTime();
	if(!this._currentTypedWord 
	|| this._lastTypeStamp + this._typedSelectTimout <= now)
	{
		this._currentTypedWord = "";
	}
	this._lastTypeStamp = now;

	var ch = String.fromCharCode(code).toLowerCase();
	this._currentTypedWord += ch;
	
	var startNode = this.selectedNodeDiv;
	if(!startNode) 
	{
		this._seekNodes(firstNode.node, true);
	}
	else
	{
		if(!this._seekNodes(startNode.node, true))
		{
			this._seekNodes(firstNode.node, true);
		}
	}
}

/*proto._seekNodes = function(startNode, seekUp)
{
	while(startNode)
	{
		if((this._currentTypedWord.length != 1 || startNode != this.selectedNodeDiv.node)
			 //&& !startNode.disabled
		 )
		{
			if(startNode.isNodeDiv)
			{
				var text = startNode.children[4].textContent;
				if(text.toLowerCase().indexOf(this._currentTypedWord) == 0)
				{
					this.set_selectedNodeIndex(this.getDottedIndex(startNode), true);
					return true;
				}
			}
			else if(startNode.isNodeContainer)
			{
				if(this._seekNodes(startNode.firstChild, false)) return true;
			}
		}
		var nextNode = startNode.nextSibling;
		if(seekUp && nextNode == null)
		{
			var p = startNode;
			do
			{
				p = p.parentNode;
				if(p && p.isNodeContainer) nextNode = p.nextSibling;
				else break;
			}
			while(nextNode == null);	
		}
		startNode = nextNode;
	}
	return false;
}*/


proto._seekNodes = function(startNode, seekUp)
{
	while(startNode && startNode.nodeType == 1)
	{
		if((this._currentTypedWord.lhellhength != 1 
			|| this.selectedNodeDiv == null || startNode != this.selectedNodeDiv.node))
		{
			var text = startNode.getAttribute("text");
			if(text != null && text.toLowerCase().indexOf(this._currentTypedWord) == 0)
			{
				// Node index is unknown probably.
				if(this._selectNode(startNode)) return true;
			}
		}
		if(startNode.childNodes.length > 0)
		{
			if(this._seekNodes(startNode.firstChild, false)) return true;
		}

		var nextNode = startNode.nextSibling;
		if(seekUp && nextNode == null)
		{
			var p = startNode;
			do
			{
				p = p.parentNode;
				if(p && p.tagName == "node") nextNode = p.nextSibling;
				else break;
			}
			while(nextNode == null);	
		}
		startNode = nextNode;
	}
	return false;
}

proto._selectNode = function(node)
{
	var builtNode = node;
	var ni = null;
	var upperNodes = [];
	while(builtNode && (ni = builtNode.getAttribute("nodeIndex")) == null)
	{
		upperNodes.push(builtNode);
		builtNode = builtNode.parentNode;
	}
	
	if(builtNode == null || ni == null) 
	{
		alert("ASSERT: can't select by xml node");
		return true;
	}
	
	for(var i = upperNodes.length - 1; i >= 0; i--)
	{
		var index = this.getNodeDottedIndex(upperNodes[i]);
		var p = this._findAndExpandByNodeIndex(index);
	}
	
	return this.set_selectedNodeIndex(this.getNodeDottedIndex(node), true, true);
}

proto._content_onmousedown = function()
{
	var jso = CNUtil.dispatchObject();
	if(jso) jso.content_onmousedown();
}
proto.content_onmousedown = function()
{
	if(this._disabled || !this._allowClearSelection || this.selectedNodeDiv == null
	|| this._currentEditLabel != null) return;
	var l = CNUtil.eventTarget();
	if(l.className != 'nodeDiv' && l.className != 'nodeDivSelected' && l.id != 'content') 
	{
		return;
	}
	var content = this.element.children['content'];
	var bounds = content.getBoundingClientRect();
	if(Event.current().clientX >= bounds.left + content.clientWidth ||
		Event.current().clientY >= bounds.top + content.clientHeight) return;
	
	this.unselectNodeDiv();
	this._selectionDirty = true;
	this._selectedNodeIndex = -1;
	var ev = {};
	this.onselectedindexchange(ev);
}

proto._checkBoxSpan_onclick = function()
{
	CNUtil.findJSObject(CNUtil.eventTarget()).checkBoxSpan_onclick();
}
proto.checkBoxSpan_onclick = function()
{
	if(this._readOnly || this._disabled) return;
	
	//CNUtil.cancelBubble();
	
	var l = Util.findByClassName(CNUtil.eventTarget(), "checkBoxSpan");
	var nodeDiv = CNUtil.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("enabled") == "false") return;
	var checked = !this.isChecked(nodeDiv.node);
	nodeDiv.node.setAttribute("checked", checked ? "true" : "false");
	if(this._vista) this._set_checked(l.firstChild, false, checked, true, true, true);	
	else l.innerHTML = checked ? "&#254;" : "&#111;";

	var ix = this.getDottedIndex(nodeDiv);

	if(this._collectChanges) this.storeChangedNode(ix, "nodecheckbox", "checked", checked, !checked);

	var ev = {};
	ev.treeNodeIndex = ix;
	ev.checked = checked;
	ev.node = nodeDiv.node;
	if(this.oncheck) this.oncheck(ev);
}

proto._checkBoxSpan_onmouseenter = function()
{
	var l = CNUtil.eventTarget();
	var jsObject = CNUtil.findJSObject(l);

	if(jsObject._readOnly || jsObject._disabled) return;
	if(jsObject._vista) 
	{
		var nodeDiv = CNUtil.findTag(l, "DIV");
		if(nodeDiv.node.getAttribute("enabled") == "false") return;
		var checked = jsObject.isChecked(nodeDiv.node);
		jsObject._set_checked(l.firstChild, false, checked, true, true, true);	
	}
	else l.style.color = Util.getStyle(l, "xl--hover-color");
}

proto._checkBoxSpan_onmouseleave = function()
{
	var l = CNUtil.eventTarget();
	var jsObject = CNUtil.findJSObject(l);

	if(jsObject._readOnly || jsObject._disabled) return;
	if(jsObject._vista) 
	{
		var nodeDiv = CNUtil.findTag(l, "DIV");
		if(nodeDiv.node.getAttribute("enabled") == "false") return;
		var checked = jsObject.isChecked(nodeDiv.node);
		jsObject._set_checked(l.firstChild, false, checked, false, true, true);	
	}
	else l.style.color = "";
}

proto._icon_textSpan_onclick = function()
{
	CNUtil.findJSObject(CNUtil.eventTarget()).icon_textSpan_onclick();
}
proto.icon_textSpan_onclick = function()
{
	//CNUtil.cancelBubble();
	var l = CNUtil.eventTarget();
	if(this._disabled) return;

	var nodeDiv = CNUtil.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("enabled") == "false") return;
	
	this.selectNodeDiv(nodeDiv, true);
	if(this._selectExpands && !this.isExpanded(nodeDiv.node)) this.expandCollapse(nodeDiv, true, true);
	
	this._mouseButtonPressed = true;
}

proto._icon_textSpan_ondblclick = function()
{
	CNUtil.findJSObject(CNUtil.eventTarget()).icon_textSpan_ondblclick();
}
proto.icon_textSpan_ondblclick = function()
{
	var l = CNUtil.eventTarget();
	if(this._disabled) return;
	var nodeDiv = CNUtil.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("enabled") == "false") return;
	
	this.selectNodeDiv(nodeDiv, true);
	this.toggleExpand(nodeDiv, true);
}

proto._icon_textSpan_onmouseenter = function()
{
	CNUtil.findJSObject(CNUtil.eventTarget()).icon_textSpan_onmouseenter();
}
proto.icon_textSpan_onmouseenter = function()
{
	var l = CNUtil.eventTarget();	
	if(this._disabled) return;
	var nodeDiv = CNUtil.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("enabled") == "false") return;

	this.hoverNodeDiv(nodeDiv);
}

proto._icon_textSpan_onmouseleave = function()
{
	CNUtil.findJSObject(CNUtil.eventTarget()).icon_textSpan_onmouseleave();
}
proto.icon_textSpan_onmouseleave = function()
{
	if(this._disabled) return;
	var l = CNUtil.eventTarget();
	var nodeDiv = CNUtil.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("enabled") == "false") return;

	this.unhoverNodeDiv(nodeDiv);
	
	// Drag-and-drop.
	if(this.allowNodeDrag && !this._dragging && this._mouseButtonPressed && this.selectedNodeDiv == nodeDiv
	&& !nodeDiv._noDrag)
	{
		this._dragging = true;
		
		this._insertCursor = Util.createElementFromHTML("<div class=insertCursor>");
		this._insertCursor.style.userSelect = "none";
		this._insertCursor.style.position = "absolute";
		this._insertCursor.style.top = "-10px";
		this._insertCursor.style.left = "-10px";
		this.element.appendChild(this._insertCursor);

		var dragged = document.createElement("span");
		dragged.style.position = "absolute";
		dragged.style.userSelect = "none";
		
		dragged.textContent = nodeDiv.children[4].textContent;
		dragged.className = "draggedNode"
		this.element.appendChild(dragged);
		
		this._dragged = dragged;
		this._dragNodeDiv = nodeDiv;
		
		var xy = CNUtil.findAbsolutePos(nodeDiv.children[4], this.element);

		this._startX = xy.x - Event.current().screenX;
		this._startY = xy.y - Event.current().screenY;

		dragged.style.top = (xy.y - this._content.scrollTop) + "px";
		dragged.style.left = (xy.x - this._content.scrollLeft) + "px";

		Event.add(document, "mousemove", this, this.element_onmousemove);
		Event.add(document, "mouseup", this, this.element_onmouseup);
	}
}

proto._element_onmousemove = function()
{
	var jsObject = CNUtil.dispatchObject();
	if(jsObject) jsObject.element_onmousemove();
}
proto.element_onmousemove = function()
{
	if(this._disabled) return;
	this._dragged.style.left = (this._startX + Event.current().screenX - this._content.scrollLeft) + "px";
	this._dragged.style.top = (this._startY + Event.current().screenY - this._content.scrollTop) + "px";

	this._insertCursor.style.display = "none";
	this._dragged.style.display = "none";
	var l = document.elementFromPoint(Event.current().clientX, Event.current().clientY);
	this._dragged.style.display = "block";
	this._insertCursor.style.display = "block";
	
	if(!l) return;

	if(l != this.element.children["content"])
	{
		var nodeDiv = CNUtil.findTag(l, "DIV");
		if(nodeDiv && nodeDiv.isNodeDiv)
		{
			this._dragTarget = nodeDiv;
	
			var textElement = nodeDiv.children[4];
			
			this._dehighlightTextElement();
		
			var xy = CNUtil.findAbsolutePos(textElement, this.element);
			var clientXY = CNUtil.findAbsolutePos(textElement);
					
			if(Event.current().clientY < clientXY.y + 5 - this._content.scrollTop)
			{
				this._insertCursor.style.visibility = "inherit";
				this._insertCursor.style.top = (xy.y - 2 - this._content.scrollTop) + "px"; 
				this._dragTargetPos = 0;
			}
			else if(Event.current().clientY >= clientXY.y + 5 - this._content.scrollTop && Event.current().clientY < clientXY.y + 15 - this._content.scrollTop)
			{
				this._insertCursor.style.visibility = "hidden";
				// Put as a child.
				this._dragTargetPos = 2;
				textElement.style.background = Util.getStyle(this.element, "xl--drag-over-background");
				this._highlightedTextElement = textElement;
			}
			else
			{
				this._insertCursor.style.visibility = "inherit";
				this._insertCursor.style.top = (xy.y + textElement.offsetHeight - this._content.scrollTop) + "px";
				this._dragTargetPos = 1;
			}
	
			this._insertCursor.style.width = (textElement.offsetWidth + 10) + "px";		
			this._insertCursor.style.left = (xy.x - 5 - this._content.scrollLeft) + "px";
	
			var cont = this._dragNodeDiv.nextSibling;
			
			if(cont && cont.isNodeContainer && cont.contains(this._dragTarget)
			|| !this.onnodereorderallowed({draggedNodeDiv: this._dragNodeDiv, dragTarget: this._dragTarget, dragTargetPos: this._dragTargetPos}))
			{
				this._dragTargetPos = -1;
				this.element.style.cursor = "not-allowed";
			}
			else
			{
				this.element.style.cursor = "default";
			}
		}
	}
}

proto._dehighlightTextElement = function()
{
	if(this._highlightedTextElement)
	{
		this._highlightedTextElement.style.background = "";
		this._highlightedTextElement = null;
	}
}

proto._element_onmouseup = function()
{
	var jsObject = CNUtil.dispatchObject();
	if(jsObject) jsObject.element_onmouseup();
}
proto.element_onmouseup = function()
{
	if(this._disabled) return;
	this._mouseButtonPressed = false;
	if(this._dragging) 
	{
		if(this._dragTarget) this._moveNode(this._dragNodeDiv, this._dragTarget, this._dragTargetPos);

		this.element_onlosecapture();
	}
}

proto._element_onlosecapture = function()
{
	CNUtil.dispatchObject().element_onlosecapture();
}
proto.element_onlosecapture = function()
{
	Event.del(document, "mousemove", this, this.element_onmousemove);
	Event.del(document, "mouseup", this, this.element_onmouseup);
	
	this._dehighlightTextElement();
	this.element.style.cursor = "default";
	
	Util.removeElement(this._insertCursor);
	this._insertCursor = null;
	
	Util.removeElement(this._dragged);
	
	this._dragTarget = null;
	this._dragNodeDiv = null;

	this._mouseButtonPressed = false;
	this._dragging = false;
	this._dragged = null;
	
	// Check for pending selection event.
	if(this._pending_onselectedindexchangeEV) this._handle_onselectedindexchangeTO();
}

proto._pmImg_onmousedown = function()
{
	var jso = CNUtil.findJSObject(CNUtil.eventTarget());
	if(jso) jso.pmImg_onmousedown();
}
proto.pmImg_onmousedown = function()
{
	if(Event.current().button != 0 && Event.current().button != 1) return;
	var l = CNUtil.eventTarget();
	var div = CNUtil.findTag(l, "DIV");
	this.toggleExpand(div, true);
	if(CNFormManager.vista)
	{
		var span = div.children[this.ix_plusMinusSpan];
		var expanded = this.isExpanded(div.node);
		var hoverIMG = span.lastChild;
		if(hoverIMG._hover) hoverIMG.src = expanded ? "themes/vista/g/hover-minus.gif" : "themes/vista/g/hover-plus.gif";
	}
}

proto._pmImg_onmouseenter = function()
{
	var div = Util.findTag(CNUtil.eventTarget(), "DIV");
	var jso = Util.findJSObject(div);
	var span = div.children[jso.ix_plusMinusSpan];
	if(span.lastChild._hover) return;
	
	//span.style.border = "1px solid red";
	
	var expanded = jso.isExpanded(div.node);
	var hoverIMG = document.createElement("img");
	span.style.position = "relative";
	hoverIMG._hover = true;
	hoverIMG.src = expanded ? "themes/vista/g/hover-minus.gif" : "themes/vista/g/hover-plus.gif";
	hoverIMG.style.position = "absolute";
	hoverIMG.style.left = "5px";
	hoverIMG.style.top = "5px";
	span.appendChild(hoverIMG);
	Event.add(span, "mouseleave", this, jso._pmImg_onmouseleave);
	jso._hoverPM = hoverIMG;
}
proto._pmImg_onmouseleave = function()
{
	var span = CNUtil.eventTarget();
	var jso = Util.findJSObject(span);
	Event.del(span, "mouseleave", this, jso._pmImg_onmouseleave);
//	span.style.position = "static"; // Commented as this makes hover to be misaligned to the right.
	if(span.lastChild && span.lastChild._hover) Util.removeElement(span.lastChild);
	jso._hoverPM = null;
}


proto._element_onmouseleave = function()
{
	var jsObject = CNUtil.dispatchObject();
	if(jsObject) jsObject.element_onmouseleave();
}
proto.element_onmouseleave = function()
{
	// Reset.
	this._mouseButtonPressed = false;
	
	// Document listeners keep the drag active after the pointer leaves the tree.
}


// Properties. ===================================
proto.set_readOnly = function(value)
{
	this._readOnly = Util.parseBoolean(value);
	this.element.style.backgroundColor = 
		this._disabled || this._readOnly ? Util.getStyle(this.element, "xl--disabled-background") : "";
}

proto.set_selectedNodeIndex = function(value, userClick, doNotSelectDisabled)
{
	if(this._selectedNodeIndex == value) return;
	this._selectedNodeIndex = value;
	if(!this.isReady) return true;
	return this._set_selectedNodeIndex(userClick, doNotSelectDisabled);
}

proto._set_selectedNodeIndex = function(userClick, doNotSelectDisabled)
{
	if(this._selectedNodeIndex == "" || parseInt(this._selectedNodeIndex) == -1)
	{
		this.unselectNodeDiv();
		return;
	}
	var p = this._findAndExpandByNodeIndex(this._selectedNodeIndex);

	if(p && (!doNotSelectDisabled || !p.disabled))
	{
		this.selectNodeDiv(p, userClick);
		return true;
	}
	return false;
}

proto._findAndExpandByNodeIndex = function(index)
{
	var ar = index.split(".");
	if(ar.length == 0) 
	{
		alert("ASSERT: _set_selectedNodeIndex: ar.length == 0");
		return null;
	}
	var p = this.element.children["content"];

	for(var i = 0; i < ar.length; i++)
	{
		if(!p) return;
		this.expand(p);

		var oldp = p;
		var index = parseInt(ar[i]);

		if(p.nextSibling && p.nextSibling.isNodeContainer) p = p.nextSibling;
		var count = p.children.length;
		for(var j = 0; j < count; j++)
		{
			if(parseInt(p.children[j].nodeIndex) == index)
			{
				p = p.children[j];
				break;
			}
		}
		if(p == oldp) 
		{
			alert("ASSERT: No such index: " + this._selectedNodeIndex);
			return null;
		}
	}
	if(p.isNodeContainer) p = p.previousSibling;
	return p;
}

proto.set_disabled = function(value)
{
	value = Util.parseBoolean(value);
	if(this._disabled == value) return;
	this._disabled = value;

	if(!this.isReady) return;
	this._set_disabled();
}

proto._set_disabled = function()
{
//	this.disabler.style.visibility = this._disabled ? "inherit" : "hidden";
	this.element.style.backgroundColor = 
		this._disabled || this._readOnly ? Util.getStyle(this.element, "xl--disabled-background") : "";
	var content = this.element.children[0];
	content.style.opacity = this._disabled ? "0.5" : "";
}

proto.set_expandLevel = function(value)
{
	if(this._expandLevel == value) return;
	this._expandLevel = value * 1;
	if(this.isReady) this._set_expandLevel()
}

proto._set_expandLevel = function()
{
	if(this._expandLevel > 0) this.expandContainers(this.element.children["content"], this._expandLevel);
}

proto.get_changedNodesDOM = function()
{
	return this.changedFragment;
}

/*
	#1049 - new isValid for DateTimeBox cell.
	#1036-4 - ev.isDirty processed now by Combo/MutableCombo
	#1036-3 proxyTabKeyDown
	v. 2.0.19
	#1023 - added firstChild = span which holds text value for StringTypeCell and derived. This helps to avoid content from hidden box in the cell.
	+ to allow persistant focused cell, edit mode box is not removed, but hidden. Box removal from DOM causes focus to be moved
      to document.body on next rendering pass, which sometimes happens in 100-150ms or more 
      i.e. not resilient to setTimeouts focusing).
	+ enabled fixCombo back for readOnly grid state change.
	+ header height respected now.
	+ worker reactivated.
	+ vista support.
	+ added anchoring resize optimization - no visible extra columns resize.
	+ walkCells for readOnly (ComboBox/MutableCombobox set_readOnly)
	+ double focus to outer element on focus-out from grid.
	+ wraptext border fix.
	+ <c> readOnly.
	+ <col> data support.
	+ textcolor/backcolor for cells.
	+ ...
	+ searchable combo support.
	+ comment maxLength.

	TypeCell defenition/interface:
		var TYPE_NAME = CN_grid.CellTypes["GRID_TYPE_ID"] = function(colTag, grid);
		TYPE_NAME.cn_tagName = "TAG_NAME"; - Optional: if setChangedValue() used.
		var wp = TYPE_NAME.prototype;
		wp.isValid = function(cell); - Returns true|false, checked when grid is submitted, all cells called.
		wp.prerender = function(cell, colTag);
		wp.render = function(cell, node);
		wp.set_readOnly = function(cell, readOnly);
*/
function CN_grid()
{
   	this.formManager = null;
	this.captionAlign = "left";
	this.headerHeight = 24;
	this.alternateBackcolor = "";
	this.cssPath = "css";

	this.rowsPerFill = 100;
	this.fillTimeout = 10;
	this.continuousFillThreshold = 100;
	this.showTiming = false;
	this.alwaysScrollToSelected = true;
	this.storeScrollState = true;

	this._rowHeight = 23;
	this._gridLines = "both";

	this._selectedRow = -1;
	this._readOnly = false;

	this._selectorVisible = true;

	this.xml = null;
	this.templateRow = null;
	
	this.cellRenderers = [];
	this.colTags = null;
	
	this.filledRows = 0;
	this.startDataCell = 1;
	
	this.rowsNodes = null;
	
	this.selectedTR = null;
	this.isReady = false;
	
	this.cssRules = null;
	
	this.totalTime = 0;
	this.prebuildTime = 0;
	this.fillTime = 0;
	
	this.normHeaderRowTO = null;
	this._startRow = null;
	this._endRow = null;
	this.rowIndex = 0;
	
	this.doLoadStateAfterFill = true;
	this._pendingSelectedRow = null;
	
	this._postingCellXY = null;
	this._elementWidth = 0;

	// Tree.
	this.childType = null;
	
	this.folderTemplateRow = null;
	this._showPlus = true;
	this._showRootLines = true;
	this._showLines = true;
	this._selectExpands = true;

	this.lineImg_Width = 19;
	this.lineImg_Height = 21;

	this.tree_nodeTypes = [];
	this.tree_rootType = null;

	this.state_default = 0;
	this.state_selected = 1;
	this.state_expanded = 2;
	this.state_expandedSelected = 3;

	this.ix_lineSpan = 0;
	this.ix_plusMinusSpan = 1;
	this.ix_checkBoxSpan = 2;
	this.ix_iconImg = 3;
	this.ix_textSpan = 4;

	this.tree_selectedNodeDiv = null;
	
	this.tree_inited = false;
	
	this._jsObjects = [];
	
	this._currentSort_hcell = null;

//	this._skipNextFocus = false;
	this._tagPrefix = "grid";
	
	this._treeAutoPostBack = false;	
	
	this._allowClearSelection = false;
	this._resetScrollPosition = false;
	
	this._maxFooterHeight = Number.MAX_VALUE;
	
	this._requiresReadOnlyWalk = false;
	//this._unscrollableCols = 0;
	this._resizeCounter = 0;

	this._rowBorderOffset = 0;
	this._vista = CNFormManager.vista; // Speed up variable access.
	if(this._vista) this._rowBorderOffset = 1;
	
	this._headerLayedout = false;
	
	this._enableBlinkDivs = [];
	this._removeBlinkDivs = [];
}
CN_grid.SORT_NONE = 0;
CN_grid.SORT_AUTO = 1;
CN_grid.SORT_MANUAL = 2;

CN_grid.CellTypes = [];


// Standards-browser boundary for the historical grid control.
// The grid still exposes its old handler names, but all native registration,
// event lookup, element creation, and selection behavior pass through here.
CN_grid.currentEvent = function() {
	return (typeof Event != "undefined" && Event.current) ? Event.current() : null;
}
CN_grid.relatedTarget = function() {
	var ev = CN_grid.currentEvent();
	return ev ? (ev.relatedTarget || null) : null;
}
CN_grid.addEvent = function(element, eventName, handler, context) {
	if(!element || !handler) return null;
	if(eventName == "transitionend") return null;
	return Event.add(element, eventName, context || element, handler);
}
CN_grid.removeEvent = function(element, eventName, handler, context) {
	if(!element || !handler) return false;
	if(eventName == "transitionend") return false;
	return Event.del(element, eventName, context || element, handler);
}
CN_grid.descendants = function(root) {
	if(!root) return [];
	if(root.getElementsByTagName) return root.getElementsByTagName("*");
	return root.children || root.childNodes || [];
}
CN_grid.readClipboardText = function() {
	var ev = CN_grid.currentEvent();
	var clipboard = ev && ev.clipboardData;
	if(clipboard && clipboard.getData) return clipboard.getData("text/plain") || clipboard.getData("Text") || "";
	return "";
}
CN_grid.insertTextAtSelection = function(text) {
	if(typeof window == "undefined" || typeof window.getSelection != "function") return false;
	var selection = window.getSelection();
	if(!selection || selection.rangeCount == 0) return false;
	var range = selection.getRangeAt(0);
	range.deleteContents();
	var node = document.createTextNode(String(text));
	range.insertNode(node);
	range.setStartAfter(node);
	range.collapse(true);
	selection.removeAllRanges();
	selection.addRange(range);
	return true;
}
CN_grid.dispatchEvent = function(element, eventName) {
	if(!element || !element.dispatchEvent || typeof document == "undefined") return false;
	var ev = document.createEvent ? document.createEvent("Event") : null;
	if(!ev) return false;
	ev.initEvent(eventName, true, true);
	return element.dispatchEvent(ev);
}

CN_grid.fullRowSelect = false;
CN_grid._pendingCombo = null;
CN_grid._openPendingCombo = function()
{
	if(CN_grid._pendingCombo == null) return;

	CN_grid._pendingCombo.jsObject.element = CN_grid._pendingCombo.element;
	CN_combobox.pendingCombobox = CN_grid._pendingCombo.jsObject;
	var obj = CN_grid._pendingCombo.jsObject;
	var el = CN_grid._pendingCombo.element;
	setTimeout(function()
	{ 
		obj.element = el;
		obj._showPopup(); 
	}, 0);

	CN_grid._pendingCombo = null;
}


CN_grid.findTag = function(l, tag)
{
	while(l != null && l.tagName != tag) l = l.parentElement;
	return l;
}

CN_grid.findCell = function(cell)
{
	while(cell != null && !cell.isCell) cell = CN_grid.findTag(cell.parentElement, "SPAN");
	return cell;
}

CN_grid.cancelBackspace = function()
{
	if(Event.keyValue(CN_grid.currentEvent()) == 8) CNUtil.cancelEvent();
}

CN_grid.proxyTabKeyDown = function() {
	if(Event.keyValue(CN_grid.currentEvent()) == 9) { // TBD - do not leave box if it is invalid.
		var cell = CN_grid.findCell(Util.eventTarget()); // 1036-2 - js error.
		if(!cell) return;
		var typeObject = cell.colTag.typeObject;
		if(!typeObject.box || EditorBoxManager.canBlurBox(typeObject.box, typeObject)) {
			var gridEl = Util.findByClassName(Util.eventTarget(), "cn_grid");
			gridEl.jsObject.element_onkeydown();
		} else {
			Util.cancelEvent();
		}
	}	
}


var proto = CN_grid.prototype;

// Events. ===================================================================
proto.onchanged = function(ev)
{
}

proto.onpostback = function(ev)
{
	this._postingCellXY = {column: ev.cellIndex, row: ev.rowIndex};
	this.formManager.postData(this.element);
}

proto.onrowselected = function(ev)
{
	if(CN_grid.currentEvent() && (CN_grid.currentEvent().type == "mousedown" || CN_grid.currentEvent().type == "click")) 
	{
		this._selectionPostback = {button: CN_grid.currentEvent().button};
		this.formManager.postData(this.element);
	}
}

// IXMLDataAware. ============================================================
proto.loadData = function(node)
{
	if(CN_grid.fullRowSelect) this._hideHover();
	this._resizeColumns(); // Fast pass on just template/header.

	EditorBoxManager.activeBox = null;
	
	this._loadColumnsData(node);

	attr = node.getAttribute("treeAutoPostBack");
	if(attr) this._treeAutoPostBack = attr == "true";

	attr = node.getAttribute("readOnly");
	if(attr) this.set_readOnly(attr == "true");

	attr = node.getAttribute("allowClearSelection");
	if(attr) this._allowClearSelection = attr == "true";

	var attr = node.getAttribute("selectedRow");
	var ix = parseInt(attr, 10);
	
	this._resetScrollPosition = node.getAttribute("resetScrollPosition") == "true";
	if(this._resetScrollPosition) this.rowsDiv.scrollTop = 0;
	
	var rows = Util.xmlSelectSingleNode(node, "rows");
	if(rows) 
	{
		this.cleanTable();
		if(attr) this._pendingSelectedRow = ix;
		this.fillTable(rows);
	}
	else if(attr) this.set_selectedRow(ix);
	
	this._loadHeader(node);
	this._loadFooter(node);
	
	if(!CN_grid.fullRowSelect) {
		this._loadSelectorVisible(node);
	} 
}
proto._loadSelectorVisible = function(node) {
	var attr = node.getAttribute("selectorVisible");
	if(attr == null) return;
	
	attr = attr == "true";
	if(attr != this._selectorVisible) {
		this._selectorVisible = attr;

		this.headerRow.children[0].style.display = this.templateRow.children[0].style.display = 
			this.folderTemplateRow.children[0].style.display = this._selectorVisible ? "block" : "none";

		this._walkRows(this.rowsDiv, "_setRowSelectorVisible");
		this._resizeColumns();
	}
}
proto._setRowSelectorVisible = function(row) {
	row.children[0].style.display = this._selectorVisible ? "inline" : "none";
}

proto.storeData = function(xmldoc)
{
	EditorBoxManager.endActiveEdit();

	this.saveState();

	var gridData = null;
	var selectionData = null;
	
	var nodes = Util.xmlSelectNodes(this.changedFragment, "*")
	if(nodes.length > 0)
	{
		gridData = this.changedFragment.cloneNode(true);
		
		if(this._postingCellXY)
		{
			// Now, get posting cell and move it to end.
			var query = '*[@row="' + this._postingCellXY.row + '" and @column="' + this._postingCellXY.column + '"]';
			var posterNode = Util.xmlSelectSingleNode(gridData, query);
		
			// Just append to end.
			if(gridData.lastChild != posterNode) gridData.appendChild(posterNode);
			this._postingCellXY = null;
		}
		
		// Make it clean.
		this.changedFragment = this.changedDoc.createDocumentFragment();
	}

	if(this._selectionPostback)
	{
		selectionData = xmldoc.createElement(this._tagPrefix + "selection")
		selectionData.setAttribute("selection", this._selectedRow);
		if(this._selectionPostback.button) selectionData.setAttribute("button", this._selectionPostback.button);
		this._filterSelectionData(selectionData);
		this._selectionPostback = null;
	}

	var fragment = xmldoc.createDocumentFragment();
	if(gridData) fragment.appendChild(gridData);
	if(selectionData) fragment.appendChild(selectionData);

	return fragment;
}

// Required by dg2.
proto._filterSelectionData = function(selectionData)
{
}

proto.createElement = function(node, parentElement)
{
	this.totalTime = new Date().getTime();

	// A grid is always a child of a form/container element. Do not silently
	// create a detached grid: that would hide a broken form lifecycle and
	// produce later layout failures. Report the control and form context.
	if(!parentElement)
	{
		var controlID = node && node.getAttribute ? node.getAttribute("id") : "";
		var controlTag = node && node.tagName ? node.tagName : "";
		var placeholderID = this.formManager && this.formManager._formPlaceholder ? this.formManager._formPlaceholder.id : "";
		throw new Error("CN_grid.createElement: missing parent for " + controlTag + "#" + controlID + " (form=" + placeholderID + ")");
	}
	
	var l = document.createElement("div");
	parentElement.appendChild(l);
	// Cross-reference.
	this.element = l;
	l.jsObject = this;

	l.className = "cn_grid";
	this._buildElement();
	
	CN_grid.addEvent(l, "focus", this._element_onfocus, this);
	
	CN_grid.addEvent(l, "keydown", this._element_onkeydown, this);
	//Event.add(l, "keyup", this, this._element_onkeyup);
	//Event.add(l, "keypress", this, this._element_onkeyup);
	
	// NOTE: width is needed before initialization.	
	var attr = node.getAttribute("width");
	if(attr) this._elementWidth = parseInt(attr, 10);
	
	attr = node.getAttribute("headerHeight");
	if(attr) this.headerHeight = parseInt(attr, 10);

	attr = node.getAttribute("captionAlign")
	if(attr) this.captionAlign = String(attr);
	
	//attr = node.getAttribute("alternateBackcolor");
	//if(attr && attr != "true" && attr != "false") this.alternateBackcolor = String(attr);
	
	attr = node.getAttribute("alwaysScrollToSelected");
	if(attr) this.alwaysScrollToSelected = attr == "true";
	
	if(CN_grid.fullRowSelect) this._selectorVisible = false;
	else {
		attr = node.getAttribute("selectorVisible");
		if(attr) this._selectorVisible = attr == "true";
	}

	attr = node.getAttribute("treeAutoPostBack");
	if(attr) this._treeAutoPostBack = attr == "true";

	this._init(node);
	
	attr = node.getAttribute("gridLines");
	if(attr) this.set_gridLines(String(attr));

	attr = node.getAttribute("rowHeight");
	if(attr) this.set_rowHeight(parseInt(attr, 10));

	if(node.getAttribute("alwaysShowVScroll") == "true") this.rowsDiv.style.overflowY = "scroll";
	
/*	if(CN_grid.fullRowSelect) {
		this._hover = VistaSupport.createHover('item-gradient-5a.gif', 30);
		this._hover.strokecolor = ThemeNonCSSStyles.hoverRect_strokeColor2;
	}*/
	
	return l;
}

proto.unload = function()
{
	this.saveState();
	
	if(this._workerTO)
	{
		clearTimeout(this._workerTO);
		this._workerTO = null;
	}
	
	if(CommentTypeCell.activePopup)
	{
		CommentTypeCell.activePopup.style.display = "none";
		CommentTypeCell.activePopup = null;
		CommentTypeCell._currentCell = null;
	}

	this._hideSorting();

	for(var i = 0; i < this.cellRenderers.length; i++)
	{
		var renderer = this.cellRenderers[i];
		if(renderer._grid) renderer._grid = null;
	}
	this.cellRenderers = null;
	this.selectedTR = null;

	EditorBoxManager.activeBox = null; // Can't unload one grid when another is active?

	CNFormManager.destroyJSObjects(this._jsObjects);
	this._jsObjects = null;
}


proto._loadFooter = function(node)
{
	var footerNode = Util.xmlSelectSingleNode(node, "footer");
	if(!footerNode) return;
	
	var footerDiv = this._getFooter();

	var text = this._filterHtml(Util.xmlText(footerNode));
	footerDiv.innerHTML = text;

	if(text == "")
	{
		this.footerTR.style.display = "none";
	}
	else
	{
		this.footerTR.style.display = "block";
	}

	var attr = footerNode.getAttribute("maxHeight");
	if(attr) 
	{
		this._maxFooterHeight = parseInt(attr, 10);
		if(this._maxFooterHeight == -1) this._maxFooterHeight = Number.MAX_VALUE;
	}
	this.footerTR.firstElementChild.style.height = Math.min(this._maxFooterHeight, footerDiv.scrollHeight + 1);
}
proto._getFooter = function()
{
	var div = this.footerTR.firstElementChild.firstElementChild;
	return div;
}
proto._loadHeader = function(node) {
	var headerNode = Util.xmlSelectSingleNode(node, "header");
	if(!headerNode) return;

	var div = this._headerTR.firstElementChild.firstElementChild;
	var text = this._filterHtml(Util.xmlText(headerNode));
	div.innerHTML = text;

	this._headerTR.style.display = text == "" ? "none" : "block";
	var attr = headerNode.getAttribute("maxHeight");
	if(attr) {
		this._maxFooterHeight = parseInt(attr, 10);
		if(this._maxFooterHeight == -1) this._maxFooterHeight = Number.MAX_VALUE;
	}
	this._headerTR.firstElementChild.style.height = Math.min(this._maxFooterHeight, div.scrollHeight + 1);
}
proto._filterHtml = function(text) {
	return String(text).replace(/<hr.*?>/ig, '<div class="hr"></div>'); // Normalize legacy paragraph/hr markup before inserting into the grid.
}

proto.set_tabIndex = function(ti)
{
	this._tabIndex = ti;
	this._set_tabIndex(ti);
}

proto._set_tabIndex = function(ti)
{
	this.element.tabIndex = ti;
}


proto._element_onfocus = function()
{
	CNUtil.dispatchObject().element_onfocus();
}
proto.element_onfocus = function()
{
//	CNFormManager._trace("grid.element_onfocus"); 
/*	if(this._skipNextFocus)  // # 1036-3
	{
		CNFormManager._trace("_skipNextFocus");
		CNUtil.cancelEvent();
		this.element.blur();
		this._skipNextFocus = false;
		return;
	}*/
	if(this.rowsDiv.children.length > 4) 
	{
		//CNFormManager._trace("seeking next cell");
		var firstRow = this._findChildByClassName(this.rowsDiv, "rowDiv");
		if(firstRow && firstRow.children && firstRow.children.length > 1)
		{
			var firstCell = firstRow.children[1];
			if(firstCell)
			{
				if(this._isFocusableCell(firstCell)) 
				{
					CNUtil.cancelEvent();
					this._focusCell(firstCell);
				}
				else
				{
					var nextCell = this._findNextFocusableCell(firstCell);
					if(nextCell) 
					{
						this._focusCell(nextCell);
					}
				}
			}
		}
	}
}

proto._findChildByClassName = function(p, className)
{
	var c = p.firstChild;
	while(c)
	{
		if(c.className == className) return c;
		c = c.nextSibling;
	}
	return null;
}

//proto._element_onkeyup = function()
//{
//	if(Event.keyValue(CN_grid.currentEvent()) == 9) CNUtil.cancelEvent();
//}

proto._element_onkeydown = function()
{
	//CNFormManager._trace("grid._element_onkeydown");
	var jsObject = CNUtil.dispatchObject();
	if(jsObject.constructor != CN_grid) return;
	jsObject.element_onkeydown();
}
proto.element_onkeydown = function()
{
	if(Event.keyValue(CN_grid.currentEvent()) == 9) // Tab.
	{
		this.processTab();
	}
}
proto.processTab = function() {
	CNFormManager._trace("grid.processTab");
	var cell = CN_grid.findCell(Util.eventTarget());
	if(!cell) 
	{
		//this._skipNextFocus = true;
		return;
	}
	CNUtil.cancelEvent();

	var backward = CN_grid.currentEvent().shiftKey;
	var nextCell = backward ? this._findPrevFocusableCell(cell) : this._findNextFocusableCell(cell);
	if(!nextCell) 
	{
		EditorBoxManager.endActiveEdit();
		// Should focus next element with > tabIndex.
		
		/*var el = this._findNextTabbableElement(); // 1036-3
		if(el)
		{
			try
			{ 
				//Event.add(el, "focusout", this, CN_grid._interceptNextDeactivate);
				el.focus(); // Focus stealed.
				//setTimeout(function(){ el.focus(); }, 100);
			} 
			catch(e){}
		}*/

		this.formManager._focusFirstFocusableControl(this.element.tabIndex);
					
		return;
	}

	this._focusCell(nextCell);
}

proto._findNextTabbableElement = function()
{
//	CNFormManager._trace("_findNextTabbableElement")
	var ar = [];
	var all = CN_grid.descendants(this.formManager._formPlaceholder);
	var count = all.length;
	var ti = this.element.tabIndex;
	var lowestTabIndexEl = null;
	for(var i = 0; i < count; i++)
	{
		var l = all[i];
		if(l.jsObject // Only jsCN components.
		&& Util.getStyle(l, "visibility") != "hidden" 
		&& Util.getStyle(l, "display") != "none" 
		&& l.offsetWidth != 0
		&& !l.disabled
		&& !this.element.contains(l)
		&& !l.jsObject._disabled)
		{
			var lti = l.tabIndex;
			if(lti > ti) 
			{
				ar.push(l);
			}
			else if(lti != 0 && (lowestTabIndexEl == null || lowestTabIndexEl.tabIndex > lti))
			{
				lowestTabIndexEl = l;
			}
		}
	}
	if(ar.length > 0) 
	{
		ar.sort(function(a, b)
			{ 
				if(a.tabIndex < b.tabIndex) return -1; 
				if(a.tabIndex == b.tabIndex) return 0;
				return 1;
			}
		)
		return ar[0];
	}
	return lowestTabIndexEl; // Can be null.
}


CN_grid._interceptNextDeactivate = function()
{
	CNUtil.cancelEvent();
	CN_grid.removeEvent(Util.eventTarget(), "focusout", CN_grid._interceptNextDeactivate, null);
}

proto._focusCell = function(cell)
{
	EditorBoxManager.hideHover(); // #1036-3 - hide hover when tabbing to non-box managed cell (combo/mutalbe combo).
	var typeObject = cell.colTag.typeObject;
	if(typeObject.box)
	{
		var el = this.element;
		cell.tabIndex = el.tabIndex;
		EditorBoxManager.beginEdit(cell);
	}
	else
	{
		EditorBoxManager.endActiveEdit();
		CNUtil.cancelEvent();

		var to = cell.colTag.typeObject;
		if(to.focusCell) 
		{
			to.focusCell(cell);
		}
		else
		{
			cell.tabIndex = this.element.tabIndex;
			try
			{
				cell.focus(); // Not focusing after ti change.
				setTimeout(function(){ cell.focus(); }, 0);
			}
			catch(e){}
		}
	}
}

proto._getNextRow = function(row, subCall)
{
	if(subCall)
	{
		if(row.className == 'rowDiv') 
		{
			return row;
		}
		else if(row.isNodeContainer && row.children.length > 0)
		{
			return row.children[0];
		}
	}
	var nextRow = row.nextSibling;
	if(nextRow)
	{
		if(nextRow.isNodeContainer)
		{
			if(nextRow.children.length != 0) return nextRow.children[0];
		}
		else if(nextRow.className == 'rowDiv') 
		{
			return nextRow;
		}
	}
	var parent = row.parentElement;
	if(parent.isNodeContainer)
	{
		 while(parent && parent.nextSibling == null && parent.isNodeContainer) parent = parent.parentNode;
		 if(parent && parent.nextSibling) return this._getNextRow(parent.nextSibling, true);
	}
	return null;
}

proto._getPrevRow = function(row, subCall) {

	if(subCall)	{
		if(row.className == 'rowDiv') {
			return row;
		} else if(row.isNodeContainer && row.children.length > 0) {
			return row.lastChild;
		}
	}
	var prevRow = row.previousSibling;
	if(prevRow) {
		if(prevRow.isNodeContainer) {
			if(prevRow.children.length != 0) return nextRow.lastChild;
		} else if(prevRow.className == 'rowDiv') {
			return prevRow;
		}
	}
	var parent = row.parentElement;
	if(parent.isNodeContainer) {
		 while(parent && parent.previousSibling == null && parent.isNodeContainer) parent = parent.parentNode;
		 if(parent && parent.previousSibling) return this._getPrevRow(parent.previousSibling, true);
	}
	return null;
}

proto._findNextFocusableCell = function(cell)
{
	var nextCell = cell.nextSibling;
	if(!nextCell)
	{
		var nextRow = this._getNextRow(cell.parentElement);
		if(nextRow) 
		{
			nextCell = nextRow.children[0];
		}
		else 
		{
			return null;
		}
	}
	var finished = false;
	while(!finished)
	{
		if(this._isFocusableCell(nextCell)) 
		{
			return nextCell;
		}
		
		if(nextCell.nextSibling == null)
		{
			var nextRow = this._getNextRow(nextCell.parentElement);
			if(nextRow) 
			{
				nextCell = nextRow.children[0];
			}
			else 
			{
				finished = true;
			}
		}
		else nextCell = nextCell.nextSibling;
	}
	return null;
}

proto._findPrevFocusableCell = function(cell) {
	var prevCell = cell.previousSibling;
	if(!prevCell || Util.hasClass(prevCell, "selectionSpan")) {
		var prevRow = this._getPrevRow(cell.parentElement);
		if(prevRow) 
		{
			prevCell = prevRow.lastChild;
		}
		else 
		{
			return null;
		}
	}
	var finished = false;
	while(!finished)
	{
		if(this._isFocusableCell(prevCell)) {
			return prevCell;
		}
		
		if(prevCell.previousSibling == null || Util.hasClass(prevCell, "selectionSpan"))
		{
			var prevRow = this._getPrevRow(prevCell.parentElement);
			if(prevRow) 
			{
				prevCell = prevRow.lastChildl;
			}
			else 
			{
				finished = true;
			}
		}
		else prevCell = prevCell.previousSibling;
	}
	return null;
}

proto._isFocusableCell = function(cell)
{
	if(cell.offsetWidth > 0 && cell.colTag && !this.getCascadedReadOnly(cell))
	{
		var typeObject = cell.colTag.typeObject;
		if(typeObject.box) 
		{
			return true;
		}
		else if(typeObject.isFocusable) 
		{
			return true;
		}
	}
	return false;
}

proto._buildElement = function()
{
	/*
		NOTE: 
			- rowDiv should be the first child of rowsDiv.
			- update startRowIndex if number of rowsDiv child is changed.
			- comments are also counted!
	*/
	this.element.innerHTML = '\
		<table width=100% height=100% border=0 cellpadding=0 cellspacing=0>\
		<col width=100%>\
		<tr><td id=headerTD>\
		<div id=headerRow></div>\
		</td></tr>\
		<tr style="display: none; "><td><div class="gridHeaderDiv"></div></td></tr>\
		<tr><td height=100%>\
			<div id=rowsDiv>\
		\
			<div class=rowDiv></div>\
		\
			<div id=leftBorder></div><div id=topBorder></div>\
			<div id=bottomBorder></div>\
			<div id=rightBorder></div>\
		\
			</div>\
		</td></tr>\
		<tr id=footerTR style="display: none; "><td><div class="gridFooterDiv"></div></td></tr>\
		</table>';
		
	var all = CN_grid.descendants(this.element);
	//this.disabler = all["disabler"];
	this.headerTD = Util.findById(this.element, "headerTD");
	this.headerRow = Util.findById(this.element, "headerRow");
	this.rowsDiv = Util.findById(this.element, "rowsDiv");
	this.leftBorder = Util.findById(this.element, "leftBorder");
	this.rightBorder = Util.findById(this.element, "rightBorder");
	this.topBorder = Util.findById(this.element, "topBorder");
	this.bottomBorder = Util.findById(this.element, "bottomBorder");
	this.footerTR = Util.findById(this.element, "footerTR");
	// Standards DOM preserves the whitespace around the template table as text
	// nodes.  Do not assume firstChild is the table (that was only reliable in
	// the old IE HTML parser).
	var gridTable = this.element.firstElementChild;
	this._headerTR = gridTable.rows[1];

	this.disabler = Util.createElementFromHTML('<div style="position: absolute; background: white; z-index: 1000; opacity: 0.5; width: 100%; height: 100%; visibility: hidden; top: 0; left: 0; ">');
	//this.element.appendChild(this.disabler);
	
	var obj = this;
}

proto._init = function(node)
{
	if(!top.__ontopZ) top.__ontopZ = 10000;
	this.xml = node;
	
	this.templateRow = this.rowsDiv.children[0];
	
	this.folderTemplateRow = this.templateRow.cloneNode(true);

	if(this.cssPath.length > 0 && !this.cssPath.match(/\\|\/$/)) this.cssPath = this.cssPath + "/";

	//this.preloadImages();
	//this.prebuildPopup();
	
	this.initChangedDOM();

	//this._processUnscrollable(node);
	this.prebuildTable(node);
	
	// Header auto-scroll.
	CN_grid.addEvent(this.rowsDiv, "scroll", this._rowsDiv_onscroll, this);
	//Event.add(this.rowsDiv, "resize", this, this._rowsDiv_onresize);
	CN_grid.addEvent(this.element, "resize", this._rowsDiv_onresize, this);
	
	if(CN_grid.fullRowSelect) {
		Event.add(this.rowsDiv, "click", this, this.rowsDiv_click)
		Event.add(this.templateRow, "mouseenter", this, this.row_mouseenter);
		Event.add(this.templateRow, "mouseleave", this, this.row_mouseleave);
	}
	
	this.isReady = true;
	//this._set_readOnly();	
}
proto.rowsDiv_click = function(event) {
	if(this._allowClearSelection && Util.eventTarget() == this.rowsDiv)  {
		this.deselectRow(true);
	}
}
proto.row_mouseenter = function(event) {
	var row = Util.findByClassName(Util.eventTarget(), "rowDiv");
	if(row) {
		Util.addClass(row, "rowDivHover");
		this._hoveredRow = row;
	}
/*	row.appendChild(this._hover);
	this._hover.style.visibility = "inherit";
	this._hover.style.left = "1px";
	this._hover.style.width = row.offsetWidth - 3;
	this._hover.style.height = row.offsetHeight - 1;*/
}
proto.row_mouseleave = function(event) {
	var row = Util.findByClassName(Util.eventTarget(), "rowDiv");
	this._hideHover();
}
proto._hideHover = function() {
//	var parent = this._hover.parentNode;
//	if(parent) parent.removeChild(this._hover);
	if(!this._hoveredRow) return;
	Util.removeClass(this._hoveredRow, "rowDivHover");
	this._hoveredRow = null;
}

proto.preloadImages = function()
{
	var img1 = new Image();
	img1.src = CNFormManager.themeImagesPath + "selectedRow.gif";
}

proto.initChangedDOM = function()
{
	this.changedDoc = Util.createXMLDocument();
	this.changedFragment = this.changedDoc.createDocumentFragment();
}

proto.prebuildTable = function(node)
{
	this.prebuildTime = new Date().getTime();
		
	if(this.headerHeight > 0) this.headerTD.style.height = this.headerHeight;	
	else this.headerTD.style.display = "none";
	
	// Selection col.
	var cell = Util.createElementFromHTML("<span class=selectionSpan>");
	cell.title = '';	
	this.templateRow.appendChild(cell);
	
	CN_grid.addEvent(cell, "mousedown", this._selectioncell_onmousedown, this);
	
	if(CN_grid.fullRowSelect) {
		//Event.add(this.templateRow, "mousedown", this, this._row_onmousedown);
		Event.add(this.templateRow, "mousedown", this, this._row_onmousedown);
	}

	if(this._vista)
	{
		var img = VistaSupport.createImageButton("normalRow.gif", 16, 16);
		cell.appendChild(img);
	}
	else
	{
		var img = Util.createElementFromHTML("<img width=16 height=16>");
		cell.appendChild(img);
		img.src = CNFormManager.themeImagesPath + "normalRow.gif";
	}

	cell.style.width = 20;
	
	this.folderTemplateRow.appendChild(cell.cloneNode(true));
	
	cell = document.createElement("span");
	this.headerRow.appendChild(cell);
	
	cell.textContent = " ";
	cell.style.width = 20;

	//this._lastWidth = this._elementWidth - (this._selectorVisible ? 20 : 0);
	
	// Preset with real width to precalculate column widths.
	var offset = this._selectorVisible ? 20 : 0;
	var width = this.rowsDiv.clientWidth - offset;
	
	// Check if we have vertical scrollbars.
	var scrollBarsVisible = this.rowsDiv.offsetWidth != this.rowsDiv.clientWidth;
	if(!scrollBarsVisible) 
	{
		// Reserve width for scrollbars.
		width -= CNFormManager.scrollBarSize;
	}
	
	this._realWidth = width;
	this._lastWidth = width;
	this._oldRowsDivWidth = width;
	
	this._x = offset;
		
	var cols = Util.xmlSelectNodes(node, "col");
	
	var colsCount = cols.length;
	this.colTags = new Array(colsCount);
	for(var i = 0; i < colsCount; i++)
	{
		var colNode = cols[i];
		this._processColTag(node, colNode, i, colsCount);
	}
	
	Util.removeElement(this.templateRow);

	if(!this._selectorVisible)
	{
		this.headerRow.children[0].style.display = this.templateRow.children[0].style.display = 
		this.folderTemplateRow.children[0].style.display = "none";
	}

	this.prebuildTime = new Date().getTime() - this.prebuildTime;
}

proto._processColTag = function(node, colNode, i, colsCount)
{
	// Convert to bool. 
	// NOTE: all 3 props. default to false.
	var readOnly = colNode.getAttribute("readOnly") == "true";
	var autoPostBack = colNode.getAttribute("autoPostBack") == "true";
	var canBeEmpty = colNode.getAttribute("canBeEmpty") != "false";
	
	var align = this._getAttribute(colNode, "align");
	var verticalAlign = this._getAttribute(colNode, "verticalAlign");
	var width = this._getAttribute(colNode, "width");
	var captionAlign = this._getAttribute(colNode, "captionAlign");
	var validationString = this._getAttribute(colNode, "validationString");
	var fixedWidth = colNode.getAttribute("fixedWidth") == "true";
	
	var sort = CN_grid.SORT_NONE;
	var attr = colNode.getAttribute("sort");
	if(attr)
	{
		if(attr == "auto") sort = CN_grid.SORT_AUTO;
		else if(attr == "manual") sort = CN_grid.SORT_MANUAL
	}

	var col = {readOnly: readOnly, 
				autoPostBack: autoPostBack, 
				canBeEmpty: canBeEmpty, 
				align: align,
				verticalAlign: verticalAlign,
				width: width,
				name: this._getAttribute(colNode, "name"),
				type: this._getAttribute(colNode, "type"),
				fixedFont: this._getAttribute(colNode, "fixedFont") == "true",
				bold: colNode.getAttribute("bold") == "true",
				node: colNode,
				validationString: validationString,
				sort: sort,
				index: i,
				fixedWidth: fixedWidth
				};

	this.colTags[i] = col;
	
	var hcell = document.createElement("span");
	hcell.style.top = 0;
	if(this.headerHeight <= 24) hcell.style.whiteSpace = 'nowrap';

	this.headerRow.appendChild(hcell);
	
	var tooltip = colNode.getAttribute("tooltip");
	if(tooltip != null) Tooltip.attach(hcell, String(tooltip));

	var caption = this._getAttribute(colNode, "caption");
	//hcell.title = caption
	hcell.textContent = caption;

	var captionImage = this._getAttribute(colNode, "captionImage");
	if(captionImage)
		hcell.innerHTML = '<img style=\"width:24px;height:24px;vertical-align:middle\" src=' + captionImage + ' class=captionImage>' + caption;
	
	var cell = Util.createElementFromHTML("<span class=cellSpan isCell=true>");
	this.templateRow.appendChild(cell);
	
	if(this._realWidth < 1) this._realWidth = this._elementWidth;

	var colWidth = 0;
	var scaledColWidth = 0;
	if(width && width != "*" && width * 1 != -1)
	{
		var w = parseInt(width, 10);
		colWidth = /*col.cellWidth =*/ w;

		if(fixedWidth) scaledColWidth = colWidth;
		else 
		{
			var ratio = col.widthRatio = colWidth / this._elementWidth;
			scaledColWidth = ratio * this._realWidth; // Scale to final width.
		}
		cell.style.width = hcell.style.width = scaledColWidth + "px";
	}
	else if(i == colsCount - 1)
	{
		scaledColWidth = colWidth = Math.max(this._lastWidth, 16);
		hcell.style.width = cell.style.width = scaledColWidth + "px";
		col.widthRatio = -1;
	}
	else
	{
		colWidth = hcell.offsetWidth;
		if(fixedWidth) scaledColWidth = colWidth;
		else
		{
			var ratio = col.widthRatio = colWidth / this._elementWidth;
			scaledColWidth = ratio * this._realWidth; // Scale to final width.
		}
		cell.style.width = hcell.style.width = scaledColWidth + "px";
	}
	this._lastWidth -= scaledColWidth;

	hcell.style.left = this._x + "px";
	//this._x += colWidth;
	this._x += scaledColWidth;

	if(col.align) cell.style.textAlign = col.align;
	if(col.verticalAlign) cell.style.verticalAlign = col.verticalAlign;
	var isTreeCol = col.type == "TreeNode";
	if(!this.tree_inited && isTreeCol) this.tree_init(node);

	if(col.fixedFont) cell.style.fontFamily = "Courier New";
	if(col.bold) cell.style.fontWeight = "bold";

	var renderer = CN_grid.CellTypes[col.type];
	if(!renderer) { 
		renderer = UnknownTypeCell;
	}
	renderer = this.cellRenderers[this.cellRenderers.length] = new renderer(col, this);

	if(!this._requiresReadOnlyWalk && renderer.set_readOnly)
	{
		this._requiresReadOnlyWalk = true;
	}

	col.typeObject = renderer;
	renderer.prerender(cell, col);
	
	if(isTreeCol) this.folderTemplateRow.appendChild(cell.cloneNode(true));

	if(captionAlign) hcell.style.textAlign = captionAlign;
	else hcell.style.textAlign = this.captionAlign;
	
	if(this.headerHeight > 0)
	{
		hcell.style.marginTop = Math.max(0, (this.headerHeight - 15) / 2);
		//hcell.style.paddingTop = Math.max(0, (this.headerHeight - hcell.offsetHeight) / 2);
		//hcell.style.height = Math.max(1, this.headerHeight - 1);
	}
	
	if(sort == CN_grid.SORT_AUTO || sort == CN_grid.SORT_MANUAL)
	{
		hcell.colTag = col;
		
		CN_grid.addEvent(hcell, "mouseenter", this._hcell_onmouseenter, this);
		CN_grid.addEvent(hcell, "mouseleave", this._hcell_onmouseleave, this);
		CN_grid.addEvent(hcell, "click", this._hcell_onclick, this);
		hcell.style.cursor = "default";
		
		var sortArrow = Util.createElementFromHTML("<img width=7 height=7 class=gridSortArrow>");
		hcell.appendChild(sortArrow);
		sortArrow.src = this._vista ? 'themes/vista/g/sortundefined.gif' :
			CNFormManager.neutralImagesPath + "sortundefined.gif";
		//sortArrow.src = CNFormManager.neutralImagesPath + "sortdown.gif";
		//sortArrow.style.marginTop = (hcell.clientHeight - 13) / 2;
	}
}

proto._loadColumnsData = function(node)
{
	var colNodes = Util.xmlSelectNodes(node, 'col');
	var count = colNodes.length;
	for(var i = 0; i < count; i++)
	{
		var colNode = colNodes[i];
		var index = parseInt(colNode.getAttribute("index"), 10);
		var caption = String(colNode.getAttribute("caption"));
		var headerSpan = this.headerRow.children[index + 1];
		if(headerSpan)
		{
			var fc = headerSpan.firstChild;
			if(fc && fc.tagName != 'IMG') headerSpan.replaceChild(document.createTextNode(caption), fc);
			else headerSpan.textContent = caption;
			headerSpan.title = caption;
		}
	}
}

proto._hcell_onmouseenter = function()
{
	var l = Util.eventTarget();
	if(this._vista)
	{
		var span = Util.findTag(l, "SPAN");
		span.className = "headerSpan_hover"
	}
	else
	{
		l.style.textDecoration = "underline";
	}
}

proto._hcell_onmouseleave = function()
{
	var l = Util.eventTarget();
	if(this._vista)
	{
		var span = Util.findTag(l, "SPAN");
		span.className = ""
	}
	else
	{
		l.style.textDecoration = "";
	}
}

proto._hideSorting = function()
{
	if(!this._currentSort_hcell) return;
	//this._currentSort_hcell.children[0].style.visibility = "hidden";
	if (this._currentSort_hcell.children[0].className == "captionImage")
		this._currentSort_hcell.children[1].src = 
			this._vista ? 'themes/vista/g/sortundefined.gif' : CNFormManager.neutralImagesPath + "sortundefined.gif";
	else
		this._currentSort_hcell.children[0].src = 
			this._vista ? 'themes/vista/g/sortundefined.gif' : CNFormManager.neutralImagesPath + "sortundefined.gif";
	this._currentSort_hcell = null;
}

proto._hcell_onclick = function()
{
	CNUtil.dispatchObject().hcell_onclick();
}
proto.hcell_onclick = function()
{
	if(this.tree_inited) 
	{
		Util.assert("TreeGrid can't be sorted.")
		return;
	}

	var hcell = CNUtil.findTag(Util.eventTarget(), "SPAN");
	
	this._hideSorting();
	this._currentSort_hcell = hcell;

	if(hcell.colTag.sort == CN_grid.SORT_AUTO)
	{
		var src;
		if(!hcell.colTag.sortType || hcell.colTag.sortType != "DESC")
		{
			src = "sortdown.gif";
			hcell.colTag.sortType = "DESC";
		}
		else
		{
			src = "sortup.gif";
			hcell.colTag.sortType = "ACS";
		}
		if (hcell.children[0].className == "captionImage")
			hcell.children[1].src = (this._vista ? 
				CNFormManager.themeImagesPath : CNFormManager.neutralImagesPath) + src;
		else		
			hcell.children[0].src = (this._vista ? 
				CNFormManager.themeImagesPath : CNFormManager.neutralImagesPath) + src;
		//hcell.children[0].style.visibility = "inherit";
		
		this._sortGrid(hcell.colTag, hcell.colTag.sortType == "DESC");
	}
	else
	{
		var node = this.changedDoc.createElement(this._tagPrefix + "headerclick");
		node.setAttribute("column", hcell.colTag.index);
		this.changedFragment.appendChild(node);
		
		this.formManager.postData(this.element);
	}
}

proto._sortGrid = function(colTag, isDesc)
{
	var startRowIndex = this._getFirstRowIndex();

	var colIndex = colTag.index;
	var row = this.rowsDiv.children[startRowIndex];

	var rowCount = this.rowsDiv.children.length - startRowIndex;
	var rowAr = [];
	var cellIndex = this.startDataCell + colIndex;
	
	var i = 0;
	while(row && row.rowIndex !== undefined)
	{
		var cell = row.children[cellIndex];
		rowAr[i] = [String(cell.textContent).toLowerCase(), row, cell];
		row = row.nextSibling;
		i++;
	}

	var descSortFunction;
	var ascSortFunction;
	if(colTag.typeObject.descSortFunction) descSortFunction = colTag.typeObject.descSortFunction;
	else descSortFunction = this._descSortFunction;
	if(colTag.typeObject.ascSortFunction) ascSortFunction = colTag.typeObject.ascSortFunction;
	else ascSortFunction = this._ascSortFunction;

	rowAr.sort(isDesc ? descSortFunction : ascSortFunction);
	
	var prev, startIX;
	if(startRowIndex == 0)
	{
		if(rowAr.length > 0)
		{
			var row = rowAr[0][1];
			row.parentElement.appendChild(row);
			prev = row;
		}
		startIX = 1;
	}
	else
	{
		prev = this.rowsDiv.children[startRowIndex - 1];
		startIX = 0;
	}
	
	for(var j = startIX; j < rowAr.length; j++)
	{
		var row = rowAr[j][1];
		prev.parentNode.insertBefore(row, prev.nextSibling);
		prev = row;
	}
	this.reselectRow();
}

proto._ascSortFunction = function(a, b)
{
	if(a[0] < b[0]) return 1;
	if(a[0] == b[0]) return 0;
	return -1;
}

proto._descSortFunction = function(a, b)
{
	if(a[0] > b[0]) return 1;
	if(a[0] == b[0]) return 0;
	return -1;
}


proto._getAttribute = function(node, attrName)
{
	var attr = node.getAttribute(attrName);
	if(attr == null) return null;
	return String(attr);
}

proto.cleanTable = function()
{
	this._hideSorting();

	var rows = this.rowsDiv.children;
	var count = rows.length;
	for(var i = count - 1; i >= 0; i--)
	{
		var row = rows[i];
		if(row.rowIndex !== undefined || row.isNodeContainer)
		{
			Util.removeElement(row);
		}
	}
}

proto.fillTable = function(rowsTag)
{
	this.fillTime = new Date().getTime();

	this.rowsNodes = rowsTag.childNodes;
	this.rowIndex = 0;

	if(this.rowsNodes.length < this.continuousFillThreshold)
		this.rowsPerFill = this.continuousFillThreshold;
	// Raise rowsPerFill for extra large sets.
	if(this.rowsNodes.length > 1000) this.rowsPerFill = this.rowsPerFill * 3;
	
	this._startRow = 0;
	this._endRow = this.rowsPerFill;

	this.fillTableWorker();
}

proto.fillTableWorker = function()
{
	var rowsCount = Math.min(this.rowsNodes.length, this._endRow);
	for(var i = this._startRow; i < rowsCount; i++)
	{
		var row = this.rowsNodes[i];
		if(row.nodeType != 1) continue;
		
		this.appendAnyRow(row, this.rowsDiv, null, 0, i, this.tree_rootType);
	}
	this._startRow = this._endRow;
	this._endRow = this._startRow + this.rowsPerFill;

	var obj = this;
	if(this._startRow < this.rowsNodes.length) 
	{
		this._workerTO = setTimeout(function(){ obj.fillTableWorker(); }, this.fillTimeout);
	}
	// Give ie chance to draw rows.
	else 
	{
		 this._setFillTableFinishedTO(200);
	}
	
	CNFormManager.getBaseFormManager()._enableTextAndBackgroundBlink(this._enableBlinkDivs);		
	CNFormManager.getBaseFormManager()._removeBlink(this._removeBlinkDivs);
}

proto._setFillTableFinishedTO = function(time)
{
	var obj = this;
	this._workerTO = setTimeout(function(){ obj.fillTableFinished(); }, time);
}

proto.fillTableFinished = function()
{
	var time = new Date().getTime();
	this.totalTime = time - this.totalTime;
	this.fillTime = time - this.fillTime;

	// NOTE: should happen only one time after grid loading.
	if(this.doLoadStateAfterFill) 
	{
		doLoadStateAfterFill = false;
		this._setLoadStateTO();		
	}

	if(this._pendingSelectedRow !== null)
	{
		this.set_selectedRow(this._pendingSelectedRow);
		this._pendingSelectedRow = null;
	}

	if(this.showTiming) status = "Filled " + this.rowsNodes.length + " rows in " + this.fillTime + " ms, "
								  + "prebuilt in " + this.prebuildTime + " ms, "
								  + "built everything in " + this.totalTime + " ms.";
	this.isReady = true;	
	this._set_readOnly();	
	CN_grid._openPendingCombo();
}

proto._setLoadStateTO = function()
{
	var obj = this;
	setTimeout(function(){ obj.loadState(); }, 0);
}

proto.appendAnyRow = function(row, parent, parentRowIndex, tree_level, tree_index, tree_type)
{
	var childRows = Util.xmlSelectSingleNode(row, "childRows");
	if(childRows) this.appendFolderRow(row, childRows, parent, parentRowIndex, tree_level, tree_index, tree_type);
	else this.appendRow(row, parent, parentRowIndex, tree_level, tree_index, tree_type);
}

proto.appendRow = function(rowNode, parent, parentRowIndex, tree_level, tree_index, tree_type)
{
	var row = this.templateRow.cloneNode(true);
	parent.appendChild(row);
	
	this.setCommonRowProperties(row, rowNode, parentRowIndex);
	
	var cells = row.children;
	var cellNodes = rowNode.childNodes;
	var cellNodesCount = cellNodes.length;

	// Render cells.
	for(var i = 0, j = 0; i < cellNodesCount; i++)
	{
		var cellNode = cellNodes[i];
		if(cellNode.nodeType != 1) continue;
		var cell = cells[j + this.startDataCell];
		cell.cellIndex = j;
		var colTag = this.colTags[j];
		// !! Possible cross-ref.
		cell.colTag = colTag;
		// Set up common stuff.
		this._setTooltip(cellNode, cell);

		var attr = cellNode.getAttribute("backcolor");
		if(attr) cell.style.backgroundColor = String(attr);
		attr = cellNode.getAttribute("textcolor");
		if(attr) cell.style.color = String(attr);

		var readOnly = cellNode.getAttribute("readOnly") == "true";
		if(readOnly)
		{
			cell.readOnly = true;
			cell.className += " readOnly";
		}
		
		if(cellNode.getAttribute("empty") != "true")
		{
			this.cellRenderers[j].render(cell, cellNode, tree_level, tree_index, tree_type, readOnly);
		}
		else
		{
			cell._isEmpty = true;
			cell.style.visibility = "hidden";
		}
		j++;
	}
}

proto.appendFolderRow = function(rowNode, childRows, parent, parentRowIndex, tree_level, tree_index, tree_type)
{
	var cellNodes = rowNode.childNodes;
	var cellNodesCount = cellNodes.length;
	
	var row;
	if(cellNodesCount > 2) row = this.templateRow.cloneNode(true);
	else row = this.folderTemplateRow.cloneNode(true);
	parent.appendChild(row);
	
	this.setCommonRowProperties(row, rowNode, parentRowIndex);

	var cells = row.children;

	var childNodeType = tree_type;
	var childType = rowNode.getAttribute("childType");
	if(childType)
	{
		var type = this.tree_nodeTypes[String(childType)];
		// NOTE: completely new type, based on chilttype name.
		if(type) childNodeType = type;
	}

	//var chilsRows = Util.xmlSelectSingleNode(rowNode, "childRows");
	if(childRows != null) rowNode.setAttribute("expandable", "true");

	var expanded = false;
	
	// Render cells.
	for(var i = 0, j = 0; i < cellNodesCount; i++)
	{
		var cellNode = cellNodes[i];
		if(cellNode.nodeType != 1) continue;

		if(cellNode.tagName == "c")
		{
			var cell = cells[j + this.startDataCell];
			if(!cell) continue;
			
			cell.cellIndex = j;
			var colTag = this.colTags[j];

			// !! Possible cross-ref.
			cell.colTag = colTag;
			var attr = cellNode.getAttribute("backcolor");
			if(attr) cell.style.backgroundColor = String(attr);
			attr = cellNode.getAttribute("textcolor");
			if(attr) cell.style.color = String(attr);
			
			if(colTag.type == "TreeNode")
			{
				if(cellNode.parentNode.getAttribute("expanded") != "false") 
				{
					expanded = true;
					cellNode.parentNode.setAttribute("expanded", "true");
				}
			}
			
			this._setTooltip(cellNode, cell);
			//this.cellRenderers[j].render(cell, cellNode, tree_level, tree_index, tree_type);

			var readOnly = cell.readOnly = cellNode.getAttribute("readOnly") == "true";
			if(readOnly)
			{
				cell.className += " readOnly";
			}

			if(cellNode.getAttribute("empty") != "true")
			{
				this.cellRenderers[j].render(cell, cellNode, tree_level, tree_index, tree_type, readOnly);
			}
			else
			{
				cell._isEmpty = true;
				cell.style.visibility = "hidden";

			}
		}
		else if(cellNode.tagName == "childRows")
		{
			var containerDiv = document.createElement("div");
			parent.appendChild(containerDiv);
			
			containerDiv.style.display = expanded ? "block" : "none";
			containerDiv.isNodeContainer = true;
			containerDiv.nodesBuilt = true;

			var childRows = cellNode.childNodes;
			var childRowCount = childRows.length;
			for(var k = 0, n = 0; k < childRowCount; k++)
			{
				var childRow = childRows[k];
				if(cellNode.nodeType != 1 || childRow.tagName != "r") continue;
				
				this.appendAnyRow(childRow, containerDiv, row.rowIndex, tree_level + 1, n, tree_type);
				n++;
			}
		}
		j++;		
	}
}

proto._setTooltip = function(node, cell)
{
	var tooltip = node.getAttribute("tooltip");
	if(tooltip) Tooltip.attach(cell, String(tooltip));
}

proto.setCommonRowProperties = function(row, rowNode, parentRowIndex)
{
	row.rowIndex = this.rowIndex++;
	row.parentRowIndex = parentRowIndex;	

	var isSelectable = row.isSelectable = rowNode.getAttribute("selectable") != "false";
	if(!isSelectable)
	{
		var cell = row.children[0];
		var img = cell.children[0];
		cell.style.cursor = "default";
		CN_grid.removeEvent(cell, "mousedown", this._selectioncell_onmousedown, this);
		//img.src = CNFormManager.themeImagesPath + "non-selectableRow.gif";
		//img.width = img.height = 16;
		img.style.visibility = "hidden";
	}

	var backColor = rowNode.getAttribute("backcolor");
	if(backColor) row.style.backgroundColor = String(backColor);
	else if(this.alternateBackcolor && this.rowIndex % 2) row.style.backgroundColor = this.alternateBackcolor;

	var textColor = rowNode.getAttribute("textcolor");
	if(textColor) row.style.color = String(textColor);

	var readOnly = rowNode.getAttribute("readOnly") == "true";
	if(readOnly) row.readOnly = true;
	
	var bold = rowNode.getAttribute("bold") == "true";
	if(bold) row.style.fontWeight = "bold";

	// Bind node to row.
	row.xmlNode = rowNode;
}

proto._stateKey = function()
{
	return "cn_gridstate_" + String(this.element && this.element.id || "");
}
proto._readState = function()
{
	var key = this._stateKey();
	try
	{
		if(typeof sessionStorage != "undefined")
		{
			var raw = sessionStorage.getItem(key);
			return raw ? JSON.parse(raw) : null;
		}
	}
	catch(ignore) {}
	return CN_grid._memoryState ? CN_grid._memoryState[key] || null : null;
}
proto._writeState = function(state)
{
	var key = this._stateKey();
	try
	{
		if(typeof sessionStorage != "undefined")
		{
			sessionStorage.setItem(key, JSON.stringify(state));
			return;
		}
	}
	catch(ignore) {}
	if(!CN_grid._memoryState) CN_grid._memoryState = {};
	CN_grid._memoryState[key] = state;
}
proto.loadState = function()
{
	if(!this.element || !this.element.id || this._resetScrollPosition) return;
	var state = this._readState();
	if(!state) return;
	if(state.rowsDiv_scrollTop != null) this.rowsDiv.scrollTop = state.rowsDiv_scrollTop * 1;
	if(state.rowsDiv_scrollLeft != null) this.rowsDiv.scrollLeft = state.rowsDiv_scrollLeft * 1;
}

proto.saveState = function()
{
	if(!this.element || !this.element.id || !this.storeScrollState) return;
	this._writeState({
		rowsDiv_scrollTop: this.rowsDiv.scrollTop,
		rowsDiv_scrollLeft: this.rowsDiv.scrollLeft
	});
}

// Kept as a small compatibility-shaped accessor for callers from reconstructed
// extensions. It no longer exposes MSXML/userData; attributes are backed by a
// plain object and persisted by saveState().
proto.getStoredGridTag = function()
{
	var state = this._readState() || {};
	return {
		getAttribute: function(name) { return state[name] == null ? null : state[name]; },
		setAttribute: function(name, value) { state[name] = value; },
		removeAttribute: function(name) { delete state[name]; }
	};
}


proto.selectRow = function(l, doNotFireEvent)
{
	if(!l.isSelectable /*|| l == this.selectedTR*/) return;
	
	this.deselectRow();
	
	var img = l.children[0].children[0];
	if(this._allowClearSelection)
	{
		img._src = null; // Vista
		img.src = CNFormManager.themeImagesPath + "deselectRow.gif";
		img.title = 'Clear selection';	
	}
	else
	{
		img._src = null; // Vista
		img.src = CNFormManager.themeImagesPath + "selectedRow.gif";
		img.title = "";
	}

//	if(this._vista || CN_grid.fullRowSelect)
		Util.addClass(l, "selectedRow");

	this.rowBorder_select(l);

	this._selectedRow = l.rowIndex;
	this.selectedTR = l;

	if(this.tree_inited)
	{
		// NOTE: Assume TreeNode is first data column.
		this.tree_selectNodeDiv(l.children[1].children[0]);
	}
	
	if(this.isReady && !doNotFireEvent)
	{
		var ev = {};
		ev.selectedRow = this._selectedRow;
		ev.rowNode = l.xmlNode;
		this.onrowselected(ev);
	}
}

proto.deselectRow = function(generateEvent)
{
	if(this.selectedTR == null) return;
	var l = this.selectedTR;

	//if(this._vista || CN_grid.fullRowSelect) 

	var img = l.children[0].children[0];
	img._src = "normalRow.gif";
	img.src = CNFormManager.themeImagesPath + "normalRow.gif";
	img.title = '';
	this.rowBorder_deselect(l);
	this._selectedRow = -1;
	this.selectedTR = null;

	if(this.isReady && generateEvent)
	{
		var ev = {};
		ev.selectedRow = -1;
		this.onrowselected(ev);
	}
}

proto.reselectRow = function()
{
	if(this.selectedTR && this.selectedTR.parentElement) this.selectRow(this.selectedTR, true); 
}



// Event handlers. ==========================================================

proto._rowsDiv_onresize = function()
{
	CNUtil.findJSObject(Util.eventTarget()).rowsDiv_onresize();
}
proto.rowsDiv_onresize = function()
{
	if(this.element.clientWidth == 0) return;
	
	if(this._resizeTO) 
	{	
		clearTimeout(this._resizeTO);
		this._resizeTO = null;
	}

	var obj = this;
	this._resizeTO = setTimeout(function(){ obj._resizeColumns(); }, 55);
	
	var table = this.element.firstElementChild;
	table.width = this.element.clientWidth;
	table.height = this.element.clientHeight;

	this.rowsDiv_onscroll();
}

proto.layoutHeader = function()
{
	if(this._headerLayedout) return;
	
	var cells = this.headerRow.children;
	var length = cells.length;
	for(var i = 0; i < length; i++)
	{
		var hcell = cells[i];
		if(hcell.offsetHeight == 0) return;
		hcell.style.marginTop = Math.max(0, (this.headerHeight - hcell.offsetHeight) / 2);
	} 
	this._headerLayedout = true;
}

proto._resizeColumns = function()
{
	var start = new Date().getTime();
	if(!this.colTags) return;

	var offset = this._selectorVisible ? 20 : 0;
	
	if(this._disabled)
	{
		this.disabler.style.width = this.element.clientWidth;
	}

	this.layoutHeader();

	var width = this.rowsDiv.clientWidth - offset;
	var scrollBarsVisible = this.rowsDiv.offsetWidth != this.rowsDiv.clientWidth;
	if(!scrollBarsVisible) 
	{
		// Reserve width for scrollbars.
		width -= CNFormManager.scrollBarSize;
	}

	var lastColWidth = width;
	if(this._oldRowsDivWidth != width) 
	{
		this._resizeCounter++;
		this._oldRowsDivWidth = width;
		var x = offset;
		var length = this.colTags.length;
		var headerRowChildren = this.headerRow.children;
		var templateRowChildren = this.templateRow.children;
		var firstRowIndex = this._getFirstRowIndex();
		for(var i = 0; i < length; i++)
		{
			var widthRatio = this.colTags[i].widthRatio;
			var colWidth = 0;
			
			var hcell = headerRowChildren[this.startDataCell + i];
			if(!this.colTags[i].fixedWidth)
			{
				if(widthRatio != -1) colWidth = this.colTags[i].widthRatio * width;
				else 
				{
					colWidth = lastColWidth;
				}
				
				if(colWidth > 0) 
				{
					lastColWidth -= colWidth;
					hcell.style.width = colWidth;
					templateRowChildren[this.startDataCell + i].style.width = colWidth;

					if(i == 0 && this.tree_inited && this.folderTemplateRow.children.length > 1) 
					{
						this.folderTemplateRow.children[1].style.width = colWidth;
					}
					this._resizeRows(this.rowsDiv, colWidth, i, width, firstRowIndex)
				}
			}
			else
			{
				if(widthRatio != -1) colWidth = parseInt(this.colTags[i].width, 10);
				else colWidth = lastColWidth;
				
				
				lastColWidth -= colWidth;
			}
			hcell.style.left = x;
			x += colWidth;
		}
	}
	//this._walkCells(this._resizeCell);

	//status = "Resize in " + (new Date().getTime() - start) + "ms";
	//this.reselectRow();
	if(this.selectedTR) this.rowBorder_updateSize(this.selectedTR);
	//CN_grid._handle_onresize();	
}
/*proto._resizeCell = function(cell)
{
	cell.style.width = cell.colTag._colWidth;
}*/

// NOTE: overriden in dynamicgrid2.
proto._resizeRows = function(rowsDiv, colWidth, ix, rowsDivWidth, firstRowIndex)
{
	var startRowIndex = 0;
	if(!rowsDiv.isNodeContainer) startRowIndex = firstRowIndex;
	
	var children = rowsDiv.children;
	var length = children.length;
	for(var j = 0/*startRowIndex*/; j < length; j++)
	{
		var row = children[j];
		if(row.isNodeContainer)
		{
			this._resizeRows(row, colWidth, ix, rowsDivWidth, firstRowIndex);
		}
		else if(row.className == "rowDiv")
		{
			// Check cell, as we can get missing cell in treegrid.
			var cell = row.children[this.startDataCell + ix];
			if(cell) 
			{
				cell.style.width = colWidth;
			}
		}
	}
}

proto._getFirstRowIndex = function()
{
	var index = 0;
	var l = this.rowsDiv.firstElementChild;
	
	//If first row is selected class name will be "rowDiv selectedRow" not "rowDiv"
	if (l && l.className == "rowDiv selectedRow")
	{
		return index;
	}
	
	while(l && l.className != "rowDiv") 
	{
		l = l.nextSibling;
		index++;
	}

	return index;
}

proto._rowsDiv_onscroll = function()
{
	CNUtil.findJSObject(Util.eventTarget()).rowsDiv_onscroll();
}
proto.rowsDiv_onscroll = function()
{
	if(this.normHeaderRowTO) 
	{	
		clearTimeout(this.normHeaderRowTO);
		this.normHeaderRowTO = null;
	}
	// Give ie a chance to redraw content w/o flickering.
	var obj = this;
	this.normHeaderRowTO = setTimeout(function(){ obj.normHeaderRow(); }, 20);
}
proto.normHeaderRow = function()
{
	this.headerRow.style.right = this.rowsDiv.scrollLeft;
}

proto._selectioncell_onmousedown = function()
{
	//if(CN_grid.currentEvent().button != 1) return;
	CNUtil.findJSObject(Util.eventTarget()).selectioncell_onmousedown();
}
proto.selectioncell_onmousedown = function()
{
	if(this._disabled) return;
	var l = CN_grid.findTag(Util.eventTarget(), "DIV");

	if(l == this.selectedTR && this._allowClearSelection) 
	{
		if(CN_grid.currentEvent().button == 1) this.deselectRow(true);
		return;
	}

	this.selectRow(l);
}
proto._row_onmousedown = function(event) {
	if(this._disabled || !this._selectorVisible && !CN_grid.fullRowSelect) return;
	var selSpan = Util.findByClassName(Util.eventTarget(), "selectionSpan");
	if(selSpan) return;

	var l = Util.findByClassName(Util.eventTarget(), "rowDiv");

	if(l == this.selectedTR && this._allowClearSelection && this._readOnly) 
	{
		if(CN_grid.currentEvent().button == 1) this.deselectRow(true);
		return;
	}

	if(l != this.selectedTR) this.selectRow(l);
}


proto.isValid = function()
{
	if(this._disabled) return true;
	var rows = this.rowsDiv.children;	
	return this._checkIsValid(rows);
}

proto._checkIsValid = function(rows)
{
	var rowCount = rows.length;
	for(var i = 0; i < rowCount; i++)
	{
		var row = rows[i];
		if(row.isNodeContainer)
		{
			if(!this._checkIsValid(row.children)) return false;
		}
		else if(row.rowIndex === undefined) continue;
		else
		{
			var cells = row.children;
			var cellCount = cells.length;
			for(var j = this.startDataCell; j < cellCount; j++)
			{
				if(!this.isCellValid(cells[j])) 
				{
					this.validationString = cells[j].colTag.validationString;
					if(!this.validationString)
					{
						var renderer = CN_grid.CellTypes[cells[j].colTag.type];
						if(renderer)
						{
							this.validationString = renderer.defaultValidationString;
						}
					}
					if(!this.validationString) this.validationString = "Invalid cell value";

					return false;
				}
			}
		}
	}
	return true;
}

proto.isCellValid = function(cell)
{
	if(cell._isEmpty) return true;
	var cellType = this.cellRenderers[cell.cellIndex];
	if(!cellType) return true;

	var result = cellType.isValid(cell);
	return result;
}

// Util methods. ============================================================
proto.getCascadedReadOnly = function(l)
{
	if(this._readOnly || this._disabled) return true;

	var cell = CN_grid.findCell(l);
	if(!cell) return false;
	
	if(cell.readOnly) return true;
	
	if(!cell.colTag) alert("ASSERT: no colTag for " + cell.outerHTML);
	if(cell.colTag.readOnly) return true;

	var row = cell.parentElement;
	if(row.readOnly) return true;
	return false;
}

proto.setChangedValue = function(row, cell, value)
{
	var node = this._getChangedNode(row, cell);
	if(!node) return;
	
	if(value !== null) node.setAttribute("value", value);
}

proto._getChangedNode = function(row, cell)
{
	var colTag = cell.colTag;
	
	var colRenderer = CN_grid.CellTypes[colTag.type];
	if(!colRenderer) return null;
	var tagName = colRenderer.cn_tagName;
	if(!tagName) return null;
	
	var id = this.element.id;
	if(!id) return null;

	var rowIndex = row.rowIndex;
	var cellIndex = cell.cellIndex;
	var tableRowId = cell.tableRowId;
	var tableCellId = cell.tableCellId;
	
	// NOTE: id is set by FormManager.
	var elementName = this._tagPrefix + tagName;
	var query = elementName	+ '[@row="' + rowIndex + '" and @column="' + cellIndex + '"]';
	var node = Util.xmlSelectSingleNode(this.changedFragment, query);
	if(!node)
	{
		node = this.changedDoc.createElement(elementName);
		node.setAttribute("row", rowIndex);
		node.setAttribute("column", cellIndex);
		if(row.id) node.setAttribute("rowID", String(row.id).substr(3));
		if (tableRowId && tableCellId)
		{
			node.setAttribute("tableRowId", tableRowId);
			node.setAttribute("tableCellId", tableCellId);	
		}
		
		this.changedFragment.appendChild(node);
	}
	return node;
}

proto.getEvent = function(row, cell, value)
{
	var ev = {};
	ev.sender = this;
	ev.value = value;
	ev.cellIndex = cell.cellIndex;
	ev.rowIndex = row.rowIndex;
	ev.colName = cell.colTag.name;
	ev.rowID = String(row.xmlNode.getAttribute("id"));
	ev.tableRowId = cell.tableRowId;
	ev.tableCellId = cell.tableCellId;
	ev.cell = cell;
	return ev;
}

proto.fireChangedEvent = function(row, cell, value)
{
	this.onchanged(this.getEvent(row, cell, value));
}

proto.postBack = function(row, cell, value)
{
	var node = this._getChangedNode(row, cell);
	if(node)
	{
		// NOTE: move node to end of fragment, so it's assumed as postback element.
		this.changedFragment.appendChild(node);		
	}
	
	this.onpostback(this.getEvent(row, cell, value));
}

proto.rowBorder_select = function(row)
{
	var p = row.parentElement;
	
	if(p.offsetHeight == 0 || p.offsetWidth == 0) return;
	
	p.appendChild(this.leftBorder);
	p.appendChild(this.topBorder);
	p.appendChild(this.bottomBorder);
	p.appendChild(this.rightBorder);

	var x = row.offsetLeft;
	var y = row.offsetTop;

	this.leftBorder.style.left = x + this._rowBorderOffset;
	this.leftBorder.style.top = y + this._rowBorderOffset;
	this.leftBorder.style.height = row.offsetHeight - this._rowBorderOffset * 2;
	
	this.topBorder.style.left = x + this._rowBorderOffset * 2;
	this.topBorder.style.top = y;

	this.rightBorder.style.top = y + this._rowBorderOffset;
	this.rightBorder.style.height = row.offsetHeight - this._rowBorderOffset * 2;
	//this.rightBorder.style.left = row.offsetWidth - this.rightBorder.offsetWidth;
	
	this.bottomBorder.style.left = x + this._rowBorderOffset * 2;
	this.bottomBorder.style.top = y + row.offsetHeight - this.bottomBorder.offsetHeight;

	this.rightBorder.style.visibility = 
	this.topBorder.style.visibility =
	this.leftBorder.style.visibility = this.bottomBorder.style.visibility = "inherit";
	
	this.rightBorder.style.zIndex = 
	this.topBorder.style.zIndex =
	this.leftBorder.style.zIndex = this.bottomBorder.style.zIndex = top.__ontopZ++
	
	this.rowBorder_updateSize(row);
}

proto.rowBorder_updateSize = function(row)
{
	if(row.offsetWidth == 0) return;
	this.rightBorder.style.left = (row.offsetWidth - this.rightBorder.offsetWidth - this._rowBorderOffset) + "px";
	this.topBorder.style.width = this.bottomBorder.style.width = 
		(row.offsetWidth - this._rowBorderOffset * 4) + "px";
}

proto.rowBorder_deselect = function()
{
	// NOTE: rightBorder often inproperly positioned, so leave it.
	this.rightBorder.style.visibility =
	this.topBorder.style.visibility =
	this.leftBorder.style.visibility =
	this.bottomBorder.style.visibility = "hidden";
	
	// Move to top to avoid scrolling.
	this.topBorder.style.top = this.leftBorder.style.top = this.bottomBorder.style.top = 
		this.rightBorder.style.top = 0;
}


// Tree functions. =========================================================
proto.tree_init = function(node)
{
	if(this.tree_inited) return;
	this.tree_inited = true;

	this.tree_initializeNodeTypes(node);
	
	var rootType = {};
	if(this.childType) 
	{
		var type = this.tree_nodeTypes[childType];
		if(type) rootType = type;
	}
	this.tree_rootType = this.tree_getOverridenTypeObject(rootType, node);
}
	
proto.tree_initializeNodeTypes = function(node)
{
	var types = Util.xmlSelectNodes(node, "nodetype");
	var count = types.length;
	for(var i = 0; i < count; i++)
	{
		var typeNode = types[i];
		var typeObject = this.tree_getOverridenTypeObject({}, typeNode);
		this.tree_nodeTypes[String(typeNode.getAttribute("type"))] = typeObject;
	}
}

proto.tree_typeAttributes = ["checkBox", "imageUrl", "selectedImageUrl", "expandedImageUrl"];

proto.tree_cloneObject = function(matrix)
{
	var obj = {};
	for(var i in matrix) obj[i] = matrix[i];
	return obj;
}

proto.tree_getOverridenTypeObject = function(typeObj, l)
{
	var result = null;
	for(var i = 0; i < this.tree_typeAttributes.length; i++)
	{
		var attrName = this.tree_typeAttributes[i];
		var attr = null;
		if(l instanceof Object) attr = l[attrName];
		else attr = l.getAttribute(attrName);
		if(attr != null)
		{
			if(result == null) result = this.tree_cloneObject(typeObj);
			result[attrName] = String(attr);
		}
	}
	if(result == null) return typeObj;
	return result;
}

proto.tree_buildNodeTemplate = function(parentElement)
{
	var nodeDiv = Util.createElementFromHTML("<div class=tree_nodeDiv>");
	parentElement.appendChild(nodeDiv);
	
	nodeDiv.isNodeDiv = true;
	
	var lineSpan = Util.createElementFromHTML("<span class=tree_lineSpan>"); // 0 
	nodeDiv.appendChild(lineSpan);
	
	var pmSpan = Util.createElementFromHTML("<span class=tree_plusMinusSpan>") // 1 
	nodeDiv.appendChild(pmSpan);
	
	var checkBoxSpan = Util.createElementFromHTML("<span class=tree_checkBoxSpan>"); // 2 
	CN_grid.addEvent(checkBoxSpan, "click", this._tree_checkBoxSpan_onclick, this);
	CN_grid.addEvent(checkBoxSpan, "dblclick", this._tree_checkBoxSpan_onclick, this);	
	if(this._vista)
	{
		CN_grid.addEvent(checkBoxSpan, "mouseenter", this._tree_checkBoxSpan_onmouseenter, this);
		CN_grid.addEvent(checkBoxSpan, "mouseleave", this._tree_checkBoxSpan_onmouseleave, this);	
	}

	nodeDiv.appendChild(checkBoxSpan);

	var icon = Util.createElementFromHTML("<img width=16 height=16 align=absmiddle class='tree_iconImg'>"); // 3 
	CN_grid.addEvent(icon, "mousedown", this._tree_icon_textSpan_onclick, this);
	CN_grid.addEvent(icon, "dblclick", this._tree_icon_textSpan_ondblclick, this);
	nodeDiv.appendChild(icon);
	
	var text = Util.createElementFromHTML("<span class=tree_textSpan>"); // 4
	CN_grid.addEvent(text, "mousedown", this._tree_icon_textSpan_onclick, this);
	CN_grid.addEvent(text, "dblclick", this._tree_icon_textSpan_ondblclick, this);
	nodeDiv.appendChild(text);
	
	return nodeDiv;
}

proto.tree_isExpanded = function(n)
{
	return n && String(n.parentNode.getAttribute("expanded")) == "true";
}

proto.tree_buildLine = function(nodeDiv, node, lineSpan, level)
{
	if(node.parentNode.parentNode.tagName == "rows") return;

	var lineImg = Util.createElementFromHTML("<img align=absmiddle width=" + this.lineImg_Width + " height=" + this.lineImg_Height + ">");

	if(this._showLines)
	{
		var row = node.parentNode.parentNode.parentNode;
		while(row && (parseInt(row.getAttribute("nodeLevel")) != 0 || this._showRootLines))
		{
			var img = lineImg.cloneNode();
			lineSpan.insertBefore(img, lineSpan.firstChild);
			
			if(this.tree_isNode(row.nextSibling)) img.src = CNFormManager.themeImagesPath + "grid-i.gif";
			else img.src = CNFormManager.themeImagesPath + "white.gif";
			
			row = row.parentNode;
			if(row && row.tagName == "childRows") row = row.parentNode;
			if(row && row.tagName == "rows") break;
		}
	}
	else
	{
		lineSpan.insertBefore(lineImg, lineSpan.firstChild);
		lineImg.width = this.lineImg_Width * level;
		lineImg.src = CNFormManager.themeImagesPath + "white.gif";
	}
}

proto.tree_isNode = function(l)
{
	return l && (l.tagName == "r" || l.tagName == "childRows");
}

proto.tree_getNextSiblingNode = function(node)
{
	if(!node || !node.parentNode) return null;
	var nextSibling = node.parentNode.nextSibling
	return nextSibling;
}

proto.tree_previousSiblingNode = function(node)
{
	if(!node || !node.parentNode) return null;
	var prevSibling = node.parentNode.previousSibling
	return prevSibling;
}

proto.tree_getParentNode = function(node)
{
	if(!node || !node.parentNode) return null;
	return node.parentNode.parentNode;
}

proto.tree_buildPM = function(node, pmSpan, level)
{
	var pmImg = Util.createElementFromHTML("<img align=absmiddle width=" + this.lineImg_Width + " height=" + this.lineImg_Height + ">");
	pmSpan.appendChild(pmImg);

	var img = pmSpan.basePMImg = "";

	if(this._showPlus && (level > 0 || this._showRootLines == true))
	{
		if(this._showLines)
		{
			if(this.tree_isNode(this.tree_getNextSiblingNode(node))) 
			{
				if(!this.tree_isNode(this.tree_previousSiblingNode(node)) 
				&& !this.tree_isNode(this.tree_getParentNode(node))) img = "f";
				else img = "t";
			}
			else if(this.tree_isNode(this.tree_previousSiblingNode(node)) 
			|| this.tree_isNode(this.tree_getParentNode(node))) 
			{	
				img = "l";
			}
			else 
			{
				img = "r";
			}
			
			pmSpan.basePMImg = img;
		}

		if(node.parentNode.getAttribute("expandable") == "true")
		{
			if(this.tree_isExpanded(node)) img += "minus";
			else img += "plus";
			
			if(this._vista) img.height = 20;
			CN_grid.addEvent(pmSpan, "mousedown", this._tree_pmImg_onmousedown, this);
			CN_grid.addEvent(pmSpan, "dblclick", this._tree_pmImg_onmousedown, this);		
			if(this._vista)	CN_grid.addEvent(pmSpan, "mouseenter", this._tree_pmImg_onmouseenter, this);
		}
		else
		{
			img = "grid-" + img;		
		}

		if(img.length == 0) pmImg.style.display = "none";
		else pmImg.src = CNFormManager.themeImagesPath + img + ".gif";
	}
	else
	{
		pmImg.style.display = "none";
	}
}

proto._tree_pmImg_onmouseenter = function()
{
	var div = Util.findTag(Util.eventTarget(), "DIV");
	var jso = Util.findJSObject(div);
	
	var span = div.children[jso.ix_plusMinusSpan];
	var expanded = jso.tree_isExpanded(div.node);
	var hoverIMG = document.createElement("img");
	
	span.style.position = "relative";
	hoverIMG._hover = true;
	hoverIMG.src = expanded ? "themes/vista/g/hover-minus.gif" : "themes/vista/g/hover-plus.gif";
	hoverIMG.style.position = "absolute";
	hoverIMG.style.left = "5px";
	hoverIMG.style.top = "5px";
	span.appendChild(hoverIMG);
	CN_grid.addEvent(span, "mouseleave", jso._tree_pmImg_onmouseleave, jso);
}
proto._tree_pmImg_onmouseleave = function()
{
	var span = Util.eventTarget();
	var jso = Util.findJSObject(span);
	CN_grid.removeEvent(span, "mouseleave", jso._tree_pmImg_onmouseleave, jso);
	span.style.position = "static";
	if(span.lastChild && span.lastChild._hover) Util.removeElement(span.lastChild);
}

proto.tree_updateImageToState = function(nodeDiv, state)
{
	var icon = nodeDiv.children[this.ix_iconImg];
	var type = nodeDiv.type;
	var img;

	if(state == this.state_expandedSelected)
	{
		if(type.expandedImageUrl) img = type.expandedImageUrl;
		else if(type.selectedImageUrl) img = type.selectedImageUrl;
		if(!img) img = type.imageUrl;
	}
	else if(state == this.state_expanded)
	{
		img = type.expandedImageUrl;
		if(!img) img = type.imageUrl;
	}
	else if(state == this.state_selected)
	{
		if(!type.expandedImageUrl) img = type.selectedImageUrl;
		else img = type.imageUrl;
		if(!img) img = type.imageUrl;
	}
	else if(state == this.state_default) img = type.imageUrl;

	if(img) 
	{
		icon.src = img;
		icon.style.display = "inline";		
	}
	else icon.style.display = "none";
}

proto.tree_buildNode = function(nodeDiv, cell, node, level, index, nodeType)
{
	//if(node.parentNode.tagName != "r") alert("Assert for r tag.")

	node.parentNode.setAttribute("nodeIndex", index);
	nodeDiv.node = node; // Watch for circular refs!
	nodeDiv.nodeLevel = level;
	node.setAttribute("nodeLevel", level);

	var children = nodeDiv.children;

	var disabled = false;
	if(node.getAttribute("disable") == "true") disabled = nodeDiv.disabled = true; 
	
	var realType = nodeType;

	var rowNode = node.parentNode;
	var type = rowNode.getAttribute("type");
	if(type)
	{
		var type = this.tree_nodeTypes[String(type)];
		if(type) realType = this.tree_getOverridenTypeObject(realType, type);
	}
	realType = this.tree_getOverridenTypeObject(realType, rowNode);
	nodeDiv.type = realType;
	
	this.tree_buildLine(nodeDiv, node, children[this.ix_lineSpan], level);
	this.tree_buildPM(node, children[this.ix_plusMinusSpan], level);

	children[this.ix_textSpan].textContent = String(Util.xmlText(node));
	
	var expanded = this.tree_isExpanded(node);
	this.tree_updateImageToState(nodeDiv, expanded ? this.state_expanded : this.state_default);
	
	this.tree_buildNodeCheckbox(node, children, realType, disabled);

}

proto.tree_buildNodeCheckbox = function(node, children, realType, disabled)
{
	var checkBoxSpan = children[this.ix_checkBoxSpan];	
	
	var rowNode = node.parentNode;
	if(realType.checkBox == "true" && rowNode.getAttribute("checkBoxVisible") != "false") 
	{
		var checkedAttr = rowNode.getAttribute("checked");
		var checked = checkBoxSpan._checked = checkedAttr == "true";

		if(this._vista)
		{
			var img = document.createElement("img");
			checkBoxSpan.appendChild(img);
			this._set_checked(img, disabled, checked, false, false, false);
		}
		else
		{
			checkBoxSpan.innerHTML = checked ? "&#254;" : "&#111";
		}
		return true;
	}
	
	checkBoxSpan.style.display = "none";
	return false;
}

proto._set_checked = function(l, disabled, checked, hover, userAction, checkedChanged)
{
	var img;
	if(disabled)
		img = checked ? "checkedDisabledCheckbox.gif" : "uncheckedDisabledCheckbox.gif";
	else if(hover)
		img = checked ? "checkedHoverCheckbox.gif" : "uncheckedHoverCheckbox.gif";
	else
		img = checked ? "checkedCheckbox.gif" : "uncheckedCheckbox.gif";

	if(userAction || hover) 
	{
		VistaSupport.imageTrans(l, CNFormManager.themeImagesPath + img, checkedChanged);
	}
	else l.src = CNFormManager.themeImagesPath + img;
}


proto._tree_checkBoxSpan_onmouseenter = function()
{
	var l = Util.eventTarget();
	var jsObject = Util.findJSObject(l);

	if(!jsObject._vista || jsObject._readOnly || jsObject._disabled) return;

	var nodeDiv = CNUtil.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("disable") == "true") return;

	var checkBoxSpan = nodeDiv.children[jsObject.ix_checkBoxSpan];	
	var checked = checkBoxSpan._checked;
	jsObject._set_checked(l.firstChild, false, checked, true, true, true);	
}

proto._tree_checkBoxSpan_onmouseleave = function()
{
	var l = Util.eventTarget();
	var jsObject = Util.findJSObject(l);

	if(!jsObject._vista || jsObject._readOnly || jsObject._disabled) return;

	var nodeDiv = CNUtil.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("disable") == "true") return;
	var checkBoxSpan = nodeDiv.children[jsObject.ix_checkBoxSpan];	
	var checked = checkBoxSpan._checked;
	jsObject._set_checked(l.firstChild, false, checked, false, true, true);	
}

proto._tree_checkBoxSpan_onclick = function()
{
	CNUtil.dispatchObject().tree_checkBoxSpan_onclick();
}
proto.tree_checkBoxSpan_onclick = function()
{
	if(this._readOnly || this._disabled) return;

	var l = Util.eventTarget();
	var nodeDiv = CN_grid.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("disable") == "true") return;

	var row = CNUtil.findByClassName(nodeDiv, "rowDiv");
	if(row.readOnly) return;
	
	var checkBoxSpan = nodeDiv.children[this.ix_checkBoxSpan];	
	var checked = checkBoxSpan._checked = !checkBoxSpan._checked

	if(this._vista) this._set_checked(checkBoxSpan.firstChild, false, checked, true, true, true);	
	else checkBoxSpan.innerHTML = checked ? "&#254;" : "&#111";

	this.tree_storeChangedNode(row, row.rowIndex, "checked", checked);
}

proto._tree_icon_textSpan_onclick = function()
{
	CNUtil.findJSObject(Util.eventTarget()).tree_icon_textSpan_onclick();
}
proto._tree_icon_textSpan_ondblclick = function()
{
	CNUtil.findJSObject(Util.eventTarget()).tree_icon_textSpan_onclick();
}
proto.tree_icon_textSpan_onclick = function()
{
	var l = Util.eventTarget();
	var nodeDiv = CN_grid.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("disable") == "true") return;
	
	if(this._selectExpands) this.tree_toggleExpand(nodeDiv, true);
}

proto._tree_icon_textSpan_onmouseenter = function()
{
	CNUtil.findJSObject(Util.eventTarget()).tree_icon_textSpan_onmouseenter();
}
proto.tree_icon_textSpan_onmouseenter = function()
{
	var l = Util.eventTarget();	
	var nodeDiv = CN_grid.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("disable") == "true") return;

	this.tree_hoverNodeDiv(nodeDiv);
}

proto._tree_icon_textSpan_onmouseleave = function()
{
	CNUtil.findJSObject(Util.eventTarget()).tree_icon_textSpan_onmouseleave();
}
proto.tree_icon_textSpan_onmouseleave = function()
{
	var l = Util.eventTarget();
	var nodeDiv = CN_grid.findTag(l, "DIV");
	if(nodeDiv.node.getAttribute("disable") == "true") return;

	this.tree_unhoverNodeDiv(nodeDiv);
}

proto._tree_pmImg_onmousedown = function()
{
	CNUtil.findJSObject(Util.eventTarget()).tree_pmImg_onmousedown();
}
proto.tree_pmImg_onmousedown = function()
{
	if(this.formManager._loading)
		return;

	var l = Util.eventTarget();
	var div = CN_grid.findTag(l, "DIV");
	this.tree_toggleExpand(div, true);

	if(this._vista)
	{
		var span = div.children[this.ix_plusMinusSpan];
		var expanded = this.tree_isExpanded(div.node);
		var hoverIMG = span.lastChild;
		if(hoverIMG._hover) hoverIMG.src = expanded ? "themes/vista/g/hover-minus.gif" : "themes/vista/g/hover-plus.gif";
	}
}

proto.tree_hoverNodeDiv = function(l)
{
	if(this.tree_selectedNodeDiv != l) l.className = "tree_nodeDivOver";
}

proto.tree_unhoverNodeDiv = function(l)
{
	if(this.tree_selectedNodeDiv != l) l.className = "tree_nodeDiv";
	else l.className = "tree_nodeDivSelected";
}

proto.tree_toggleExpand = function(nodeDiv, userClick)
{
	this.tree_expandCollapse(nodeDiv, !this.tree_isExpanded(nodeDiv.node), userClick);
}

proto.tree_updateImage = function(nodeDiv)
{
	var state = this.state_default;
	var expanded = this.tree_isExpanded(nodeDiv.node);
	var selected = nodeDiv == this.tree_selectedNodeDiv;
	if(expanded && selected) state = this.state_expandedSelected;
	else if(expanded) state = this.state_expanded;
	else if(selected) state = this.state_selected;
	this.tree_updateImageToState(nodeDiv, state);
}

proto.tree_storeChangedNode = function(row, rowIndex, key, value, noStoreValue)
{
	var node = Util.xmlSelectSingleNode(this.changedFragment, this._tagPrefix + 'node[@row="' + rowIndex + '"]');
	var store = true;
	if(!node)
	{
		node = this.changedDoc.createElement(this._tagPrefix + "node");
		node.setAttribute("row", rowIndex);
		if(row.id) node.setAttribute("rowID", String(row.id).substr(3));
		this.changedFragment.appendChild(node);
	}
	node.setAttribute(key, String(value));
	
	if(this._treeAutoPostBack) this.formManager.postData(this.element);
}

proto.tree_selectNodeDiv = function(l)
{
	if(this.tree_selectedNodeDiv == l) return;
	
	this.tree_unselectNodeDiv();
	l.className = "nodeDivSelected";
	this.tree_selectedNodeDiv = l;
	this.tree_updateImage(l);
}

proto.tree_unselectNodeDiv = function()
{
	if(this.tree_selectedNodeDiv == null) return;
	var l = this.tree_selectedNodeDiv;
	l.className = "nodeDiv";

	this.tree_selectedNodeDiv = null;
	this.tree_updateImage(l);
} 

proto.tree_getContainerForNodeDiv = function(nodeDiv)
{
	return nodeDiv.parentElement.parentElement.nextSibling;
}

proto.tree_expandCollapse = function(nodeDiv, expand, userClick)
{
	var cont = this.tree_getContainerForNodeDiv(nodeDiv);
	if(!cont || !cont.isNodeContainer) return;
	if(!expand && (!cont.nodesBuilt || !this.tree_isExpanded(nodeDiv.node))) return;
	if(!expand)
	{
		// We should move focus out from grid to prevent IE from badly crash.
		// Always move focus, it's ok as user clicks +/- button anyway.
		try
		{
			document.body.focus();
		}
		catch(e){}
	}
	if(!cont.nodesBuilt)
	{
		Util.assert("Not implemented yet.");
		//if(expand) buildNodes(cont.storedNodes, cont, nodeDiv.nodeLevel + 1, cont.storedType);
		return;
	}

	if(this._vista)
	{
		if(expand)
		{
			cont.style.visibility = "hidden";
			cont.style.display = "block";
			
			var h = cont.offsetHeight;
			cont.style.height = "1px";
			cont.style.overflow = "hidden";
			cont.style.visibility = "visible";
			var anim = new AnimResize(cont, cont.offsetWidth, h);
			Animator.start(anim);
			anim.onend = function()
			{
				cont.style.height = "auto";
				cont.style.overflow = "auto";
			};
		}
		else
		{
			cont.style.overflow = "hidden";
			var anim = new AnimResize(cont, cont.offsetWidth, 1);
			Animator.start(anim);
			anim.onend = function()
			{
				cont.style.display = "none";
				cont.style.height = "auto";
				cont.style.overflow = "auto";
			};
		}
	}
	else cont.style.display = expand ? "block" : "none";

	var node = nodeDiv.node;
	node.parentNode.setAttribute("expanded", expand + "");
	
	var pmSpan = nodeDiv.children[this.ix_plusMinusSpan];
	pmSpan.children[0].src = CNFormManager.themeImagesPath + pmSpan.basePMImg 
										+ (expand ? "minus" : "plus") + ".gif";

	this.tree_updateImage(nodeDiv);
										
	// NOTE: reselect row, so border catches dimensions properly.
	if(this.selectedTR && this.selectedTR.parentElement) this.selectRow(this.selectedTR, true);

	var row = nodeDiv;
	while(row && row.rowIndex === undefined) row = row.parentElement;
	var rowIndex = row.rowIndex;

	if(userClick)
	{
		//if(tree_selectedNodeDiv && cont.contains(tree_selectedNodeDiv)) selectNodeDiv(nodeDiv, false);
		this.tree_storeChangedNode(row, rowIndex, "expanded", expand, !expand);
	}

	/*var ev = {};
	ev.rowIndex = rowIndex;
	ev.node = nodeDiv.node;
	ev.expanded = expand;
	if(this.onexpandcollapse) this.onexpandcollapse(ev);*/
}



// Properties. ============================================
proto.set_readOnly = function(value)
{
	this._readOnly = Util.parseBoolean(value);
	if(!this.isReady) return;
	this._set_readOnly();
}
proto._set_readOnly = function()
{
	var newClass = this._readOnly ? "readOnly" : "";
	this.rowsDiv.className = newClass;

	if(this._requiresReadOnlyWalk)
	{
		this._cellCount = 0;
		this._walkCells(this._fixCombos);
	}
}

proto._fixCombos = function(cell)
{
	var ct = cell.colTag;
	if(ct && ct.typeObject.set_readOnly)
	{
		ct.typeObject.set_readOnly(cell, this._readOnly);
		this._cellCount++;
	}
}

proto._walkCells = function(func)
{
	var all = this.rowsDiv.getElementsByTagName('span');
	var length = all.length;
	for(var i = 0; i < length; i++)
	{
		var l = all[i];
		if(l.isCell) func.apply(this, [l]);
	}
}

proto._walkRows = function(rowsDiv, func) {
	var children = rowsDiv.children;
	var length = children.length;
	for(var j = 0; j < length; j++) {
		var row = children[j];
		if(row.isNodeContainer) {
			this._walkRows(row, ix, func);
		}  else if(row.className == "rowDiv") {
			this[func](row);
		}
	}
}

proto.get_readOnly = function()
{
	return this._readOnly;
}

proto.set_disabled = function(value)
{
	if(value == this._disabled) return;
	this._disabled = value;

	if(value) this._set_tabIndex(-1);
	else if(this._tabIndex) this._set_tabIndex(this._tabIndex);


	if(this._disabled)
	{
		//this.element.appendChild(this.disabler);
		this.disabler.style.width = this.element.clientWidth;
		this.disabler.style.visibility = "inherit";
		this.element.style.backgroundColor = Util.getStyle(this.element, "xl--disabled-background");
		this.element.className = "cn_grid cn_grid_disabled";
	}
	else
	{
		this.element.style.backgroundColor = "";
		Util.removeElement(this.disabler);
		this.element.className = "cn_grid";
	}
}
proto.get_disabled = function()
{
	return this._disabled;
}

proto.set_selectedRow = function(value)
{
	value = parseInt(value, 10);
	if(!isNaN(value)) this._selectedRow = value;
	if(!this.isReady) return;
	this._set_selectedRow();
}
proto._set_selectedRow = function()
{
	if(this._selectedRow == -1) this.deselectRow();
	else if(this._selectedRow >= 0)
	{
		var divs = CN_grid.descendants(this.rowsDiv);
		var divCount = divs.length;
		for(var i = 0; i < divCount; i++)
		{
			var row = divs[i];
			if(row && row.rowIndex == this._selectedRow)
			{
				this.selectRow(row)
				if(this.alwaysScrollToSelected) 
				{
					this.rowsDiv.scrollTop = row.offsetTop;
				}
				break;
			}
		}
	}
	else 
	{
		this.deselectRow();
	}
}

proto._setRows = function(func, params)
{
	func(this.templateRow, params);
	func(this.folderTemplateRow, params);
	
	var rows = this.rowsDiv.children;
	var rowCount = rows.length;
	for(var i = 0; i < rowCount; i++)
	{
		var row = rows[i];
		if(row.rowIndex === undefined) continue;
		func(row, params);
	}
}

proto.set_gridLines = function(value)
{
	if(value == this._gridLines) return;
	this._gridLines = value;

	if(value == "none") this._setRows(this._set_rowGridLines, {rowLine: 0, cellLine: 0});
	else if(value == "horizontal") this._setRows(this._set_rowGridLines, {rowLine: 1, cellLine: 0});
	else if(value == "vertical") this._setRows(this._set_rowGridLines, {rowLine: 0, cellLine: 1});
	else if(value == "both") this._setRows(this._set_rowGridLines, {rowLine: 1, cellLine: 1});
}
proto._set_rowGridLines = function(row, params)
{
	row.style.borderWidth = params.rowLine;
	
	var cells = row.children;
	var cellCount = cells.length;
	for(var i = 0; i < cellCount; i++)
	{
		cells[i].style.borderWidth = params.cellLine;
	}
}

proto.set_rowHeight = function(value)
{
	if(value == this._rowHeight) return;
	this._rowHeight = value;
	
	this._setRows(this._set_rowHeight, value);
}

proto._set_rowHeight = function(row, value)
{
	row.style.height = value;
}

// Cell types. ==============================================================
var UnknownTypeCell = CN_grid.CellTypes["_UnknownType"] = function(colTag){}
var wp = UnknownTypeCell.prototype;
wp.prerender = function(cell, col){}
wp.isValid = function(cell){ return true; }
wp.render = function(cell, node)
{
	cell.textContent = "UNKNOWN TYPE: " + Util.xmlText(node);
}


/*
	Support for in-place activated editor box.
	For jsObject boxes:
		- directlyAssignEvents object field should be set to true.
		- focusout and keypress events used.
		- doNotCheckValidChars object field can be optionally set.
		- get_readOnly, set_readOnly, get_value, set_value, blur, focus, select
		  methods should be implemented.
	TypeObject should support:
		- box field.
		- validateValue(value, cell),
		- commitChange(value, cell, row, colTag),
		- validCharsRegex (if doNotCheckValidChars == false),
		- getCellValue(cell),
*/
var EditorBoxManager = 
{
	activeBox: null,
	cancelingChange: false,
	ignoreNextBlur: false,
	attachBoxEvents: function(l)
	{
		l._isBox = true;
		
		if(l.jsObject && l.jsObject.directlyAssignEvents)
		{
			l.jsObject.onblur = this.box_onblur;
			l.jsObject.onkeypress = this.box_onkeypress;
			l.jsObject.onpaste = this.box_onpaste;
		}
		else
		{
			CN_grid.addEvent(l, "blur", this.box_onblur, this);
			CN_grid.addEvent(l, "keypress", this.box_onkeypress, this);
			CN_grid.addEvent(l, "paste", this.box_onpaste, this);
		}
	},
	attachCellEvents: function(cell)
	{
		CN_grid.addEvent(cell, "mousedown", this.cell_onmousedown, this);
		CN_grid.addEvent(cell, "mouseenter", this._cell_onmouseenter, this);
		CN_grid.addEvent(cell, "mouseleave", this._cell_onmouseleave, this);
	},

	_cell_onmouseenter: function()
	{
		var cell = CN_grid.findCell(Util.eventTarget());

		if(!cell || (EditorBoxManager.activeBox == cell || EditorBoxManager.activeBox && cell.contains(EditorBoxManager.activeBox))) { // #975
			return;
		}

		var grid = CNUtil.dispatchObject();
		if(grid._readOnly) return;

		CNUtil.cancelEvent();
		// NOTE: do not show border for both _showEditorRectangle = "always" or "never".
		if(cell._isEmpty || cell._showEditorRectangle || !cell.colTag) return;

		var l = EditorBoxManager._hoverBorder;
		if(!l)
		{
			l = Util.createElementFromHTML("<div class=cellHoverBorderDiv>");
			//document.body.appendChild(l);
			EditorBoxManager._hoverBorder = l;
		}
		var to = cell.colTag.typeObject;
		if(to.setHoverBorderStyle) 
		{	
			to.setHoverBorderStyle(l, cell);
			l.style.visibility = "inherit";			
		}
		else EditorBoxManager._setHoverBorderStyle(l, cell);
		cell.appendChild(l);
	},
	
	_setHoverBorderStyle: function(l, cell)
	{
		l.style.visibility = "inherit";
		var paddingLeft = parseInt(Util.getStyle(cell, "paddingLeft"), 10);
		l.style.width = cell.clientWidth - paddingLeft + 2;		
		l.style.left = paddingLeft - 2;
		l.style.top = parseInt(Util.getStyle(cell, "paddingTop"), 10) - 2; // !!!
	},
	
	_cell_onmouseleave: function()
	{
		var cell = CN_grid.findCell(Util.eventTarget());
		if(!cell) return;
		
		var grid = CNUtil.dispatchObject();
		if(grid._readOnly) return;

		//if(CN_grid.relatedTarget() == EditorBoxManager._hoverBorder) return;
		if(EditorBoxManager.activeBox && cell.contains(EditorBoxManager.activeBox)) return;
		if(cell._isEmpty || cell._showEditorRectangle) return;
		if(cell.contains(CN_grid.relatedTarget())) 
		{
			return;
		}
		CNUtil.cancelEvent();		
		EditorBoxManager.hideHover();
	},
	hideHover : function() {
		var l = EditorBoxManager._hoverBorder;
		if(!l) return;
		if(CNFormManager.vista)
		{
			l.style.visibility = "hidden";
			EditorBoxManager._hoverBorder = null;
			Util.removeElement(l);
		}
		else l.style.visibility = "hidden";
	},
	_hover_ontransitionend: function()
	{
		var l = Util.eventTarget();
		Util.removeElement(l);
		CN_grid.removeEvent(l, "transitionend", EditorBoxManager._hover_ontransitionend, EditorBoxManager);
	},
	
	isCurrentBoxValid: function()
	{
		if(EditorBoxManager.activeBox == null) return true;
		var box = EditorBoxManager.activeBox;
		var cell = CN_grid.findCell(box);
		var typeObject = cell.colTag.typeObject;
		return EditorBoxManager._get_box_readOnly(box) || EditorBoxManager.canBlurBox(box, typeObject);
	},
	_get_box_readOnly: function(box)
	{
		if(box.jsObject) return box.jsObject.get_readOnly();
		else return box.readOnly;
	},	
	_set_box_readOnly: function(box, val)
	{
		if(box.jsObject) box.jsObject.set_readOnly(val);
		else box.readOnly = val;
	},	
	_get_box_value: function(box)
	{
		if(box.jsObject) return box.jsObject.get_value();
		else return box.value;
	},
	_set_box_value: function(box, val)
	{
		if(box.jsObject) box.jsObject.set_value(val);
		else box.value = val;
	},
	_box_blur: function(box)
	{
		if(box.jsObject) box.jsObject.blur();
		else {
			box.blur();
		}
	},
	_box_focus: function(box)
	{
		if(box.jsObject) {
			box.jsObject.focus();
		}
		else {
			try{ 
				box.focus(); 
			}catch(ex){}
		}
	},
	_box_select: function(box)
	{
		if(box.jsObject) box.jsObject.select();
		else box.select();
	},
	focusBox: function(box)
	{
		EditorBoxManager._box_focus(box);
		try
		{
			if(!EditorBoxManager._get_box_readOnly(box)) EditorBoxManager._box_select(box);
		}
		catch(ex){}
	},
	_findBox: function(box)
	{
		while(box != null && !box._isBox) box = box.parentElement;
		return box;
	},
	
	box_onblur: function()
	{
		if(EditorBoxManager.ignoreNextBlur)
		{
			EditorBoxManager.ignoreNextBlur = false;
			var grid = CNUtil.dispatchObject();
			if(CN_grid.relatedTarget() && grid.element.contains(CN_grid.relatedTarget()) || CN_grid.relatedTarget() == document.body)
			{
				return;
			}
		}
		
		var box = EditorBoxManager.activeBox;
		if(!box || !box.parentElement)
		{
			 return;
		}
		
		//CNFormManager._trace("BoxManager.box_onblur by " + Util.eventTarget().outerHTML);

		var box = EditorBoxManager._findBox(Util.eventTarget());

		var cell = CN_grid.findCell(box);
		var typeObject = cell.colTag.typeObject;
	
		var boxReadOnly = EditorBoxManager._get_box_readOnly(box);
		var canBlur = boxReadOnly || EditorBoxManager.canBlurBox(box, typeObject);
		var doCommit = !boxReadOnly && !EditorBoxManager.cancelingChange && canBlur;
		var remove = false;

		if(EditorBoxManager.cancelingChange || canBlur)
		{
			if(EditorBoxManager._hoverBorder) EditorBoxManager._hoverBorder.style.visibility = "hidden";
			
			if(typeObject.onAfterEdit) typeObject.onAfterEdit(cell);
			remove = true;
		}
		else 
		{
			Event.cancel(CN_grid.currentEvent());
		}

		if(doCommit) typeObject.commitChange(EditorBoxManager._get_box_value(box), cell, cell.parentElement, cell.colTag);
		if(remove) EditorBoxManager.removeBox(cell, box);
	},
	endActiveEdit: function(catchedCell) // catchedCell - optional.
	{
		var box = EditorBoxManager.activeBox;

		// Check if box is still visible and invalid.
		if(box && box.parentElement && !EditorBoxManager._get_box_readOnly(box))
		{
			//box.tabIndex = -1;
			var cell = CN_grid.findCell(box);
			if(cell == catchedCell) return;
			
			var typeObject = cell.colTag.typeObject;
			if(!EditorBoxManager.canBlurBox(box, typeObject)) {
				return;
			}
			var boxCell = box.parentElement;

			EditorBoxManager.removeBox(cell, box);
			typeObject.commitChange(EditorBoxManager._get_box_value(box), boxCell, boxCell.parentElement, boxCell.colTag);
			
			if(typeObject.onAfterEdit) typeObject.onAfterEdit(cell);
		}
	},
	beginEdit: function(catchedCell)
	{
		var cell = catchedCell;
		if(!cell.colTag) return;
		var typeObject = cell.colTag.typeObject;
		var box = typeObject.box;
		if(!box) return;
		
		if(catchedCell.contains(EditorBoxManager.activeBox)) return;

		EditorBoxManager.endActiveEdit(catchedCell);

		var gridJSO = Util.findJSObject(cell);
		if(gridJSO._readOnly && CN_grid.fullRowSelect) return;

		EditorBoxManager.activeBox = box;
				
		// NOTE: check readOnly only AFTER commit, as commit can change readOnly state (via ignorePostBack).
		
		var readOnly = gridJSO.getCascadedReadOnly(cell);
		EditorBoxManager._set_box_readOnly(box, readOnly);
		if(readOnly) 
		{
			// Attach to cell, as box doesn't fire events in readOnly mode.
			Event.add(cell, "keydown", cell, CN_grid.cancelBackspace);
		}
		
		EditorBoxManager.cancelingChange = false;
		var paddingLeft = parseInt(Util.getStyle(cell, "paddingLeft"), 10);
		box.style.left = paddingLeft - 2;
		box.style.top = parseInt(Util.getStyle(cell, "paddingTop")) - 2; /// !!!
		box.style.width = cell.clientWidth - paddingLeft + 2;

		EditorBoxManager._set_box_value(box, typeObject.getCellValue(cell));
		cell.className = cell.className + " edited";
		cell.appendChild(box);
		box.style.display = "block";
		if(typeObject.onBeforeEdit) typeObject.onBeforeEdit(cell);
		
		// WARNING: possible cross-ref.
		setTimeout(function()
		{
			//EditorBoxManager.ignoreNextBlur = true;
			//gridJSO._skipNextFocus = true; // 1036-3
			EditorBoxManager.focusBox(box);

			//CNFormManager._trace("box.parentElement: " + box.parentElement + " box.offsetWidth: " + box.offsetWidth);
		}, 0);

	},
	removeBox: function(cell, box)
	{
		Util.removeClass(cell, "edited");
		EditorBoxManager.ignoreNextBlur = true;
		if(box == EditorBoxManager.activeBox) EditorBoxManager.activeBox = null;
		//setTimeout(function(){ - NOTE: setTimeout here causing FWUI-1264 due to removeBox async'ly called right after beginEdit. 
			//CNFormManager._trace("removeBox: hiding the box");
			box.style.display = "none";
		//}, 0);
	},
	box_onkeypress: function()
	{
		var box = EditorBoxManager._findBox(Util.eventTarget());

		var code = Event.keyValue(CN_grid.currentEvent());
		if(code == 0) return;

		if(code == 13) 
		{
			//alert("box manager enter")
			Util.cancelEvent(CN_grid.currentEvent());
			EditorBoxManager.endActiveEdit();
//			try{ EditorBoxManager._box_blur(box); } catch(e){}
		}
		else if(code == 27)
		{
			EditorBoxManager.cancelingChange = true;
			try{ EditorBoxManager._box_blur(box); } catch(e){}
		}
		else if(!box.doNotCheckValidChars)
		{
			// Validate char.
			var l = Util.eventTarget();
			var cell = CN_grid.findCell(l);
			var validCharsRegex = cell.colTag.typeObject.validCharsRegex;
			if(!validCharsRegex) return true;
	
			var charx = String.fromCharCode(code);
			return charx.match(cell.colTag.typeObject.validCharsRegex) != null;
		}
	},
	cell_onmousedown: function()
	{
		var catchedCell = CN_grid.findCell(Util.eventTarget());
		if(catchedCell._isEmpty) return;
		EditorBoxManager.beginEdit(catchedCell);
	},
	canBlurBox: function(box, typeObject)
	{
		var cell = CN_grid.findCell(box);
		if(!typeObject.validateValue(EditorBoxManager._get_box_value(box), cell))
		{			
			var cellIndex = cell.cellIndex;			
			
			EditorBoxManager._box_setError(box, typeObject, true);
//			EditorBoxManager._box_focus(box);
			setTimeout(function(){ EditorBoxManager._box_setError(box, typeObject, false); }, 500);
			return false;
		}
		return true;
	},
	box_onpaste: function(box, typeObject)
	{
		var box = EditorBoxManager._findBox(Util.eventTarget());
		var cell = CN_grid.findCell(box);
		var typeObject = cell.colTag.typeObject;
		
		if(!typeObject.validateValue(CN_grid.readClipboardText(), cell))
		{			
			var cellIndex = cell.cellIndex;			
			
			EditorBoxManager._box_setError(box, typeObject, true);
//			EditorBoxManager._box_focus(box);
			setTimeout(function(){ EditorBoxManager._box_setError(box, typeObject, false); }, 500);
			return false;
		}
		return true;
	},
	_box_setError: function(box, typeObject, error) {
		if(typeObject.setErrorBorder) { // Used for dateboxtime.
			typeObject.setErrorBorder(error);
		} else {
			box.style.borderColor = error ? "red" : "";
		}
	}	
}

// String. =========================================================
// NOTE: this type is generic for other types but it's also fully functional as cell type.
var StringTypeCell = CN_grid.CellTypes["String"] = function(colTag)
{
	this.box = StringTypeCell.createBox();
}
StringTypeCell.cn_tagName = "textbox";
StringTypeCell.createBox = function()
{
	var l = Util.createElementFromHTML("<input class=textbox type=text>");
	EditorBoxManager.attachBoxEvents(l);
	return l;
}
var wp = StringTypeCell.prototype;

wp.getCellValue = function(cell)
{
	return cell.firstChild.textContent;
}
wp.setCellValue = function(cell, value)
{
	var border;
	if(cell._showEditorRectangle) 
	{
		border = cell.lastChild;
		Util.removeElement(border);
	}
	cell.innerHTML = "<span>" + value + "</span>";
	if(border) cell.appendChild(border);
}
wp.isValid = function(cell)
{ 
	var result;
	// Always return true for readEnly empty cells.
	if(EditorBoxManager.activeBox != null && EditorBoxManager.activeBox.parentElement == cell)
	{
		result = this.validateValue(this.box.value, cell); 
	}
	else	
	{
		result = this.validateValue(this.getCellValue(cell), cell); 
	}
	return result;
}
wp.validateValue = function(value, cell)
{
	if(value.replace(/\s+/, "") == "")
	{
		if(cell.colTag.canBeEmpty) return true;
		else
		{ 
			var jsObject = CNUtil.findJSObject(cell);
			if(jsObject.getCascadedReadOnly(cell)) return true; 
		}
		return false;		
	}
	else return true;
}
wp.commitChange = function(value, cell, row, colTag)
{
	if(this._casing)
	{
		if(this._casing == "upper") value = value.toUpperCase();
		else if(this._casing == "lower") value = value.toLowerCase();
	}

	if(!this.validateValue(value, cell)) return;

	if(this.getCellValue(cell) != value)
	{
		var self = this;
		setTimeout(function(){ self.setCellValue(cell, value); }, 0); // FWUI-1253 - set cell value async'ed as else no events happens in next focused control out of grid.
		var jsObject = CNUtil.findJSObject(cell);
		jsObject.setChangedValue(row, cell, value);
		jsObject.fireChangedEvent(row, cell, value);
		//if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, value);
	}
}
wp.prerender = function(cell, colTag)
{
	var attr = colTag.node.getAttribute("maxLength");
	if(attr) this.box.maxLength = parseInt(attr, 10);

	colTag.typeObject = this;
	EditorBoxManager.attachCellEvents(cell);
	
	var casing = colTag.node.getAttribute("casing");
	if(casing)
	{
		this._casing = String(casing);
		if(casing == "upper") this.box.style.textTransform = cell.style.textTransform = "uppercase";
		else if(casing == "lower") this.box.style.textTransform = cell.style.textTransform = "lowercase";
	}
}
wp.render = function(cell, node)
{
	cell.innerHTML = "<span>" + Util.xmlText(node) + "</span>";
}


// Bool. =========================================================
var BoolTypeCell = CN_grid.CellTypes["Bool"] = function(colTag)
{
}
BoolTypeCell.cn_tagName = "checkbox";
BoolTypeCell._toggleBox = function(box, jsObject, mo)
{
	var cell = box.parentElement;
	var row = cell.parentElement;
		
	box.checked = !box.checked;
	var src;
	if(mo) src = CNFormManager.themeImagesPath + (box.checked ? "checkedHoverCheckbox.gif" : "uncheckedHoverCheckbox.gif");
	else src = CNFormManager.themeImagesPath + (box.checked ? "checkedCheckbox.gif" : "uncheckedCheckbox.gif");
	
	if(CNFormManager.vista) VistaSupport.imageTrans(box, src, !box.checked);
	else box.src = src;

	jsObject.setChangedValue(row, cell, String(box.checked));
	jsObject.fireChangedEvent(row, cell, box.checked);
	if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, box.checked);
}
var wp = BoolTypeCell.prototype;
wp.isFocusable = true;
wp.ascSortFunction = function(a, b)
{
	var aChecked = a[2].children[0].checked;
	var bChecked = b[2].children[0].checked;
	if(!aChecked && bChecked) return 1;
	if(aChecked && !bChecked) return -1;
	return 0;

}
wp.descSortFunction = function(a, b)
{
	var aChecked = a[2].children[0].checked;
	var bChecked = b[2].children[0].checked;
	if(aChecked && !bChecked) return 1;
	if(!aChecked && bChecked) return -1;
	return 0;
}
// Event handlers.
wp.box_onmousedown = function()
{
	if(CN_grid.currentEvent().button != 1) return;
	var box = Util.eventTarget();
	var jsObject = CNUtil.findJSObject(box);
	if(jsObject.getCascadedReadOnly(box)) return;

	BoolTypeCell._toggleBox(box, jsObject, true);
}
wp.box_onmouseenter = function()
{
	var l = Util.eventTarget();
	var jsObject = CNUtil.findJSObject(l);
	if(jsObject.getCascadedReadOnly(l)) return;

	var src = CNFormManager.themeImagesPath + (l.checked ? "checkedHoverCheckbox.gif" : "uncheckedHoverCheckbox.gif");
	if(CNFormManager.vista) VistaSupport.imageTrans(l, src, false);
	else l.src = src;
}
wp.box_onmouseleave = function()
{
	var l = Util.eventTarget();
	var jsObject = CNUtil.findJSObject(l);
	if(jsObject.getCascadedReadOnly(l)) return;
	src = CNFormManager.themeImagesPath + (l.checked ? "checkedCheckbox.gif" : "uncheckedCheckbox.gif");
	if(CNFormManager.vista) VistaSupport.imageTrans(l, src, true);
	else l.src = src;
}
wp._cell_onkeydown = function()
{
	if(Event.keyValue(CN_grid.currentEvent()) != 32) return;
	var box = Util.eventTarget().children[0];
	var jsObject = CNUtil.findJSObject(box);
	if(jsObject.getCascadedReadOnly(box)) return;

	BoolTypeCell._toggleBox(box, jsObject, false);
}
wp._cell_beforedeactivate = function()
{
	if(CN_grid.relatedTarget() == document.body) CNUtil.cancelEvent();
	else Util.eventTarget().tabIndex = -1;
}
wp.isValid = function(cell){ return true; }
wp.prerender = function(cell, colTag)
{
}
wp.render = function(cell, node)
{
	var l = Util.createElementFromHTML("<img width=13 height=13 class=xlcheckboximg>")
	cell.appendChild(l);
	
	CN_grid.addEvent(l, "mousedown", this.box_onmousedown, this);
	CN_grid.addEvent(l, "mouseenter", this.box_onmouseenter, this);
	CN_grid.addEvent(l, "mouseleave", this.box_onmouseleave, this);
	CN_grid.addEvent(cell, "keydown", this._cell_onkeydown, this);
	CN_grid.addEvent(cell, "focusout", this._cell_beforedeactivate, this);
	
	if(Util.xmlText(node) == "false") 
	{
		l.src = CNFormManager.themeImagesPath + "uncheckedCheckbox.gif";
		l.checked = false;
	}
	else
	{
		l.src = CNFormManager.themeImagesPath + "checkedCheckbox.gif";
		l.checked = true;
	}
}

// Int. =========================================================
var IntTypeCell = CN_grid.CellTypes["Int"] = function(colTag)
{
	this.box = StringTypeCell.createBox();
	CN_grid.addEvent(this.box, "keypress", IntTypeCell._box_onkeypress, null);	
	
	this.box.maxLength = 9;
	
	//Check maxLength: default maxLength = 9
	var attr = colTag.node.getAttribute("maxLength");
	if(attr)
	{
		if (parseInt(attr, 10) > 0)
		{
			this.box.maxLength = parseInt(attr, 10);
		}
	}
	
	this.validCharsRegex = /[0-9\-]/;
}

//IntTypeCell onkeypress event
IntTypeCell._box_onkeypress = function() 
{
	var cell = CN_grid.findCell(Util.eventTarget());
	var jsObject = cell.colTag.typeObject;
	
	if(jsObject.box.textContent.length > 0 && 
			cell.textContent.length >= jsObject.box.maxLength)	
	{
		CNUtil.cancelEvent();
	}
}

IntTypeCell.cn_tagName = "intbox";
var wp = IntTypeCell.prototype;
wp.getCellValue = StringTypeCell.prototype.getCellValue;
wp.setCellValue = StringTypeCell.prototype.setCellValue;
wp.isValid = StringTypeCell.prototype.isValid;
wp.ascSortFunction = function(a, b)
{
	var af = parseInt(a[0]);
	var bf = parseInt(b[0]);
	if(af > bf || isNaN(bf)) return 1;
	if(af < bf || isNaN(af)) return -1;
	return 0;

}
wp.descSortFunction = function(a, b)
{
	var af = parseInt(a[0]);
	var bf = parseInt(b[0]);
	if(af < bf || isNaN(af)) return 1;
	if(af > bf || isNaN(bf)) return -1;
	return 0;
}
wp.validateValue = function(value, cell)
{
	if(value.replace(/\s+/, "") == "")
	{
		if(cell.colTag.canBeEmpty) return true;
		else
		{
			var jsObject = CNUtil.findJSObject(cell);
			if(jsObject.getCascadedReadOnly(cell)) return true;
		}
	}
	return value.match(/^(\+|\-)?\d+$/);
}
wp.commitChange = function(value, cell, row, colTag)
{
	if(!this.validateValue(value, cell)) return;
	var doChange = false;

	var v1 = cell.firstChild.textContent.replace(/\s+/, "");
	var v2 = value.replace(/\s+/, "");
	if(v1 != v2)
	{
		if(v1 != "" && v2 == "")
		{
			// Empty
			value = "";
			this.setCellValue(cell, value);
			doChange = true;
		}
		else if(v1 == "" || cell.firstChild.textContent * 1 != value * 1)
		{
			value = value * 1;
			this.setCellValue(cell, value);
			doChange = true;
		}
	}
	if(doChange)
	{
		var jsObject = CNUtil.findJSObject(cell);
		jsObject.setChangedValue(row, cell, value);
		jsObject.fireChangedEvent(row, cell, value);
		if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, value);
	}
}
wp.prerender = StringTypeCell.prototype.prerender;
wp.render = StringTypeCell.prototype.render;


// Decimal. =========================================
var DecimalTypeCell = CN_grid.CellTypes["Decimal"] = function(colTag)
{
	this.box = StringTypeCell.createBox();

	var scale = colTag.node.getAttribute("scale");
	if(scale) this.scale = parseInt(scale, 10);
	else this.scale = 2;
	
	var precision = colTag.node.getAttribute("precision");
	if(precision) this.precision = parseInt(precision, 10);
	else this.precision = 10;

	var decDigits = this.precision - this.scale;
							// 000.00
	var str;
	if(this.scale > 0)
	{
		str = "^(\\+|\\-)?(\\d{1," + decDigits + "}(\\.)\\d{1," + this.scale + "}|"
								// .00
								+ "(\\.)\\d{1," + this.scale + "}|"
								// 00
								+ "\\d{1," + decDigits + "})$";
	}
	else str = "^\\d(\\+|\\-)?(\\d{1," + decDigits + "})$";
	
	this.regex = new RegExp(str);
	this.validCharsRegex = /[0-9+\-.]/;
}

DecimalTypeCell.cn_tagName = "decimalbox";
var wp = DecimalTypeCell.prototype;
wp.getCellValue = StringTypeCell.prototype.getCellValue;
wp.setCellValue = StringTypeCell.prototype.setCellValue;
wp.isValid = StringTypeCell.prototype.isValid;
wp.ascSortFunction = function(a, b)
{
	var af = parseFloat(a[0]);
	var bf = parseFloat(b[0]);
	if(af > bf) return 1;
	if(af < bf) return -1;
	return 0;

}
wp.descSortFunction = function(a, b)
{
	var af = parseFloat(a[0]);
	var bf = parseFloat(b[0]);
	if(af < bf) return 1;
	if(af > bf) return -1;
	return 0;
}
wp.validateValue = function(value, cell)
{
	if(value.replace(/\s+/, "") == "")
	{
		if(cell.colTag.canBeEmpty) return true;
		else
		{
			var jsObject = CNUtil.findJSObject(cell);
			if(jsObject.getCascadedReadOnly(cell)) return true;
		}
	}
	var result = value.match(this.regex) != null;
	return result;
}
wp.commitChange = IntTypeCell.prototype.commitChange;
wp.prerender = StringTypeCell.prototype.prerender;
wp.render = StringTypeCell.prototype.render;


// Date. ====================================================
var DateTypeCell = CN_grid.CellTypes["Date"] = function(colTag)
{
	this.box = StringTypeCell.createBox();
	this.box.maxLength = 10;
	this.validCharsRegex = /[0-9\/]/;
}
DateTypeCell.cn_tagName = "datebox";
DateTypeCell.defaultValidationString = "Invalid Date";
DateTypeCell.calendar_onxlresult = function()
{
	// NOTE: probably serving alien grid.
	var calendar = CNPopupCalendar.defaultInstance;
	var cell = calendar._activeCell;
	calendar._activeCell = null;
	
	var value = calendar.get_dateString();
	// Update edit box.
	if(EditorBoxManager.activeBox && cell.contains(EditorBoxManager.activeBox)) EditorBoxManager.activeBox.value = value;
	
	cell.colTag.typeObject.commitChange(value, cell, cell.parentElement, cell.colTag);
}
DateTypeCell._getDate = function(str)
{
	var ar = String(str).split("/");
	return new Date(parseInt(ar[2], 10), parseInt(ar[1], 10) - 1, parseInt(ar[0], 10));
}
var wp = DateTypeCell.prototype;
wp.ascSortFunction = function(a, b)
{
	if(a[0].length == 0) return 1;
	if(b[0].length == 0) return -1;
	a = DateTypeCell._getDate(a[0]).getTime();
	b = DateTypeCell._getDate(b[0]).getTime();

	if(a < b) return 1;
	if(a == b) return 0;
	return -1;
}
wp.descSortFunction = function(a, b)
{
	if(a[0].length == 0) return -1;
	if(b[0].length == 0) return 1;
	a = DateTypeCell._getDate(a[0]).getTime();
	b = DateTypeCell._getDate(b[0]).getTime();

	if(a > b) return 1;
	if(a == b) return 0;
	return -1;
}

wp.getCellValue = function(cell){ return cell.children[0].textContent; }
wp.setCellValue = function(cell, value){ cell.children[0].textContent = value; }
wp.button_onclick = function()
{
	var cell = CN_grid.findCell(Util.eventTarget());
	var jsObject = CNUtil.findJSObject(cell);
	
	if(jsObject.getCascadedReadOnly(cell)) return;

	var x = CN_grid.currentEvent().screenX - window.screenLeft;
	var y = CN_grid.currentEvent().screenY - window.screenTop;

	var calendar = CNPopupCalendar.defaultInstance;
	calendar._activeCell = cell;
	calendar.onxlresult = DateTypeCell.calendar_onxlresult;
	calendar.show(cell.children[0].textContent, null, x, y);

	//Event.cancel(CN_grid.currentEvent());
}
wp.isValid = StringTypeCell.prototype.isValid;
wp.validateValue = function(value, cell)
{
	if(value.replace(/\s+/, "") == "")
	{
		if(cell.colTag.canBeEmpty) return true;
		else
		{
			var jsObject = CNUtil.findJSObject(cell);
			if(jsObject.getCascadedReadOnly(cell)) return true;
		}
	}
	var ar = value.split(/\/|\.|\-/);
	if(ar.length == 3) 
	{
		var year = ar[2] * 1;
		//if(year > 50 && year < 100) year += 1900;
		//if(year < 50) year += 2000;
		var date = new Date(year, ar[1] - 1, ar[0]);
		return date.getMonth() == ar[1] - 1 && date.getDate() == ar[0] && date.getFullYear() == year;
	}
	return false;
}
wp.commitChange = function(value, cell, row, colTag)
{
	if(!this.validateValue(value, cell)) return;
	if(cell.children[0].textContent != value)
	{
		// NOTE: always leave some space to click on.
		if(value.replace(/\s+/, "") == "") cell.children[0].textContent = "   ";
		else cell.children[0].textContent = value;

		var jsObject = CNUtil.findJSObject(cell);
		jsObject.setChangedValue(row, cell, value);
		jsObject.fireChangedEvent(row, cell, value);
		if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, value);
	}
}
wp.setHoverBorderStyle = function(l, cell)
{
	l.style.width = cell.clientWidth - 18;
	l.style.left = 0;
	l.style.top = 3;
}
wp.prerender = function(cell, colTag)
{
	colTag.typeObject = this;
	var text = document.createElement("div")
	cell.appendChild(text);
	
	EditorBoxManager.attachCellEvents(cell);
	
	var button;
	if(CNFormManager.vista)
	{
		button = VistaSupport.createImageButton("grid-datebox-button.gif", 16, 16);
		cell.style.paddingRight = "18px";
		button.style.top = "3px";
	}
	else
	{
		button = Util.createElementFromHTML("<button class=xllookupbutton>");
		CN_grid.addEvent(button, "mouseenter", _CN_button_onmouseenter, null);
		CN_grid.addEvent(button, "mouseleave", _CN_button_onmouseleave, null);
		button.tabIndex = -1;
		button.style["float"] = "right"; // float => rhino reserved
		text.style.width = "100%"//Math.max(cell.clientWidth - button.offsetWidth - 8 - parseInt(Util.getStyle(cell, "paddingLeft")), 1); /* !!! */
		button.style.top = "5px";
	}

	CN_grid.addEvent(button, "click", this.button_onclick, this);
	CN_grid.addEvent(button, "mousedown", CNUtil.cancelEvent, null);
	
	button.style.position = "absolute";
	button.style.right = "0px";
	cell.appendChild(button);
}
wp.render = function(cell, node)
{
	if(!CNFormManager.vista)
	{
		var img = Util.createElementFromHTML("<img width=8 height=8>");
		cell.children[1].appendChild(img);
		img.src = CNFormManager.themeImagesPath + "calendar8x8.gif";
	}

	cell.children[0].textContent = Util.xmlText(node);
	
	if(cell.parentElement.readOnly || cell.colTag.readOnly) cell.children[1].style.display = "none";
}


var DateTimeTypeCell = CN_grid.CellTypes["DateTime"] = function(colTag, grid)
{
	this.box = DateTimeTypeCell.createBox();
	var boxJSO = this.box.firstChild.jsObject;
	grid._jsObjects.push(boxJSO);
	boxJSO._canBeEmpty = colTag.canBeEmpty;
	this.validCharsRegex = /[0-9]/;
}
DateTimeTypeCell.cn_tagName = "datetimebox";
DateTimeTypeCell.defaultValidationString = "Invalid Date/Time";
DateTimeTypeCell.createBox = function()
{
	var box = new CN_datebox();
	var l = box.createElement(Util.wrapIntoNode({time: "true"}));
	box._timeBox.dontCancelBlur = true; // FWUI-1036 - allow focus to go out of invalid timebox, so grid validation can take place.

	CN_grid.addEvent(box.element, "keydown", DateTimeTypeCell._box_onkeydown, null);
	
	// Wrap date-time table with the div, as table produces unwanted padding to the cell (even absolute pos'ed table!).
	var div = document.createElement("div");
	div.appendChild(l);
	div.style.position = "absolute";
	div.jsObject = box;
		
	EditorBoxManager.attachBoxEvents(div);
	return div;
}
DateTimeTypeCell._box_onkeydown = function() { // FWUI-1036 - proxy tab keys to grid from the calendar button.
	CN_grid.proxyTabKeyDown();
}

var wp = DateTimeTypeCell.prototype;
wp.setErrorBorder = function(error) {
	this.box.firstChild.style.borderColor = error ? "red" : "";
}
wp.getCellValue = function(cell)
{
	return cell._raw;
}
wp.setCellValue = function(cell, value)
{
	var dt = this.box.firstChild.jsObject.getReadableDateTime(value)
	cell.children[0].textContent = dt[0] + " " + dt[1];
	cell._raw = String(value);
}
wp.validateValue = function(value, cell)
{
	var val = this.box.firstChild.jsObject.isValid(true);
	return val;
}
// This sometimes called for box-less cells, so it should not assume box is active and correct.
wp.isValid = function(cell) {
	var boxJSO = this.box.firstChild.jsObject;

	if(boxJSO._canBeEmpty && cell._raw == "") return true;
	try {
		var dt = boxJSO._parseDate(cell._raw);
		return true;
	} catch(e) {
	}
	return false;	
}
wp.commitChange = function(value, cell, row, colTag)
{
	if(!this.isValid(cell)) return;
	
	if(cell._raw != value)
	{
		this.setCellValue(cell, value);
		
		var jsObject = CNUtil.findJSObject(cell);
		jsObject.setChangedValue(row, cell, value);
		jsObject.fireChangedEvent(row, cell, value);
		if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, value);
	}
}
//wp.onAfterEdit = function(cell)
//{
////	cell.style.paddingTop = "5px";
////	this.box.parentNode.removeChild(this.box);
//}
//wp.onBeforeEdit = function(cell)
//{
////	cell.style.paddingTop = "1px";
////	cell.firstChild.style.display = "none";
//}
wp.prerender = function(cell, colTag)
{
	colTag.typeObject = this;
	EditorBoxManager.attachCellEvents(cell);
	
	var text = document.createElement("span")
	text.className = "dateTimeText";
	cell.appendChild(text);
	cell.style.paddingTop = "5px";
}
wp.render = function(cell, node)
{
	this.setCellValue(cell, Util.xmlText(node));
}


// Time. ==================================================
var TimeTypeCell = CN_grid.CellTypes["Time"] = function(colTag, grid)
{
	this.box = TimeTypeCell.createBox();
	grid._jsObjects.push(this.box.jsObject);	
	this.box.jsObject._canBeEmpty = colTag.canBeEmpty;
	this.box.jsObject.onchange = null; // Remove fommanager call.
	this.box.jsObject._grid = grid;
	this.validCharsRegex = /[0-9]/;
}
TimeTypeCell.cn_tagName = "timebox";
TimeTypeCell.defaultValidationString = "Invalid Time";
TimeTypeCell.createBox = function()
{
	var timebox = new CN_timebox();
	var l = timebox.createElement();
	l.style.position = "absolute";
	
	EditorBoxManager.attachBoxEvents(l);
	return l;
}
var wp = TimeTypeCell.prototype;
wp.getCellValue = StringTypeCell.prototype.getCellValue;
wp.setCellValue = StringTypeCell.prototype.setCellValue;
wp.isValid = function(cell)
{ 
	var result;
	if(EditorBoxManager.activeBox != null && EditorBoxManager.activeBox.parentElement == cell) {
		result = this.validateValue(this.box.jsObject.get_value(), cell); 
 	} else {
		result = this.validateValue(this.getCellValue(cell), cell); 
	}
	return result;
}
wp.validateValue = function(value, cell)
{
	if(!this.box.jsObject) return true;
	return this.box.jsObject.validateValue(value, cell.colTag.canBeEmpty);
}
wp.commitChange = function(value, cell, row, colTag)
{
	if(!this.validateValue(value, cell)) return;
	if(cell.children[0].textContent != value)
	{
		if(value.replace(/\s+/g, "") == ":") cell.children[0].textContent = " ";
		else cell.children[0].textContent = value;
		
		var jsObject = CNUtil.findJSObject(cell);
		jsObject.setChangedValue(row, cell, value);
		jsObject.fireChangedEvent(row, cell, value);
		if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, value);
	}
}
wp.prerender = function(cell, colTag)
{
	colTag.typeObject = this;
	EditorBoxManager.attachCellEvents(cell);
	
	var text = document.createElement("span")
	cell.appendChild(text);
}
wp.render = function(cell, node)
{
	cell.children[0].textContent = Util.xmlText(node);
}


// Button. ==============================================
var ButtonTypeCell = CN_grid.CellTypes["Button"] = function(colTag){}
ButtonTypeCell.cn_tagName = "button";
var wp = ButtonTypeCell.prototype;
wp.isValid = function(cell){ return true; }
wp.isFocusable = true;
// Event handlers.
wp.box_onclick = function()
{
	var cell = CN_grid.findCell(Util.eventTarget());
	var jsObject = CNUtil.findJSObject(cell);
	if(jsObject._disabled) return;
	var row = cell.parentElement;

	var jsObject = CNUtil.findJSObject(cell);
	jsObject.setChangedValue(row, cell, null);
	jsObject.fireChangedEvent(row, cell, null);
	if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, null);
}
wp._cell_onkeydown = function()
{
	if(Util.eventTarget().className != "cellSpan") return;
	if(Event.keyValue(CN_grid.currentEvent()) == 13)
	{
		CNUtil.cancelEvent();
		var cell = Util.eventTarget();
		cell.children[cell.children.length - 1].click();
	}
}
wp._button_onmouseenter = function()
{
	VistaSupport.imageTrans(Util.eventTarget().firstChild, "themes/vista/g/hover-grid-button.gif");
}
wp._button_onmouseleave = function()
{
	VistaSupport.imageTrans(Util.eventTarget().firstChild, "themes/vista/g/grid-button.gif");
}
wp._button_onmouseup = function()
{
	var img = Util.findByClassName(Util.eventTarget(), "gridButtonSpan").firstChild;
	VistaSupport.imageTrans(img, "themes/vista/g/hover-grid-button.gif");
}
wp._button_onmousedown = function()
{
	var img = Util.findByClassName(Util.eventTarget(), "gridButtonSpan").firstChild;
	VistaSupport.imageTrans(img, "themes/vista/g/down-grid-button.gif", true);
}
wp._createSpanButton = function()
{
	var button = Util.createElementFromHTML("<span class='gridButtonSpan'>");
	var img = document.createElement("img");
	img.src = "themes/vista/g/grid-button.gif";
	img.width = img.height = 16;
	button.appendChild(img);
	CN_grid.addEvent(button, "mouseenter", this._button_onmouseenter, this);
	CN_grid.addEvent(button, "mouseleave", this._button_onmouseleave, this);
	CN_grid.addEvent(button, "mousedown", this._button_onmousedown, this);
	CN_grid.addEvent(button, "mouseup", this._button_onmouseup, this);
	return button;
}
wp.prerender = function(cell, colTag)
{
	var text = document.createElement("span");
	cell.appendChild(text);
	
	var button;
	if(CNFormManager.vista)
	{
		cell.style.paddingTop = "3px";
		button = this._createSpanButton();
		button.style.marginLeft = "3px";
		cell.appendChild(button);		
	}
	else
	{
		button = Util.createElementFromHTML("<button class=xllookupbutton>")
		cell.appendChild(button);
		
		button.tabIndex = -1;
		CN_grid.addEvent(button, "mouseenter", _CN_button_onmouseenter, null);
		CN_grid.addEvent(button, "mouseleave", _CN_button_onmouseleave, null);
	}
	CN_grid.addEvent(button, "click", this.box_onclick, this);
	CN_grid.addEvent(cell, "keydown", this._cell_onkeydown, this);

	this._img_src = CNFormManager.themeImagesPath + "lookup.gif";
	//this._img_width = 8;
	//this._img_wheight = 8;
}
wp.render = function(cell, node)
{
	var src;//, width, height;
	
	var buttonText = node.getAttribute("buttonText");
	{
		if (buttonText)
		{
			cell.style.paddingTop = "3px";
			cell.style.paddingBottom = "3px";
			
			var b = cell.children[1];			
			b.style.marginLeft = "3px";
			b.style.marginRight = "3px";
			if (cell.clientWidth && cell.clientWidth > 0)			
				b.style.width = cell.clientWidth - 8 + "px";
			else
				b.style.width = parseInt(cell.style.width) - 8 + "px";
			
			b.style.height = "23px";
			
			var textSpan = document.createTextNode(String(buttonText));				
			
			var buttonTextColor = node.getAttribute("buttonTextColor");			
			if (buttonTextColor)
			{
				var font = document.createElement("font");
				font.style.color = buttonTextColor;
				font.appendChild(textSpan);
				b.appendChild(font);
			}
			else
				b.appendChild(textSpan);
			
			cell.children[0].textContent = Util.xmlText(node);
			
			return;
		}
	}
	
	var imgAttr = node.getAttribute("img");
	if(imgAttr)
	{
		src = String(imgAttr);
		/*var attr = node.getAttribute("imgWidth");
		if(attr) 
		{
			var w = parseInt(attr, 10);
			width = w;
			//b.style.width = w + 4;
		}	
		else width = this._img_width;
		var attr = node.getAttribute("imgHeight");
		if(attr) 
		{
			var h = parseInt(attr, 10);
			height = h;
			//b.style.height = h + 4;
		}	
		else height = this._img_height;*/
	}
	else if(imgAttr != "")
	{
		src = this._img_src;
		//width = this._img_width;
		//height = this._img_height;
	}
	
	if(src)
	{
		var img = document.createElement("img")
		var b = cell.children[1];

		if(CNFormManager.vista)
		{
			img.style.position = "absolute";
			img.style.left = "7px";
			img.style.top = "4px";
		}
		img.src = src;
		img.width = img.height = 8;
		/*if(width) 
		{
			b.firstChild.width = width + 5;
		}
		if(height) 
		{
			b.firstChild.height = height + 5;
		}*/
		b.appendChild(img);
	}
	
	//img.style.userSelect = "none";

	cell.children[0].textContent = Util.xmlText(node);
}


// Image. =====================================
var ImageTypeCell = CN_grid.CellTypes["Image"] = function(colTag){}
ImageTypeCell.cn_tagName = "image";
var wp = ImageTypeCell.prototype;
wp.isValid = function(cell){ return true; }
// Event handlers.
wp.box_onclick = function()
{
	var box = Util.eventTarget();
	var jsObject = CNUtil.findJSObject(box);
	
	var cell = CN_grid.findCell(box);
	if(jsObject.getCascadedReadOnly(cell)) return;
	var row = cell.parentElement;
	
	cell.focus();

	if(cell.colTag.autoPostBack) 
	{
		jsObject.setChangedValue(row, cell, null);
		jsObject.fireChangedEvent(row, cell, null);
		jsObject.postBack(row, cell, null);
	}
}
wp.prerender = function(cell, colTag)
{
	var imageWidth = colTag.node.getAttribute("imageWidth");
	var imageHeight = colTag.node.getAttribute("imageHeight");
	if(imageWidth) this._img_width = imageWidth * 1;
	if(imageHeight) this._img_height = imageHeight * 1;

	cell.style.padding = "0.25em"; /* !! */
}
wp.render = function(cell, node)
{
	var img = document.createElement("img")
	cell.appendChild(img);

	if(this._img_width) img.width = this._img_width;
	if(this._img_height) img.height = this._img_height;

	img.style.userSelect = "none";
	CN_grid.addEvent(img, "click", this.box_onclick, this);

	var text = Util.xmlText(node);
	if(text == "") img.style.display = "none";
	else img.src = Util.xmlText(node);
}

// ImageButton. =====================================
var ImageButtonTypeCell = CN_grid.CellTypes["ImageButton"] = function(colTag){}
ImageButtonTypeCell.cn_tagName = "imagebutton";
var wp = ImageButtonTypeCell.prototype;
wp.isValid = function(cell){ return true; }
// Event handlers.
wp.box_onclick = ImageTypeCell.prototype.box_onclick;

var bproto = ButtonTypeCell.prototype;
wp._button_onmouseenter = bproto._button_onmouseenter;
wp._button_onmouseleave = bproto._button_onmouseleave;
wp._button_onmousedown = bproto._button_onmousedown;
wp._button_onmouseup = bproto._button_onmouseup;
wp._createSpanButton = bproto._createSpanButton;
wp.prerender = function(cell, colTag)
{
	cell.style.padding = "0.25em";
	if(CNFormManager.vista)
	{
		cell.style.paddingTop = "3px";
		var button = this._createSpanButton();
		cell.appendChild(button);		
	}
}
wp.render = function(cell, node)
{
	var button;
	if(CNFormManager.vista)
	{
		button = cell.firstChild;
	}
	else
	{
		button = document.createElement("button");
		cell.appendChild(button);
	}

	var img = document.createElement("img");
	button.appendChild(img);
	
	if(CNFormManager.vista)
	{
		img.style.position = "absolute";
		img.style.left = "2px";
		img.style.top = "2px";
	}	

	var attr = node.getAttribute("imgWidth");
	if(attr) 
	{
		var width = img.width = parseInt(attr, 10);
		var w = Math.max(width + 3, 6);
		if(CNFormManager.vista) button.firstChild.style.width = w;
		else button.style.width = w;
	}
	
	attr = node.getAttribute("imgHeight");
	if(attr) 
	{
		var height = img.height = parseInt(attr, 10);
		var h = Math.max(height + 3, 6);
		if(CNFormManager.vista) button.firstChild.style.height = h;
		else button.style.height = h;
	}

	button.style.userSelect = "none";
	CN_grid.addEvent(button, "click", this.box_onclick, this);

	var text = Util.xmlText(node);
	if(text == "") img.style.display = "none";
	else img.src = Util.xmlText(node);
}


// Comment. =============================
var CommentTypeCell = CN_grid.CellTypes["Comment"] = function(colTag, grid)
{
	this._maxLength = -1;
	this._grid = grid;
}
CommentTypeCell.cn_tagName = "comment";
CommentTypeCell.activePopup = null;
CommentTypeCell.showPopup = function(l, cell)
{
	CommentTypeCell.activePopup = l;
	CommentTypeCell._currentCell = cell;

	CNDialogManager.showDialog(l, [CommentTypeCell, "ondialogresult"], true);
}
CommentTypeCell.ondialogresult = function(dialog, cancel)
{
	if(cancel) return;
	var box = CNDialogManager.getContents(dialog).lastChild;
	var jso = CommentTypeCell._currentCell.colTag.typeObject;
	jso.commitChange(CommentTypeCell._currentCell, box.textContent);
	CommentTypeCell.activePopup = null;
	CommentTypeCell._currentCell = null;
}
CommentTypeCell._textarea_onkeypress = function()
{
	var jso = CommentTypeCell._currentCell.colTag.typeObject;
	var dialog = CommentTypeCell.activePopup;
	if(jso._maxLength != -1)
	{
		var box = CNDialogManager.getContents(dialog).lastChild;
		if(box.value.length >= jso._maxLength) CNUtil.cancelEvent();
	}
}
CommentTypeCell._textarea_onpaste = function()
{
	var jso = CommentTypeCell._currentCell.colTag.typeObject;
	var dialog = CommentTypeCell.activePopup;	
	if(jso._maxLength != -1)
	{
		var box = CNDialogManager.getContents(dialog).lastChild;
		var text = CN_grid.readClipboardText();
		if(box.value.length + text.length >= jso._maxLength)
		{
			CNUtil.cancelEvent();
			var textLength = jso._maxLength - box.value.length;
			if(textLength > 0) 
			{
				CN_grid.insertTextAtSelection(text.substr(0, textLength));
			}
		}
	}
}

var wp = CommentTypeCell.prototype;
wp.isFocusable = true;
wp.isValid = function(cell){ return true; }
// Event handlers.
wp._box_onclick = function()
{
	var cell = CN_grid.findCell(Util.eventTarget());

	var row = cell.parentElement;
	var jsObject = CNUtil.findJSObject(row);
	if(jsObject._disabled) return;

	cell.colTag.typeObject._showDialog(cell, jsObject);
}
wp._createVistaDialog = function()
{
	var dialog = CNDialogManager.createVistaDialog();
	dialog.style.width = "600px";
	dialog.style.height = "360px";
	return dialog;
}
wp._createDialog = function()
{
	var popupDiv = CNDialogManager.createDialog("");
	popupDiv.style.width = "620px"; 
	popupDiv.style.height = "380px";
	return popupDiv;
}
wp._showDialog = function(cell, grid)
{
	var readOnly = grid.getCascadedReadOnly(cell);
	var dialog = $('__gridCommentDialog');
	if(!dialog) 
	{
		if(CNFormManager.vista) dialog = this._createVistaDialog();
		else dialog = this._createDialog();
		dialog.id = "__gridCommentDialog";
		this._createDialogContents(dialog);	
	}
	CNDialogManager.setCaption(dialog, "Comment " + (readOnly ? "viewer" : "editor") 
												+ " - " + cell.colTag.node.getAttribute("caption"));
	var contents = CNDialogManager.getContents(dialog);
												
	// Textarea.
	contents.lastChild.textContent = cell._value;
	contents.lastChild.readOnly = readOnly;

	// Save button.
	var bottom = CNDialogManager.getBottom(dialog);
	bottom.firstChild.style.visibility = readOnly ? "hidden" : "inherit";
	// Close button.
	var closeText = readOnly ? "Close" : "Cancel";
	if(CNFormManager.vista) bottom.lastChild.jsObject.loadData(Util.wrapIntoNode({value: closeText}));
	else bottom.lastChild.textContent = closeText;

	CommentTypeCell.showPopup(dialog, cell);
}

wp._createDialogContents = function(dialog)
{
	var parent = CNDialogManager.getContents(dialog);
	var textArea = Util.createElementFromHTML("<textarea class=commentBoxTextArea>");
	parent.appendChild(textArea);
	CN_grid.addEvent(textArea, "keypress", CommentTypeCell._textarea_onkeypress, null);
	CN_grid.addEvent(textArea, "paste", CommentTypeCell._textarea_onpaste, null);

	var saveButton = CNDialogManager.createBottomButton(dialog, "Save", true);
	saveButton.style.width = "80px";
	var cancelButton = CNDialogManager.createBottomButton(dialog, "Cancel", false);
	cancelButton.style.width = "80px";
}

wp.commitChange = function(cell, val)
{
	var row = cell.parentElement;
	var jsObject = CNUtil.findJSObject(row);
		
	var value = cell._value = String(val);
	var rowID = String(row.xmlNode.getAttribute("id"));
	var contentNode = jsObject.changedDoc.createCDATASection(value);
	var node = jsObject._getChangedNode(row, cell);
	if(node.hasChildNodes) node.replaceChild(contentNode, node.firstChild);
	else node.appendChild(contentNode);
	
	if(value.length > 0)
	{
		if(cell.children[0].children.length == 0) this._attachImage(cell);
	}
	else
	{
		if(cell.children[0].children.length > 0) Util.removeElement(cell.children[0].children[0]);
	}

	if(cell.colTag.autoPostBack) 
	{
		jsObject.fireChangedEvent(row, cell, value);
		jsObject.postBack(row, cell, value);
	}
}


var bproto = ButtonTypeCell.prototype;
wp._button_onmouseenter = bproto._button_onmouseenter;
wp._button_onmouseleave = bproto._button_onmouseleave;
wp._button_onmousedown = bproto._button_onmousedown;
wp._button_onmouseup = bproto._button_onmouseup;
wp._createSpanButton = bproto._createSpanButton;
wp.prerender = function(cell, colTag)
{
	colTag.typeObject = this;

	var button;
	
	if(CNFormManager.vista)
	{
		cell.style.paddingTop = "3px";
		button = this._createSpanButton();
		cell.appendChild(button);		
	}
	else
	{
		button = Util.createElementFromHTML("<button class=xllookupbutton>")
		cell.appendChild(button);
		CN_grid.addEvent(button, "mouseenter", _CN_button_onmouseenter, null);
		CN_grid.addEvent(button, "mouseleave", _CN_button_onmouseleave, null);
	}
	
	var imgSrc = colTag.node.getAttribute("imgSrc");
	if(imgSrc) this._img_src = imgSrc;
	else this._img_src = CNFormManager.themeImagesPath + "comment.gif";
	
	var attr = colTag.node.getAttribute("maxLength");
	if(attr) this._maxLength = parseInt(attr, 10);

	CN_grid.addEvent(button, "click", this._box_onclick, this);
}
wp._attachImage = function(cell)
{
	var img = document.createElement("img")
	cell.children[0].appendChild(img);
	
	img.style.userSelect = "none";
	img.src = this._img_src;
	img.width = 8;
	img.height = 8;
	if(CNFormManager.vista)
	{
		img.style.position = "absolute";
		img.style.top = "4px";
		img.style.left = "4px";
	}
}

wp.render = function(cell, node)
{
	var value = String(Util.xmlText(node));
	cell._value = value;
	
	if(value.length > 0) this._attachImage(cell);
	if(node.getAttribute("opened") == "true") this._showDialog(cell, this._grid);		
}


// ComboBox. =====================================
var ComboBoxCell = CN_grid.CellTypes["ComboBox"] = function(colTag, grid)
{
	this._combobox = null;
	this._grid = grid;
}

ComboBoxCell.cn_tagName = "combobox";
var wp = ComboBoxCell.prototype;
wp.isFocusable = true;
wp.focusCell = function(cell) { // #1036-3
	var typeObject = cell.colTag.typeObject;
	CN_combobox.currentCombobox = typeObject._combobox;
	typeObject._combobox.element = cell.firstChild;
	CN_combobox.currentCombobox.focus();
}

wp._cell_beforedeactivate = function()
{
	if(!CN_grid.relatedTarget() || CN_grid.relatedTarget() == document.body) CNUtil.cancelEvent();
	else 
	{
		Util.eventTarget().tabIndex = -1;
	}
}
wp.isValid = function(cell){ return true; }
wp.set_readOnly = function(cell, readOnly)
{
	cell.className = readOnly ? "cellSpan xlgridcomboReadOnly" : "cellSpan";
}
wp.prerender = function(cell, colTag)
{
	cell.style.paddingTop = CNFormManager.vista ? 1 : 2; // !!!	

	var node = colTag.node.cloneNode(true);
	
	var combobox = this._combobox = new CN_combobox();
	this._grid._jsObjects.push(combobox);

	var l = combobox.createElementOnly(node, true);
	cell.appendChild(l);
	
	combobox.initData(node);
	
	combobox.onchange = this._combobox_onchange;
	combobox.oncheckreadonly = this._combobox_oncheckreadonly;
		
	CN_grid.addEvent(cell, "keydown", this._cell_onkeydown, this);
	CN_grid.addEvent(cell, "focusout", this._cell_beforedeactivate, this);

	//var w = parseInt(Util.getStyle(cell, "width")) - parseInt(Util.getStyle(cell, "paddingLeft")) - parseInt(Util.getStyle(cell, "paddingLeft"));
	//l.style.width = w - 3; // ?
	l.style.width = "100%";
}
wp._cell_onkeydown = function()
{
	if(Util.eventTarget().className != 'cellSpan') return;
	var cell = CN_grid.findCell(Util.eventTarget());
	if(cell.contains(Util.eventTarget()) && Util.eventTarget() != cell) return;
	if(Event.keyValue(CN_grid.currentEvent()) != 9) CNUtil.cancelEvent();
	
	var typeObject = cell.colTag.typeObject;
	CN_combobox.currentCombobox = typeObject._combobox;
	typeObject._combobox.element = cell.firstChild;
	//CN_grid.dispatchEvent(cell.children[0], "keydown");
	CN_combobox.currentCombobox.element_onkeydown();
}
wp._combobox_onchange = function(ev)
{
	if(!ev.isDirty) return; // #1036-4

	// Executed in combobox context.
	var cell = this.element.parentElement;
	var row = cell.parentElement;

	var jsObject = CNUtil.findJSObject(cell);
	var value = ev.selectedIndex;
	if(value == -2) 
	{
		value = ev.value;
		var node = jsObject._getChangedNode(row, cell);
		if(node && value !== null) node.setAttribute("text", value);
	}
	else
	{
		jsObject.setChangedValue(row, cell, value);
	}
	jsObject.fireChangedEvent(row, cell, value);
	if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, value);
}

wp._combobox_oncheckreadonly = function()
{
	// Executed in combobox context.
	var cell = CN_grid.findCell(Util.eventTarget());
	var jsObject = CNUtil.findJSObject(cell);
	var ro = jsObject.getCascadedReadOnly(cell);
	return ro;
}

wp.render = function(cell, node, tree_level, tree_index, tree_type, cellReadOnly)
{
	var row = cell.parentElement;
	var colTag = cell.colTag;

	var comboElement = cell.children[0];
	comboElement.style.left = "1px";
	
	if(this._combobox.popupOpened) {
		this._combobox.hidePopup();
	}
	
	// Temporary set element.
	this._combobox.element = comboElement;

	var valueSet = false;
	if(this._combobox._searchable)
	{
		this._combobox.set_tabIndex(-1);
		// Do we have free text?
		var attr = node.getAttribute("value");
		if(attr) 
		{
			this._combobox.set_textValue(String(attr));
			valueSet = true;
		}
	}

	if(!valueSet)
	{
		var ix = parseInt(Util.xmlText(node), 10);

		this._combobox.element._selectedIndex = ix;
		this._combobox._set_selectedIndex(true);
	}
		
	if(node.getAttribute("opened") == "true")
	{
		CN_grid._pendingCombo = {jsObject: this._combobox, element: comboElement};
	}
	
	this._combobox.element = null;

	if(this._grid._readOnly || cellReadOnly || colTag.readOnly || cell.parentElement.readOnly) 
	{
		cell.className = "cellSpan xlgridcomboReadOnly";
	}
}

// MutableComboBox. =====================================
var MutableComboBoxCell = CN_grid.CellTypes["MutableComboBox"] = function(colTag, grid)
{
	this._grid = grid;
}

MutableComboBoxCell.cn_tagName = "mutablecombobox";
var wp = MutableComboBoxCell.prototype;
wp.isFocusable = true;
wp.focusCell = function(cell) { // #1036-3
	var combo = cell.children[0].jsObject;	
	combo.focus();
}
wp.isValid = function(cell)
{
	var combo = cell.children[0].jsObject;
	return !combo._searchable || combo.__canBeEmpty || combo.get_textValue() != "";
}
wp._combobox_onchange = ComboBoxCell.prototype._combobox_onchange;
wp._combobox_oncheckreadonly = ComboBoxCell.prototype._combobox_oncheckreadonly;
wp.set_readOnly = ComboBoxCell.prototype.set_readOnly;
wp._cell_onkeydown = function()
{
	if(Util.eventTarget().className != 'cellSpan') return;

	var cell = CN_grid.findCell(Util.eventTarget());
	if(cell.contains(Util.eventTarget()) && Util.eventTarget() != cell) return;
	if(Event.keyValue(CN_grid.currentEvent()) != 9) CNUtil.cancelEvent();
	CN_grid.dispatchEvent(cell.children[0], "keydown");
}
wp._cell_beforedeactivate = function()
{
	if(CN_grid.relatedTarget() == document.body) CNUtil.cancelEvent();
	else Util.eventTarget().tabIndex = -1;
}
wp.prerender = function(cell, colTag)
{
	cell.style.paddingTop = CNFormManager.vista ? 1 : 2; // !!!
	cell.style.paddingRight = 2;
	CN_grid.addEvent(cell, "focusout", this._cell_beforedeactivate, this);
	CN_grid.addEvent(cell, "keydown", this._cell_onkeydown, this);
}
wp.render = function(cell, node, tree_level, tree_index, tree_type, cellReadOnly)
{
	var combobox = new CN_combobox();
	this._grid._jsObjects.push(combobox);

	var colTag = cell.colTag;
	
	node = node.cloneNode(true);

	var colAttr = colTag.node.getAttribute("canBeEmpty");
	var cAttr = node.getAttribute("canBeEmpty");
	if(colAttr && !cAttr)
	{
		node.setAttribute("canBeEmpty", String(colAttr));
	}
	
	combobox.__canBeEmpty = true;
	if(cAttr) combobox.__canBeEmpty = cAttr == "true";
	
	var searchableAttr = colTag.node.getAttribute("searchable");
	if(searchableAttr) node.setAttribute("searchable", String(searchableAttr));
	
	var apAttr = colTag.node.getAttribute("autoPostBack");
	if(apAttr) node.setAttribute("autoPostBack", String(apAttr));
	
	combobox._inGrid = true; // As we can't pass this as parameter.
	var l = combobox.createElement(node, cell);
	
	combobox.onchange = this._combobox_onchange;
	combobox.oncheckreadonly = this._combobox_oncheckreadonly;

	//var w = parseInt(Util.getStyle(cell, "width")) - parseInt(Util.getStyle(cell, "paddingLeft")) - parseInt(Util.getStyle(cell, "paddingRight"));
	//l.style.width = w - 3; // ?
	l.style.width = "100%";


	var valueSet = false;
	if(combobox._searchable)
	{
		// Do we have free text?
		var attr = node.getAttribute("value");
		if(attr) 
		{
			combobox.set_textValue(String(attr));
			valueSet = true;
		}
	}

	if(!valueSet)
	{
		var ix = -1;
		var attr = node.getAttribute("selectedValue");
		if(attr) ix = parseInt(String(attr), 10);
		combobox.element._selectedIndex = ix;
		combobox._set_selectedIndex(true);
	}

	if(node.getAttribute("opened") == "true")
	{
		CN_grid._pendingCombo = {jsObject: combobox, element: l};
	}

	if(this._grid._readOnly || cellReadOnly|| colTag.readOnly || cell.parentElement.readOnly) 
	{
		cell.className = "cellSpan xlgridcomboReadOnly";
	}
}


// WrapText. ====================================================
var WrapTextCell = CN_grid.CellTypes["WrapText"] = function(colTag)
{
	this._maxLength = -1;
}
WrapTextCell.cn_tagName = "wraptext";

WrapTextCell._toEditMode = function(cell)
{
	cell._isEdited = true;
	var table = cell.children[0];
	table._borderColor = Util.getStyle(table, "borderColor");
	table.style.borderColor = Util.getStyle(table, "xl--edit-border-color");
	var div = table.rows[0].cells[0].children[0];
	
	CN_grid.addEvent(div, "blur", WrapTextCell._div_onblur, WrapTextCell);
	CN_grid.addEvent(div, "keydown", WrapTextCell._div_onkeydown, WrapTextCell);
	CN_grid.addEvent(div, "keypress", WrapTextCell._div_onkeypress, WrapTextCell);
	CN_grid.addEvent(div, "resize", WrapTextCell._div_onresize, WrapTextCell);

	div.focus();
	div.contentEditable = true;
	div.focus();
}

WrapTextCell._toDefaultMode = function(cell)
{
	cell._isEdited = false;
	var table = cell.children[0];
	table.style.borderColor = table._borderColor;
	var div = table.rows[0].cells[0].children[0];

	div.contentEditable = false;

	CN_grid.removeEvent(div, "blur", WrapTextCell._div_onblur, WrapTextCell);
	CN_grid.removeEvent(div, "keydown", WrapTextCell._div_onkeydown, WrapTextCell);
	CN_grid.removeEvent(div, "keypress", WrapTextCell._div_onkeypress, WrapTextCell);
	CN_grid.removeEvent(div, "resize", WrapTextCell._div_onresize, WrapTextCell);
	
	// Remove html;)
	div.textContent = div.textContent;

	var row = cell.parentElement;

	var text = div.textContent;
	
	var jsObject = CNUtil.findJSObject(cell);
	var node = jsObject._getChangedNode(row, cell);
	if(node)
	{
        // Clean up node.
        node.textContent = "";
        // Server expects CData.
		node.appendChild(jsObject.changedDoc.createCDATASection(text));
	}
	jsObject.fireChangedEvent(row, cell, text);
	if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, text);
}

WrapTextCell._div_onresize = function()
{
	var cell = CN_grid.findCell(Util.eventTarget());
	var table = cell.children[0];
	var div = table.rows[0].cells[0].children[0];
	cell.style.height = table.offsetHeight + 1;

	var grid = CNUtil.findJSObject(table);
	if(grid.selectedTR == cell.parentElement)
	{
		grid.rowBorder_select(cell.parentElement);
	}
}

WrapTextCell._div_onkeypress = function()
{
	var cell = CN_grid.findCell(Util.eventTarget());
	var jsObject = cell.colTag.typeObject;
		
	if(jsObject._maxLength != -1 && Util.eventTarget().textContent.length >= jsObject._maxLength)
	{
		CNUtil.cancelEvent();
	}

	if(Event.keyValue(CN_grid.currentEvent()) ==  13) // Enter
	{
		Event.cancel(CN_grid.currentEvent());
		return;
	}
}

WrapTextCell._div_onpaste = function()
{
	var cell = CN_grid.findCell(Util.eventTarget());
	var jsObject = cell.colTag.typeObject;

	if(jsObject._maxLength == -1) return; // No limit.
	var text = CN_grid.readClipboardText();

	if(Util.eventTarget().textContent.length + text.length >= jsObject._maxLength)
	{
		CNUtil.cancelEvent();
		var textLength = jsObject._maxLength - Util.eventTarget().textContent.length;
		if(textLength > 0)
		{
			CN_grid.insertTextAtSelection(text.substr(0, textLength));
		}
	}
}


WrapTextCell._div_onkeydown = function()
{
	if(Event.keyValue(CN_grid.currentEvent()) ==  13) // Enter
	{
		Event.cancel(CN_grid.currentEvent());
		return;
	}

	// Disallow any WYSIWYG commands.
	if(!CN_grid.currentEvent().ctrlKey) return;

	switch(Event.keyValue(CN_grid.currentEvent()))
	{
		case 86: // V paste
		case 67: // C copy
		case 88: // X cut
		case 37: // left
		case 38: // up
		case 39: // right
		case 40: // down
		case 36: // home
		case 35: // end
		case 45: // insert
		case 46: // del
			return;
	}

	CNUtil.cancelEvent();
}


WrapTextCell._div_onmousedown = function()
{
	var cell = CN_grid.findCell(Util.eventTarget());
	if(cell._isEdited) return;

	var jsObject = CNUtil.findJSObject(cell);
	if(jsObject.getCascadedReadOnly(cell)) return;

	WrapTextCell._toEditMode(cell);
}

WrapTextCell._div_onblur = function()
{
	var cell = CN_grid.findCell(Util.eventTarget());
	WrapTextCell._toDefaultMode(cell);
}


var wp = WrapTextCell.prototype;
wp.isValid = function(cell){ return true; }
wp.noDefaultStaticRectangle = true;
wp.isFocusable = true;
wp.focusCell = function(cell)
{
	WrapTextCell._toEditMode(cell);
}
wp.prerender = function(cell, colTag)
{
	cell.style.paddingTop = cell.style.paddingBottom = 0; // Left padding is used for tree node leveling.
	var wrap = document.createElement("table");
	wrap.className = "wrapTextTable";
	wrap.border = 0;
	wrap.cellSpacing = wrap.cellPadding = 0;
	var row = wrap.insertRow(-1);
	row.vAlign = "middle";
	row.insertCell(-1).appendChild(document.createElement("div"));
	cell.appendChild(wrap);
	var table = cell.children[0];
	var div = table.rows[0].cells[0].children[0];
	div._isCellDiv = true;
	CN_grid.addEvent(div, "mousedown", WrapTextCell._div_onmousedown, WrapTextCell);
	CN_grid.addEvent(div, "paste", WrapTextCell._div_onpaste, WrapTextCell);

	if(colTag.fixedFont) div.style.fontFamily = "Courier New";
	if(colTag.bold) div.style.fontWeight = "bold";

	var attr = colTag.node.getAttribute("textColor");
	if(attr) div.style.color = String(attr);

	var attr = colTag.node.getAttribute("maxLength");
	if(attr) this._maxLength = parseInt(attr, 10);

	if(cell._showEditorRectangle) // Dynamicgrid2
	{
		table.style.borderColor = Util.getStyle(table, "xl--edit-border-color");
	}
}
wp.render = function(cell, node)
{
	var table = cell.children[0];
	
	var value = String(Util.xmlText(node)).replace(/\t/g,"    ");
	table.rows[0].cells[0].children[0].textContent = value;
	
	var color = cell.Util.getStyle(parentElement, "backgroundColor");
	if(color != "transparent") table.style.borderColor = color;
}


// TreeNode. ====================================================
var TreeNodeCell = CN_grid.CellTypes["TreeNode"] = function(colTag, grid)
{
	this.grid = grid;
}
var wp = TreeNodeCell.prototype;
wp.isValid = function(cell){ return true; }
wp.prerender = function(cell, colTag)
{
}
wp.render = function(cell, node, level, index, nodeType)
{
	cell.style.paddingTop = 0;
	this.grid.tree_buildNodeTemplate(cell);
	this.grid.tree_buildNode(cell.firstChild, cell, node, level, index, nodeType);
} 

/*
	v. 2.02
	+ vista.
*/
function CN_answerbox()
{
	this.formManager = null;
	this.isReady = false;

	this.optionTags = null;

	this.activeOption = null;

	this.popup = null;

	this.popupOpened = false;

	this._disabled = false;
	this._isDirty = false;
	this._autoPostBack = false;
	this._canBeEmpty = false;
	this._imgHeight = 10;
	
	this.supportsRequired = true;
}
CN_answerbox.currentCombobox = null;
CN_answerbox.pendingCombobox = null;

var proto = CN_answerbox.prototype;
// Inherit.
proto._processTypedWord = CN_combobox.plainThemeProto._processTypedWord;
proto._typedSelectTimout = 0;
proto._lastTypeStamp = 0;


// Events. =================
proto.onchange = function(ev)
{
	if(this._autoPostBack) this.formManager.postData(this.element);
}
proto.oncheckreadonly = function(){ return false; }


proto.createElement = function(node, parentElement)
{
	var l = this.createElementOnly(node, parentElement);

	this.element = l;
	
	var attr = node.getAttribute("autoPostBack");
	if(attr) this._autoPostBack = attr == "true";

	var attr = node.getAttribute("imgHeight");
	if(attr) this._imgHeight = parseInt(attr, 10);

	this.initData(node);
	
	return l;
}

proto.createElementOnly = function(node, parentElement)
{
	var l = document.createElement("span");
	parentElement.appendChild(l);

	var attr = node.getAttribute("canBeEmpty");
	this._canBeEmpty = attr == "true";

	l.className = "cn_answerbox";
	//l.style.userSelect = "none";
	l._isComboBox = true;
	l._selectedIndex = this._canBeEmpty ? -1 : 0;
	
	l.jsObject = this;
	
	Event.add(l, "click", this, this._element_onmousedown);
	Event.add(l, "contextmenu", this, this._element_oncontextmenu);
	Event.add(l, "dblclick", this, this._element_onmousedown);

	this.buildElement(l);

	var attr = node.getAttribute("text");
	if(attr) l.children[1].textContent = String(attr);
	
	Event.add(l, "keydown", this, this._element_onkeydown);

	this.isReady = true;	
	
	return l;
}

proto.loadData = function(node)
{
	this.initData(node);
	var ix = parseInt(node.getAttribute("selection"));

	if(!isNaN(ix)) 
	{
		if(this.element) this.set_selectedIndex(ix);
		this._isDirty = false;
	}
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty) return null;
		
	this._isDirty = false;

	var node = xmldoc.createElement("answerbox");
	node.setAttribute("selection", this.element._selectedIndex);
	return node;
}

proto.buildElement = function(l)
{
	var checkElement = Util.createElementFromHTML("<span class=checkSpan>")
	//checkElement.style.userSelect = "none";
	l.appendChild(checkElement);
	
	var img = document.createElement("img");
	img.width = img.height = this._imgHeight;
	checkElement.appendChild(img);

	var textElement = Util.createElementFromHTML("<span class=textSpan>")
	//textElement.style.userSelect = "none";
	l.appendChild(textElement);
}

proto.initData = function(data)
{
	if(data == null) return;
	
	var options = null;
	if(data instanceof Array) options = CN_combobox.makeOptions(data);
	else options = Util.xmlSelectNodes(data, "option");
	if(!options || options.length == 0) return;

	// Reset popup.
	this.popup = null;
	
	this.optionTags = options;

	this.initOptions();

	if(this.element) this._set_selectedIndex();
}		

proto.initOptions = function()
{
	var count = this.optionTags.length;
	for(var i = 0; i < count; i++)
	{
		this.optionTags[i].setAttribute("index", i);
	}
}

proto.setNextState = function()
{
	this.element._selectedIndex++;
	if(this.element._selectedIndex >= this.optionTags.length) 
	{
		if(this._canBeEmpty) this.element._selectedIndex = -1;
		else this.element._selectedIndex = 0;
	}
	this._set_selectedIndex();
	this._isDirty = true;
}

proto.fireChangedEvent = function()
{
	var ev = {};
	ev.selectedIndex = this.element._selectedIndex;
	if(this.onchange) this.onchange(ev);
}


proto.createPopup = function()
{
	if(this.popup) return;

	this.popup = document.createElement("div");
	this.popup.className = "cn_comboboxPopup";
	this.popup._isPopup = true;
	document.body.appendChild(this.popup);

	if(this._canBeEmpty)
	{
		var option = this.createOption(" ", null, -1);
		this.popup.appendChild(option);
	}

	var count = this.optionTags.length;
	for(var ix = 0; ix < count; ix++)
	{
		var optionTag = this.optionTags[ix];

		var text = String(optionTag.getAttribute("text"));
		text = text == "" ? " " : text; // !!
		
		var option = this.createOption(text, String(optionTag.getAttribute("img")), ix);
		this.popup.appendChild(option);

		var attr = optionTag.getAttribute("textColor");
		if(attr) option.style.color = String(attr);
	}
	
	this.popup.style.overflow = "auto";
	
	if(CNFormManager.vista) new Shadow(this.popup, false, true);
	
	Event.add(this.popup, "mousedown", CNUtil, CNUtil.cancelEvent);
	Event.add(this.popup, "click", this, this._popup_onclick);
	Event.add(this.popup, "mouseover", this, this._popup_onmouseover);
	Event.add(this.popup, "mouseout", this, this._popup_onmouseout);
	Event.add(this.popup, "keydown", this, this._popup_onkeydown);
}

proto.createOption = function(text, imgUrl, index)
{
	var option = Util.createElementFromHTML("<div class=xlcombooption style=\"padding: 1px; position: relative; display: inline-block; white-space: nowrap; \"></div>");

	option.textContent = text;
	option.index = index;

	if(imgUrl)
	{
		var img = Util.createElementFromHTML("<img align=absmiddle style=\"margin-right: 4px; \">");
		img.src = imgUrl;
		option.insertBefore(img, option.firstChild);
	}

	return option;
}

proto._showPopup = function()
{
	CN_answerbox.currentCombobox = CN_answerbox.pendingCombobox;
	CN_answerbox.pendingCombobox = null;
	CN_answerbox.currentCombobox.showPopup();
}

proto.showPopup = function()
{
	this.createPopup();

	this.popupOpened = true;
	this.popup.scrollTop = this.popup.scrollLeft = 0;

	var ix = this.element._selectedIndex;
	if(this._canBeEmpty) ix++;

	this.popup.style.zIndex = top.__ontopZ++;
	
	var xy = CNUtil.findAbsolutePos(this.element, null, false, true);
	// ?? For some reason this padding is not catched by findAbsolutePos..
	if(this.element.parentNode.className == "cellSpan") xy.x += 2; 
	//xy.x += 1;
	
	xy.y += this.element.offsetHeight;
	
	var popupWidth = Math.max(this.element.offsetWidth, 80);
	this.popup.style.width = popupWidth + "px";
	this.popup.style.overflowY = "auto";
	this.popup.style.visibility = "hidden";
	this.popup.style.display = "block";
	
	var maxHeight = parseInt(Util.getStyle(this.element, "xl--popup-max-height"), 10);
	if(!isNaN(maxHeight) && this.popup.offsetHeight >= maxHeight) this.popup.style.height = maxHeight + "px";
	else this.popup.style.height = "auto";
	
	CNUtil.posPopup(this.popup, xy.x, xy.y);

	if(this.popup.scrollHeight <= this.popup.offsetHeight) this.popup.style.overflowY = "hidden";

	if(CNFormManager.vista)
	{
		this.popup.style.visibility = "visible";
		if(this.popup.shadow) this.popup.shadow.show();
		
		if(ThemeNonCSSStyles.animateDropdowns) {
			var h = this.popup.offsetHeight;
			this.popup.style.height = "1px";
			Animator.start(new AnimResize(this.popup, this.popup.offsetWidth, h, 0));
		}
	}
	else this.popup.style.visibility = "visible";
	if(ix !== undefined)
	{
		this.unhoverOption();
		this.activeOption = this.popup.children[ix];
		this.hoverOption(this.activeOption);
	}
	
	Event.add(document, "mousedown", this, this._document_onmousedown);
	Event.add(document, "wheel", this, this._document_onmousedown);
	
	this.popup.tabIndex = -1;
	this.popup.focus();
}

proto.hidePopup = function()
{
	this.popupOpened = false;

	this.unhoverOption();

	if(this.popup) 
	{
		this.popup.style.display = "none";
		if(this.popup.shadow) 
		{
			this.popup.shadow.hide();
		}
	}

	Event.del(document, "mousedown", this, this._document_onmousedown);
	Event.del(document, "wheel", this, this._document_onmousedown);
}

proto.hoverOption = CN_combobox.plainThemeProto.hoverOption;
proto.unhoverOption = CN_combobox.plainThemeProto.unhoverOption;

proto.selectOption = function(l)
{
	if(this.element._selectedIndex != l.index)
	{
		this.set_selectedIndex(l.index);
		this.fireChangedEvent();		
	}
}

// Event handlers. =================================
proto._document_onmousedown = function()
{
	CN_answerbox.currentCombobox.document_onmousedown();
}
proto.document_onmousedown = function()
{
	this.closing = true;
	CNUtil.cancelBubble();
	this.hidePopup();
	CN_answerbox.currentCombobox = null;
}

proto._popup_onclick = function()
{
	CN_answerbox.currentCombobox.popup_onclick();
}
proto.popup_onclick = function()
{
	var l = Util.eventTarget();
	if(!l || !this.popup.contains(l) || l.className != "xlcombooption") return;
	this.hidePopup();
	this.selectOption(l);
}

proto._popup_onmouseover = function()
{
	CN_answerbox.currentCombobox.popup_onmouseover();
}
proto.popup_onmouseover = function()
{
	var l = Util.eventTarget();
	if(!l || !this.popup.contains(l) || l.className != "xlcombooption") return;
	this.hoverOption(l);
}

proto._popup_onmouseout = function()
{
	if(CN_answerbox.currentCombobox) CN_answerbox.currentCombobox.popup_onmouseout();
}
proto.popup_onmouseout = function()
{
	var l = Util.eventTarget();
	var option = CNUtil.findByClassName(l, "xlcombooption");
	if(!l || !this.popup.contains(l) || l.className != "xlcombooption"
	|| (option && Event.current().relatedTarget && option.contains(Event.current().relatedTarget))) return;
	this.unhoverOption();
}

proto._popup_onkeydown = function()
{
	CN_answerbox.currentCombobox.popup_onkeydown();
}
proto.popup_onkeydown = function()
{
	var code = Event.keyValue(Event.current());
	switch(code)
	{
		case 27:
			 this.hidePopup(); 
			 CNUtil.cancelEvent();
			 break;
		case 38: // Up
			if(this.activeOption && this.activeOption.previousSibling) this.hoverOption(this.activeOption.previousSibling);
			CNUtil.cancelEvent();
			break;
		case 40:
			if(this.activeOption && this. activeOption.nextSibling) this.hoverOption(this.activeOption.nextSibling);
			CNUtil.cancelEvent();
			break;
		case 13: 
			if(this.activeOption) 
			{
				this.selectOption(this.activeOption);
				this.hidePopup();
			}
			CNUtil.cancelEvent();
			break;
		default:
			this._processTypedWord(code, false);
			CNUtil.cancelEvent();
	}
	CNUtil.cancelEvent();
}

proto._element_oncontextmenu = function()
{
	CNUtil.findJSObject(Util.eventTarget()).element_oncontextmenu();
}

proto.element_oncontextmenu = function()
{
	CNUtil.cancelEvent();
	
	if(this._disabled || this.oncheckreadonly()) return;

	var l = Util.eventTarget();
	while(l && !l._isComboBox) l = l.parentElement;
	this.element = l;

	if(this.popupOpened) 
	{
		this.hidePopup();
		CNUtil.cancelBubble();		
		return;
	}

	this.element.focus();
	CN_answerbox.pendingCombobox = this;
	setTimeout(this._showPopup, 0);
}

proto._element_onkeydown = function()
{
	CNUtil.dispatchObject().element_onkeydown();
}
proto.element_onkeydown = function()
{
	if(this._disabled || this.oncheckreadonly()) return;
	this.createPopup(); // Ensure popup created.
	var code = Event.keyValue(Event.current());
	this._processTypedWord(code, true);
}

proto._element_onkeypress = function()
{
	if(Event.keyValue(Event.current()) == 27) 
	{
		var jsObject = CNUtil.findJSObject(Util.eventTarget());
		jsObject.hidePopup();
	}
}

proto._element_onmousedown = function()
{
	CNUtil.findJSObject(Util.eventTarget()).element_onmousedown();
}

proto.element_onmousedown = function()
{
	if(this._disabled || this.oncheckreadonly()) return;
	
	var l = Util.eventTarget();
	while(l && !l._isComboBox) l = l.parentElement;
	this.element = l;

	this.setNextState();
	this.fireChangedEvent();
}


// Properties. ===============================
proto.set_disabled = function(val)
{
	this._disabled = val;
	this.element.style.opacity = this._disabled ? "0.5" : "";
	if(this._tabIndex) 
	{
		if(this._disabled) this.element.tabIndex = -1;
		else this.element.tabIndex = this._tabIndex;
	}
}

proto.set_selectedIndex = function(val)
{
	val = val * 1;
	if(this.element._selectedIndex == val) return;
	this.element._selectedIndex = val;
	this._isDirty = true;
	if(this.isReady) this._set_selectedIndex();
}
proto._set_selectedIndex = function()
{
	if(!this.optionTags) return;
	var option = this.optionTags[this.element._selectedIndex];
	var checkElement = this.element.children[0];
	if(!option)
	{
		checkElement.firstChild.style.visibility = "hidden";
		Tooltip.detach(this.element);
	}
	else
	{
		checkElement.firstChild.src = String(option.getAttribute("img"));
		checkElement.firstChild.style.visibility = "inherit";

		var text = "";
		var attr = option.getAttribute("text");
		if(attr) text = String(attr);
		Tooltip.set(this.element, String(attr));
	}
}

proto.set_tabIndex = function(ti)
{
	this._tabIndex = ti;
	this.element.tabIndex = ti;
}

// Grid support.
// AnswerBox. =====================================
var AnswerBoxCell = CN_grid.CellTypes["AnswerBox"] = function(colTag, grid)
{
	this._combobox = null;
	this._grid = grid;
	this._imgHeight = 10;
}

AnswerBoxCell.cn_tagName = "answerbox";
var wp = AnswerBoxCell.prototype;
wp.isFocusable = true;
wp.isValid = function(cell){ return true; }
wp._cell_beforedeactivate = function()
{
	var ev = Event.current();
	if(ev && ev.relatedTarget == document.body) CNUtil.cancelEvent(ev);
	else if(Util.eventTarget()) Util.eventTarget().tabIndex = -1;
}
wp.prerender = function(cell, colTag)
{
	var node = colTag.node.cloneNode(true);
	var combobox = this._combobox = new CN_answerbox();
	this._grid._jsObjects.push(combobox);
	
	var attr = node.getAttribute("imgHeight");
	if(attr) combobox._imgHeight = this._imgHeight = parseInt(attr, 10);

	var l = combobox.createElementOnly(node, cell);
	combobox.initData(node);
	combobox.onchange = this._answerbox_onchange;
	combobox.oncheckreadonly = this._answerbox_oncheckreadonly;
	
	Event.add(cell, "keydown", this, this._cell_onkeydown)
	Event.add(cell, "focusout", this, this._cell_beforedeactivate);	
}
wp._cell_onkeydown = function()
{
	if(Util.eventTarget().className != 'cellSpan') return;
	var cell = CN_grid.findCell(Util.eventTarget());
	var typeObject = cell.colTag.typeObject;
	CN_answerbox.currentCombobox = typeObject._combobox;
	typeObject._combobox.element = cell.firstChild;
	this._combobox.element_onkeydown(Event.current());
}
wp._answerbox_onchange = function(ev)
{
	// Executed in combobox context.
	var cell = this.element.parentElement;
	var row = cell.parentElement;
	
	// Probably resets current focused box, allow changed box commit.
	cell.focus(); 

	var jsObject = CNUtil.findJSObject(cell);
	jsObject.setChangedValue(row, cell, ev.selectedIndex);
	jsObject.fireChangedEvent(row, cell, ev.selectedIndex);
	if(cell.colTag.autoPostBack) jsObject.postBack(row, cell, ev.selectedIndex);
}

wp._answerbox_oncheckreadonly = function()
{
	// Executed in combobox context.
	var cell = CN_grid.findCell(Util.eventTarget());
	var jsObject = CNUtil.findJSObject(cell);
	return jsObject.getCascadedReadOnly(cell);
}

wp.render = function(cell, node)
{
	var row = cell.parentElement;
	var colTag = cell.colTag;

	var top = (18 - this._imgHeight) / 2;
	if(top < 0) top = 0;
	cell.style.paddingTop = top + "px";
	
	var comboElement = cell.children[0];
	
	var ix = parseInt(Util.xmlText(node), 10);
	
	// Temporary set element.
	this._combobox.element = comboElement;
	this._combobox.element._selectedIndex = ix;
	this._combobox._set_selectedIndex(true);
	this._combobox.element = null;
}


// MutableAnswerBox. ==================================
var MutableAnswerBoxCell = CN_grid.CellTypes["MutableAnswerBox"] = function(colTag, grid)
{
	this._combobox = null;
	this._grid = grid;
	this._imgHeight = 10;
}

MutableAnswerBoxCell.cn_tagName = "mutableanswerbox";

var wp = MutableAnswerBoxCell.prototype;
wp.isValid = function(cell){ return true; }
wp.isFocusable = true;
wp._cell_beforedeactivate = AnswerBoxCell.prototype._cell_beforedeactivate;
wp._cell_onkeydown = function()
{
	if(Util.eventTarget().className != 'cellSpan') return;
	var cell = CN_grid.findCell(Util.eventTarget());
	var combo = Util.findJSObject(cell.children[0]);
	if(combo) combo.element_onkeydown(Event.current());
}

wp.prerender = function(cell, colTag)
{
	Event.add(cell, "keydown", this, this._cell_onkeydown);
	Event.add(cell, "focusout", this, this._cell_beforedeactivate);	
}

wp._answerbox_onchange = AnswerBoxCell.prototype._answerbox_onchange;

wp._answerbox_oncheckreadonly = AnswerBoxCell.prototype._answerbox_oncheckreadonly;

wp.render = function(cell, node)
{
	var row = cell.parentElement;
	var colTag = cell.colTag;

	var top = (18 - this._imgHeight) / 2;
	if(top < 0) top = 0;
	cell.style.paddingTop = top + "px";
	
	node = node.cloneNode(true);
	
	var comboElement = cell.children[0];

	var combobox = new CN_answerbox();
	this._grid._jsObjects.push(combobox);
	
	var l = combobox.createElement(node, cell);
	
	combobox.onchange = this._answerbox_onchange;
	combobox.oncheckreadonly = this._answerbox_oncheckreadonly;
	
	var attr = node.getAttribute("selectedIndex");
	if(attr)
	{
		var index = parseInt(attr, 10);
		combobox.set_selectedIndex(index);
	}
}

/*
	REVISIT: rendering
	v. 2.0
*/
function CN_bookingcalendar()
{
	this.formManager = null;
	this._disabled = false;

	this._today = null;
	// NOTE: 1..12.
	this._selectedMonth = null;
	this._selectedYear = null;
	this._selectedDate = null;
	
	this._rebooking = true;

	this.table = null;

	this.header = null;
	
	var isReady = false;

	this.monthes = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	this.days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
	
	this.usWeekToEu = [6, 0, 1, 2, 3, 4, 5];

	this.disabledDaysAr = [];
	this.noSessionDaysAr = [];
	this.conflictDaysAr = [];
	this.noSlotsDaysAr = [];
	this.percentAr = [];
	this.bookedDaysAr = [];
	this.rebookedDaysAr = [];
	
	this.template = null;

	// One exemplar needed.
	this.nowDate = new Date();
	
	this._postbackValue = null;
	this._checksDisabled = false; // #1044
}
var proto = CN_bookingcalendar.prototype;

// Events. ======================
proto.onpostback = function(ev)
{
	this._postbackValue = ev.value;
	this.formManager.postData(this.element);
}


// Main. ==========================
proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);
	
	l.className = "cn_bookingcalendar";
	
	this.element = l;
	l.jsObject = this;

	this.buildElement(node);

	return l;	
}

proto.storeData = function(xmldoc)
{
	if(this._postbackValue === null) return null;
	var node = xmldoc.createElement("bookingcalendar");
	node.setAttribute("value", this._postbackValue);
	this._postbackValue = null;
	return node;
}

proto.unload = function()
{
	this.table = null;
	this.header = null;
	this.template = null;
	this._combobox.element.jsObject = null;
	this._combobox.element = null;
	this._combobox = null;
	this._controls = null;
}

proto.loadData = function(node)
{
	this.isReady = false;

	attr = node.getAttribute("selectedMonth");
	if(attr) this._selectedMonth = attr * 1 - 1;
	
	attr = node.getAttribute("selectedYear");
	if(attr) this._selectedYear = attr * 1;

	if(isNaN(this._selectedMonth) || isNaN(this._selectedYear))
	{
		var date = new Date(this.nowDate.getFullYear(), this.nowDate.getMonth(), this.nowDate.getDate());
		this._selectedYear = date.getFullYear();
		this._selectedMonth = date.getMonth();
	}

	attr = node.getAttribute("selectedDate");
	if(attr) this._selectedDate = this.parseDate(String(attr));
	else if(attr === "") this._selectedDate = null;

	attr = node.getAttribute("percent");
	if(attr) this.percentAr = String(attr).split(",");
	else if(attr === "") this.percentAr = [];

	attr = node.getAttribute("bookedDays");
	if(attr) this.bookedDaysAr = this.parseToHash(attr);
	else if(attr === "") this.bookedDaysAr = [];

	attr = node.getAttribute("rebookedDays");
	if(attr) this.rebookedDaysAr = this.parseToHash(attr);
	else if(attr === "") this.rebookedDaysAr = [];

	attr = node.getAttribute("disabledDays");
	if(attr) this.disabledDaysAr = this.parseToHash(attr);
	else if(attr === "") this.disabledDaysAr = [];

	attr = node.getAttribute("noSessionDays");
	if(attr) this.noSessionDaysAr = this.parseToHash(attr);
	else if(attr === "") this.noSessionDaysAr = [];
	
	attr = node.getAttribute("conflictDays");
	if(attr) this.conflictDaysAr = this.parseToHash(attr);
	else if(attr === "") this.conflictDaysAr = [];

	attr = node.getAttribute("noSlotsDays");
	if(attr) this.noSlotsDaysAr = this.parseToHash(attr);
	else if(attr === "") this.noSlotsDaysAr = [];

	var all = this._controls;
	all.yearSelect.value = this._selectedYear;

	var combobox = all.monthTD.children[0].jsObject;
	combobox.set_selectedIndex(this._selectedMonth);
	
	this._checksDisabled = node.getAttribute("checksDisabled") == "true";
	if(this._checksDisabled) {
		Util.addClass(this.table, "checksDisabled");
	} else {
		Util.removeClass(this.table, "checksDisabled");
	}
	
	this._loadDays(Util.xmlSelectNodes(node, "day"));

	this.fillDays(this._selectedMonth, this._selectedYear);

	this.isReady = true;
}

proto._loadDays = function(dayNodes) {
	var count = dayNodes.length;
	this._days = {};
	for(var i = 0; i < count; i++) {
		var node = dayNodes[i];
		this._days[parseInt(node.getAttribute("n"), 10)] = {color: node.getAttribute("color")};
	}
}

proto.buildElement = function(node)
{
	var attr = node.getAttribute("today");
	if(attr) this._today = this.parseDate(String(attr));
	
	if(this._today == null) this._today = new Date(this.nowDate.getFullYear(), this.nowDate.getMonth(), this.nowDate.getDate());
	
	attr = node.getAttribute("rebooking");
	if(attr) this._rebooking = attr == "true";
	
	this.template = this.createTemplate();

	var html = "<table width=100% height=100% border=0 cellpadding=0 cellspacing=0>\
					<tr id=topControls><td width=1%><button id=prevMonthButton class=arrows10>3</button></td>\
					<td width=32%>&nbsp;</td>\
					<td align=right width=100 nowrap id=monthTD></td>\
					<td width=5%>&nbsp;</td>\
					<td width=100 align=right><input type=text readonly=true maxlength=4 id=yearSelect></td>\
					<td><table border=0 cellpadding=0 cellspacing=0>\
					<tr><td><button id=yearUpButton class=arrows7>5</button></td></tr>\
					<tr><td><button id=yearDownButton class=arrows7>6</button></td></tr></table></td>\
					<td width=35%>&nbsp;</td>\
					</td><td width=1% align=right><button id=nextMonthButton class=arrows10>4</button></td></tr>\
					<tr><td colspan=8 height=100% id=contentTD></td></tr>\
					</table>";
	
	Util.appendHTML(this.element, html);
	var all = this._controls = {};
	var ids = ["yearSelect", "monthTD", "prevMonthButton", "nextMonthButton", "yearUpButton", "yearDownButton", "contentTD"];
	for(var idIx = 0; idIx < ids.length; idIx++) all[ids[idIx]] = this.element.querySelector("#" + ids[idIx]);

	var combobox = this._combobox = new CN_combobox();
	var options = [];
	for(var i = 0; i < 12; i++)
	{
		var option = {text: this.monthes[i]};
		options[options.length] = option;
	}

	var combo = combobox.createElement(options, all.monthTD)
	combo.id = "monthSelect";

	combobox.onchange = this._monthSelect_onchange;
	
	Event.add(all.prevMonthButton, "click", this, this._prevMonthButton_onclick);
	Event.add(all.prevMonthButton, "dblclick", this, this._prevMonthButton_onclick);

	Event.add(all.nextMonthButton, "click", this, this._nextMonthButton_onclick);
	Event.add(all.nextMonthButton, "dblclick", this, this._nextMonthButton_onclick);

	Event.add(all.yearUpButton, "click", this, this._yearUpButton_onclick);
	Event.add(all.yearUpButton, "dblclick", this, this._yearUpButton_onclick);
	
	Event.add(all.yearDownButton, "click", this, this._yearDownButton_onclick);
	Event.add(all.yearDownButton, "dblclick", this, this._yearDownButton_onclick);
	
	if(CNFormManager.vista) VistaSupport.attachToTextBox(all.yearSelect);	

	this.table = Util.createElementFromHTML("<table width=100% height=100% id=daysTable border=1 frame=void cellpadding=0 cellspacing=0></table>");
	this.header = this.table.insertRow();
	this.header.id = "header";

	for(var td = 0; td < 7; td++)
	{
		var cell = this.header.insertCell();
		cell.style.userSelect = "none";
		var span = Util.createElementFromHTML("<span></span>");
		cell.appendChild(span);
		span.textContent = this.days[td];
	}
	
	for(var tr = 0; tr < 6; tr++)
	{
		var row = this.table.insertRow();
		row.style.userSelect = "none";
		for(var td = 0; td < 7; td++)
		{
			var cell = row.insertCell();
			cell.style.userSelect = "none";
			cell.textContent = " ";
		}
	}
	all.contentTD.appendChild(this.table);
	
	this._disabler = Util.createElementFromHTML('<div style="position: absolute; background: white; z-index: 1000; opacity: .5; width: 100%; height: 100%; top: 0px; left: 0px; visibility: hidden; ">');
	this.element.appendChild(this._disabler);	

	this._set_disabled();

	this.isReady = true;
}

proto.createTemplate = function()
{
	var contDiv = Util.createElementFromHTML("<div>");
	
	var dayButton = Util.createElementFromHTML("<button class=dayButton>");
	contDiv.appendChild(dayButton); // 0
	
	
	
	var bookedCheckbox = Util.createElementFromHTML("<span class=bookedCheckbox>");
	contDiv.appendChild(bookedCheckbox); // 1
	bookedCheckbox.innerHTML = "&#111";
	

	var gauge = Util.createElementFromHTML("<div class=gauge>");
	contDiv.appendChild(gauge); // 2
	
	var gaugeBar = Util.createElementFromHTML("<div class=gaugeBar>")
	gauge.appendChild(gaugeBar);
	
	if(this._rebooking)
	{
		var rebookedCheckbox = Util.createElementFromHTML("<span class=rebookedCheckbox>");
		contDiv.appendChild(rebookedCheckbox);	 // 3
		rebookedCheckbox.innerHTML = "&#111";
	}

	return contDiv;
}

proto.fillDays = function(month, year)
{
	var date = new Date(year, month, 1);

	// NOTE: set date before month or the month can be shifted.
	var dayCount = 1;

	var lastDayCell;
	for(var tr = 0; tr < 6; tr++)
	{
		var row = this.table.rows[tr + 1];
		date.setDate(dayCount);
		var firstOnWeek = this.usWeekToEu[date.getDay()];
		for(var td = 0; td < 7; td++)
		{
			var cell = row.cells[td];
			date.setDate(dayCount);
			if(td < firstOnWeek || date.getMonth() != month || dayCount > 31)  
			{
				cell.textContent = " ";
				cell.className = "empty";
				cell.style.backgroundColor = "";
			}
			else 
			{
				this.renderDayCell(cell, date);

				lastDayCell = cell;
				dayCount++;
			}
		}
	}
}

proto.renderDayCell = function(cell, date)
{
	cell.textContent = " ";

	var div = this.template.cloneNode(true);
	Event.add(div.children[0], "click", this, this._dayButton_onclick);
	Event.add(div.children[0], "dblclick", this, this._dayButton_onclick);
	Event.add(div.children[1], "click", this, this._bookedCheckbox_onclick);
	Event.add(div.children[1], "dblclick", this, this._bookedCheckbox_onclick);
	Event.add(div.children[1], "mouseenter", this, this._bookedCheckbox_onmouseenter);
	Event.add(div.children[1], "mouseleave", this, this._bookedCheckbox_onmouseleave);

	var dateDay = date.getDate();
	div.children[0].textContent = String(dateDay);

	var todayValue = this._today.valueOf();
	var dateValue = date.valueOf();
	
	if(dateValue < todayValue) cell.className = "beforeTodayDay";
	else if(todayValue == dateValue) cell.className = "todayDay";
	else cell.className = "normalDay";
	
	if(this._selectedDate && dateValue.valueOf() == this._selectedDate.valueOf()) cell.className = "selectedDay";
	
	var percent = this.percentAr[dateDay - 1] * 1;
	var bar = div.children[2].children[0];
	if(percent < 1) bar.style.visibility = "hidden";
	else if(percent >= 100) bar.style.height = "150%";
	else bar.style.height = percent + "%";
	
	if(this.bookedDaysAr[dateDay])
	{ 
		div.children[1].innerHTML = "&#254";
		div.children[1].checked = true;
	}
	if(!this._rebooking) div.children[1].style.left = "27%";

	if(this._rebooking && this.rebookedDaysAr[dateDay])
	{
		 div.children[3].innerHTML = "&#254";
		 div.children[3].checked = true;
	}

	if(this.disabledDaysAr[date.getDay()] || this.noSessionDaysAr[dateDay])
	{
		var dayDisabled = Util.createElementFromHTML("<div class=dayDisabled>");
		div.replaceChild(dayDisabled, div.children[0]);
		dayDisabled.textContent = dateDay;
		
		// Remove booking button.
		Util.removeElement(div.children[1]);
	}
	if(this.conflictDaysAr[dateDay]) div.children[0].className = "conflictDay";
	if(this.noSlotsDaysAr[dateDay]) div.children[0].className = "noSlotsDay";
	
	var dayObj = this._days[dateDay];
	if(dayObj && dayObj.color) {
		cell.style.backgroundColor = dayObj.color;
	} else {
		cell.style.backgroundColor = "";
	}
	
	cell.appendChild(div);
}

proto.findCell = function(l)
{
	return l.parentElement;
}

proto.parseDate = function(dateStr)
{
	var dateAr = String(dateStr).split("/");
	var date = null;
	if(dateAr.length == 3) date = new Date(dateAr[2], dateAr[1] * 1 - 1, dateAr[0]);
	return date;
}

proto.parseToHash = function(str)
{
	var ar = String(str).split(",");
	var result = [];
	for(var i = 0; i < ar.length; i++)
	{
		result[ar[i] * 1] = true;
	}
	return result;
}

proto.normalizePath = function(p)
{
	if(p.length > 0 && !p.match(/\\|\/$/)) p = p + "/";	
	return p;
}

proto.commitChange = function(value)
{
	var ev = {};
	ev.value = value;
	if(this.onpostback) this.onpostback(ev);
}


// Event handlers. ==============================
proto._bookedCheckbox_onclick = function()
{
	var l = Util.eventTarget();

	var jsObject = CNUtil.findJSObject(l);
	
	if(jsObject._disabled || jsObject._checksDisabled) return;
	l.checked = !l.checked;
	l.innerHTML = l.checked ? "&#254" : "&#111";

	jsObject.commitChange((l.checked ? 1000 : 2000) + parseInt(l.parentElement.children[0].textContent, 10));
}

proto._bookedCheckbox_onmouseenter = function()
{
	var jso = Util.dispatchObject();
	if(jso._checksDisabled) return;

	var l = Util.eventTarget();
	l.style.color = Util.getStyle(l, "xl--hover-color");
}

proto._bookedCheckbox_onmouseleave = function()
{
	var jso = Util.dispatchObject();
	if(jso._checksDisabled) return;

	var l = Util.eventTarget();
	l.style.color = "";
}

proto._dayButton_onclick = function()
{
	var l = Util.eventTarget();
	var jsObject = CNUtil.findJSObject(l);
	
	if(jsObject._disabled) return;
	jsObject.commitChange(l.textContent);
}

proto._prevMonthButton_onclick = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	
	if(jsObject._disabled) return;
	jsObject.commitChange(-1);
}

proto._nextMonthButton_onclick = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	
	if(jsObject._disabled) return;
	jsObject.commitChange(-2);
}

proto._yearUpButton_onclick = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	
	if(jsObject._disabled) return;
	jsObject.commitChange(-3);
}
	
proto._yearDownButton_onclick = function()
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget());
	
	if(jsObject._disabled) return;
	jsObject.commitChange(-4);
}

proto._monthSelect_onchange = function()
{
	// Executed in combobox context.
	var jsObject = CNUtil.findJSObject(this.element.parentElement);

	if(jsObject._disabled || !jsObject.isReady) return;
	jsObject.commitChange(-(parseInt(this.get_selectedIndex()) + 10));
}


// Properties. ===============================
proto.set_disabled = function(value)
{
	value = Util.parseBoolean(value);
	if(this._disabled == value) return;
	this._disabled = value;

	if(!this.isReady) return;
	this._set_disabled();
}

proto._set_disabled = function()
{
	this._disabler.style.visibility = this._disabled ? "inherit" : "hidden";
}

/* Standards-port boundary for the historical VML marker control. */
function CN_markercontrol() {
  this._disabled = false;
  this._unsupported = true;
  this.initiateUpload = false;
}
var proto = CN_markercontrol.prototype;
proto.createElement = function(node, parentElement) {
  var element = Util.createElement("div", "cn_markercontrol cn_unsupported_feature");
  element.jsObject = this;
  element.setAttribute("role", "status");
  element.textContent = "Marker editing is unavailable in the standards Client Framework.";
  parentElement.appendChild(element);
  this.element = element;
  Util.reportUnsupported("CN_markercontrol", "VML marker editing", "Requires an SVG/canvas renderer and pointer interaction rewrite");
  return element;
};
proto.loadData = function() { Util.reportUnsupported("CN_markercontrol", "VML marker editing"); };
proto.storeData = function() { return null; };
proto.unload = function() {};
proto.set_disabled = function(value) { this._disabled = !!value; if(this.element) this.element.setAttribute("aria-disabled", String(this._disabled)); };

/* Standards-port boundary for the historical VML drawing control. */
function CN_drawingcontrol() {
  this._disabled = false;
  this._unsupported = true;
  this.initiateUpload = false;
}
CN_drawingcontrol.BRUSH_IMAGE = 1;
CN_drawingcontrol.BRUSH_FREEDRAW = 2;
var proto = CN_drawingcontrol.prototype;
proto.createElement = function(node, parentElement) {
  var element = Util.createElement("div", "cn_drawingcontrol cn_unsupported_feature");
  element.jsObject = this;
  element.setAttribute("role", "status");
  element.textContent = "Drawing is unavailable in the standards Client Framework.";
  parentElement.appendChild(element);
  this.element = element;
  Util.reportUnsupported("CN_drawingcontrol", "VML drawing/editor", "Requires a canvas/SVG renderer and pointer interaction rewrite");
  return element;
};
proto.loadData = function() { Util.reportUnsupported("CN_drawingcontrol", "VML drawing/editor"); };
proto.storeData = function() { return null; };
proto.unload = function() {};
proto.set_disabled = function(value) { this._disabled = !!value; if(this.element) this.element.setAttribute("aria-disabled", String(this._disabled)); };
proto.get_Vml = function() { return null; };

/*
	v. 0.4
	+ hookForm
	v. 0.34
	+ ...
	+ theme support.
	ver. 0.11
*/
function CN_htmlviewer()
{
	this.formManager = null;
	this._clicked = false;
	this._param = "";
	this._disabled = false;
	this._isReady = false;
	this._sendSizeInfo = false;
}
var proto = CN_htmlviewer.prototype;

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);
	l.style.position = "absolute";
	
	this.element = l;
	l.jsObject = this;

	l.className = "cn_htmlviewer";
	var content = document.createElement("div");
	l.appendChild(content);
	
	this._disabler = Util.createElement("div", "", {style: "position: absolute; background: white; z-index: 1000; opacity: 0.5; width: 100%; height: 100%; visibility: hidden; top: 0px; left: 0px;"});
	l.appendChild(this._disabler);
	
	this._isReady = true;
	
	this._sendSizeInfo = node.getAttribute("sendSizeInfo") == "true";
	
	if(node.getAttribute("border") == "false") this.element.style.border = "none";
	
	Event.nativeAdd(l, "click", CN_htmlviewer._handle_onclick);

	return l;
} 

proto.loadData = function(node)
{
    var valueNode = Util.xmlSelectSingleNode(node, "value");
	if(valueNode) 
	{
		var embeddedObject = node.getAttribute("embeddedObject") == "true";
		if (embeddedObject)
		{
			var iframe = document.createElement('iframe');
				iframe.style.height = "100%";
				iframe.style.width = "100%";
				iframe.style.border =  "0";
				iframe.style.position = "absolute";
				iframe.style.top = "0px";
				iframe.style.left = "0px";
				
			this.element.appendChild(iframe);			
			
			var frameDocument = iframe.contentDocument;
			var parsedDocument = new DOMParser().parseFromString(String(Util.xmlText(valueNode)), "text/html");
			var parsedRoot = frameDocument.importNode(parsedDocument.documentElement, true);
			frameDocument.replaceChild(parsedRoot, frameDocument.documentElement);
		}
		else
		{
			try
			{
				this.element.children[0].innerHTML = "<span>" + Util.xmlText(valueNode) + "</span>";
			}
			catch(e)
			{
				alert("ASSERT: can't set HTML: " + Util.xmlText(valueNode))
			}
		}
	}

	this._hookForm = node.getAttribute("hookForm") == "true";
	if(this._hookForm) {
		this._processHookForm();
	}
}

proto._processHookForm = function() {
	var content = this.element.children[0].children[0];
	var forms = content.getElementsByTagName("form");
	for(var i = 0; i < forms.length; i++) {
		var form = forms[i];
		Event.add(form, "submit", this, this._form_onsubmit)
	}
}
proto._form_onsubmit = function() {
	this._formSubmitted = Event.current().target;
	Util.cancelEvent();
	this.formManager.postData(this.element);
}

proto.storeData = function(xmldoc)
{
	if(!this._clicked && !this._sendSizeInfo && !this._formSubmitted) return null;
	
	var fragment = xmldoc.createDocumentFragment();

	if(this._clicked)
	{
		var node = xmldoc.createElement("htmlviewerclicked");
		node.setAttribute("link", String(this._param));
		this._clicked = false;
		this._param = "";
		fragment.appendChild(node);
	}
	if(this._sendSizeInfo)
	{
		node = xmldoc.createElement("htmlviewersize");
		node.setAttribute("width", this.element.offsetWidth);
		node.setAttribute("height", this.element.offsetHeight);
		fragment.appendChild(node);
	}
	if(this._formSubmitted) {
			node = xmldoc.createElement("htmlviewerform");
		this._saveForm(this._formSubmitted, xmldoc, node);
		fragment.appendChild(node);
		this._formSubmitted = null;
	}
	return fragment;
}
proto._saveForm = function(form, xmldoc, parentNode) {
	for(var i = 0; i < form.elements.length; i++) {
		var el = form.elements[i];
		if(el.name != "") {
			if(el.tagName == "SELECT") {
				for(var j = 0; j < el.options.length; j++) {
					var op = el.options[j];
					if(op.selected) {
						var node = xmldoc.createElement("p");
						node.setAttribute("name", el.name);
						node.setAttribute("value", op.value || op.text);
						parentNode.appendChild(node);
					}
				}
			} else if(el.type != "checkbox" && el.type != "radio" || el.checked) {
				var node = xmldoc.createElement("p");
				node.setAttribute("name", el.name);
				node.setAttribute("value", el.value);
				parentNode.appendChild(node);
			}

		}
	}
}

CN_htmlviewer._handle_onclick = function()
{
	var a = CNUtil.findTag(Event.current().target, "A");
	if(!a || !a.href) return;
	CNUtil.cancelEvent();

	window.open(a.href);
}

function HTMLViewerClick(param)
{
	var jsObject = CNUtil.findJSObject(Event.current().target);
	if(jsObject._disabled) return;
	
	jsObject._clicked = true;
	jsObject._param = param;
	Util.cancelEvent(Event.current());
	jsObject.formManager.postData(jsObject.element);
}


// Properties. ===================================
proto.set_disabled = function(value)
{
	value = Util.parseBoolean(value);
	if(this._disabled == value) return;
	this._disabled = value;

	if(!this._isReady) return;
	this._set_disabled();
}

proto._set_disabled = function()
{
	this._disabler.style.visibility = this._disabled ? "inherit" : "hidden";
}


// Grid support. ====================================================
var HTMLCell = CN_grid.CellTypes["Html"] = function(colTag)
{
}
HTMLCell.cn_tagName = "html";

var wp = HTMLCell.prototype;
wp.isValid = function(cell){ return true; }
wp.prerender = function(cell, colTag)
{
	cell.style.paddingTop = 1;
	Util.appendHTML(cell, "<table border=0 class=HTMLTable cellspacing=0 cellpadding=0><tr valign=middle><td><div></div></td></tr></table>");
	var div = cell.children[0].rows[0].cells[0].children[0];
	div._isCellDiv = true;
	Event.nativeAdd(cell, "click", CN_htmlviewer._handle_onclick);
}
wp.render = function(cell, node)
{
	var table = cell.children[0];
	table.rows[0].cells[0].children[0].innerHTML = String(Util.xmlText(node));
	var color = Util.getStyle(cell.parentElement, "backgroundColor");
	if(color != "transparent") table.style.borderColor = color;
}

/*
	v. 0.23
	+ anchor.	
	v. 0.21
	+ theme support.
	v. 0.1
	+ initial release.
*/
function CN_barcontrol()
{
	this._contentTable = null;
}
var proto = CN_barcontrol.prototype;


proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;

	l.className = "cn_barcontrol";
	
	var contentTable = Util.createElement("table", "resourceTable", {cellSpacing: 3, cellPadding: 0, border: 0});
	l.appendChild(contentTable);
	
	var tbody = document.createElement("tbody");
	contentTable.appendChild(tbody);
	var tr = document.createElement("tr");
	tbody.appendChild(tr);
	tr = document.createElement("tr");
	tbody.appendChild(tr);
	
	this._contentTable = contentTable;
	
	return l;
}

proto.loadData = function(node)
{
	this._clean();
	this._build(node);
}

proto.storeData = function(xmldoc)
{
	return null;
}


proto._clean = function()
{
	this._cleanRow(1);
	this._cleanRow(0);
}

proto._cleanRow = function(rowIx)
{
	var row = this._contentTable.rows[rowIx];
	var count = row.cells.length;
	for(var i = 0; i < count; i++)
	{
		row.deleteCell(0);
	}
}

proto._build = function(node)
{
	var resources = Util.xmlSelectNodes(node, "resources/resource");
	var resourceCount = resources.length;
	this._createBars(resourceCount);
	
	var highestTotal = 0;
	for(var i = 0; i < resourceCount; i++)
	{
		highestTotal = Math.max(highestTotal, parseInt(resources[i].getAttribute("total"), 10));
	}

	for(var i = 0; i < resourceCount; i++)
	{
		this._fillBar(i, resources[i], highestTotal);
	}
}

proto._createBars = function(colNum)
{
	var row = this._contentTable.rows[0];
	for(var i = 0; i < colNum; i++)
	{
		var td = Util.createElement("td", "resourceBarTD");
		row.appendChild(td);
		var div = Util.createElement("div", "resourceBarDiv");
		td.appendChild(div);
		var gauge = Util.createElement("div", "resourceGaugeDiv");
		div.appendChild(gauge);
	}
	row = this._contentTable.rows[1];
	for(var i = 0; i < colNum; i++)
	{
		var td = Util.createElement("td", "resourceNumberTD");
		row.appendChild(td);
		td.textContent = " ";
	}
}

proto._fillBar = function(col, node, highestTotal)
{
	var barTD = this._contentTable.rows[0].cells[col];
	var bar = barTD.children[0];
	var gauge = bar.children[0];
	var numberTD = this._contentTable.rows[1].cells[col];
	
	var total = parseInt(node.getAttribute("total"), 10);
	var completed = parseInt(node.getAttribute("completed"), 10);
	
	var height = Math.round(total / highestTotal * 100);
	if(height < 1 || isNaN(height)) height = 1;
	
	bar.style.height = height + "%";
	
	bar.style.top = (100 - height) + "%";
	
	var gaugeHeight = Math.round(completed / total * 100);
	if(isNaN(gaugeHeight) || gaugeHeight < 1) gauge.style.visibility = "hidden";
	else 
	{
		gauge.style.height = gaugeHeight + "%";
		gauge.style.visibility = "inherit";
		gauge.style.top = (100 - gaugeHeight) + "%";
	}

	numberTD.textContent = String(col + 1);
	
	var attr = node.getAttribute("message");
	if(attr) Tooltip.attach(numberTD, String(attr));
}

/* Standards-based replacement boundary for the historical IE rich editor. */
function CN_wysiwygeditor() {
  this.formManager = null;
  this._disabled = false;
  this._event = "wysiwygeditor";
  this._simpleMode = false;
  this._unsupported = true;
}
CN_wysiwygeditor._simpleMode = false;
CN_wysiwygeditor._autoCorrectCache = [];
CN_wysiwygeditor._autoCorrectMaxLength = 0;
CN_wysiwygeditor._hideAutocompleteUI = function() {};
var proto = CN_wysiwygeditor.prototype;
proto.createElement = function(node, parentElement) {
  var wrapper = Util.createElement("div", "cn_wysiwygeditor cn_unsupported_feature");
  var content = Util.createElement("div", "cnContentDiv");
  content.contentEditable = "true";
  content.setAttribute("role", "textbox");
  content.setAttribute("aria-multiline", "true");
  wrapper.appendChild(content);
  wrapper.jsObject = this;
  parentElement.appendChild(wrapper);
  this.element = wrapper;
  this._contentDiv = content;
  this._event = node && node.getAttribute("event") || "wysiwygeditor";
  Util.reportUnsupported("CN_wysiwygeditor", "legacy rich-editor features", "TextRange/VML autocomplete and spell-check paths require a standards editor implementation");
  return wrapper;
};
proto.loadData = function(node) {
  var documentNode = Util.xmlSelectSingleNode(node, "document");
  var html = documentNode ? (Util.xmlText(documentNode)) : (Util.xmlText(node));
  if(this._contentDiv) this._contentDiv.innerHTML = String(html);
};
proto.storeData = function(xmldoc) {
  if(!this._contentDiv) return null;
  var node = xmldoc.createElement("wysiwygdocument");
  node.appendChild(xmldoc.createCDATASection(this._contentDiv.innerHTML));
  return node;
};
proto.unload = function() {};
proto.set_disabled = function(value) {
  this._disabled = !!value;
  if(this._contentDiv) this._contentDiv.contentEditable = this._disabled ? "false" : "true";
};
proto.set_tabIndex = function(value) { if(this._contentDiv) this._contentDiv.tabIndex = value; };

/*
	v. 2.0
*/
function CN_videoplayer()
{
	this.player = null;
	this._src = null;
	this.paused = false;
	this.stopProbeTimeout = null;
}
var proto = CN_videoplayer.prototype;


proto.createElement = function(node, parentElement)
{
	var l = Util.createElement("div", "cn_videoplayer");
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;

	l.style.whiteSpace = "nowrap";

	this.buildElements();
	
	this.element.disabled = true;
	
	return l;
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("src");
	if(attr) 
	{
		this.set_disabled(false);
		this._src = String(attr);

		this._startPlayTO();
	}
	else 
	{
		this.set_disabled(true);
	}
}

proto._startPlayTO = function()
{
	var obj = this;
	setTimeout(function()
	{
		if(!obj || !obj.player) return;
		obj.player.autoplay = false;
		obj.player.src = obj._src;
	}, 300);
}

proto.unload = function()
{
	this.player = null;
}

proto.buildElements = function()
{
	var player = Util.createElement("video", "wmpObject", {controls: true, disabled: true});
	this.element.appendChild(player);
	this.player = player;
	this.set_disabled(true);
}

proto.set_disabled = function(val)
{
	if(!this._src) val = true;
	this.element.disabled = val;
	this.player.controls = !val;
}
/*
	v. 0.32
	+ anchor support
	+ theme support.
	v. 0.22
	+ before/after icons.
*/
function CN_timeline()
{
	this._minTDWidth = 50;
	this._zoomStep = .20;
	this._disabled = false;
	this._wasClicked = false;
}
var proto = CN_timeline.prototype;

CN_timeline.monthes = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];


// ICNControl implementation. ===============================
proto.createElement = function(node, parentElement)
{
	var l = Util.createElementFromHTML("<div class=cn_timeline>");
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;
	
	this._buildElement(node);
	
	Event.add(window, "resize", this, this._element_onresize);
	if(typeof ResizeObserver != "undefined") {
		this._resizeObserver = new ResizeObserver(this.element_onresize.bind(this));
		this._resizeObserver.observe(l);
	}

	return l;
}

proto.loadData = function(node)
{
	var lines = Util.xmlSelectNodes(node, "line");
	var count = lines.length;
	for(var i = 0; i < count; i++)
	{
		var line = lines[i];
		var dates = Util.xmlSelectNodes(line, "date");
		var dateCount = dates.length;
		for(var j = 0; j < dateCount; j++)
		{
			var dateNode = dates[j];
			var dateStr = String(dateNode.getAttribute("value"));
			var date = this._getDate(dateStr);
			var month = date.getMonth();
			var year = date.getFullYear();
			
			var offset = (year - this._fromDate.getFullYear()) * 12 + (month - this._fromDate.getMonth());
			var tr = this._lineTable.rows[i];
			var td = tr.cells[offset];
			if(!td)
			{
				alert("ASSERT: can't find line with date: " + date);
				return;
			}

			var icon = Util.createElementFromHTML("<img class=timelineIcon>");
			td.appendChild(icon);

			var src;
			if(date.getTime() > this._nowDate.getTime()) src = String(tr._iconAfter);
			else src = String(tr._iconBefore);
			
			icon.src = src;
			
			icon.style.left = ((100 / this._getDaysInMonth(date) * (date.getDate() - 1)) - 1) + "%";

			var attr = dateNode.getAttribute("tooltip");
			if(attr) Tooltip.attach(icon, String(attr));
			
			Event.add(icon, "click", this, this._icon_onclick);
			icon._date = dateStr;
		}
	}
}

proto.storeData = function(xmldoc)
{
	if(!this._wasClicked) return;
	this._wasClicked = false;
	var node = xmldoc.createElement("timeline");
	node.setAttribute("date", this._clickedDate);
	node.setAttribute("lineID", this._clickedLineID);
	return node;
}

proto.unload = function()
{
	this._legendDiv = null;
	this._tableDiv = null;
	if(this._resizeObserver) this._resizeObserver.disconnect();
	Event.del(window, "resize", this, this._element_onresize);
}

proto.validateLoading = function()
{
	this._tableDiv.style.height = this._legendDiv.style.height = this.element.clientHeight + "px";	
	this._tableDiv.style.width = (this.element.clientWidth - this._legendDiv.offsetWidth 
									- this._toolbarDiv.offsetWidth) + "px";
	this._toolbarDiv.style.left = (this.element.clientWidth - this._toolbarDiv.offsetWidth) + "px";
	this._toolbarDiv.style.height = this.element.clientHeight + "px";
	
	if(!this._nowDiv)
	{
		this._nowDiv = Util.createElementFromHTML("<div class=nowMarkDiv>");
		this._tableDiv.appendChild(this._nowDiv);
		
		//this._nowLabel = Util.createElementFromHTML("<div class=nowLabelDiv>");
		//this._tableDiv.appendChild(this._nowLabel);
		//this._nowLabel.textContent = "Now";
	}		
	this._updateNowDiv();
}

proto._updateNowDiv = function()
{
	if(!this._nowTD)
	{
		alert("ASSERT: can't find now cell for now mark.")
		return;
	}
	this._nowDiv.style.height = (this._lineCount * 20 + 6) + "px";
	var x = this._nowTD.offsetLeft + this._getDayX(this._nowTD, this._nowDate);
	this._nowDiv.style.left = x + "px";
	
	//this._nowLabel.style.top = (this._lineTable.rows.length - 2) * 20 + 9;
	//this._nowLabel.style.left = x;
}

proto._getDayX = function(td, date)
{
	var days = this._getDaysInMonth(date);
	return td.offsetWidth / days * (date.getDate() - 1);
}


// Control implementation. ================================
proto._buildElement = function(node)
{
	this._fromDate = this._getPartialDate(String(node.getAttribute("from")));
	this._toDate = this._getPartialDate(String(node.getAttribute("to")));	
	this._nowDate = this._getDate(String(node.getAttribute("now")));
	
	var lines = Util.xmlSelectNodes(node, "line");
	this._lineCount = lines.length;

	this._buildToolbar();
	this._buildLegend(node, lines);
	this._buildLines(node, lines);
	
	this._lineTable.width = this._getMinTableWidth();

	this.disabler = Util.createElementFromHTML('<div style="position: absolute; background: white; z-index: 1000; opacity: .5; width: 100%; height: 100%; visibility: hidden; top: 0px; left: 0px; ">');
	this.element.appendChild(this.disabler);
} 

proto._getPartialDate = function(str)
{
	var ar = str.split(/\.|\//);
	return new Date(parseInt(ar[1], 10), parseInt(ar[0], 10) - 1, 1);
}

proto._getDate = function(str)
{
	var ar = str.split(/\.|\//);
	return new Date(parseInt(ar[2], 10), parseInt(ar[1], 10) - 1, parseInt(ar[0]));
}

proto._buildLegend = function(node, lines)
{
	this._legendDiv = Util.createElementFromHTML("<div class=timelineLegendDiv>");
	this.element.appendChild(this._legendDiv);
	
	for(var i = 0; i < this._lineCount; i++)
	{
		var line = lines[i];
		var div = Util.createElementFromHTML("<div class=timelineCaptionDiv>");
		this._legendDiv.appendChild(div);
		div.style.left = "5px";
		div.style.top = (3 + i * 20) + "px";
		
		var img = Util.createElementFromHTML("<img align=absmiddle width=16 height=16>");
		div.appendChild(img);
		img.src = String(line.getAttribute("before"));
		img.style.marginRight = "4px";
		
		div.appendChild(document.createTextNode(line.getAttribute("caption")));
	}
}

proto._buildLines = function(node, lines)
{
	this._tableDiv = Util.createElementFromHTML("<div class=timelineTableDiv>");
	this.element.appendChild(this._tableDiv);

	this._lineTable = Util.createElementFromHTML("<table class=timelineTable frame=void rules=rows cellpadding=3 cellspacing=0 border=0 bordercolor=B3B6CE>");
	this._tableDiv.appendChild(this._lineTable);
	
	this._lineTable.width = 4000;
	
	var tbody = document.createElement("tbody");
	this._lineTable.appendChild(tbody);
	
	for(var i = 0; i < this._lineCount; i++)
	{
		var line = lines[i];
		
		var tr = Util.createElementFromHTML("<tr>");
		tbody.appendChild(tr);
		
		tr._isLineTR = true;
		tr._iconBefore = String(line.getAttribute("before"));
		tr._iconAfter = String(line.getAttribute("after"));
		tr._lineID = String(line.getAttribute("id"));
		
		var dt = new Date(this._fromDate);
		while(dt.getTime() <= this._toDate.getTime())
		{
			var td = Util.createElementFromHTML("<td nowrap>");
			tr.appendChild(td);
			
			td.textContent = " ";
			dt.setMonth(dt.getMonth() + 1);
		}
	}

	this._buildLowerLine(tbody);
}

proto._buildLowerLine = function(tbody)
{
	var tr = Util.createElementFromHTML("<tr class=lowerMonthes1 valign=top>");
	tbody.appendChild(tr);
	
	var dt = new Date(this._fromDate);
	while(dt.getTime() <= this._toDate.getTime())
	{
		var td = Util.createElementFromHTML("<td nowrap>");
		tr.appendChild(td);
		
		var div = Util.createElementFromHTML("<div class=lowerMonthesMark>");
		td.appendChild(div);

		td.style.background = dt.getMonth() % 2 ? "#eeeeee" : "white";
		td.align = "center"
		dt.setMonth(dt.getMonth() + 1);
	}

	var tr = Util.createElementFromHTML("<tr class=lowerMonthes2>");
	tbody.appendChild(tr);
	
	var dt = new Date(this._fromDate);
	while(dt.getTime() <= this._toDate.getTime())
	{
		var td = Util.createElementFromHTML("<td nowrap>");
		tr.appendChild(td);
		
		td.textContent = CN_timeline.monthes[dt.getMonth()];
		td.align = "center"

		if(dt.getMonth() == this._nowDate.getMonth() && dt.getFullYear() == this._nowDate.getFullYear())
		{
			this._nowTD = td;
			td._monthDate = new Date(dt);
		}

		dt.setMonth(dt.getMonth() + 1);
	}
}

proto._getDaysInMonth = function(date)
{
	var dt = new Date(date);
	
	dt.setDate(29);
	if(dt.getMonth() != date.getMonth()) return 28;
	
	dt.setDate(30);
	if(dt.getMonth() != date.getMonth()) return 29;

	dt.setDate(31);
	if(dt.getMonth() != date.getMonth()) return 30;
	
	return 31;
}

proto._buildToolbar = function()
{
	this._toolbarDiv = CNUtil.createToolbar(this.element);
	
	CNUtil.addButton(this._toolbarDiv, "zoomIn", null, "Zoom In", CNFormManager.neutralIconsPath + "zoom-plus.gif");
	CNUtil.addButton(this._toolbarDiv, "zoomOut", null, "Zoom Out", CNFormManager.neutralIconsPath + "zoom-minus.gif");
}

proto._getMinTableWidth = function()
{
	return this._lineTable.rows[0].cells.length * this._minTDWidth;
}

proto.zoomIn = function()
{
	var maxWidth = this._lineTable.rows[0].cells.length * (this._tableDiv.offsetWidth) * 1.05;
	var zoomWidth = Math.round(this._lineTable.offsetWidth * (1 + this._zoomStep));
	if(zoomWidth > maxWidth) zoomWidth = maxWidth;
	this._lineTable.width = zoomWidth;
	this._updateNowDiv();
}

proto.zoomOut = function()
{
	var minWidth = this._getMinTableWidth();
	var zoomWidth = Math.round(this._lineTable.offsetWidth * (1 - this._zoomStep));
	if(zoomWidth < minWidth) zoomWidth = minWidth;
	this._lineTable.width = zoomWidth;
	this._updateNowDiv();
}

// Event handlers. ================================
proto._icon_onclick = function()
{
	CNUtil.dispatchObject().icon_onclick();
}

proto.icon_onclick = function()
{
	var tr = CNUtil.findTag(Util.eventTarget(), "TR");
	this._clickedDate = Util.eventTarget()._date;
	this._clickedLineID = tr._lineID;
	this._wasClicked = true;
	this.formManager.postData(this.element);
}

proto.set_disabled = function(value)
{
	this._disabled = value;

	this._set_disabled();
}
proto._set_disabled = function()
{
	this.disabler.style.visibility = this._disabled ? "inherit" : "hidden";
}

proto._element_onresize = function()
{
	this.element_onresize();
}
proto.element_onresize = function()
{
	if(this.element.clientWidth == 0) return;
	this._tableDiv.style.height = this._legendDiv.style.height = this.element.clientHeight + "px";	
	this._tableDiv.style.width = (this.element.clientWidth - this._legendDiv.offsetWidth 
									- this._toolbarDiv.offsetWidth) + "px";
	this._toolbarDiv.style.left = (this.element.clientWidth - this._toolbarDiv.offsetWidth) + "px";
	this._toolbarDiv.style.height = this.element.clientHeight + "px";
	
	if(!this._nowDiv)
	{
		this._nowDiv = Util.createElementFromHTML("<div class=nowMarkDiv>");
		this._tableDiv.appendChild(this._nowDiv);
		
		//this._nowLabel = Util.createElementFromHTML("<div class=nowLabelDiv>");
		//this._tableDiv.appendChild(this._nowLabel);
		//this._nowLabel.textContent = "Now";
	}		
	this._updateNowDiv();
}

/*
	v. 0.36
	+ load/resize performance optimizations.
	- nonInteractive
	+ anchor support.
*/
function CN_availabilitycontrol()
{
	this._clicked = false;
	this._loadedOnce = false;
	this._periodsData = [];
}
var proto = CN_availabilitycontrol.prototype;

proto.createElement = function(node, parentElement)
{
	var l = this.element = Util.createElementFromHTML("<div class=cn_availabilitycontrol>");
	parentElement.appendChild(l);

	l.jsObject = this;

	this._buildElement();
	
	Event.add(window, "resize", this, this._element_onresize);
	if(typeof ResizeObserver != "undefined") {
		this._resizeObserver = new ResizeObserver(this.element_onresize.bind(this));
		this._resizeObserver.observe(l);
	}

	return l;
} 

proto._buildElement = function()
{
	var patternDiv = Util.createElementFromHTML("<div class=patternDiv>");
	this.element.appendChild(patternDiv);

	var table = Util.createElementFromHTML("<table cellspacing=0 frame=void border=1>");
	this.element.appendChild(table);
	
	table.borderColor = Util.getStyle(this.element, "xl--grid-color");
}

proto._buildGrid = function()
{
//	Util.benchmark(function() {

	var table = this.element.children[1];
	for(var i = 8; i < 20; i += .5)
	{
		var k = Math.floor(i);
		var k2 = k + 1;

		var s1 = (k < 10) ? "0" + k : k;
		var s2 = (k2 < 10) ? "0" + k2 : k2;

		var text;
		if(k == i) text = s1 + ".00-" + s1 + ".30";
		else text = s1 + ".30-" + s2 + ".00";
		
		var tr = table.insertRow();
		var td1 = tr.insertCell();
		td1.className = "firstColumnTD"
		
		var button = Util.createElementFromHTML("<button class=availbutton>");
		td1.appendChild(button);
		
		Event.add(button, "click", this, this._button_onclick);
		
		button.textContent = text;
	}
	
//	}, "CN_availabilitycontrol._buildGrid", this);
}

proto.storeData = function(xmldoc)
{
	if(!this._clicked) return;
	this._clicked = false;

	var node = xmldoc.createElement("availabilitycontrolclick");
	node.setAttribute("value", this._trIndex);
	return node;
}

proto._element_onresize = function()
{
	this.element_onresize();
}
proto.element_onresize = function()
{
	if(!this._loadedOnce) return;
	this._resizeDataSet();
}


proto.loadData = function(node)
{
//	Util.benchmark(function() {	

	this._loadedOnce = true;
	this._cleanData();
	this._buildGrid();

	var patternDiv = this.element.children[0];

	var table = this.element.children[1];
	
	var dateNodes = Util.xmlSelectNodes(node, "date");
	var dateCount = dateNodes.length;

	if(dateCount == 0) 
	{
		this._processEmptyData();
		return;
	}
	else
	{
		var dateTooltips = new Array(dateCount);
		for(var i = 0; i < dateCount; i++)
		{
			var attr = dateNodes[i].getAttribute("tooltip");
			if(attr) dateTooltips[i] = String(attr);
			else dateTooltips[i] = null;
		}
		
		this._renderGrid(dateCount, dateTooltips);
	}
	
//	Util.benchmark(function() {	

	var left = 0;
	
	var row0cells = table.rows[0].cells;
	for(var i = 0; i < dateCount; i++)
	{
		var dateNode = dateNodes[i];
		var pNodes = Util.xmlSelectNodes(dateNode, "p");
		var pCount = pNodes.length;

		var width = row0cells[1 + i].offsetWidth;
	
		var tooltip = null;

		for(var j = 0; j < pCount; j++)
		{
			var pNode = pNodes[j];
			patternDiv.appendChild(this._buildPeriod(pNode, table, patternDiv, left, width, i));
		}
		left += width;		
	}

	
	//CNFormManager._trace("pCount: " + dateCount);

	this._setPatternSizes();
	
//	}, "CN_availabilitycontrol.loadData 2/2", this);
//	}, "CN_availabilitycontrol.loadData", this);
}

proto._resizeDataSet = function() {
	//Util.benchmark(function() {	
	
	this._setPatternSizes();
	
	var patternDiv = this.element.children[0];
	var childNodes = patternDiv.childNodes;
	var count = childNodes.length;

	if(!Util.assert(function(){ return count == this._periodsData.length; }, this)) return;

	var table = this.element.children[1];

	var left = 0;
	var dateIx = 0;
	var row0cells = table.rows[0].cells;
	for(var i = 0; i < count; i++) {
		var div = childNodes[i];
		var data = this._periodsData[i];

		var yBounds = this._calculatePeriodYBounds(table, data[0], data[1]);
		
		var width = row0cells[1 + dateIx].offsetWidth;

		if(data[2] != dateIx) left += width;

		dateIx = data[2];
		
		div.style.top = yBounds[0] + "px";
		div.style.height = yBounds[1] + "px";
		div.style.left = left + "px"
		div.style.width = width + "px";
	}

	//}, "CN_availabilitycontrol._resizeDataSet", this);
}

proto._processEmptyData = function()
{
	var patternDiv = this.element.children[0];
	var grayDiv = Util.createElement("div", "periodDiv_unavail");
	patternDiv.appendChild(grayDiv);
	grayDiv.style.width = "100%";
	grayDiv.style.height = "100%";
	this._renderGrid(1, []);
	this._setPatternSizes();
}

proto.validateLoading = function()
{
	if(this._loadedOnce) return;
	this._cleanData();
	this._buildGrid();
	this._processEmptyData();
}

proto._setPatternSizes = function()
{
	var patternDiv = this.element.children[0];
	var table = this.element.children[1];
	patternDiv.style.left = table.rows[0].cells[0].offsetWidth + "px";
	patternDiv.style.top = "0px";
	patternDiv.style.width = "100%";
	patternDiv.style.height = "100%";
}

proto._cleanData = function()
{
	this._periodsData = [];
	
	var patternDiv = this.element.children[0];
	var table = this.element.children[1];
	
	var children = patternDiv.children;
	var count = children.length;
	for(var i = count - 1; i >= 0; i--)
	{
		Util.removeElement(children[i]);
	}
	
	var rows = table.rows;
	var count = rows.length;
	for(var i = count - 1; i >= 0; i--)
	{
		table.deleteRow(0);
	}
}

proto._renderGrid = function(colNum, dateTooltips)
{
	var table = this.element.children[1];
	// Grid.
	for(var rowIx = 0; rowIx < table.rows.length; rowIx++)
	{
		var row = table.rows[rowIx];
		for(var tdIx = 0; tdIx < colNum; tdIx++)
		{
			var td = row.insertCell();
			td.className = "innerGridTD"
			td.textContent = " ";
			var tooltip = dateTooltips[tdIx];
			if(tooltip) Tooltip.attach(td, tooltip);
		}
	}
}

proto._buildPeriod = function(pNode, table, patternDiv, left, width, dateIx)
{
	var type = String(pNode.getAttribute("type"));
	var time = String(pNode.getAttribute("time"));
	
	var times = time.split("-");

	var fromPeriod = this._getPeriod(times[0]);
	var toPeriod = this._getPeriod(times[1]);

	var data = this._periodsData[this._periodsData.length] = [fromPeriod, toPeriod, dateIx]

	var yBounds = this._calculatePeriodYBounds(table, fromPeriod, toPeriod);

/*	var div = document.createElement("div");
	div.className = "periodDiv_" + type;
	div.style.position = "absolute";
	div.style.top = fromY + "px";
	div.style.height = toY - fromY + "px";
	div.style.left = left + "px";
	div.style.width = width + "px";
	patternDiv.appendChild(div);*/
	
	var div = Util.createElement("div", "periodDiv_" + type);
	div.style.position = "absolute";
	div.style.top = yBounds[0] + "px";
	div.style.left = left + "px";
	div.style.width = width + "px";
	div.style.height = yBounds[1] + "px";
	return div;
}

proto._calculatePeriodYBounds = function(table, fromPeriod, toPeriod) {
	var fromRow = table.rows[fromPeriod[0]].cells[0]; // +1 == header row.
	var toRow = table.rows[toPeriod[0]].cells[0];

	var fromY = Math.round(fromRow.offsetTop + fromRow.offsetHeight * fromPeriod[1]);
	var toY = Math.round(toRow.offsetTop + toRow.offsetHeight * toPeriod[1]);
	
	return [fromY, toY - fromY] // y, h
}

proto._getPeriod = function(time)
{
	var parts = time.split(":");
	var h = parseInt(parts[0], 10) - 8;
	var m = parseInt(parts[1], 10);
	var complete = (h + m  / 60) * 2;
	var rounded = Math.floor(complete);
	var fraction = complete - rounded;
	if(rounded == 24 && fraction == 0)
	{
		rounded--;
		fraction = 1;
	}

	return [rounded, fraction]
}


// Event handlers. ===============================
proto._button_onclick = function()
{
	CNUtil.dispatchObject().button_onclick();
}
proto.button_onclick = function()
{
	if(this.element.disabled) return;
	var tr = CNUtil.findTag(Util.eventTarget(), "TR");
	this._trIndex = tr.rowIndex;
	this._clicked = true;
	this.formManager.postData(this.element);
}
/*
	# 1036-3 - fine grained tab handling for grid - proxyTabKeyDown
	v. 2.0.3
	+ autopostback fine tuned.
*/
function CN_partialdatebox()
{
	this._isDirty = false;
	this._readOnly = false;
	this._disabled = false;
	this.validationString = "Invalid Date";
	
	// Grid support.
	this.directlyAssignEvents = true;
	this.doNotCheckValidChars = true;

	this.supportsRequired = true;
	this._minValue = null;
	this._maxValue = null;
	this._autoPostBack = false;	

	this._inGrid = false;
}

var proto = CN_partialdatebox.prototype; 

// Events. =========================
proto.onfocusout = function(){}
proto.onkeypress = function(){}


// Public methods. ================================
proto.createElement = function(node, parentElement)
{
	var l = document.createElement("span");
	// Grid support.
	if(parentElement) parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;
	
	l.className = "cn_partialdatebox";
	
	var dayBox = document.createElement("input");
	dayBox.type = 'text';
	dayBox.maxLength = 2;
	dayBox.style.width = '15px';
	dayBox.style.paddingLeft = '1px';
	l.appendChild(dayBox);
	l.appendChild(document.createTextNode("/"));
	
	var monthBox = document.createElement("input");
	monthBox.type = 'text';
	monthBox.maxLength = 2;
	monthBox.style.width = '14px';
	l.appendChild(monthBox);
	l.appendChild(document.createTextNode("/"));

	var yearBox = document.createElement("input");
	yearBox.type = 'text';
	yearBox.maxLength = 4;
	yearBox.style.width = '28px';
	l.appendChild(yearBox);
		
	dayBox._maxValue = 31;
	monthBox._maxValue = 12;

	Event.add(dayBox, "keypress", this, this._box_onkeypress);
	Event.add(monthBox, "keypress", this, this._box_onkeypress);
	Event.add(yearBox, "keypress", this, this._box_onkeypress);

	Event.add(dayBox, "keyup", this, this._box_onkeyup);
	Event.add(monthBox, "keyup", this, this._box_onkeyup);
	Event.add(yearBox, "keyup", this, this._box_onkeyup);

	Event.add(dayBox, "keydown", this, this._box_onkeyup);
	Event.add(monthBox, "keydown", this, this._box_onkeyup);
	Event.add(yearBox, "keydown", this, this._box_onkeyup);

	Event.add(dayBox, "focus", this, this._box_onfocus);
	Event.add(monthBox, "focus", this, this._box_onfocus);
	Event.add(yearBox, "focus", this, this._box_onfocus);
	
	Event.add(dayBox, "change", this, this._box_onchange);
	Event.add(monthBox, "change", this, this._box_onchange);
	Event.add(yearBox, "change", this, this._box_onchange);

	Event.add(this.element, "focusout", this, this._element_onfocusout);
	Event.add(this.element, "focusout", this, this._element_ondeactivate);
	Event.add(this.element, "focusin", this, this._element_onactivate);
	
	if(node)
	{
		var attr = node.getAttribute("validationString");
		if(attr) this.validationString = String(attr);

		var attr = node.getAttribute("autoPostBack");
		if(attr) this._autoPostBack = attr == "true";
	}

	if(CNFormManager.vista) VistaSupport.attachToJSCNBox(this);

	return l;
}

proto.loadData = function(node)
{
	this._isDirty = false;
	if(this.element.style.borderColor == "red") this.element.style.borderColor = "";

	var boxes = this.element.getElementsByTagName("input");
	var dayAttr = node.getAttribute("day");
	if(dayAttr != null) boxes[0].value = String(dayAttr);
	var monthAttr = node.getAttribute("month");
	if(monthAttr != null) boxes[1].value = String(monthAttr);
	var yearAttr = node.getAttribute("year");
	if(yearAttr != null) boxes[2].value = String(yearAttr);
	
	var attr = node.getAttribute("minvalue");
	if(attr) this._minValue = this._parseDate(String(attr));
	attr = node.getAttribute("maxvalue");
	if(attr) this._maxValue = this._parseDate(String(attr));
}

proto._parseDate = function(str)
{
	var ar = str.match(/^(\d{4})(\d{2})?(\d{2})?/);
	if(!ar) return null;
	ar.splice(0, 1);
	for(var i = 0; i < ar.length; i++) ar[i] = parseInt(ar[i], 10);
	return ar;
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty || !this.isValid()) return null;
	this._isDirty = false;

	var node = xmldoc.createElement("partialdatebox");

	var boxes = this.element.getElementsByTagName("input");
	if(!isNaN(parseInt(boxes[0].value, 10))) node.setAttribute("day", boxes[0].value);
	if(!isNaN(parseInt(boxes[1].value, 10))) node.setAttribute("month", boxes[1].value);
	if(!isNaN(parseInt(boxes[2].value, 10))) node.setAttribute("year", boxes[2].value);

	return node;
}

proto.isValid = function()
{
	if(this._disabled) return true;
	
	var values = this.get_values();
	var valid = true;
	
	var day = parseInt(values[0], 10);
	var month = parseInt(values[1], 10);
	var year = parseInt(values[2], 10);

	if(isNaN(day) && isNaN(month) && isNaN(year)) valid = true;
	else if(!isNaN(day) && (day < 1 || day > 31)
	|| !isNaN(month) && (month < 1 || month > 12)
	|| !isNaN(year) && (values[2].length < 4 || year < 1800)) 
	{
		valid = false;
	}
	else if(!isNaN(day))
	{
		if(isNaN(month) || isNaN(year)) valid = false;
		else if(values[2].length < 4) valid = false;
		else
		{
			var date = new Date(year, month - 1, day);
			valid = date.getMonth() == month - 1 && date.getDate() == day && date.getFullYear() == year;
		}
	}
	else if(isNaN(day) && isNaN(year)) valid = false;

	if(valid && this._maxValue)
	{
		if(this._maxValue[0] && !isNaN(year))
		{
			if(this._maxValue[0] < year) valid = false;
			else if(this._maxValue[0] == year && this._maxValue[1] && !isNaN(month))
			{
				if(this._maxValue[1] < month) valid = false;
				else if(this._maxValue[1] == month && this._maxValue[2] && !isNaN(day))
				{
					if(this._maxValue[2] < day) valid = false;
				}
			}
		}
	}

	if(valid && this._minValue)
	{
		if(this._minValue[0] && !isNaN(year))
		{
			if(this._minValue[0] > year) valid = false;
			else if(this._minValue[0] == year && this._minValue[1] && !isNaN(month))
			{
				if(this._minValue[1] > month) valid = false;
				else if(this._minValue[1] == month && this._minValue[2] && !isNaN(day))
				{
					if(this._minValue[2] > day) valid = false;
				}
			}
		}
	}

	if(valid) 
	{
		if(this.element.style.borderColor == "red") this.element.style.borderColor = "";
		return true;
	}
	this.element.style.borderColor = "red";
	return false;
}

// Private methods. =================================
proto._tryNextField = function(box)
{
	if(box.value.length == box.maxLength && box.selectionStart == box.selectionEnd && box.selectionEnd == box.value.length)
	{
		this._moveToNextField(box);
	} 
}

proto._moveToNextField = function(box)
{
	var boxes = this.element.getElementsByTagName("input");
	if(box == boxes[0]) boxes[1].focus();
	else if(box == boxes[1]) boxes[2].focus();
}

proto._moveToPreviousField = function(box)
{
	var boxes = this.element.getElementsByTagName("input");
	if(box == boxes[2]) boxes[1].focus();
	else if(box == boxes[1]) boxes[0].focus();
}

proto._checkLeftRight = function(box, code)
{
	if(code == 37) // Left
	{
		if(box.selectionStart == 0 && box.selectionEnd == 0) 
		{
			this._moveToPreviousField(box);		
			return true;
		}
	}
	else if(code == 39) // Right
	{
		if(box.selectionStart == box.value.length && box.selectionEnd == box.value.length) 
		{
			this._moveToNextField(box);
			return true;
		}
	}
	return false;
}

// Used by grid BoxManager.
proto.focus = function()
{
	var boxes = this.element.getElementsByTagName("input");	
	boxes[0].focus();
}

// Used by grid BoxManager.
proto.select = function(){}

// Used by grid BoxManager.
proto.blur = function()
{
	var boxes = this.element.getElementsByTagName("input");
	for(var i = 0; i < boxes.length; i++)
	{
		if(document.activeElement == boxes[i])
		{
			boxes[i].blur();
			break;
		}
	}
}


// Event handlers. ============================
proto._box_onkeypress = function()
{
	CNUtil.dispatchObject().box_onkeypress();
}
proto.box_onkeypress = function()
{
	if(this._disabled) return;
	var code = (Event.keyValue(Event.current()));
	var charx = String.fromCharCode(code);
	if((charx < "0" || charx > "9") && code != 13)
	{
		CNUtil.cancelEvent();
		return;
	}
}

proto._box_onkeyup = function()
{
	CNUtil.dispatchObject().box_onkeyup();
}
proto.box_onkeyup = function()
{
	if(this._disabled) return;
	var box = Util.eventTarget();
	
	var code = (Event.keyValue(Event.current()));

	if(Event.current().type == "keydown")
	{
		if(this._checkLeftRight(box, code)) return;
		var value = parseInt(box.value, 10);
		if(!isNaN(value))
		{
			if(code == 38 && (!box._maxValue || value < box._maxValue)) // Up.
			{
				box.value = value + 1;
				this._isDirty = true;
			}
			else if(code == 40 && value > 1) // Down.
			{
				box.value = value - 1;
				this._isDirty = true;				
			}
		}
		
		if(code == 9 && this._inGrid) {
			//	else if(box == boxes[1]) boxes[2].focus();		
			var boxes = this.element.getElementsByTagName("input");
			if(box == boxes[2]) {
				CN_grid.proxyTabKeyDown();
				return;
			}
		}
	}

	var charx = String.fromCharCode(code);
	if(code == 46) return;
	if((charx < "0" || charx > "9") && (code < 96 || code > 105) || code == 13) 
	{
		var newVal = box.value.replace(/\D/g, '');
		if(newVal != box.value)
		{
			box.value = newVal;
			this._isDirty = true;
		}
		return;
	} 

	if(Event.current().type == "keydown") this._tryNextField(box);
}

proto._box_onfocus = function()
{
	var box = Util.eventTarget();
	box.select();
}

proto._element_ondeactivate = function()
{
	CNUtil.dispatchObject().element_ondeactivate();
}
proto.element_ondeactivate = function()
{
	if(this.element.contains(Event.current().relatedTarget)) return;
	if(this._isDirty && this.isValid() && this._autoPostBack) this.formManager.postData(this.element);
}

proto._element_onactivate = function()
{
	CNUtil.dispatchObject().element_onactivate();
}
proto.element_onactivate = function()
{
	if(this.element.contains(Event.current().relatedTarget)) return;
	if(this.element.style.borderColor == "red") this.element.style.borderColor = "";
}

proto._box_onchange = function()
{
	var jsObject = CNUtil.dispatchObject();
	// Grid support.
	if(jsObject) jsObject.box_onchange();
}
proto.box_onchange = function()
{
	this._isDirty = true;
}

proto._element_onfocusout = function()
{
	var jso = CNUtil.dispatchObject()
	if(jso && jso.element_onfocusout) jso.element_onfocusout();
}
proto.element_onfocusout = function()
{
	if(this._disabled) return;
	if(this.element.contains(Event.current().relatedTarget)) return;
	if(this.onfocusout) this.onfocusout();
}


// Properties. =====================
proto.get_values = function()
{
	var values = [];
	var boxes = this.element.getElementsByTagName("input");
	for(var i = 0; i < boxes.length; i++) values.push(boxes[i].value);
	return values;
}

// Used by grid BoxManager.
proto.get_value = function()
{
	var boxes = this.element.getElementsByTagName("input");	
	var value = "";
	if(!isNaN(parseInt(boxes[0].value, 10))) value += boxes[0].value;
	value += "/";
	if(!isNaN(parseInt(boxes[1].value, 10))) value += boxes[1].value;
	value += "/";
	if(!isNaN(parseInt(boxes[2].value, 10))) value += boxes[2].value;
	if(value == "//") return "";
	return value;
}

// Used by grid BoxManager.
proto.set_value = function(val)
{
	var boxes = this.element.getElementsByTagName("input");	
	var values = val.split("/");
	for(var i = 0; i < values.length && i < 3; i++) boxes[i].value = values[i]; 
	for(var i = values.length; i < 3; i++) boxes[i].value = ""; 
}

// Used by grid BoxManager.
proto.set_readOnly = function(value)
{
	this._readOnly = value;
	this._set_disabled();
}

// Used by grid BoxManager.
proto.get_readOnly = function()
{
	return this._readOnly;
}

proto.set_disabled = function(val)
{
	if(val) this._set_tabIndex(-1);
	else if(this._tabIndex) this._set_tabIndex(this._tabIndex);
	this._disabled = val
	this._set_disabled();		
}
proto._set_disabled = function()
{
	var val = this._readOnly || this._disabled;
	var boxes = this.element.getElementsByTagName("input");	
	if(CNFormManager.vista) 
	{
		this.element.className = val ? "cn_partialdatebox cn_partialdatebox_disabled" : "cn_partialdatebox";
		for(var i = 0; i < 3; i++) 
		{
			boxes[i].readOnly = val;
		}
	}
	else 
	{
		this.element.style.backgroundColor = val ? Util.getStyle(this.element, "xl--disabled-background") : "";
		for(var i = 0; i < 3; i++) 
		{
			boxes[i].readOnly = val;
			boxes[i].style.backgroundColor =  val ? Util.getStyle(this.element, "xl--disabled-background") : "";
		}
	}
}
 
proto.set_tabIndex = function(ti)
{
	this._tabIndex = ti;
	this._set_tabIndex(ti);
}

proto._set_tabIndex = function(ti)
{
	var boxes = this.element.getElementsByTagName("input");	
	for(var i = 0; i < 3; i++) 
	{
		boxes[i].tabIndex = ti;
	}
}

// Grid support. =======================================
var PartialDateBoxCell = CN_grid.CellTypes["PartialDateBox"] = function(colTag, grid)
{
	this.box = PartialDateBoxCell._createBox();
	grid._jsObjects.push(this.box.jsObject);
}
PartialDateBoxCell.cn_tagName = "partialdatebox";
PartialDateBoxCell._createBox = function()
{
	var box = new CN_partialdatebox();
	box._inGrid = true;
	var l = box.createElement();
	l.style.position = "absolute";
	
//	Event.add(l, "keydown", this, CN_grid.proxyTabKeyDown);

	EditorBoxManager.attachBoxEvents(l);
	return l;
}
var wp = PartialDateBoxCell.prototype;
// Used by BoxManager.
wp.getCellValue = StringTypeCell.prototype.getCellValue;
// Used by commitChange.
wp.setCellValue = StringTypeCell.prototype.setCellValue;
wp.render = StringTypeCell.prototype.render;
// Used by Grid.
wp.isValid = function(cell)
{ 
	// Called when data is submitted, for all cells.

	var value = this.getCellValue(cell);
	if(value == "" && !cell.colTag.canBeEmpty) return false; // #1076

	return this.box.jsObject.isValid();
}
// Used by BoxManager.
wp.validateValue = function(value, cell)
{
	// NOTE: Value and cell is not used -> box content is checked. Actually, BoxManager
	// always checks box value.
	return this.box.jsObject.isValid();
}
// Used by BoxManager.
wp.commitChange = function(value, cell, row, colTag)
{
	if(cell.firstChild.textContent != value)
	{
		if(value == "" || value.replace(/\s+/g, "") == "///") cell.firstChild.textContent = " ";
		else cell.firstChild.textContent = value;
		
		if(value != "")
		{		
			var ymd = value.split("/");
			if(ymd[2].length > 0) ymd[2] = CNUtil.padString(ymd[2], "0", 4);
			if(ymd[1].length > 0) ymd[1] = CNUtil.padString(ymd[1], "0", 2);
			if(ymd[0].length > 0) ymd[0] = CNUtil.padString(ymd[0], "0", 2);
			value = ymd[2] + ymd[1] + ymd[0];
		}
		var grid = CNUtil.findJSObject(cell);
		grid.setChangedValue(row, cell, value);
		grid.fireChangedEvent(row, cell, value);
		if(cell.colTag.autoPostBack) grid.postBack(row, cell, value);
	}
}
wp.prerender = function(cell, colTag)
{
	EditorBoxManager.attachCellEvents(cell);
}

/*
	v. 2.0.1
*/
function CN_rangebox()
{
	this._isDirty = false;
	this._readOnly = false;
	this._disabled = false;
	this.validationString = null;
	
	// Grid support.
	this.directlyAssignEvents = true;
	this.doNotCheckValidChars = true;
	this._type = CN_rangebox.INT_TYPE;
	
	this._lastValidValue1 = '';
	this._lastValidValue2 = '';

	this.supportsRequired = true;
}
CN_rangebox.DECIMAL_TYPE = 1;
CN_rangebox.INT_TYPE = 0;

var proto = CN_rangebox.prototype; 

// Events. =========================
proto.onfocusout = function(){}
proto.onkeypress = function(){}

// Public methods. ================================
proto.createElement = function(node, parentElement)
{
	var l = document.createElement("table");
	l.cellPadding = 0;
	l.cellSpacing = 0;
	l.border = 0;
	// Grid support.
	if(parentElement) parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;
	
	l.className = "cn_rangebox";
	
	var boxType = CN_intbox;
	if(node.getAttribute("type") == "decimal")
	{
		this._type = CN_rangebox.DECIMAL_TYPE;
		boxType = CN_decimalbox;
		this.validationString = "Invalid Decimal Range";
	}
	else
	{
		this.validationString = "Invalid Integer Range";
	}

	var tr = l.insertRow();
	tr.valign = "middle";
	var td = tr.insertCell();
	td.width = "50%";

	this._box1 = new boxType();
	this._box1._canBeEmpty = true;
	var box1El = this._box1.createElement(node, td);
	box1El.style.width = "100%";
	
	td = tr.insertCell();
	td.width = 7;
	td.align = "center";
	td.noWrap = true;
	td.appendChild(document.createTextNode("-"));

	td = tr.insertCell();
	td.width = "50%";

	this._box2 = new boxType();
	this._box2._canBeEmpty = true;
	var box2El = this._box2.createElement(node, td);
	box2El.style.width = "100%";

	this._box1.onchange = this._box_onchange;
	this._box2.onchange = this._box_onchange;

	Event.add(this.element, "focusout", this, this._element_onfocusout);
	Event.add(this.element, "focusout", this, this._element_ondeactivate);
	Event.add(this.element, "focusin", this, this._element_onactivate);
	
	if(CNFormManager.vista && parentElement) this.attachToTextBox(this.element);
	
	return l;
}
			  
proto.attachToTextBox = function(l)
{
	Event.add(this.element, "mouseenter", this, this._textbox_onmouseenter);
	Event.add(this.element, "mouseleave", this, this._textbox_onmouseleave);
	Event.add(this._box1.element, "focusin", this, this._textbox_onmouseenter);
	Event.add(this._box1.element, "focusout", this, this._textbox_onmouseleave);	
	Event.add(this._box2.element, "focusin", this, this._textbox_onmouseenter);
	Event.add(this._box2.element, "focusout", this, this._textbox_onmouseleave);	
}
proto._textbox_onmouseenter = function()
{
	var l = Util.findByClassName(Util.eventTarget(), "cn_rangebox");
	var jso = l.jsObject;
	if(jso._disabled || jso._readOnly) return;
	if(jso._anim) Animator.stop(jso._anim);
	jso.element.style.borderColor =  "#B5CFE7"; 
	jso.element.style.borderTopColor = "#3D7BAD";
}
proto._textbox_onmouseleave = function()
{
	var l = Util.findByClassName(Util.eventTarget(), "cn_rangebox");
	var jso = l.jsObject;
	if(jso._disabled || jso._readOnly || jso.element.contains(document.activeElement)) return;
	Animator.start(jso._anim = new AnimVistaBoxFadeout(jso.element));
}


proto.unload = function()
{
	CNFormManager.destroyJSObject(this._box1);
	CNFormManager.destroyJSObject(this._box2);
	this._box1 = null;
	this._box2 = null;
}

proto.loadData = function(node)
{
	this._isDirty = false;

	var attr = node.getAttribute("minValue");
	if(attr != null) this._lastValidValue1 = this._box1.element.value = String(attr);
	attr = node.getAttribute("maxValue");
	if(attr != null) this._lastValidValue2 = this._box2.element.value = String(attr);
}

proto.resetValue = function()
{
	this._isDirty = false;
	this._box1.element.value = this._lastValidValue1;	
	this._box2.element.value = this._lastValidValue2;
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty) return null;
	this._isDirty = false;

	var node = xmldoc.createElement("rangebox");

	node.setAttribute("minValue", this._box1.element.value);
	node.setAttribute("maxValue", this._box2.element.value);

	return node;
}

proto.isValid = function()
{
	var minValue = parseInt(this._box1.element.value, 10);
	var maxValue = parseInt(this._box2.element.value, 10);
	if(!isNaN(minValue) && !isNaN(maxValue)) 
	{
		if(maxValue < minValue 
		|| !this._box1.isValid()
		|| !this._box2.isValid())
		{
			this.element.style.borderColor = "red";
			return false;
		}
	}

	if(this.element.style.borderColor == "red") this.element.style.borderColor = "";
	return true;
}

// Private methods. =================================
proto._tryNextField = CN_partialdatebox.prototype._tryNextField;

proto._moveToNextField = function(box)
{
	var boxes = this.element.getElementsByTagName("input");
	if(box == boxes[0]) boxes[1].focus();
}

proto._moveToPreviousField = function(box)
{
	var boxes = this.element.getElementsByTagName("input");
	if(box == boxes[1]) boxes[0].focus();
}

proto._checkLeftRight = CN_partialdatebox.prototype._checkLeftRight;

// Used by grid BoxManager.
proto.focus = CN_partialdatebox.prototype.focus;

// Used by grid BoxManager.
proto.select = function(){}

// Used by grid BoxManager.
proto.blur = CN_partialdatebox.prototype.blur;


// Used by grid BoxManager.
proto.get_value = function()
{
	return this._box1.element.value + "-" + this._box2.element.value;
}

// Used by grid BoxManager.
proto.set_value = function(val)
{
	var values = val.split("-");
	this._box1.element.value = values[0];
	this._box2.element.value = values[1];
}

// Used by grid BoxManager.
proto.set_readOnly = function(value)
{
	this._readOnly = Util.parseBoolean(value);
	var boxes = this.element.getElementsByTagName("input");	
	var val = this._readOnly || this._disabled;

	this._box1._readOnly = this._box2._readOnly = this._readOnly;
	this._box1._set_disabled();
	this._box2._set_disabled();

	if(CNFormManager.vista)
		this.element.className = val ? "cn_rangebox cn_rangebox_disabled" : "cn_rangebox";
	else 
		this.element.style.backgroundColor = val ? Util.getStyle(this.element, "xl--disabled-background") : "";
}

// Used by grid BoxManager.
proto.get_readOnly = function()
{
	return this._readOnly;
}

proto.set_disabled = function(val)
{
	this._disabled = val
	this._box1.set_disabled(val);
	this._box2.set_disabled(val);

	var val = this._readOnly || this._disabled;
	if(CNFormManager.vista)
		this.element.className = val ? "cn_rangebox cn_rangebox_disabled" : "cn_rangebox";
	else
		this.element.style.backgroundColor =
			this._box1.element.style.borderColor = 
			this._box2.element.style.borderColor = 
				val ? Util.getStyle(this.element, "xl--disabled-background") : "";
}


// Event handlers. =========================
proto._box_onchange = function(ev)
{
	var jsObject = CNUtil.findJSObject(Util.eventTarget(ev).parentElement);
	// Grid support.
	if(jsObject) jsObject.box_onchange();
}
proto.box_onchange = function()
{
	this._isDirty = true;
}

proto._element_ondeactivate = function()
{
	this.element_ondeactivate();
}
proto.element_ondeactivate = function()
{
	if(this.element.contains(Event.current().relatedTarget)) return;
	this.isValid();
}

proto._element_onactivate = function()
{
	this.element_onactivate();
}
proto.element_onactivate = function()
{
	if(this.element.contains(Event.current().relatedTarget)) return;
	if(this.element.style.borderColor == "red") this.element.style.borderColor = "";
}

proto._element_onfocusout = function()
{
	this.element_onfocusout();
}
proto.element_onfocusout = function()
{
	if(this.element.disabled) return;
	if(this.element.contains(Event.current().relatedTarget)) return;
	if(this.onfocusout) this.onfocusout();
}

proto.set_tabIndex = function(ti)
{
	this._box1.element.tabIndex = ti;
	this._box2.element.tabIndex = ti;
}


// Grid support. =======================================
var RangeBoxCell = CN_grid.CellTypes["RangeBox"] = function(colTag, grid)
{
	var node = colTag.node.cloneNode(true);
	node.setAttribute("type", node.getAttribute("boxType"));
	this.box = RangeBoxCell._createBox(node);
	grid._jsObjects.push(this.box);
}
RangeBoxCell.cn_tagName = "rangebox";
RangeBoxCell._createBox = function(node)
{
	var box = new CN_rangebox();
	var l = box.createElement(node);
	l.style.position = "absolute";
	
	EditorBoxManager.attachBoxEvents(l);
	return l;
}
var wp = RangeBoxCell.prototype;
// Used by BoxManager.
wp.getCellValue = StringTypeCell.prototype.getCellValue;
// Used by commitChange.
wp.setCellValue = StringTypeCell.prototype.setCellValue;
// Used by Grid.
wp.isValid = function(cell)
{ 
	// Assume, server always sends correct data and BoxManager disallows invalid data.
	return true;
}
// Used by BoxManager.
wp.validateValue = function(value, cell)
{
	// NOTE: Value and cell is not used -> box content is checked. Actually, BoxManager
	// always checks box value.
	return this.box.jsObject.isValid();
}
// Used by BoxManager.
wp.commitChange = function(value, cell, row, colTag)
{
	if(cell.textContent != value)
	{
		if(value.replace(/\s+/g, "") == "///") cell.textContent = " ";
		else cell.textContent = value;
		
		var grid = CNUtil.findJSObject(cell);
		grid.setChangedValue(row, cell, value);
		grid.fireChangedEvent(row, cell, value);
		if(cell.colTag.autoPostBack) grid.postBack(row, cell, value);
	}
}
wp.prerender = function(cell, colTag)
{
	EditorBoxManager.attachCellEvents(cell);
}
wp.render = StringTypeCell.prototype.render;

/*
	v. 2.0
*/
function CN_dynamicgrid()
{
   	this.formManager = null;
	this._headerHeight = 20;
	this._selectorVisible = true;
	this._clickedRowIndex = -1;
	this._rowBorderOffset = CNFormManager.vista ? 1 : 0;
	this._selectedRow = null;
}

var proto = CN_dynamicgrid.prototype;

proto.createElement = function(node, parentElement)
{
	var l = Util.createElement("div", "cn_dynamicgrid");
	parentElement.appendChild(l);
	l.jsObject = this;
	this.element = l;
	
	Event.add(l, "resize", this, this._element_onresize);

	var captionTable = Util.createElement("table", "captionTable", {width: "100%", border: 0, cellPadding: 0, cellSpacing: 0});
	l.appendChild(captionTable);
	
	var div = Util.createElement("div", "contentDiv");
	l.appendChild(div);
	
	var table = Util.createElement("table", "contentTable", {width: "100%", border: 0, cellPadding: 0, cellSpacing: 0});
	div.appendChild(table);

	if(CNFormManager.vista)
	{
		this._select = VistaSupport.createHover();
		this._select.arcsize = .05;
		var fill = this._select.lastChild;
		fill.type = "gradient";
		fill.color = "#DAF0FC";
		fill.color2 = "#F4FAFD";
		div.appendChild(this._select);
	}
	else
	{
		this._leftBorder = Util.createElement("div", "leftBorder");
		div.appendChild(this._leftBorder);
		this._rightBorder = Util.createElement("div", "rightBorder");
		div.appendChild(this._rightBorder);
		this._topBorder = Util.createElement("div", "topBorder");
		div.appendChild(this._topBorder);
		this._bottomBorder = Util.createElement("div", "bottomBorder");
		div.appendChild(this._bottomBorder);
	}	
	this._disabler = Util.createElement("div");
	this._disabler.style.position = "absolute";
	this._disabler.style.background = "white";
	this._disabler.style.zIndex = 1000;
	this._disabler.style.opacity = "0.5";
	this._disabler.style.width = "100%";
	this._disabler.style.height = "100%";
	this._disabler.style.visibility = "hidden";
	this._disabler.style.top = "0px";
	this._disabler.style.left = "0px";
	this.element.appendChild(this._disabler);
	var attr = node.getAttribute("headerHeight");
	if(attr)
	{
		var headerHeight = parseInt(attr, 10);
		if(!isNaN(headerHeight)) this._headerHeight = headerHeight;
	}
	
	attr = node.getAttribute("selectorVisible");
	if(attr) this._selectorVisible = attr == "true";
	
	return l;
} 

proto.loadData = function(node)
{
	var captionTable = this.element.children[0];
	var table = this.element.children[1].children[0];
	
	this._cleanData(captionTable, table);
	
	captionTable.style.height = this._headerHeight + "px";
	
	var captionTR = captionTable.insertRow();
	if(this._selectorVisible)
	{
		var selectorTD = captionTR.insertCell();
		selectorTD.style.width = 20;
		selectorTD.textContent = " ";
	}
	
	var tBody = document.createElement("tbody");
	table.appendChild(tBody);
	
	var colNodes = Util.xmlSelectNodes(node, "columns/col");
	var colNodeCount = colNodes.length;
	
	var rowMatrix = [];
	var cols = [];
	var lastCaptionTD = null;

	for(var i = 0; i < colNodeCount; i++)
	{
		var colNode = colNodes[i];
		
		var cellNodes = Util.xmlSelectNodes(colNode, "cell");
		var cellNodeCount = cellNodes.length;
		for(var j = 0; j < cellNodeCount; j++)
		{
			if(!rowMatrix[j]) rowMatrix[j] = [];
			rowMatrix[j][i] = cellNodes[j];
		}
		
		var attr;
		
		var captionTD = captionTR.insertCell();
		attr = colNode.getAttribute("caption");
		if(attr) captionTD.textContent = String(attr);
		else captionTD.textContent = " ";

		attr = colNode.getAttribute("captionAlign");
		if(attr) captionTD.align = String(attr);

		var col = {};
		cols[i] = col;
		
		attr = colNode.getAttribute("align");
		if(attr) col.align = String(attr);
		
		attr = colNode.getAttribute("width");
		if(attr)
		{
			var width = parseInt(attr, 10);
			if(!isNaN(width) && width > 0) 
			{
				col.width = width;
				captionTD.width = width;
			}
		}
		lastCaptionTD = captionTD;
	}
	
	if(lastCaptionTD) lastCaptionTD.style.paddingRight = 20; // Scroll bar alignment.
	
	for(var i = 0; i < rowMatrix.length; i++)
	{
		var row = rowMatrix[i];
		if(!row) continue;

		this._buildRow(table, row, cols);
	}
	
	var attr = node.getAttribute("selectedRow");
	if(attr)
	{
		var selectedRow = parseInt(attr, 10);
		if(!isNaN(selectedRow))
		{
			if(selectedRow < 0)	this._rowBorder_unselect();
			else
			{
				var row = table.rows[selectedRow];
				if(row) 
				{
					var obj = this;
					setTimeout(function(){ obj._rowBorder_select(row); }, 0);
				}
			}
		}
	}
	else this._rowBorder_unselect();

	this._setLoadStateTO();
}

proto.storeData = function(xmldoc)
{
	if(this._clickedRowIndex < 0) return;
	
	var node = xmldoc.createElement("dynamicgridselection");
	node.setAttribute("selection", this._clickedRowIndex);
	this._clickedRowIndex = -1;

	return node;
}

proto.unload = function()
{
	this._saveState();
}
	
proto._cleanData = function(captionTable, table)
{
	if(captionTable.rows.length > 0) captionTable.deleteRow(0);
	var count = table.rows.length;
	for(var i = count - 1; i >= 0; i--)
	{
		table.deleteRow(i);
	}
}

proto._buildRow = function(table, row, cols)
{
	var tr = table.insertRow();
	tr.vAlign = "top";
	
	if(this._selectorVisible)
	{
		var selectorTD = tr.insertCell();
		selectorTD.style.width = 20;
		selectorTD.style.cursor = "hand";
		Event.add(selectorTD, "click", this, this._selectorTD_onclick);
		
		var img = Util.createElement("img", null, {width: 16, height: 16});
		selectorTD.appendChild(img);
		img.src = CNFormManager.themeImagesPath + "normalRow.gif";
	}

	for(var i = 0; i < row.length; i++)
	{
		var node = row[i];
		var td = tr.insertCell();

		if(!node) 
		{
			td.textContent = " ";
			continue;
		}
		
		td.textContent = String(node.getAttribute("value"));

		var col = cols[i];

		if(col.align) td.align = col.align;
		if(col.width) td.width = col.width;
	}
}

proto._setLoadStateTO = function()
{
	var obj = this;
	setTimeout(function(){ obj._loadState(); }, 0);
}

proto._loadState = function()
{
	if(!this.element || !this.element.id) return;
	var state = this._readState();
	if(state)
	{
		var contentDiv = this.element.children[1];
		contentDiv.scrollTop = Number(state.scrollTop) || 0;
		contentDiv.scrollLeft = Number(state.scrollLeft) || 0;
	}
}

proto._stateKey = function()
{
	return "cn_dynamicgrid:" + this.element.id;
}

proto._readState = function()
{
	try
	{
		var storage = window.sessionStorage || window.localStorage;
		var value = storage && storage.getItem(this._stateKey());
		return value ? JSON.parse(value) : null;
	}
	catch(ex) { return null; }
}

proto._saveState = function()
{
	if(!this.element.id) return;
	var contentDiv = this.element.children[1];
	try
	{
		var storage = window.sessionStorage || window.localStorage;
		if(storage) storage.setItem(this._stateKey(), JSON.stringify({
			scrollTop: contentDiv.scrollTop || 0,
			scrollLeft: contentDiv.scrollLeft || 0
		}));
	}
	catch(ex) {}
}

proto._rowBorder_select = function(row)
{
	this._selectedRow = row;
	
	if(CNFormManager.vista)
	{
		this._select.style.width = row.offsetWidth - 3;
		this._select.style.height = row.offsetHeight - 2;
		this._select.style.top = row.offsetTop + 1;
		this._select.style.left = row.offsetLeft + 1;
		this._select.style.visibility = "inherit";
	}
	else
	{
		var x = row.offsetLeft;
		var y = row.offsetTop;
	
		this._leftBorder.style.left = x + this._rowBorderOffset;
		this._leftBorder.style.top = y + this._rowBorderOffset;
		this._leftBorder.style.height = row.offsetHeight - this._rowBorderOffset * 2;
		
		this._topBorder.style.left = x + this._rowBorderOffset * 2;
		this._topBorder.style.top = y;
	
		this._rightBorder.style.top = y + this._rowBorderOffset;
		this._rightBorder.style.height = row.offsetHeight - this._rowBorderOffset * 2;
	
		this._bottomBorder.style.left = x + this._rowBorderOffset * 2;
		this._bottomBorder.style.top = y + row.offsetHeight - this._bottomBorder.offsetHeight;
	
		this._rightBorder.style.visibility = 
		this._topBorder.style.visibility =
		this._leftBorder.style.visibility = this._bottomBorder.style.visibility = "inherit";
		
		this._rightBorder.style.zIndex = 
		this._topBorder.style.zIndex =
		this._leftBorder.style.zIndex = this._bottomBorder.style.zIndex = top.__ontopZ++
		
		this.rowBorder_updateSize(row);
	}
}

proto.rowBorder_updateSize = function(row)
{
	if(CNFormManager.vista)
	{
		this._select.style.width = row.offsetWidth - 3;
	}
	else
	{
		this._rightBorder.style.left = row.clientWidth - this._rightBorder.offsetWidth + "px";
		this._topBorder.style.width = this._bottomBorder.style.width = row.offsetWidth + "px";
	}
}

proto._rowBorder_unselect = function()
{
	if(this._selectedRow && CNFormManager.vista) 
	{
		this._select.style.visibility = "hidden";
	}
	else
	{
		this._rightBorder.style.visibility =
		this._topBorder.style.visibility =
		this._leftBorder.style.visibility =
		this._bottomBorder.style.visibility = "hidden";
	}
	this._selectedRow = null;
}


// Properties. ========================
proto.set_disabled = function(value)
{
	this._disabled = value;
	this._disabler.style.visibility = this._disabled ? "inherit" : "hidden";
}


// Event handlers. ======================
proto._element_onresize = function()
{
	CNUtil.dispatchObject().element_onresize();
}
proto.element_onresize = function()
{
	var captionTable = this.element.children[0];
	var contentDiv = this.element.children[1];
	var table = contentDiv.children[0];
	
	if(!captionTable.offsetHeight) return;

	//var h = parseInt(Util.getStyle(this.element, "height"), 10);
	//if(!isNaN(h)) contentDiv.style.height = h - captionTable.offsetHeight;
	if(this._selectedRow) this.rowBorder_updateSize(this._selectedRow);
}

proto._selectorTD_onclick = function()
{
	CNUtil.dispatchObject().selectorTD_onclick();
}
proto.selectorTD_onclick = function(nativeEvent)
{
	var ev = Event.normalize(nativeEvent) || Event.current();
	var tr = CNUtil.findTag(ev && ev.target, "TR");
	if(!tr) return;
	this._rowBorder_unselect();
	this._rowBorder_select(tr);
	
	this._clickedRowIndex = tr.rowIndex;
	this.formManager.postData(this.element);
}

/* Standards-port boundary for the historical VML drawing configuration control. */
function CN_drawingconfigcontrol() {
  this._disabled = false;
  this._unsupported = true;
  this.initiateUpload = false;
}
var proto = CN_drawingconfigcontrol.prototype;
proto.createElement = function(node, parentElement) {
  var element = Util.createElement("div", "cn_drawingconfigcontrol cn_unsupported_feature");
  element.jsObject = this;
  element.setAttribute("role", "status");
  element.textContent = "Drawing configuration is unavailable in the standards Client Framework.";
  parentElement.appendChild(element);
  this.element = element;
  Util.reportUnsupported("CN_drawingconfigcontrol", "VML drawing configuration", "Requires an SVG/canvas model and standards context menu/editor");
  return element;
};
proto.loadData = function() { Util.reportUnsupported("CN_drawingconfigcontrol", "VML drawing configuration"); };
proto.storeData = function() { return null; };
proto.unload = function() {};
proto.set_disabled = function(value) { this._disabled = !!value; if(this.element) this.element.setAttribute("aria-disabled", String(this._disabled)); };

/* Standards-port boundary for the historical VML floor planner. */
function CN_floorplanner() {
  this._disabled = false;
  this._unsupported = true;
  this.initiateUpload = false;
}
var proto = CN_floorplanner.prototype;
proto.createElement = function(node, parentElement) {
  var element = Util.createElement("div", "cn_floorplanner cn_unsupported_feature");
  element.jsObject = this;
  element.setAttribute("role", "status");
  element.textContent = "Floor planning is unavailable in the standards Client Framework.";
  parentElement.appendChild(element);
  this.element = element;
  Util.reportUnsupported("CN_floorplanner", "VML floor planning", "Requires an SVG/canvas renderer, geometry model and pointer interaction rewrite");
  return element;
};
proto.loadData = function() { Util.reportUnsupported("CN_floorplanner", "VML floor planning"); };
proto.storeData = function() { return null; };
proto.unload = function() {};
proto.set_disabled = function(value) { this._disabled = !!value; if(this.element) this.element.setAttribute("aria-disabled", String(this._disabled)); };
function CNList(parentElement) {
  this.element = Util.createElement("div", "cn_floorplanner_list");
  if(parentElement) parentElement.appendChild(this.element);
}

/* Standards-port boundary for the historical VML bed planner. */
function CN_bedplanner() {
  this._disabled = false;
  this._unsupported = true;
  this.initiateUpload = false;
}
var proto = CN_bedplanner.prototype;
proto.createElement = function(node, parentElement) {
  var element = Util.createElement("div", "cn_bedplanner cn_unsupported_feature");
  element.jsObject = this;
  element.setAttribute("role", "status");
  element.textContent = "Bed planning is unavailable in the standards Client Framework.";
  parentElement.appendChild(element);
  this.element = element;
  Util.reportUnsupported("CN_bedplanner", "VML bed planning", "Requires an SVG/canvas renderer and standards bed geometry");
  return element;
};
proto.loadData = function() { Util.reportUnsupported("CN_bedplanner", "VML bed planning"); };
proto.storeData = function() { return null; };
proto.unload = function() {};
proto.set_disabled = function(value) { this._disabled = !!value; if(this.element) this.element.setAttribute("aria-disabled", String(this._disabled)); };

/* Standards-port boundary for the historical VML graphing control. */
function CN_graphingcontrol() {
  this._disabled = false;
  this._unsupported = true;
  this.initiateUpload = false;
}
var proto = CN_graphingcontrol.prototype;
proto.createElement = function(node, parentElement) {
  var element = Util.createElement("div", "cn_graphingcontrol cn_unsupported_feature");
  element.jsObject = this;
  element.setAttribute("role", "status");
  element.textContent = "Graph rendering is unavailable in the standards Client Framework.";
  parentElement.appendChild(element);
  this.element = element;
  Util.reportUnsupported("CN_graphingcontrol", "VML graph rendering", "Requires an SVG/canvas chart renderer");
  return element;
};
proto.loadData = function() { Util.reportUnsupported("CN_graphingcontrol", "VML graph rendering"); };
proto.storeData = function() { return null; };
proto.unload = function() {};
proto.set_disabled = function(value) { this._disabled = !!value; if(this.element) this.element.setAttribute("aria-disabled", String(this._disabled)); };

/*
	v. 2.0.4
	+ Grid 2.85
	+ ...
	+ FixedString
	+ isTree support.
	+ selectedRow => row.id support
	+ ...
	+ initial release.
*/

function CN_dynamicgrid2()
{
	this.base = CN_grid;
	this.base();
	this._tagPrefix = "dynamicgrid2";
	this._clonedNode = null;
	this._clonedRowsNode = null;
	this._isTreeGrid = false;
}
CN_dynamicgrid2.prototype = new CN_grid();
var proto = CN_dynamicgrid2.prototype;

// Override.
proto.grid_prebuildTable = proto.prebuildTable;
proto.prebuildTable = function(node)
{
	// Do nothing.
}

// Override.
proto.grid_loadData = proto.loadData;
proto.loadData = function(node)
{
	//this._oldRowsDivWidth = 0; // Reset column widths flag.
	var attr = node.getAttribute("isTree");
	if(attr == "true")
	{
		this.tree_init(node);
		this._isTreeGrid = true;
	}
	else if(attr == "false") 
	{
		this._isTreeGrid = false;
		this.tree_inited = false
	}

	var changeHeaderSelector = false;
	var changeRowsSelector = false;
	var attr = node.getAttribute("selectorVisible");
	if(attr)
	{
		var oldValue = this._selectorVisible;
		this._selectorVisible = attr == "true";
		if(oldValue != this._selectorVisible) 
		{
			changeHeaderSelector = changeRowsSelector = true;
		}
	}

	this._resetScrollPosition = node.getAttribute("resetScrollPosition") == "true";
	if(this._resetScrollPosition) this.rowsDiv.scrollTop = 0;

	var cols = Util.xmlSelectNodes(node, "col");
	var noColsNode = Util.xmlSelectSingleNode(node, "cols");
	if(cols.length > 0 || changeHeaderSelector || noColsNode)
	{
		// Store cols.
		if(cols.length > 0 || noColsNode) this._clonedNode = node.cloneNode(true);
		this.cleanCols();
		if(this._clonedNode) this.grid_prebuildTable(this._clonedNode);
	}

	attr = node.getAttribute("treeAutoPostBack");
	if(attr) this._treeAutoPostBack = attr == "true";

	attr = node.getAttribute("readOnly");
	if(attr) this.set_readOnly(attr == "true");

	var idAttr = node.getAttribute("selectedRowID");
	var id;
	if(idAttr) id = String(idAttr)

	attr = node.getAttribute("allowClearSelection");
	if(attr) this._allowClearSelection = attr == "true";

	this._resizeColumns(); // Fast pass on just template/header.

	var rows = Util.xmlSelectSingleNode(node, "rows");
	if(rows || changeRowsSelector) 
	{
		// Store rows.
		if(rows) 
		{
			this._clonedRowsNode = rows.cloneNode(true);
		
			// Reset selection if no rows arrived.
			if(!this._clonedRowsNode.hasChildNodes && !id) this._pendingSelectedRow = -1;
		}
						
		this.cleanTable();
		if(id !== undefined) this._pendingSelectedRow = id;
		if(rows) this.fillTable(this._clonedRowsNode);
	}
	else if(idAttr) this.set_selectedRow(id);
	
	this._loadHeader(node);
	this._loadFooter(node);	
}

proto.set_selectedRow = function(value)
{
	if(value != "-1")
	{
		var row = this.rowsDiv.querySelector("#row" + value);
		if(!row) return;
		this._selectedRow = row.rowIndex;
		this._selectedRowDiv = row;
	}
	else
	{
		this._selectedRow = -1
		this._selectedRowDiv = null;
	}

	if(!this.isReady) return;
	
	this._set_selectedRow();
}

proto._set_selectedRow = function()
{
	if(this._selectedRow == -1) this.deselectRow();
	else if(this._selectedRowDiv)
	{
		this.selectRow(this._selectedRowDiv)
		if(this.alwaysScrollToSelected) 
		{
			this.rowsDiv.scrollTop = this._selectedRowDiv.offsetTop;
		}
	}
	else 
	{
		this.deselectRow();
	}
}

// Override.
proto._filterSelectionData = function(selectionData)
{
	if(this._selectedRowDiv && this._selectedRow != -1) 
	{
		var id = this._selectedRowDiv.id;
		selectionData.setAttribute("selectedRowID", id.substr(3)); // cut 'row' prefix.
	}
}

// Override.
proto.grid_selectRow = proto.selectRow;
proto.selectRow = function(l, doNotFireEvent)
{
	if(!l.isSelectable) return;

	this.grid_selectRow(l, doNotFireEvent);
	
	this._selectedRowDiv = l;
}

proto._setSelectorIterator = function(parent, display)
{
	// Change selector for other nodes.
	var rows = parent.children;
	var count = rows.length;
	for(var i = count - 1; i >= 0; i--)
	{
		var row = rows[i];
		if(row.isNodeContainer)
		{
			this._setSelectorIterator(row, display);
		}
		else if(row.rowIndex !== undefined)
		{
			row.children[0].style.display = display;
		}
	}
}

proto.cleanCols = function()
{
	CNUtil.cleanElement(this.headerRow);
	CNUtil.cleanElement(this.templateRow);	
	CNUtil.cleanElement(this.folderTemplateRow);	
}

 // Override.			
proto.appendRow = function(rowNode, parent, parentRowIndex, tree_level, tree_index, tree_type)
{
	var row = this.templateRow.cloneNode(true);
	parent.appendChild(row);
	
	var attr = rowNode.getAttribute("id");
	if(attr) row.id = "row" + attr;
	this.setCommonRowProperties(row, rowNode, parentRowIndex);

	var cells = row.children;
	var cellNodes = rowNode.childNodes;
	var cellNodesCount = cellNodes.length;

	// Render cells.
	for(var i = 0, j = 0; i < cellNodesCount; i++)
	{
		var cellNode = cellNodes[i];
		if(cellNode.nodeType != 1) continue;
		var cell = cells[j + this.startDataCell];
		cell.cellIndex = j;
		
		var colTag = this.colTags[j];
		var clonedColTag = cell.colTag = CNUtil.cloneObject(colTag);
		
		var colNode = cellNode;

		this._setCommonCellFeatures(cell, cellNode, clonedColTag);
		
		if(this._isTreeGrid && j == 0)
		{
			// First column always contains treenode.
			var nodeDiv = this.tree_buildNodeTemplate(row);
			nodeDiv.style.position = "absolute";
			nodeDiv.style.left = this._selectorVisible ? 20 : 0;
			nodeDiv.style.top = 0;
			this.tree_buildNode(nodeDiv, cell, cellNode, tree_level, tree_index, tree_type);
			clonedColTag.autoPostBack = this._treeAutoPostBack;
		}

		if(cellNode.getAttribute("empty") != "true")
		{
			var renderer = CN_grid.CellTypes[clonedColTag.type];
			if(!renderer) renderer = UnknownTypeCell;
			var renderer = new renderer(clonedColTag, this);
			clonedColTag.typeObject = renderer;
			
			if(!this._requiresReadOnlyWalk && renderer.set_readOnly)
			{
				this._requiresReadOnlyWalk = true;
			}

			var editorBox = cellNode.getAttribute("showEditorRectangle") == "always";
			if(editorBox) cell._showEditorRectangle = true;
			
			renderer.prerender(cell, clonedColTag);
			renderer.render(cell, cellNode, tree_level, tree_index, tree_type);
			
			if(editorBox && !renderer.noDefaultStaticRectangle) this._createCellEditBorder(cell);
		}
		else
		{
			cell._isEmpty = true;
		}
		j++;
	}
}

// Override.
proto.appendFolderRow = function(rowNode, childRows, parent, parentRowIndex, tree_level, tree_index, tree_type)
{
	var cellNodes = rowNode.childNodes;
	var cellNodesCount = cellNodes.length;
	
	var row;
	if(cellNodesCount > 1) row = this.templateRow.cloneNode(true);
	else row = this.folderTemplateRow.cloneNode(true);
	parent.appendChild(row);
	
	var attr = rowNode.getAttribute("id");
	if(attr) row.id = "row" + attr;
	this.setCommonRowProperties(row, rowNode, parentRowIndex);

	var cells = row.children;

	var childNodeType = tree_type;
	var childType = rowNode.getAttribute("childType");
	if(childType)
	{
		var type = this.tree_nodeTypes[String(childType)];
		// NOTE: completely new type, based on chilttype name.
		if(type) childNodeType = type;
	}

	if(childRows != null) rowNode.setAttribute("expandable", "true");

	var expanded = false;
	if(this._isTreeGrid && rowNode.getAttribute("expanded") != "false") expanded = true;

	// Render cells.
	for(var i = 0, j = 0; i < cellNodesCount; i++)
	{
		var cellNode = cellNodes[i];
		if(cellNode.nodeType != 1) continue;
		
		if(cellNode.tagName == "c")
		{
			var cell = cells[j + this.startDataCell];
			if(!cell) 
			{
				alert("ASSERT: !cell");
				continue;
			}

			if(this._isTreeGrid && j == 0)
			{
				// First column always contains treenode.
				var nodeDiv = this.tree_buildNodeTemplate(row);
				nodeDiv.style.position = "absolute";
				nodeDiv.style.left = this._selectorVisible ? 20 : 0;
				nodeDiv.style.top = 0;
				this.tree_buildNode(nodeDiv, cell, cellNode, tree_level, tree_index, tree_type);
				//cell.style.paddingLeft = nodeDiv.offsetWidth;
			}

			if(cellNode.getAttribute("empty") != "true")
			{
				
				cell.cellIndex = j;
				var colTag = this.colTags[j];
				var clonedColTag = cell.colTag = CNUtil.cloneObject(colTag);
	
				this._setCommonCellFeatures(cell, cellNode, clonedColTag);

				var renderer = CN_grid.CellTypes[clonedColTag.type];
				if(!renderer) renderer = UnknownTypeCell;
				var renderer = new renderer(clonedColTag, this);
				clonedColTag.typeObject = renderer;
				
				renderer.prerender(cell, clonedColTag);
				renderer.render(cell, cellNode, tree_level, tree_index, tree_type);
			}
			else
			{
				cell._isEmpty = true;
			}
			j++;
		}
		else if(cellNode.tagName == "childRows")
		{
			var containerDiv = document.createElement("div");
			parent.appendChild(containerDiv);
			
			containerDiv.style.display = expanded ? "block" : "none";
			containerDiv.isNodeContainer = true;
			containerDiv.nodesBuilt = true;

			var childRows = cellNode.childNodes;
			var childRowCount = childRows.length;
			for(var k = 0, n = 0; k < childRowCount; k++)
			{
				var childRow = childRows[k];
				if(cellNode.nodeType != 1 || childRow.tagName != "r")
				{
					alert("ASSERT: cellNode.nodeType != 1 || childRow.tagName != 'r'");
					continue;
				}
				
				this.appendAnyRow(childRow, containerDiv, row.rowIndex, tree_level + 1, n, tree_type);
				n++;
			}
		}
	}
}

proto._getNodeWidth = function(level)
{
	return 18 + (level + 1) * 21;
}

proto._setCommonCellFeatures = function(cell, cellNode, clonedColTag)
{
	this._updateColTag(cellNode, clonedColTag);

	var attr = cellNode.getAttribute("backcolor");
	if(attr) cell.style.backgroundColor = String(attr);
	attr = cellNode.getAttribute("textcolor");
	if(attr) cell.style.color = String(attr);

	attr = cellNode.getAttribute("width");
	if(attr && attr != "-1") 
	{
		cell.style.width = attr + "px";
		if(clonedColTag.fixedWidth)
		{
			delete clonedColTag.widthRatio;
		}
		else
		{
			clonedColTag.widthRatio = parseInt(attr, 10) / this._elementWidth;		
		}
	}
	else
	{
		delete clonedColTag.widthRatio;
	}

	this._setTooltip(cellNode, cell);
	
	if(clonedColTag.fixedFont) cell.style.fontFamily = "Courier New";
}

proto._updateColTag = function(colNode, clonedColTag)
{
	// Coltag related stuff.
	var readOnly = colNode.getAttribute("readOnly") == "true";
	var autoPostBack = colNode.getAttribute("autoPostBack") == "true";
	var canBeEmpty = colNode.getAttribute("canBeEmpty") != "false";
	
	var align = this._getAttribute(colNode, "align");
	var width = this._getAttribute(colNode, "width");
	var captionAlign = this._getAttribute(colNode, "captionAlign");
	var validationString = this._getAttribute(colNode, "validationString");
	var fixedWidthAttr = colNode.getAttribute("fixedWidth");
	if(fixedWidthAttr) clonedColTag.fixedWidth =  fixedWidthAttr == "true";
	clonedColTag.readOnly = readOnly;
	clonedColTag.autoPostBack = autoPostBack;
	clonedColTag.canBeEmpty = canBeEmpty;
	clonedColTag.align = align;
	clonedColTag.width = width;
	clonedColTag.fixedFont = this._getAttribute(colNode, "fixedFont") == "true";
	clonedColTag.bold = colNode.getAttribute("bold") == "true";
	clonedColTag.node = colNode;
	clonedColTag.validationString = validationString;
	clonedColTag.type = this._getAttribute(colNode, "type");

	// Use mutable only.
	if(clonedColTag.type == 'ComboBox') clonedColTag.type = 'MutableComboBox';
	if(clonedColTag.type == 'AnswerBox') clonedColTag.type = 'MutableAnswerBox';
}

// Override.
proto.isCellValid = function(cell)
{
	if(cell._isEmpty) return true;
	if(!cell.colTag) return true; // Tree node div.
	return cell.colTag.typeObject.isValid(cell);
}

// Override.
proto.tree_selectNodeDiv = function(l)
{
	if(!l) return;
	var l = l.parentElement.parentElement.lastChild;
	if(this.tree_selectedNodeDiv == l) return;
	
	this.tree_unselectNodeDiv();
	l.className = "nodeDivSelected";
	this.tree_selectedNodeDiv = l;
	this.tree_updateImage(l);
}

// Override
proto.tree_getContainerForNodeDiv = function(nodeDiv)
{
	return nodeDiv.parentElement.nextSibling;
}

// Override.
proto.tree_buildNode = function(nodeDiv, cell, node, level, index, nodeType)
{
	if(node.parentNode.tagName != "r") alert("Assert for r tag.")

	node.parentNode.setAttribute("nodeIndex", index);
	nodeDiv.node = node; // Watch for circular refs!
	nodeDiv.nodeLevel = level;
	node.setAttribute("nodeLevel", level);

	var children = nodeDiv.children;

	if(node.getAttribute("disable") == "true") nodeDiv.disabled = true; 
	
	var realType = nodeType;

	var rowNode = node.parentNode;
	var type = rowNode.getAttribute("type");
	if(type)
	{
		var type = this.tree_nodeTypes[String(type)];
		if(type) realType = this.tree_getOverridenTypeObject(realType, type);
	}
	realType = this.tree_getOverridenTypeObject(realType, rowNode);
	nodeDiv.type = realType;
	
	this.tree_buildLine(nodeDiv, node, children[this.ix_lineSpan], level);
	this.tree_buildPM(node, children[this.ix_plusMinusSpan], level);

	//children[this.ix_textSpan].textContent = String(Util.xmlText(node));
	
	var expanded = this.tree_isExpanded(node);
	this.tree_updateImageToState(nodeDiv, expanded ? this.state_expanded : this.state_default);

	var padding = this._getNodeWidth(level);
	if(this.tree_buildNodeCheckbox(node, children, realType))
	{
		padding += 16;
	}	
	
	cell.style.paddingLeft = padding;
}


proto._grid_resizeColumns = proto._resizeColumns;
proto._resizeColumns = function()
{
	this._grid_resizeColumns();
}

proto._resizeRows = function(rowsDiv, colWidth, ix, rowsDivWidth, firstRowIndex)
{
	var startRowIndex = 0;
	if(!rowsDiv.isNodeContainer) startRowIndex = firstRowIndex;

	var children = rowsDiv.children;
	var length = children.length;
	for(var j = startRowIndex; j < length; j++)
	{
		var row = children[j];
		if(row.isNodeContainer)
		{
			this._resizeRows(row, colWidth, ix, rowsDivWidth, firstRowIndex);
		}
		else if(row.className == "rowDiv")
		{
			// Check cell, as we can get missing cell in treegrid.
			var cell = row.children[this.startDataCell + ix];
			if(cell) 
			{
				if(cell.colTag && cell.colTag.widthRatio && !cell.colTag.fixedWidth)
				{
					cell.style.width = cell.colTag.widthRatio * rowsDivWidth;
				}
				else
				{
					cell.style.width = colWidth;
				}
			}
		}
	}
}

proto._createCellEditBorder = function(cell)
{
	var l = Util.createElementFromHTML("<div class=cellHoverBorderDiv>");
	cell.appendChild(l);
	EditorBoxManager._setHoverBorderStyle(l, cell);
	l.style.width = "100%";
}


var FixedStringTypeCell = CN_grid.CellTypes["FixedString"] = function(colTag, grid)
{
	this.box = StringTypeCell.createBox();
	this._grid = grid;
}
FixedStringTypeCell.cn_tagName = "textbox";

var wp = FixedStringTypeCell.prototype;
var swp = StringTypeCell.prototype;
wp.getCellValue = swp.getCellValue;
wp.setCellValue = swp.setCellValue;
wp.isValid = swp.isValid;
wp.validateValue = swp.validateValue;
wp.commitChange = swp.commitChange;
wp.prerender = swp.prerender;
wp.render = function(cell, node)
{
	cell.style.width = "auto";
	var span = document.createElement("span");
	span.appendChild(document.createTextNode(Util.xmlText(node)));
	cell.appendChild(span);
	cell.colTag.widthRatio = cell.colTag.width / this._grid._elementWidth;
	cell.style.width = cell.colTag.width;
}


// Grid support. ====================================================
var TableCell = CN_grid.CellTypes["Table"] = function(colTag)
{
}
TableCell.cn_tagName = "table";

var wp = TableCell.prototype;

wp.box_onclick = function()
{
	var cell = CN_grid.findCell(CNUtil.eventTarget());			
		
	var cellTD = CNUtil.eventTarget().parentElement;
	if (CNUtil.eventTarget().parentElement.getAttribute("id"))
	{
		cell.setAttribute("tableCellId", CNUtil.eventTarget().parentElement.getAttribute("id"));
	}
	var cellTR = cellTD.parentElement;	
	if (cellTD.parentElement.getAttribute("id"))
	{
		cell.setAttribute("tableRowId", cellTD.parentElement.getAttribute("id"));
	}
	
	var jsObject = CNUtil.findJSObject(cell);
	if(jsObject._disabled) return;
	
	var row = cell.parentElement;
	var jsObject = CNUtil.findJSObject(cell);
	jsObject.setChangedValue(row, cell, null);
	jsObject.fireChangedEvent(row, cell, null);
	//if(cell.colTag.autoPostBack)
	jsObject.postBack(row, cell, null);
}

wp.isValid = function(cell)
{
	return true; 
}

wp.prerender = function(cell, colTag)
{
	var jsObject = CNUtil.findJSObject(cell);

	//cell.style.paddingTop = 0;
	cell.style.padding = "0.25em";
	
	var tableNodesCount = cell.colTag.node.childNodes[0];
	
	//Create TABLE element
	var table  = document.createElement("table");
		table.setAttribute("border",cell.colTag.node.childNodes[0].getAttribute("border") ? cell.colTag.node.childNodes[0].getAttribute("border") : 0); 
		table.setAttribute("cellspacing","0") 
		table.setAttribute("bgcolor","#E0ECF8") 
		table.setAttribute("cellpadding","0") 
		table.style.width = "100%";		
		table.style.wordWrap = "break-word";
		table.style.borderCollapse = "collapse";	
		table.style.tableLayout = "fixed";		
	
	//Create COL element	
	var col = document.createElement("col");
		col.style.width = "100%";		
    
	//Set TABLE element style
	var tb = document.createElement("tbody");
	
	//TR level
	var trNodesCount = cell.colTag.node.childNodes[0].childNodes.length;
	for(var i = 0; i < trNodesCount; i++)
	{
		//cell.colTag.node.childNodes[i]
		var tr = document.createElement("tr");
			tr.setAttribute("id", cell.colTag.node.childNodes[0].childNodes[i].getAttribute("id"));	
		
		//TD level	
		var tdNodesCount = cell.colTag.node.childNodes[0].childNodes[i].childNodes.length;
		for(var j = 0; j < tdNodesCount; j++)
		{
			//cell.colTag.node.childNodes[i].childNodes[j]
			var td = document.createElement("td");				
				td.setAttribute("id", cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("id"));	
			
			td.style.borderWidth = "0px";
			td.style.padding = "0px";
			
			//Attributes			
			colSpan = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("colspan");
			if(colSpan) {
				td.colSpan = colSpan; 
			}
			rowSpan = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("rowspan");
			if(rowSpan) {
				td.rowSpan = rowSpan; 
			}
			
			//Value
			value = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].childNodes[0];		
			
			//Tooltip
			tooltip = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].childNodes[1];		
			if(tooltip) 
			{
			
				var hcell = document.createElement("span");
				Tooltip.attach(td, String(Util.xmlText(tooltip)));
			}			
			
			//Type		
			type = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("type");
			if(type)
			{	
				var d;
				if (type == "Image")
				{
					//Set width
					width = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("width");							
					if(width) {
						td.setAttribute("width", width + "px");
					}
					
					//Set align
					align = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("align");							
					if(align) {
						td.setAttribute("align", align);
					}
					
					if (value && Util.xmlText(value))
					{
						td.innerHTML ="<img style=\"display: block; width: " + width + "px; margin:2px; padding:2px; border:none\" src=\"" + Util.xmlText(value) + "\">";
					}
					else
					{
						td.innerHTML ="<img style=\"display: block; width: " + width + "px; margin:2px; padding:2px; border:none\" src=\"" + CNFormManager.neutralImagesPath + "spacer.gif"; + "\">";						
					}
					
					tr.appendChild(td);	
					continue;	
				}
				if (type == "String")
				{	
					width = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("width");		
					if(width) 
					{
						table.style.tableLayout = "auto";
						width += "px;";						
						td.setAttribute("width", width);
					}
					else 
					{
						td.setAttribute("width", "auto");
					}
					
					var swp = StringTypeCell.prototype;
					wp.getCellValue = swp.getCellValue;
					wp.setCellValue = swp.setCellValue;
					wp.isValid = swp.isValid;
					wp.validateValue = swp.validateValue;
					wp.commitChange = swp.commitChange;
					wp.prerender = swp.prerender;										
					
					
					//align
					align = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("align");							
					
					//color: Set the text-color for different elements:
					//value: red, #00ff00, rgb(0,0,255)
					color = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("color");
					
					//direction: Set the text direction to "right-to-left":
					//value: ltr, rtl
					direction = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("direction");					
					
					//background-color: Set the background-color of different elements:
					//value: yellow, #00ff00, rgb(255,0,255)
					backgroundColor = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("bgColor");
					
					//background-image: Set a background-image for the body element:
					//value: url('paper.gif')
					backgroundImage = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("bgImage");					
					
					//background-repeat : Repeat a background-image only vertically:
					//value: repeat-y
					backgroundRepeat = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("bgRepeat");					
					
					//border-width: Set the width of the four borders
					//value: 15px
					borderWidth = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("borderWidth");					
					
					//border-style: Set the style of the four borders
					//value: solid
					borderStyle = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("borderStyle");	
					
					//border-color: Set the color of the four borders
					//value: red, #ff0000
					borderColor = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("borderColor");	
					
					//font-family: Specify the font for a paragraph
					//value: Times New Roman, Georgia, Serif
					fontFamily = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("fontFamily");
					
					//font-size:Set the font size for different HTML elements
					//value: value
					fontSize = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("fontSize");
					
					//font-style: Set different font styles for three paragraphs
					//value: normal, italic, oblique
					fontStyle = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("fontStyle");
					
					//font-weight: Set different font weight for three paragraphs
					//value: normal, bold, value(ex: 900)
					fontWeight = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("fontWeight");
					
					//blink
					blink = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("blink");
										
					//blink text from color
					blinkTextFromColor = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("textFromColor");
					
					//blink text to color
					blinkTextToColor = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("textToColor");
					
					//blink background from color
					blinkBackgroundFromColor = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("backgroundFromColor");
					
					//blink background to color
					blinkBackgroundToColor = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("backgroundToColor");					

					//remove blink
					removeblink = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("removeblink");
					
					//Autopostback
					autopostback = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("autopostback");
					
					d = document.createElement("div");						
										
					//Set Attributes
					if (color)
						d.style.color = color;
					if (direction)
						d.style.direction = direction;					
					if (backgroundColor)
						d.style.background = backgroundColor;
					if (backgroundImage)
						d.style.backgroundImage = "url" + "('" + backgroundImage + "')";	
					if (backgroundRepeat)
						d.style.backgroundRepeat = backgroundRepeat;		
					if (borderWidth)
						d.style.borderWidth = borderWidth + "px";			
					if (borderStyle)
						d.style.borderStyle = borderStyle;				
					if (borderColor)
						d.style.borderColor = borderColor;											
					if (fontFamily)
						d.style.fontFamily = fontFamily;	
					if (fontSize)
						d.style.fontSize = fontSize + "px";
					if (fontStyle)
						d.style.fontStyle = fontStyle;
					if (fontWeight)
						d.style.fontWeight = fontWeight;	
					if(align) 
						td.setAttribute("align", align);				
					
					if (autopostback)
						Event.add(d, "click", this, this.box_onclick);	
					
					if(value)
						d.innerHTML = Util.xmlText(value);	
						
					if (blink)
					{
						if (blinkTextFromColor || blinkTextToColor || blinkBackgroundFromColor || blinkBackgroundToColor)
						{
							d.id = "blinkDiv";	
							d.setAttribute("class", "blink");							
							d.setAttribute("blinkTextFromColor", blinkTextFromColor);
							d.setAttribute("blinkTextToColor", blinkTextToColor);
							d.setAttribute("blinkBackgroundFromColor", blinkBackgroundFromColor);
							d.setAttribute("blinkBackgroundToColor", blinkBackgroundToColor);
							
							jsObject._enableBlinkDivs.push(d);
						}
					}		

					if (removeblink)
						jsObject._removeBlinkDivs.push(d);		
				}
				else if (tytype= "Button")
				{
					var bproto = ButtonTypeCell.prototype;
					wp._createSpanButton = bproto._createSpanButton;
					wp._button_onmouseenter = bproto._button_onmouseenter;
					wp._button_onmouseleave = bproto._button_onmouseleave;
					wp._button_onmousedown = bproto._button_onmousedown;
					wp._button_onmouseup = bproto._button_onmouseup;				
				
					d = document.createElement("button");
					d.style.position = "absolute";
					d.style.whiteSpace = "normal";
					d.style.padding = "1px 6px 1px 6px";
			
					width = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("buttonWidth");		
					height = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("buttonHeight");	
					align = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("align");		
			
					if (width)
						d.style.width = width + "px";
					else
						d.style.width = "26px";
					
					if (height)
						d.style.height = height + "px";
					else
						d.style.height = "26px";
					
					//Postback
					autopostback = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("autopostback");	
					if (autopostback)
						Event.add(d, "click", this, this.box_onclick);	
					
					//Image
					imgSrc = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("imgSrc");	
					if (imgSrc)
					{
						var img = document.createElement("div");
						var img1 = document.createElement("img");					
						img1.src = imgSrc;			
						img1.style.width = "24px";
						img1.style.height = "24px";
						img1.style.verticalAlign = "middle";
						img.appendChild(img1);
						d.appendChild(img);
					}
					
					//Text
					imgText = cell.colTag.node.childNodes[0].childNodes[i].childNodes[j].getAttribute("imgText");	
					if (imgText)
					{
						var imgTxt = document.createElement("div");
						imgTxt.style.verticalAlign = "middle";
						imgTxt.style.display = "block";
						//imgTxt.style.display = "inline-block";																		
						imgTxt.innerHTML = imgText;		
						d.appendChild(imgTxt);
					}				
				}				
				td.appendChild(d)  
				tr.appendChild(td);				
			}
			tb.appendChild(tr); 
		}		
		table.appendChild(col);		
		table.appendChild(tb);		
		cell.appendChild(table);	
	}
}
wp.render = function(cell, node)
{
	//var table = cell.children[0];
	//table.rows[0].cells[0].children[0].innerHTML = String(Util.xmlText(node));
	//var color = Util.getStyle(cell.parentElement, "backgroundColor");
	//if(color != "transparent") table.style.borderColor = color;
}

wp = null;
proto = null;

/*
	v. 2.0.2
	+ vista
*/
function CN_checkedlistbox()
{
	this._disabled = false;
	this._selectedItemDiv = null;
	this._autoPostBack = false;
	this._maxCheckedItems = -1;
	this._itemsChecked = 0;
	
	this.supportsRequired = true;
}
var proto = CN_checkedlistbox.prototype;
proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	parentElement.appendChild(l);
	this.element = l;
	l.jsObject = this;
	l.className = "cn_checkedlistbox";
	l.style.userSelect = "none";
	
	this._autoPostBack = node.getAttribute("autoPostBack") == "true";
	this.element.style.whiteSpace = node.getAttribute("wrap") == "true" ? "normal" : "nowrap";
	
	return l;
}
 
// Events.
proto.onitemchecked = null;
proto.onitemselected = null;
proto.oncheckreadonly = function(){ return false; }

proto.loadData = function(node)
{
	var itemsNode = Util.xmlSelectSingleNode(node, "items");
	if(itemsNode != null)
	{
		this._deleteItems();
		this._itemsChecked = 0;
		
		var items = Util.xmlSelectNodes(itemsNode, "item");
		for(var i = 0; i < items.length; i++)
		{
			this._createItem(items[i], i);
		}
	}	
	var attr = node.getAttribute("selectedIndex");
	if(attr)
	{
		var ix = parseInt(attr, 10);
		if(!isNaN(ix))
		{
			if(ix > -1 && ix < this.element.children.length) this._selectItemDiv(this.element.children[ix], false);
			else if(ix == -1) this._unselectItemDiv();
		}
	}
	
	attr = node.getAttribute("maxCheckedItems");
	if(attr) this._maxCheckedItems = parseInt(attr, 10);
}

proto.storeData = function(xmldoc)
{
	var node = xmldoc.createElement("checkedlistbox");

	var ix = -1;
	if(this._selectedItemDiv != null) ix = this._selectedItemDiv._index;
	node.setAttribute("selectedIndex", ix);
	
	var itemsNode = node;

	for(var i = 0; i < this.element.children.length; i++)
	{
		var itemDiv = this.element.children[i];
		if(itemDiv._checked != itemDiv._originalChecked)
		{
			var itemNode = xmldoc.createElement("item");
			itemsNode.appendChild(itemNode);
			itemNode.setAttribute("checked", itemDiv._checked ? "true" : "false");
			itemNode.setAttribute("index", itemDiv._index);
			itemDiv._originalChecked = itemDiv._checked;
		}
	}

	return node;
}


proto._deleteItems = function()
{
	this._selectedItemDiv = null;
	this.element.innerHTML = "";
}

proto._createItem = function(node, ix)
{
	var itemDiv = document.createElement("div");
	itemDiv.className = 'itemDiv';
	this.element.appendChild(itemDiv);
	itemDiv.style.userSelect = "none";
	
	itemDiv._index = ix;
	
	if(node.getAttribute("enabled") == "false") itemDiv.disabled = true;
	
	var attr = node.getAttribute("tooltip");
	if(attr) Tooltip.attach(itemDiv, String(attr));

	var checkBoxSpan = document.createElement("span");
	checkBoxSpan.className = 'checkBoxSpan'; // 1 
	itemDiv.appendChild(checkBoxSpan);
	Event.add(checkBoxSpan, "click", this, this._checkBoxSpan_onclick);
	Event.add(checkBoxSpan, "dblclick", this, this._checkBoxSpan_onclick);	
	Event.add(checkBoxSpan, "mouseenter", this, this._icon_textSpan_onmouseenter);
	Event.add(checkBoxSpan, "mouseleave", this, this._icon_textSpan_onmouseleave);	
	checkBoxSpan.style.userSelect = "none";
	
	var checkElement = document.createElement("img");
	checkElement.width = 13;
	checkElement.height = 13;
	checkBoxSpan.appendChild(checkElement);
	checkElement.style.userSelect = "none";

	var attr = node.getAttribute("markerColor");
	if(attr) checkBoxSpan.style.backgroundColor = String(attr);

	var imgAttr = node.getAttribute("img");
	if(imgAttr != null)
	{
		var icon = document.createElement("img");
	icon.align = 'absmiddle';
	icon.className = 'iconImg'; // 2 
		itemDiv.appendChild(icon);
		icon.src = String(imgAttr);
		
		Event.add(icon, "mousedown", this, this._icon_textSpan_onclick);
		Event.add(icon, "dblclick", this, this._icon_textSpan_ondblclick);
		Event.add(icon, "mouseenter", this, this._icon_textSpan_onmouseenter);
		Event.add(icon, "mouseleave", this, this._icon_textSpan_onmouseleave);
		icon.style.userSelect = "none";
	}
		
	var text = document.createElement("span");
	text.className = 'textSpan'; // 3
	itemDiv.appendChild(text);

	Event.add(text, "mousedown", this, this._icon_textSpan_onclick);
	Event.add(text, "dblclick", this, this._icon_textSpan_ondblclick);
	Event.add(text, "mouseenter", this, this._icon_textSpan_onmouseenter);
	Event.add(text, "mouseleave", this, this._icon_textSpan_onmouseleave);
	text.style.userSelect = "none";
	
	var textAttr = node.getAttribute("text");
	if(textAttr != null) text.textContent = String(textAttr);
	
	var attr = node.getAttribute("textColor");
	if(attr) text.style.color = String(attr);
	
	var checked = node.getAttribute("checked") == "true";
	itemDiv._originalChecked = checked;
	
	this._setChecked(itemDiv, checked, false);
}

proto.setMaxVisibleLines = function(mvl)
{
	if(mvl == 0) return;
	
	var clientHeight = 17 * mvl;
	//if(this.element.children.length == 0) clientHeight = 17 * mvl;
	//else clientHeight = this.element.children[0].offsetHeight * mvl;
	
	if(this.element.offsetHeight > clientHeight) 
	{
		this.element.style.height = clientHeight + 2;
	}
}

proto.set_disabled = function(value)
{
	value = Util.parseBoolean(value);
	if(this._disabled == value) return;
	this._disabled = value;

	this.element.style.backgroundColor = 
		this._disabled ? Util.getStyle(this.element, "xl--disabled-background") : "";
	this.element.style.opacity = this._disabled ? "0.5" : "";
}

proto._setChecked = function(itemDiv, checked, userClick)
{
	var autoUncheck = false;
	if(userClick && checked)
	{
		if(this._maxCheckedItems == 0) return;
		else if(this._maxCheckedItems == 1) this._uncheckAllItems();
		else if(this._maxCheckedItems > 1 && this._itemsChecked >= this._maxCheckedItems) return;
	}

	if(itemDiv._checked !== undefined && itemDiv._checked != checked
	|| itemDiv._checked === undefined && checked) 
	{
		this._itemsChecked = Math.max(0, this._itemsChecked + (checked ? 1 : -1));
		if(!userClick && !checked) autoUncheck = true;
	}
	
	itemDiv._checked = checked;
	//itemDiv.firstChild.innerHTML = checked ? "&#254;" : "&#111;";
	this._set_checked(itemDiv, false, userClick);
	if(userClick)
	{
		if(this._autoPostBack) this.formManager.postData(this.element);
	}
	if(userClick || autoUncheck)
	{
		if(this.onitemchecked != null)
		{
			var ev = {target: this, itemDiv: itemDiv, checked: checked, index: itemDiv._index, 
						originalChecked: itemDiv._originalChecked, autoUncheck: autoUncheck};
			this.onitemchecked(ev);
		}
	}
}

proto._set_checked = function(itemDiv, hover, userAction)
{
	var img;
	if(itemDiv.disabled)
		img = itemDiv._checked ? "checkedDisabledCheckbox.gif" : "uncheckedDisabledCheckbox.gif";
	else if(hover)
		img = itemDiv._checked ? "checkedHoverCheckbox.gif" : "uncheckedHoverCheckbox.gif";
	else
		img = itemDiv._checked ? "checkedCheckbox.gif" : "uncheckedCheckbox.gif";


	if((userAction || hover) && CNFormManager.vista) 
		VistaSupport.imageTrans(itemDiv.children[0].children[0], CNFormManager.themeImagesPath + img);		
	else 
		itemDiv.children[0].children[0].src = CNFormManager.themeImagesPath + img; 
}


proto._uncheckAllItems = function()
{
	for(var i = 0; i < this.element.children.length; i++)
	{
		this._setChecked(this.element.children[i], false, false);
	}
}

proto._selectItemDiv = function(l, userClick)
{
	if(this._selectedItemDiv == l) return;

	this._unselectItemDiv();

	l.className = "itemDivSelected";
	this._selectedItemDiv = l;
	
	if(userClick) 
	{
		if(this.onitemselected != null)
		{
			var ev = {target: this, index: l._index};
			this.onitemselected(ev);
		}
	}
	else
	{
		this._scrollToSelectedTO();
	}
}
proto._scrollToSelectedTO = function()
{
	var obj = this;
	setTimeout(function(){ obj._scrollToSelected(); }, 50);
}
proto._scrollToSelected = function()
{
	if(!this._selectedItemDiv) return;
	var xy = CNUtil.findAbsolutePos(this._selectedItemDiv, this.element, true);
	this.element.scrollLeft = xy.x;
	this.element.scrollTop = xy.y;
}

proto._unselectItemDiv = function()
{
	if(this._selectedItemDiv == null) return;
	var l = this._selectedItemDiv;
	l.className = "itemDiv";

	this._selectedItemDiv = null;
}

proto._hoverItemDiv = function(l)
{
	if(this._selectedItemDiv != l) l.className = "itemDivOver";
	this._set_checked(l, true, true);
}

proto._unhoverItemDiv = function(l)
{
	if(this._selectedItemDiv != l) l.className = "itemDiv";
	else l.className = "itemDivSelected";
	this._set_checked(l, false, true);
}


// Event handlers. ==================================
proto._checkBoxSpan_onclick = function()
{
	CNUtil.dispatchObject().checkBoxSpan_onclick();
}
proto.checkBoxSpan_onclick = function()
{
	if(this._disabled || this.oncheckreadonly()) return;
	
	var l = Util.eventTarget();
	var itemDiv = CNUtil.findTag(l, "DIV");

	if(itemDiv.disabled) return;

	this._setChecked(itemDiv, !itemDiv._checked, true);
}

/*proto._checkBoxSpan_onmouseenter = function()
{
	var l = Util.eventTarget();
	var jsObject = CNUtil.findJSObject(l);

	if(jsObject._disabled || jsObject.oncheckreadonly()) return; 
	l.style.color = Util.getStyle(l, "xl--hover-color");
}*/

/*proto._checkBoxSpan_onmouseleave = function()
{
	var l = Util.eventTarget();
	var jsObject = CNUtil.findJSObject(l);

	if(jsObject._disabled || jsObject.oncheckreadonly()) return;
	l.style.color = "";
}
*/

proto._icon_textSpan_onclick = function()
{
	CNUtil.dispatchObject().icon_textSpan_onclick();
}
proto.icon_textSpan_onclick = function()
{
	var l = Util.eventTarget();
	if(this._disabled || this.oncheckreadonly()) return;
	var itemDiv = CNUtil.findTag(l, "DIV");
	if(itemDiv.disabled) return;
	
	this._setChecked(itemDiv, !itemDiv._checked, true);
	this._selectItemDiv(itemDiv, true);
}

proto._icon_textSpan_ondblclick = function()
{
   	CNUtil.dispatchObject().icon_textSpan_onclick();
//	CNUtil.dispatchObject().icon_textSpan_ondblclick();
}
/*
proto.icon_textSpan_ondblclick = function()
{
	var l = Util.eventTarget();
	if(this._disabled || this.oncheckreadonly()) return;
	var itemDiv = CNUtil.findTag(l, "DIV");
	if(itemDiv.disabled) return;
	
	this._setChecked(itemDiv, !itemDiv._checked, true);
	this._setChecked(itemDiv, !itemDiv._checked, true);
}
*/
proto._icon_textSpan_onmouseenter = function()
{
	CNUtil.dispatchObject().icon_textSpan_onmouseenter();
}
proto.icon_textSpan_onmouseenter = function()
{
	var l = Util.eventTarget();	
	if(this._disabled || this.oncheckreadonly()) return;
	var itemDiv = CNUtil.findTag(l, "DIV");
	if(itemDiv.disabled) return;

	this._hoverItemDiv(itemDiv);
}

proto._icon_textSpan_onmouseleave = function()
{
	CNUtil.dispatchObject().icon_textSpan_onmouseleave();
}
proto.icon_textSpan_onmouseleave = function()
{
	if(this._disabled || this.oncheckreadonly()) return;
	var l = Util.eventTarget();
	var itemDiv = CNUtil.findTag(l, "DIV");
	if(itemDiv.disabled) return;

	this._unhoverItemDiv(itemDiv);
}


// Grid support.
var CheckedListBoxCell = CN_grid.CellTypes["CheckedListBox"] = function(colTag, grid)
{
	this._grid = grid;
}

CheckedListBoxCell.cn_tagName = "checkedlistbox";

var wp = CheckedListBoxCell.prototype;

wp.isFocusable = true;

wp.isValid = function(){ return true; }

wp._oncheckreadonly = function()
{
	// Executed in combobox context.
	var cell = CN_grid.findCell(Util.eventTarget());
	var jsObject = CNUtil.findJSObject(cell);
	var ro = jsObject.getCascadedReadOnly(cell);
	return ro;
}

wp._onitemselected = function(ev)
{
	// Executed in checkedlistbox context.
	var cell = CN_grid.findCell(this.element);
	var row = cell.parentElement;
	var grid = CNUtil.findJSObject(cell);
	var node = grid._getChangedNode(row, cell);
	node.setAttribute("selectedIndex", ev.index);
	grid.fireChangedEvent(row, cell, null);
}

wp._onitemchecked = function(ev)
{
	// Executed in checkedlistbox context.
	var cell = CN_grid.findCell(this.element);
	var row = cell.parentElement;
	var grid = CNUtil.findJSObject(cell);
	
	var node = grid._getChangedNode(row, cell);
	var itemsNode = node;

	var itemNode = Util.xmlSelectSingleNode(itemsNode, 'item[@index="' + ev.index + '"]');

	if(!cell.colTag.autoPostBack && itemNode)
	{
		// Node already exists - just remove it.
		if(itemNode) itemsNode.removeChild(itemNode);
		// Check if our node is empty - contains only row, cell, id
		if(node.getAttribute("selectedIndex") == null && Util.xmlSelectNodes(node, "item").length == 0) node.parentNode.removeChild(node);
	}
	else
	{
		// Update for for non autopostback to be sure we always send value.
		if(!cell.colTag.autoPostBack) ev.itemDiv._originalChecked = ev.checked;

		if(!itemNode)
		{
			itemNode = itemsNode.ownerDocument.createElement("item");
			itemsNode.appendChild(itemNode);
			itemNode.setAttribute("index", ev.index);
		}
		itemNode.setAttribute("checked", ev.checked ? "true" : "false");

		grid.fireChangedEvent(row, cell, null);
		if(!ev.autoUncheck && cell.colTag.autoPostBack) grid.postBack(row, cell, null);
	}
}

wp.setHoverBorderStyle = function(l, cell)
{
	l.style.width = cell.clientWidth - 18;
	l.style.left = 0;
	l.style.top = 3;
	l.style.height = cell.clientHeight - 4;
}

wp.prerender = function(cell, colTag)
{
	cell.style.paddingTop = 0;
	// Need table to override nowrap.
	var table = document.createElement("table");
	table.className = "checkedlistbox_table";
	cell.appendChild(table);
	table.insertRow().insertCell();
}

wp.render = function(cell, node)
{
	var box = new CN_checkedlistbox();
	this._grid._jsObjects.push(box);

	var colTag = cell.colTag;
	
	node.setAttribute("autoPostBack", "false");

	var l = box.createElement(node, cell);//.firstChild.cells[0]);
	
	box.onitemchecked = this._onitemchecked;
	box.onitemselected = this._onitemselected;
	box.oncheckreadonly = this._oncheckreadonly;
	box.loadData(node);
	
	var attr = node.getAttribute("maxVisibleLines");
	if(attr != null)
	{
		var mvl = parseInt(attr, 10);
		if(!isNaN(mvl)) box.setMaxVisibleLines(mvl);
	}
	//l.style.width = cell.clientWidth; => doesn't work well with delayedControlsCreation=true
	l.style.width = "100%";
}

/*
	v. 2.0.2
	- #1026 fix.
*/
function CN_recordnavigator()
{
	this._isDirty = false;
	this._popup = null;
	this._activeOption = null;
	
	this._selectedIndex = 0;
	this._options = [];
}
CN_recordnavigator.current = null;

var proto = CN_recordnavigator.prototype;


proto.createElement = function(node, parentElement)
{
	var l = Util.createElementFromHTML("<table cellpadding=0 cellspacing=0 border=0>");
	parentElement.appendChild(l);

	this.element = l;
	l.jsObject = this;

	l.className = "cn_recordnavigator";

	this._buildElement();

	return l;
}


proto.loadData = function(node)
{
   	var attr = node.getAttribute("tooltip");
	if(attr) 
	{
		if(!this._centerTD.tipText) Tooltip.attach(this._centerTD, String(attr));
		else this._centerTD.tipText = String(attr);
	}

	var options = Util.xmlSelectNodes(node, "option");
	var count = options.length;

	var selectedID = null;
	var attr = node.getAttribute("selectedID");
	if(attr) 
	{	
		selectedID = String(attr);
		this._selectedIndex = 0;
	}
	
	if(count == 0 && Util.xmlSelectSingleNode(node, "nooptions") != null) 
	{
		this._clean();
		this._updateAfterSelect(false);
		return;
	}
	if(count > 0)
	{
		this._clean();	
		
		for(var i = 0; i < count; i++)
		{
			var optionNode = options[i];
			
			var id = String(optionNode.getAttribute("id"));
			var text = String(optionNode.getAttribute("text"));
			var textColor = null;
			var attr = optionNode.getAttribute("textColor");
			if(attr) textColor = String(attr);			
			
			this._options.push({id: id, text: text, textColor: textColor});
			if(id == selectedID) this._selectedIndex = i;
		}
	}	
	this._updateAfterSelect(false);
}


proto._updateAfterSelect = function(userClick)
{
	if(!this._options) return;

	if(this._options.length == 0) 
	{
		this._arrowDiv.style.visibility = "hidden";
		//this._div1.textContent = " ";
		this._div2.textContent = " ";
		this._div2.style.color = "";
		this._button1.disabled = this._button2.disabled = this._button3.disabled = this._button4.disabled = true;
		if(CNFormManager.vista)
		{
			this._setSpanButtonDisabled(this._button1, true);
			this._setSpanButtonDisabled(this._button2, true);
			this._setSpanButtonDisabled(this._button3, true);
			this._setSpanButtonDisabled(this._button4, true);
		}
		return;
	}
	this._arrowDiv.style.visibility = "visible";
	this._button1.disabled = this._button2.disabled = this._button3.disabled = this._button4.disabled = false;
	if(this._selectedIndex == 0) this._button1.disabled = this._button2.disabled = true;
	if(this._selectedIndex == this._options.length - 1) this._button3.disabled = this._button4.disabled = true;

	var option = this._options[this._selectedIndex];
	this._div2.textContent = option.text == "" ? " " : option.text;
	if(option.textColor) this._div2.style.color = option.textColor;
	else this._div2.style.color = "";
	
	//this._div1.textContent = "Record " + (this._selectedIndex + 1) + " of " + this._options.length;
	
	if(CNFormManager.vista)
	{
		this._setSpanButtonDisabled(this._button1, this._button1.disabled);
		this._setSpanButtonDisabled(this._button2, this._button2.disabled);
		this._setSpanButtonDisabled(this._button3, this._button3.disabled);
		this._setSpanButtonDisabled(this._button4, this._button4.disabled);
	}

	if(userClick) this._selectionChanged();
}

proto._clean = function()
{
	this._options = [];
	
	// Remove popup.
	
	if(this._popup) Util.removeElement(this._popup);
	this._popup = null;
}

proto.storeData = function(xmldoc)
{
	CN_recordnavigator.hideButtonHover();

	if(!this._isDirty || this._options.length == 0) return;
	this._isDirty = false;

	var node = xmldoc.createElement("recordnavigator");
	node.setAttribute("selectedID", this._options[this._selectedIndex].id)
	
	return node;
}


proto._buildElement = function()
{
	var tbody = document.createElement("tbody");
	this.element.appendChild(tbody);

	var tr = document.createElement("TR");
	tbody.appendChild(tr);
		
	var td = document.createElement("TD");
	tr.appendChild(td);

	var button1, button2, button3, button4;
	if(CNFormManager.vista)
	{
		td.style.width = "41px";
		button1 = Util.createElementFromHTML("<span class='button19'>");
		button1.style.marginRight = "1px";
		this._attachSpanButtonEvents(button1);
		button2 = Util.createElementFromHTML("<span class='button19'>");
		this._attachSpanButtonEvents(button2);
		button3 = Util.createElementFromHTML("<span class='button19'>");
		button3.style.marginLeft = "1px";
		button3.style.marginRight = "1px";
		this._attachSpanButtonEvents(button3);
		button4 = Util.createElementFromHTML("<span class='button19'>");
		this._attachSpanButtonEvents(button4);
	}
	else
	{
		td.style.width = "38px";
		button1 = document.createElement("button");
		Event.add(button1, "mouseenter", this, this._button_onmouseenter);
		Event.add(button1, "mouseleave", this, this._button_onmouseleave);
		
		button2 = document.createElement("button");
		button2.style.paddingLeft = "1px";
		Event.add(button2, "mouseenter", this, this._button_onmouseenter);
		Event.add(button2, "mouseleave", this, this._button_onmouseleave);

		button3 = document.createElement("button");
		Event.add(button3, "mouseenter", this, this._button_onmouseenter);
		Event.add(button3, "mouseleave", this, this._button_onmouseleave);

		button4 = document.createElement("button");
		Event.add(button4, "mouseenter", this, this._button_onmouseenter);
		Event.add(button4, "mouseleave", this, this._button_onmouseleave);
	}

	Event.add(button1, "click", this, this._button1_onclick);
	Event.add(button1, "dblclick", this, this._button1_onclick);
	button1.textContent = "9";
	td.appendChild(button1);
	this._button1 = button1;
	Tooltip.attach(button1, "First");
	
	Event.add(button2, "click", this, this._button2_onclick);
	Event.add(button2, "dblclick", this, this._button2_onclick);
	td.appendChild(button2);
	button2.textContent = "3";
	this._button2 = button2;
	Tooltip.attach(button2, "Previous");
	
	td = document.createElement("TD");
	tr.appendChild(td);
	td.style.width = "100%";
	td.className = "centerTD";
	td.tabIndex = -1;
	Event.add(td, "mouseenter", this, this._td_onmouseenter);
	Event.add(td, "mouseleave", this, this._td_onmouseleave);
	Event.add(td, "click", this, this._td_onclick);
	Event.add(td, "keydown", this, this._centerTD_onkeydown);	

	this._centerTD = td;

	var div2 = document.createElement("div");
	td.appendChild(div2);
	div2.className = "div2";
	this._div2 = div2;
		
	this._arrowDiv = Util.createElementFromHTML("<div class=arrowDiv>");
	td.appendChild(this._arrowDiv);
	this._arrowDiv.textContent = "6";

	td = document.createElement("TD");
	tr.appendChild(td);
	td.style.width = CNFormManager.vista ? "41px" : "38px";
	
	td.appendChild(button3);
	button3.textContent = "4";
	Event.add(button3, "click", this, this._button3_onclick);
	Event.add(button3, "dblclick", this, this._button3_onclick);
	this._button3 = button3;
	Tooltip.attach(button3, "Next");
	
	var button4;
	td.appendChild(button4);
	button4.textContent = ":";
	Event.add(button4, "click", this, this._button4_onclick);
	Event.add(button4, "dblclick", this, this._button4_onclick);
	this._button4 = button4;
	Tooltip.attach(button4, "Last");
}			  

proto._attachSpanButtonEvents = function(b)
{
	Event.add(b, "mouseenter", this, this._spanButton_onmouseenter);
	Event.add(b, "mouseleave", this, CN_recordnavigator.hideButtonHover);
	Event.add(b, "mousedown", this, this._spanButton_onmousedown);
	Event.add(b, "dblclick", this, this._spanButton_onmousedown);	
	Event.add(b, "mouseup", this, this._spanButton_onmouseenter);
}
CN_recordnavigator._activeButton = null;
proto._spanButton_onmouseenter = function()
{
	var span = CNUtil.eventTarget();
	if(span.disabled || span._disabled) return;
	CN_recordnavigator._activeButton = span;
	CN_recordnavigator._spanTrans(span, CNFormManager.themeImagesPath + "hover-button19x19.gif", true);
}
CN_recordnavigator.hideButtonHover = function()
{
	var span = CN_recordnavigator._activeButton;
	if(!span || span.disabled || span._disabled) return;
	CN_recordnavigator._spanTrans(span, CNFormManager.themeImagesPath + "button19x19.gif", false);
	CN_recordnavigator._activeButton = null;
}
proto._spanButton_onmousedown = function()
{
	var span = CNUtil.eventTarget();
	if(span.disabled || span._disabled) return;
	CN_recordnavigator._spanTrans(span, CNFormManager.themeImagesPath + "down-button19x19.gif", true);
}
CN_recordnavigator._spanTrans = function(l, toSrc, fast)
{
	l.style.backgroundImage = "url(" + toSrc + ")";
}
proto._setSpanButtonDisabled = function(b, disabled)
{
	var src = disabled ? "disabled-button19x19.gif" : "button19x19.gif";
	b.style.backgroundImage = "url(" + CNFormManager.themeImagesPath + src + ")";
}


proto._button_onmouseenter = function()
{
	var jso = CNUtil.dispatchObject();
	if(jso.element.disabled) return;

	var l = CNUtil.eventTarget();
	var color = Util.getStyle(l, "xl--hover-border-color");
	if(color) l.style.borderColor = Util.getStyle(l, "xl--hover-border-color");
} 

proto._button_onmouseleave = function()
{
	var jso = CNUtil.dispatchObject();
	if(jso.element.disabled) return;

	var l = CNUtil.eventTarget();
	l.style.borderColor = "";
} 


proto._td_onmouseenter = function()
{
	var jso = CNUtil.dispatchObject();
	if(jso.element.disabled) return;

	var l = CNUtil.eventTarget();
	l.style.background = Util.getStyle(l, "xl--option-hover-background");
}

proto._td_onmouseleave = function()
{
	var jso = CNUtil.dispatchObject();
	if(jso.element.disabled) return;

	var l = CNUtil.eventTarget();
	l.style.background = "";
}

proto._td_onclick = function()
{
	CNUtil.dispatchObject().td_onclick();
} 
proto.td_onclick = function()
{
	if(this.element.disabled) return;

	this._showPopup();
}

proto._showPopup = function()
{
	this._ensurePopupCreated();

	var xy = CNUtil.findAbsolutePos(this._centerTD);

	this._popup.style.left = xy.x + "px";
	var y = xy.y + this._centerTD.offsetHeight;
	this._popup.style.top = y + "px";
	
	this._popup.style.width = this._centerTD.offsetWidth + "px";
	
	this._popup.style.zIndex = top.__ontopZ++;
	//this._popup.style.visibility = "visible";

	if(this._popup.scrollHeight > 15 * 16) 
	{
		this._popup.style.overflowY = "auto";
		this._popup.style.height = (15 * 16 + 4) + "px";
	}
	else 
	{
		this._popup.style.height = (15 + 4) + "px";
		this._popup.style.overflowY = "visible";
	}

	var b = y + this._popup.offsetHeight;	

	if(b > document.body.clientHeight)
		this._popup.style.top = (y - b + document.body.clientHeight - 4) + "px";

	if(CNFormManager.vista)
	{
		var h = this._popup.offsetHeight;
		this._popup.style.height = "1px";
		this._popup.style.visibility = "visible";
		this._popup.shadow.show();
		
		Animator.start(new AnimResize(this._popup, this._popup.offsetWidth, h, 0));
	}
	else this._popup.style.visibility = "visible";

	if(this._selectedIndex > -1 && this._selectedIndex < this._popup.children.length)
	{
		this._hoverOption(this._popup.children[this._selectedIndex]);
	}
	
	CN_recordnavigator.current = this;
	this._popup.focus();

	Event.add(document, "mousedown", document, CN_recordnavigator._hidePopup);
	Event.add(document, "keydown", document, CN_recordnavigator._on_esc_keydown);
}

proto._ensurePopupCreated = function()
{
	if(this._popup) return;
	
	this._popup = Util.createElementFromHTML("<div class='cn_recordnavigator_popup'>");
	this._popup.tabIndex = -1;
	document.body.insertBefore(this._popup, document.body.firstChild);
	Event.add(this._popup, "mousedown", this, CNUtil.cancelEvent);
	Event.add(this._popup, "keydown", this, this._popup_onkeydown);
	
	if(CNFormManager.vista) new Shadow(this._popup, false, false);	
	
	this._createOptions();
}

proto._createOptions = function()
{
	for(var i = 0; i < this._options.length; i++)
	{
		var option = Util.createElementFromHTML("<div class='optionDiv'>")
		this._popup.appendChild(option);
		option._ix = i;
		option.textContent = this._options[i].text;
		var color = this._options[i].textColor;
		if(color) option.style.color = color;
		Event.add(option, "mouseenter", this, this._option_onmouseenter);
		Event.add(option, "mouseleave", this, this._option_onmouseleave);
		Event.add(option, "click", this, this._option_onclick);
		option.style.userSelect = "none";
	}
}

CN_recordnavigator._hidePopup = function()
{
	if(!CN_recordnavigator.current) return;
	var popup = CN_recordnavigator.current._popup;

	if(CNFormManager.vista) popup.shadow.hide();
	popup.style.visibility = "hidden";

	CN_recordnavigator.current = null;

	Event.del(document, "mousedown", document, CN_recordnavigator._hidePopup);
	Event.del(document, "keydown", document, CN_recordnavigator._on_esc_keydown);
}

CN_recordnavigator._on_esc_keydown = function()
{
	if(Event.keyValue(Event.current()) == 27) CN_recordnavigator._hidePopup();
}


proto._document_onmousedown = function()
{
	CN_recordnavigator._hidePopup();
}


proto._option_onmouseenter = function()
{
	if(!CN_recordnavigator.current._hoverOption) alert("ASSERT: !CN_recordnavigator.current._hoverOption");
	CN_recordnavigator.current._hoverOption(CNUtil.eventTarget());
}

proto._option_onmouseleave = function()
{
	if(CN_recordnavigator.current) CN_recordnavigator.current._unhoverOption();
}


proto._option_onclick = function()
{
	CN_recordnavigator.current.option_onclick();
}

proto.option_onclick = function()
{
	CN_recordnavigator._hidePopup();
	this._selectOption(this._activeOption);	
}

proto._selectOption = function(l)
{
	this._selectedIndex = l._ix;
	this._updateAfterSelect();
	this._centerTD.focus();

	this._selectionChanged();
}

proto._selectionChanged = function()
{
	this._isDirty = true;
	// Always autopostback
	this.formManager.postData(this.element);
}

proto._hoverOption = function(l)
{
	if(this._activeOption == l) return;

	this._unhoverOption();
	
	this._activeOption = l;

	var margin = (this._popup.offsetHeight - this._popup.clientHeight) / 2;
	if(l.offsetTop < this._popup.scrollTop) this._popup.scrollTop = l.offsetTop + margin;
	else if(l.offsetTop + l.offsetHeight - this._popup.scrollTop >= this._popup.clientHeight)
		this._popup.scrollTop = l.offsetTop + l.offsetHeight - this._popup.clientHeight + margin;

	l.style.background = Util.getStyle(l, "xl--option-hover-background");
	l.style.color = Util.getStyle(l, "xl--option-hover-color");
	
}

proto._unhoverOption = function()
{
	if(!this._activeOption) return;

	this._activeOption.style.background = "";
	this._activeOption.style.color = "";
	
	this._activeOption = null;

}

proto._button1_onclick = function()
{
	CNUtil.dispatchObject().button1_onclick();
} 
proto.button1_onclick = function()
{
	if(this.element.disabled) return;
	this._selectedIndex = 0;
	this._updateAfterSelect(true);
}

proto._button2_onclick = function()
{
	CNUtil.dispatchObject().button2_onclick();
} 
proto.button2_onclick = function()
{
	if(this.element.disabled) return;
	this._selectedIndex = Math.max(0, this._selectedIndex - 1);
	this._updateAfterSelect(true);
}

proto._button3_onclick = function()
{
	CNUtil.dispatchObject().button3_onclick();
} 
proto.button3_onclick = function()
{
	if(this.element.disabled) return;
	this._selectedIndex = Math.max(0, Math.min(this._options.length - 1, this._selectedIndex + 1));
	this._updateAfterSelect(true);
}

proto._button4_onclick = function()
{
	CNUtil.dispatchObject().button4_onclick();
} 
proto.button4_onclick = function()
{
	if(this.element.disabled) return;
	this._selectedIndex = Math.max(0, this._options.length - 1);
	this._updateAfterSelect(true);
}

proto._popup_onkeydown = function()
{
	CN_recordnavigator.current.popup_onkeydown();
}
proto.popup_onkeydown = function()
{
	switch(Event.keyValue(Event.current()))
	{
		case 27: 
			CN_recordnavigator._hidePopup(); 
			break;
		case 38: // Up
			if(this._activeOption)
			{
				if(this._activeOption.previousSibling) this._hoverOption(this._activeOption.previousSibling);
			}
			else if(this._popupBody.children.length > 0) 
			{
				this._hoverOption(this._popupBody.children[this._popupBody.children.length - 1]);
			}
			break;
		case 40:
			if(this._activeOption)
			{
				if(this._activeOption.nextSibling) this._hoverOption(this._activeOption.nextSibling);
			}
			else if(this._popupBody.children.length > 0) 
			{
				this._hoverOption(this._popupBody.children[0]);
			}
			break;
		case 13: 
			if(this._activeOption) 
			{
				this._selectOption(this._activeOption);
				CN_recordnavigator._hidePopup(); 
			}
			break;
	}
	if(Event.current().preventDefault) Event.current().preventDefault();
	Event.cancel(Event.current());
}

proto._centerTD_onkeydown = function()
{
	if(Event.keyValue(Event.current()) == 32 || Event.keyValue(Event.current()) == 13)
	{
		var jso = CNUtil.dispatchObject();
		if(jso.element.disabled) return;
		jso._showPopup();
	}
}


proto.set_tabIndex = function(ti)
{
	this._button1.tabIndex = this._button2.tabIndex = this._button3.tabIndex = this._button4.tabIndex = ti;
	this._centerTD.tabIndex = ti;
}

/*
	v. 1.1.1
*/
function CN_imsjourney()
{
	this._splitDragging = false;
	this._dragMargin = 150;
	this._w1 = -1;
	this._hasScrollBar = false;
	this._autoPostBack = false;
	this._selectedID = null; // Permanent, until modified.
	this._selectedTR = null; // Temp., per session.
	this._isDirty = false;
	this._clocksWidth = 56;
	this._clocksLines = [];
	this._clocksTooltip = null;
	this._clocksCount = 0;
}
var proto = CN_imsjourney.prototype;

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	l.className = "cn_imsjourney";
	parentElement.appendChild(l);
	l.jsObject = this;
	this.element = l;
	
	this._headerDiv = document.createElement("div");
	this._headerDiv.className = "headerDiv";
	l.appendChild(this._headerDiv);

	var header1 = document.createElement("div");
	header1.className = "header1";
	this._headerDiv.appendChild(header1);
	
	var header2 = document.createElement("div");
	header2.className = "header2";
	this._headerDiv.appendChild(header2);
	
	var img = document.createElement("img");
	img.src = CNFormManager.neutralImagesPath + "journey-clocks-1.gif";
	img.className = "headerIconIMG";
	this._headerDiv.appendChild(img);
	
	this._scrollDiv = document.createElement("div");
	this._scrollDiv.className = "scrollDiv";
	l.appendChild(this._scrollDiv);
	
	this._table = document.createElement("table");
	this._table.className = "contentTable";
	this._table.cellPadding = 0;
	this._table.cellSpacing = 0;
	this._scrollDiv.appendChild(this._table);
	var tr = this._table.insertRow();
	tr.insertCell();
	tr.insertCell();
	tr.insertCell();

	if(typeof ResizeObserver != "undefined") {
		var journey = this;
		this._tableResizeObserver = new ResizeObserver(function() { journey.table_onresize(); });
		this._tableResizeObserver.observe(this._table);
	}

	this._dragDiv = document.createElement("div");
	this._dragDiv.className = "dragDiv";
	l.appendChild(this._dragDiv);
	
	this._dragDiv2 = document.createElement("div");
	this._dragDiv2.className = "dragDiv";
	l.appendChild(this._dragDiv2);

	Util.handleEvent(this._dragDiv, "onmousedown", "dragDiv_");
	Util.handleEvent(this._dragDiv2, "onmousedown", "dragDiv_");
	
	this._hover = VistaSupport.createHover('item-gradient-5.gif', 30);
	this._hover.strokecolor = "#D8F0FA";
	this._select = VistaSupport.createHover('item-gradient-5.gif', 30);
	this._scrollDiv.appendChild(this._hover);
	this._scrollDiv.appendChild(this._select);
	this._hover.style.zIndex = this._select.style.zIndex = -1;
	
	this._autoPostBack = node.getAttribute("autoPostBack") == "true";
		
	return l;
}

proto.unload = function()
{
	if(this._tableResizeObserver) this._tableResizeObserver.disconnect();
	this._clocksLines = null;
}

proto.loadData = function(node)
{
	this._hover.style.visibility = "hidden";

	this._isDirty = false;

	var cols = Util.xmlSelectNodes(node, "cols/col");
	if(cols.length > 0) this._processCol(0, cols[0]);
	if(cols.length > 2) this._processCol(1, cols[2]);
	
	var attr = node.getAttribute("selectedID");
	if(attr != null) this._selectedID = String(attr);

	var scrollToRowAttr = node.getAttribute("scrollToRow");

	var trToSelect = null;
	this._pending_trToScrollTo = null;

	var rowsNode = Util.xmlSelectSingleNode(node, "rows");
	if(rowsNode)
	{
		this._clear();
		this._select.style.visibility = "hidden";
		this._rowsJustAdded = true;
		var rows = Util.xmlSelectNodes(rowsNode, "r");
		var count = rows.length;
		for(var i = 0; i < count; i++)
		{
			var tr = this._table.insertRow();
			var rNode = rows[i];
			var cNodes = Util.xmlSelectNodes(rNode, "c");
			
			var week = rNode.getAttribute("week");
			var attr = rNode.getAttribute("id");
			var marker = rNode.getAttribute("marker");
			if(marker)
			{
				attr = rNode.getAttribute("type");
				if(attr != "separator") continue;
				
				var td = tr.insertCell();
				td.colSpan = "3";
				td.className = "separatorTD";
				var div = document.createElement("div");
				div.className = "separatorDiv";
				td.appendChild(div);
				div.textContent = cNodes[0].getAttribute("text");
			}
			else
			{
				var id = String(attr);
				tr._id = id;

				if(id == this._selectedID) trToSelect = tr;
				if(id == scrollToRowAttr) this._pending_trToScrollTo = tr;

				var clocksTD;
				if(cNodes.length > 0)
				{
					var cNode = cNodes[0];
					var td = tr.insertCell();
					td.style.paddingLeft = "15px";
					this._buildCell(cNode, td, id, week);
				}
				if(cNodes.length > 1) clocksTD = tr.insertCell();
				if(cNodes.length > 2)
				{
					var cNode = cNodes[2];
					var td = tr.insertCell();
					td.style.paddingLeft = "15px";
					this._buildCell(cNode, td, id, week);
				}
				if(cNodes.length > 1) // Build clocks line at the end, as loaded base columns are required.
				{
					var cNode = cNodes[1];
					this._buildClockLine(cNode, clocksTD, id, week);
				}				
				
				/*for(var j = 0; j < 3 && j < cNodes.length; j++)
				{
					var cNode = cNodes[j];
					var td = tr.insertCell();

					if(j == 1) this._buildClockLine(cNode, td, id, week);
					if(j != 1) this._buildCell(cNode, td, id, week); // Skip processing for clocks td.

					if(j == 0) td.style.paddingLeft = "15px";
				}*/
				
				if(rNode.getAttribute("selectable") != "false")
				{
					Util.handleEvent(tr, "onmouseenter", "tr_");
					Util.handleEvent(tr, "onmouseleave", "tr_");
					Util.handleEvent(tr, "onmousedown", "tr_");
				}
			}
		}
	}

	if(trToSelect)
	{
		this._select.style.visibility = "inherit";
		this._syncHover(trToSelect, this._select)
		this._selectedTR = trToSelect;
	}
	else
	{
		this._selectedID = null;
		this._selectedTR = null;
	}
	
	this._set_colWidths(this._w1);
}
proto.tr_onmouseenter = function()
{
	var tr = Util.findTag(Util.eventTarget(), "TR");
	this._syncHover(tr, this._hover);
	this._hover.style.visibility = "inherit";
}
proto.tr_onmouseleave = function()
{
	var tr = Util.findTag(Util.eventTarget(), "TR");
	this._hover.style.visibility = "hidden";
}
proto.tr_onmousedown = function()
{
	var tr = Util.findTag(Util.eventTarget(), "TR");
	this._syncHover(tr, this._select);
	this._select.style.visibility = "inherit";
	
	this._selectedTR = tr;
	this._selectedID = tr._id;
	this._isDirty = true;
	if(this._autoPostBack) this.formManager.postData(this.element);
}

proto._syncHover = function(tr, hover)
{
	var xy = Util.findAbsolutePos(tr, this._scrollDiv);
	hover.style.left = (xy.x + 1) + "px";
	hover.style.top = xy.y + "px";
	hover.style.width = (tr.offsetWidth - 3) + "px";
	hover.style.height = (tr.offsetHeight - 1) + "px";
}

proto._processCol = function(ix, colNode)
{
	var header = this._headerDiv.childNodes[ix];
	var attr = colNode.getAttribute("title");
	if(attr != null) header.innerHTML = String(attr);
}
proto._clear = function()
{
	this._selectedTR = null;
	var count = this._table.rows.length;
	for(var i = count - 1; i >= 1; i--)
	{
		var row = this._table.rows[i];
		Util.removeElement(row);
	}
	this._clocksCount = 0;
}

proto._buildClockLine = function(node, td, rowID, week)
{
	td.style.padding = 0;
	var buildLine = false;
	var buildStopper = false;
	var heightOffset = 0;
	var alt = this._clocksCount % 2 == 0;

	if(node.getAttribute("start") == "true")
	{
		td.style.position = "relative";
		var div = document.createElement("div");
		div.className = alt ? "clockLineDiv" : "clockLineDiv clockLineAltDiv";
		td.appendChild(div);

		this._lastClockLine = {div: div};
		this._clocksLines.push(this._lastClockLine);
		
		var div = document.createElement("div");
		div.className =  alt ? "clockStopperDiv" : "clockStopperDiv clockStopperAltDiv";
		td.appendChild(div);
		div.style.top = "0px";

		var attr = node.getAttribute("tooltip");
		if(attr) this._clocksTooltip = String(attr);
	}

	if(this._clocksTooltip) Tooltip.attach(td, this._clocksTooltip);	
	
	if(node.getAttribute("stop") == "true")
	{
		this._clocksTooltip = null;
		
		if(this._lastClockLine)
		{
			this._lastClockLine.lastTD = td;
			//this._lastClockLine.style.height = td.offsetTop + td.offsetHeight - this._lastClockLine.parentNode.offsetTop;
			this._lastClockLine = null;
		}


		if(node.getAttribute("stopLine") == "true")
		{
			td.style.position = "relative";
			var div = document.createElement("div");
			div.className = alt ? "clockStopperDiv" : "clockStopperDiv clockStopperAltDiv";
			td.appendChild(div);
			div.style.top = (td.offsetHeight - div.offsetHeight) + "px";
		}
		this._clocksCount++;
	}

	var attr = node.getAttribute("week");
	if(attr)
	{
		var idSpan = document.createElement("span");
		idSpan.className = "clocksWeekSpan";
		td.appendChild(idSpan);
	
		idSpan.textContent = "[" + attr + "]";
	}

/*	if(node.getAttribute("start") == "true")
	{
		buildLine = true;
		this._clocksStarted = true;
		
		var div = document.createElement("div");
		div.className =  this._clocksCount % 2 == 0 ? "clockStopperDiv" : "clockStopperDiv clockStopperAltDiv";
		td.appendChild(div);
		heightOffset = div.offsetHeight;
		
		var attr = node.getAttribute("tooltip");
		if(attr) this._clocksTooltip = String(attr);
	}
	
	if(this._clocksTooltip) Tooltip.attach(td, this._clocksTooltip);	

	if(node.getAttribute("stop") == "true")
	{
		buildLine = true;
		this._clocksStarted = false;
		this._clocksTooltip = null;
	}
	else if(this._clocksStarted)
	{
		buildLine = true;
		if(this._clocksTooltip) Tooltip.attach(td, this._clocksTooltip);
	}

	if(node.getAttribute("stopLine") == "true")
	{
		buildStopper = true;
	}

	if(buildLine == true)
	{
		var div = document.createElement("div");
		div.className = this._clocksCount % 2 == 0 ? "clockLineDiv" : "clockLineDiv clockLineAltDiv";
		td.appendChild(div);
		
		if(buildStopper)
		{
			var sdiv = document.createElement("div");
			sdiv.className = "clockStopperDiv";
			sdiv.className = this._clocksCount % 2 == 0 ? "clockStopperDiv" : "clockStopperDiv clockStopperAltDiv";
			td.appendChild(sdiv);
			heightOffset += sdiv.offsetHeight;
		}

		div.style.height = (div.offsetHeight - heightOffset) + "px";
		
		if(!this._clocksStarted) this._clocksCount++;
	}

	attr = node.getAttribute("week");
	if(attr)
	{
		var idSpan = document.createElement("span");
		idSpan.className = "clocksWeekSpan";
		td.appendChild(idSpan);
	
		idSpan.textContent = "[" + attr + "]";
	}*/
}

proto._buildCell = function(node, td, rowID, week)
{
	var rowDiv = document.createElement("div");
	rowDiv.className = "rowDiv";
	td.appendChild(rowDiv);	

	var attr;
	attr = node.getAttribute("img");
	if(attr)
	{
		var img = document.createElement("img");
		img.className = "img";
		rowDiv.appendChild(img);
		img.src = String(attr);
	}
	else
	{
		// Build spacer.
		var span = document.createElement("span");
		span.className = "imgSpacerSpan";
		rowDiv.appendChild(span);
	}
	
	if(node.getAttribute("noWeek") != "true")
	{
		var idSpan = document.createElement("span");
		idSpan.className = "idSpan";
		rowDiv.appendChild(idSpan);
		
		var weekText;
		var attr = node.getAttribute("weekText");
		if(attr) weekText = String(attr);
		else if(week) weekText = week;

		if(weekText) idSpan.textContent = "[" + weekText + "]";
	}
	
	var textSpan = document.createElement("span");
	textSpan.className = "textSpan";
	rowDiv.appendChild(textSpan);
	attr = node.getAttribute("text");
	if(attr != null) 
	{
		textSpan.innerHTML = String(attr);
	}
	
	attr = node.getAttribute("tooltip");
	if(attr) Tooltip.attach(td, String(attr));
	
	attr = node.getAttribute("textColor");
	if(attr) rowDiv.style.color = String(attr);
	
	attr = node.getAttribute("backColor");
	if(attr) rowDiv.style.backgroundColor = String(attr);
}

proto.storeData = function(xmldoc)
{
	if(this._isDirty && this._selectedID && this._select.style.visibility == "inherit")
	{
		this._isDirty = false;
		var node = xmldoc.createElement("imsjourney");
		node.setAttribute("selection", this._selectedID);
		return node;
	}

	return null;
}

proto.layout = function()
{
	this._scrollDiv.style.height = (this.element.clientHeight - this._headerDiv.offsetHeight) + "px";

	if(this._w1 == -1)
	{
		// First run.
		var w = Math.floor(this.element.clientWidth / 2) - this._clocksWidth;
		this._headerDiv.childNodes[0].style.width = (w + this._clocksWidth + 5) + "px"; // 5 == left padding of 2nd header.
		this._headerDiv.childNodes[1].style.width = w + "px";
		this._headerDiv.childNodes[2].style.left = (w + 21) + "px"; // clocks img.
		this._dragDiv.style.left = (w - 1) + "px";
		this._dragDiv2.style.left = (w + this._clocksWidth) + "px";

		this._w1 = w;
	}

	this._set_colWidths(this._w1);

	if(this._pending_trToScrollTo) {
		this._pending_trToScrollTo.scrollIntoView();
		this._pending_trToScrollTo = null;
	}
}
proto.table_onresize = function()
{
	var actuallyHasSB = this._scrollDiv.offsetWidth - this._table.offsetWidth == CNFormManager.scrollBarSize;
	if(actuallyHasSB != this._hasScrollBar)
	{
		this._hasScrollBar = actuallyHasSB;
		this._set_colWidths(this._w1);
	}
}


proto.dragDiv_onmousedown = function()
{
	if(this._splitDragging) return;
	
	var self = this;
	this._dragHandler1 = function(ev) { self.element_onlosecapture(ev); };
	Event.nativeAdd(this.element, "pointercancel", this._dragHandler1);
	this._dragHandler2 = function(ev) { self.element_onmouseup(ev); };
	this._dragHandler3 = function(ev) { self.element_onmousemove(ev); };
	Event.nativeAdd(document, "mouseup", this._dragHandler2);
	Event.nativeAdd(document, "mousemove", this._dragHandler3);

	this._draggingDiv = Util.eventTarget() == this._dragDiv ? this._dragDiv : this._dragDiv2;
	
	this._startX = this._draggingDiv.offsetLeft - Event.current().screenX;
	
	this._splitDragging = true;
}
proto.element_onmousemove = function(ev)
{
	var x = this._startX + ev.screenX;
	if(x <= 4 || x >= this.element.clientWidth - 4) 
	{
		this.element_onlosecapture();
		return;
	}
	if(x < this._dragMargin) x = this._dragMargin;
	else if(x > this.element.clientWidth - this._dragMargin) x = this.element.clientWidth - this._dragMargin;

	this._draggingDiv.style.left = x + "px";
}
proto.element_onmouseup = function()
{
	this.element_onlosecapture();
}
proto.element_onlosecapture = function()
{
	Event.nativeDel(this.element, "pointercancel", this._dragHandler1);
	Event.nativeDel(document, "mouseup", this._dragHandler2);
	Event.nativeDel(document, "mousemove", this._dragHandler3);
	this._dragHandler1 = this._dragHandler2 = this._dragHandler3 = null;
	this._splitDragging = false;
	
	var w1, w2;
	if(this._draggingDiv == this._dragDiv)
	{
		w1 = this._dragDiv.offsetLeft + 1;
		w2 = this.element.clientWidth - w1 - this._clocksWidth;
		this._dragDiv2.style.left = (w1 + this._clocksWidth) + "px";
	}
	else
	{
		w1 = this._dragDiv2.offsetLeft + 1 - this._clocksWidth;
		w2 = this.element.clientWidth - w1;
		this._dragDiv.style.left = w1 + "px";
	}
	this._headerDiv.childNodes[0].style.width = (w1 + this._clocksWidth + 4) + "px";
	this._headerDiv.childNodes[1].style.width = w2 + "px";
	this._headerDiv.childNodes[2].style.left = (w1 + 21) + "px"; // clocks img.	
	this._w1 = w1;
	this._set_colWidths(w1);

	this._draggingDiv = null;
}
proto._set_colWidths = function(w)
{
	var rows = this._table.rows;
	if(rows.length > 0 && w > 0)
	{
		var r = rows[0];
		var w2 = this._scrollDiv.clientWidth - w - 2 - this._clocksWidth;
		
		r.cells[0].width = Math.max(w, 1);
		r.cells[1].width = this._clocksWidth;
		r.cells[2].width = Math.max(w2, 1);
		
		if(this._select.style.visibility == "inherit" && this._selectedTR)
		{
			this._syncHover(this._selectedTR, this._select);
		}
	}
	
	for(var i = 0; i < this._clocksLines.length; i++)
	{
		var cl = this._clocksLines[i];
		if(cl.lastTD) cl.div.style.height = (cl.lastTD.offsetTop + cl.lastTD.offsetHeight - cl.div.parentNode.offsetTop) + "px";
	}	
}


proto = null;


/*
	v. 1.0.6
	TODO: add "clean-table" flag optimization (don't rebuild clean table)
*/
function CN_diary()
{
	this._postbackButton = null;
	this._selectionDirty = this._isDirty = false;
	this._selectedEventID = -1;
	this._autoPostBack = true;
}

var proto = CN_diary.prototype;

proto.createElement = function(node, parentElement)
{
	var l = document.createElement("div");
	l.className = "cn_diary";
	parentElement.appendChild(l);
	l.jsObject = this;
	this.element = l;
	
	this._3mEventHeight = 17;
	
	this._days = ["Su", "M", "Tu", "W", "Th", "F", "Sa"];
	
	this._hover = VistaSupport.createHover('item-gradient-5.gif', 30);
	this._hover.strokecolor = ThemeNonCSSStyles.hoverRect_strokeColor2;
	this._select = VistaSupport.createHover('item-gradient-5.gif', 30);
	
	return l;
}

proto.loadData = function(node)
{
	var attr = node.getAttribute("autoPostBack");
	if(attr) this._autoPostBack = attr == "true";
	
	this._selectionDirty = this._isDirty = false;
	this._hover.style.visibility = "hidden";
	this._process3mData(node);
}

proto.storeData = function(xmldoc)
{
	if(!this._isDirty && !this._selectionDirty) return;

	var tag = xmldoc.createElement("diary");
	if(this._isDirty && this._postbackButton) tag.setAttribute("button", this._postbackButton);
	if(this._selectionDirty && this._selectedEventID) tag.setAttribute("selectedEventID", this._selectedEventID);

	this._selectionDirty = this._isDirty = false;
	return tag;
}

proto._process3mData = function(node)
{
	var justCreated = false;
	if(!this._table) 
	{
		this._create3mView();
		justCreated = true;
	}

	var attr = node.getAttribute("title");
	if(attr) this._textSpan.textContent = String(attr);

	var oldSelectedEventID = this._selectedEventID;
	var selectedEventIDAttr = node.getAttribute("selectedEventID");
	if(selectedEventIDAttr) this._selectedEventID = String(selectedEventIDAttr);

	var events = Util.xmlSelectSingleNode(node, "events");
	if(events)
	{
		if(!justCreated) this._clear3mView();
		this._load3mView(node, events);
	}
	else if(selectedEventIDAttr && oldSelectedEventID != this._selectedEventID)
	{
		if(this._selectedEventID == -1) 
		{
			this._select.style.visibility = "hidden";
			this._selectedEventDiv = null;
		}
		else this._selectCurrentEventID3mView()
	}
}

proto._selectCurrentEventID3mView = function()
{
	var divs = this._table.getElementsByTagName("div");
	var count = divs.length;
	for(var i = 0; i < count; i++)
	{
		var div = divs[i];
		if(div._id == this._selectedEventID && div.className.indexOf("eventDiv") != -1)
		{
			this._syncHover(div, this._select);
			this._selectedEventDiv = div;
			var xy = Util.findAbsolutePos(div, this._scrollArea);
			this._scrollArea.scrollTop = xy.y - 2;
			return;
		}
	}
}


proto._clear3mView = function()
{
	if(!this._table) return;
	this._selectedEventID = null;
	this._selectedEventDiv = null;

	if(this._hover.parentNode) Util.removeElement(this._hover);
	if(this._select.parentNode) Util.removeElement(this._select);	
	
	var rows = this._table.rows;
	var count = rows.length;
	for(var i = count - 1; i >= 0; i--)
	{
		Util.removeElement(rows[i]);
	}
	this._td2.textContent = "";
	this._td3.textContent = "";
	this._td4.textContent = "";
}

proto._create3mView = function()
{
	var header = document.createElement("div");
	header.className = "header";
	this.element.appendChild(header);
	
	var butBG = document.createElement("span");
	butBG.className = "butBG";
	header.appendChild(butBG);
	this._header = header;

	var b1, b2;
	if(CNFormManager.subTheme == "black") {
		b1 = VistaSupport.createImageSetButton("diary-nav-set.gif", 25, 25);
	} else {
		b1 = VistaSupport.createImageButton("lround-button-2.gif", 25, 25);
	}
	b1.className = "b1";	
	butBG.appendChild(b1);
	Tooltip.attach(b1, "Back One Month");
	Util.handleEvent(b1, "onclick", "b1_");
	Util.handleEvent(b1, "ondblclick", "b1_");

	if(CNFormManager.subTheme == "black") {
		b2 = VistaSupport.createImageSetButton("diary-nav-set.gif", 25, 25, 25);
	} else {
		b2 = VistaSupport.createImageButton("round-button-2.gif", 25, 25);
	}
	b2.className = "b2";	
	butBG.appendChild(b2);
	Tooltip.attach(b1, "Forward One Month");
	Util.handleEvent(b2, "onclick", "b2_");
	Util.handleEvent(b2, "ondblclick", "b2_");
	
	var textSpan = document.createElement("span");
	textSpan.className = "textSpan";
	header.appendChild(textSpan);
	textSpan.textContent = "";
	this._textSpan = textSpan;
	
	var dataHeader = document.createElement("table");
	dataHeader.className = "dataHeader3mView";
	header.appendChild(dataHeader);	
	
	var tr = dataHeader.insertRow();
	var td1 = tr.insertCell();
	td1.noWrap = "nowrap";
	td1.style.width = "50px";
	td1.textContent = "Day";
	td1.style.textAlign = "center";
	
	var td2 = tr.insertCell();
	td2.width = "32%";
	this._td2 = td2;
	
	var td3 = tr.insertCell();
	td3.width = "32%";
	this._td3 = td3;

	var td4 = tr.insertCell();
	td4.width = "32%";
	this._td4 = td4;

	var td5 = tr.insertCell();
	td5.width = CNFormManager.scrollBarSize;
	td5.textContent = " ";

	var scrollArea = document.createElement("div");
	scrollArea.className = "scrollArea3mView";
	this.element.appendChild(scrollArea);
	this._scrollArea = scrollArea;
	
	var table = document.createElement("table");
	table.className = "table3mView";
	scrollArea.appendChild(table);
	this._table = table;
	
	dataHeader.border = 0;
	table.border = 1;
	dataHeader.cellSpacing = table.cellSpacing = 0;
	dataHeader.frame = table.frame = "void";
	
	this._scrollArea.appendChild(this._hover);
	this._scrollArea.appendChild(this._select);	
}

proto._load3mView = function(node, eventsNode)
{
	var attr = node.getAttribute("from");
	if(!attr) return;
	
	var from = String(attr);
	var y = parseInt(from.substring(0, 4), 10);
	var m = parseInt(from.substring(4, 6), 10) - 1;
	var fromDate = new Date(y, m, 1);
	var workDate = new Date(y, m, 1);
	var workDate2 = new Date(y, m, 1);
	var workDate3 = new Date(y, m, 1);

	workDate2.setMonth(workDate.getMonth() + 1);
	workDate3.setMonth(workDate.getMonth() + 2);

	this._td2.textContent = CNPopupCalendar.months[fromDate.getMonth()] + " " + fromDate.getYear();
	this._td3.textContent = CNPopupCalendar.months[workDate2.getMonth()] + " " + workDate2.getYear();
	this._td4.textContent = CNPopupCalendar.months[workDate3.getMonth()] + " " + workDate3.getYear();
	
	var eventsInRow = 2;	
	var attr = node.getAttribute("eventsInRow");
	if(attr) eventsInRow = Math.max(1, parseInt(attr, 10));
	
	var rowHeight = this._3mEventHeight * eventsInRow; // Last event div has no bottom border.

	var rows = Util.xmlSelectNodes(eventsNode, "r");
	
	for(var i = 1; i <= 31; i++)
	{
		var r = null;
		var cs = null;
		if(rows.length >= i) 
		{
			r = rows[i - 1];
			cs = Util.xmlSelectNodes(r, "c");
		}

		var tr = this._table.insertRow();
		tr.style.height = rowHeight + "px";
		
		var td1 = tr.insertCell();
		td1.textContent = i;
		td1.style.width = "50px";
		td1.style.textAlign = "center";
		td1.noWrap = "nowrap";
		td1.className = "td1";
		
		var td2 = tr.insertCell();
		this._createCellContents(td2, cs, 0, workDate, i);

		var td3 = tr.insertCell();
		this._createCellContents(td3, cs, 1, workDate2, i);

		var td4 = tr.insertCell();
		this._createCellContents(td4, cs, 2, workDate3, i);
		
		if(i == 31)
		{
			// Remove bottom inner border.
			td1.style.borderBottom = td2.style.borderBottom 
				= td3.style.borderBottom = td4.style.borderBottom = "none";
		}
	}
}

proto._createCellContents = function(td, cs, ix, date, dayIx)
{
	td.width = "32%";
	var c = null;
	if(cs && cs.length > ix) c = cs[ix]

	var daySpan = document.createElement("span");
	daySpan.className = "daySpan";
	td.appendChild(daySpan);
	
	var div = document.createElement("div");
	div.className = "cellDiv";
	td.appendChild(div);

	var m = date.getMonth();
	date.setDate(dayIx);
	if(date.getMonth() == m)
	{
		daySpan.textContent = this._days[date.getDay()];
	
		if(c)
		{
			var events = Util.xmlSelectNodes(c, "e");
			var count = events.length;
			for(var i = 0; i < count; i++)
			{
				var ev = events[i];
				
				var div2 = document.createElement("div");
				div.appendChild(div2);
				div2.textContent = Util.xmlText(ev);
	
				if(i + 1 != count) div2.className = "eventDiv eventDivWithBorder";
				else div2.className = "eventDiv";
				
				var attr = ev.getAttribute("backColor");
				if(attr) div2.style.backgroundColor = String(attr);
				attr = ev.getAttribute("textColor");
				if(attr) div2.style.color = String(attr);
				attr = ev.getAttribute("img");
				if(attr) 
				{
					var img = document.createElement("img");
					div2.insertBefore(img, div2.firstChild);
					img.src = String(attr);
				}
				
				attr = ev.getAttribute("tooltip");
				if(attr) Tooltip.attach(div2, String(attr));
				
				attr = ev.getAttribute("id");
				if(attr) 
				{
					var id = div2._id = String(attr);
					if(this._selectedEventID == id)
					{
						this._selectedEventDiv = div2;
						this._select.style.visibility = "inherit";
						this._syncHover(div2, this._select)
					}
				}
				
				Util.handleEvent(div2, "onmouseenter", "div2_");
				Util.handleEvent(div2, "onmouseleave", "div2_");
				Util.handleEvent(div2, "onmousedown", "div2_");
			}
		}
	}
	else
	{
		td.className = "noDayTD";
	}
	
	if(c)
	{
		var day = date.getDay();
		var attr = c.getAttribute("dayOff");
		if(attr == "true"
		|| attr == null && (day == 0 || day == 6)) td.className = "dayOffTD";

		var attr = c.getAttribute("backColor");
		if(attr) td.style.backgroundColor = String(attr);
	}
}

proto.layout = function()
{
	var obj = this;
	setTimeout(function(){ obj._layout3mView(); }, 0);
}

proto._layout3mView = function()
{
	if(!this._scrollArea) return;
	this._scrollArea.style.height = Math.max(1, parseInt(this.element.style.height, 10)
										 - this._header.offsetHeight - 2) + "px";
	if(this._selectedEventDiv) this._syncHover(this._selectedEventDiv, this._select);
}

proto.b1_onclick = proto.b1_ondblclick = function()
{
	this._postbackButton = "back";
	this._isDirty = true;
	this.formManager.postData(this.element);
}

proto.b2_onclick = proto.b2_ondblclick = function()
{
	this._postbackButton = "forward";
	this._isDirty = true;	
	this.formManager.postData(this.element);
}

proto._syncHover = function(l, hover)
{
	hover.style.left = "-2px";
	hover.style.top = "0px";
	l.style.position = "relative";
	hover.style.visibility = "inherit";
	
	l.appendChild(hover);

	hover.style.width = (l.offsetWidth - 2) + "px";
	hover.style.height = (l.offsetHeight - 1) + "px";
}


proto.div2_onmouseenter = function()
{
	var l = Util.eventTarget();
	this._syncHover(l, this._hover);
	this._hover.style.visibility = "inherit";
}
proto.div2_onmouseleave = function()
{
	var l = Util.eventTarget();
	this._hover.style.visibility = "hidden";
	if(this._selectedEventDiv != l) l.style.position = "static";
}
proto.div2_onmousedown = function()
{
	var l = Util.findTag(Util.eventTarget(), "DIV");
	this._syncHover(l, this._select);
	this._select.style.visibility = "inherit";
	
	this._selectedEventDiv = l;
	this._selectedEventID = l._id;
	this._selectionDirty = true;
	if(this._autoPostBack) this.formManager.postData(this.element);
}

/*
	v. 0.1
*/

function CN_portaldesigner() {
	this._lastZIndex = 1;
}

var proto = CN_portaldesigner.prototype;

proto.createElement = function(node, parentElement) {
	var l = this.element = document.createElement("div");
	l.className = "cn_portaldesigner";
	if(parentElement) parentElement.appendChild(l);
	
	l.jsObject = this;
	
	this._toolboxID = String(node.getAttribute("toolbox"));
	
	this._draggableWrapper = document.createElement("div");
	this._draggableWrapper.className = "cn_portaldesigner_draggableWrapper";
	document.body.appendChild(this._draggableWrapper);
	var div = document.createElement("div");
	div.className = "cn_portaldesigner_draggableWrapperInner"
	this._draggableWrapper.appendChild(div);
	
	var menu = this._component_contextMenu = new PopupMenu(document.body, "beforeend");
	menu.element.style.width = "180px";
	menu.parentJSObject = this;

	var item = menu.createItem("Delete");
	item.onmenuclick = this._delete_onxlclick;
	
	return l;
}
proto.unload = function() {
	this._component_contextMenu.destroy();

	this._currentDragged = null;
	document.body.removeChild(this._draggableWrapper);
	this._draggableWrapper = null;

	this._toolbox = null;
//	Event.purge(this); - done by fm.
}

proto.loadData = function(node) {
}

proto.validateLoading = function() {
	if(this._toolboxID && !this._toolboxInited) {
		this._initToolbox();
	}
}

proto.storeData = function(xmldoc) {
	return null;
}

proto._initToolbox = function(id) {
	this._toolboxInited = true;
	this._toolbox = document.getElementById(this._toolboxID);
	
	var cont = this._toolbox.containerElement;
	for(var i = 0; i < cont.children.length; i++) {
		var l = cont.children[i];
		
		if(!l.jsObject) continue;
		
		l.style.cursor = "move";
		l._dragRoot = true;
		
		var obj = this;
		Event.add(l, "mousedown", this, this.draggable_onmousedown);
	}
}

proto.draggable_onmousedown = function(event) {
	var l = Event.current().target;
	while(l && !l._dragRoot) l = l.parentNode;

	//this._currentDragged = l;
	this._currentDragged = this._draggableWrapper;

	var xy = Util.findAbsolutePos(l);

	//l.style.left = xy.x + "px";
	//l.style.top = xy.y + "px";
	this._draggableWrapper.style.left = xy.x + "px";
	this._draggableWrapper.style.top = xy.y + "px";
	this._draggableWrapper.style.width = l.offsetWidth + "px";
	this._draggableWrapper.style.height = l.offsetHeight + "px";

	var l = l.cloneNode(true);
	l.style.cursor = "";
	this._draggableWrapper.appendChild(l);
	l.style.top = 0;
	l.style.left = 0;
	
	this._draggableWrapper.style.display = "block";

	Event.add(document.body, "mouseup", this, this.draggable_onmouseup);
	Event.add(document.body, "mousemove", this, this.draggable_onmousemove);

	this._initComponentDragging(xy);
}

proto._initComponentDragging = function(xy) {
	this._dx = Event.current().screenX - xy.x;
	this._dy = Event.current().screenY - xy.y;

	var xy = Util.getXY(this.element);
	this._cachedLBounds = {xy: xy, r: this.element.offsetWidth + xy.x, b: this.element.offsetHeight + xy.y};
	this._dropOK = true;
}

proto.draggable_onmousemove = function(event) {
	Event.cancel(event);

	var x = Event.current().screenX - this._dx;
	var y = Event.current().screenY - this._dy;
	var dr = x + this._currentDragged.offsetWidth;
	var db = y + this._currentDragged.offsetHeight;

	//status = x + "," + y + " : " + this._cachedLBounds.xy.x + "," + this._cachedLBounds.xy.y
	//status = x + "," + y + " : " + this._cachedLBounds.r + "," + this._cachedLBounds.b
	
	if(x > this._cachedLBounds.xy.x && y > this._cachedLBounds.xy.y && dr < this._cachedLBounds.r && db < this._cachedLBounds.b) {
		x = Math.round(x / 4) * 4;
		y = Math.round(y / 4) * 4;

		if(!this._dropOK) {
			this._dropOK = true;
			this._currentDragged.firstChild.className = "cn_portaldesigner_draggableWrapperInner ";
			this._currentDragged.firstChild.style.cursor = "move";
		}
	} else {
		if(this._dropOK) {
			this._dropOK = false;
			this._currentDragged.firstChild.className = "cn_portaldesigner_draggableWrapperInner cn_portaldesigner_denied";
			this._currentDragged.firstChild.style.cursor = "no-drop";
		}
	}

	this._currentDragged.style.left = x + "px";
	this._currentDragged.style.top = y + "px";

}

proto.draggable_onmouseup = function(event) {
	Event.del(document.body, "mouseup", this, this.draggable_onmouseup);
	Event.del(document.body, "mousemove", this, this.draggable_onmousemove);
	this._currentDragged = null;
	
	if(this._draggableWrapper.childNodes.length > 1) {
		var l = this._draggableWrapper.childNodes[1];
		
		if(this._dropOK) {
			this._putL(this._draggableWrapper.cloneNode(true));
		}

		this._draggableWrapper.removeChild(l);
		this._draggableWrapper.style.display = "none";
	}
}

proto._putL = function(clonedDraggableWrapper) {
	var l = clonedDraggableWrapper;
	
	this._appendComponent(l);
		
	l.lastChild.style.width = "100%";
	l.lastChild.style.height = "100%";
	l.style.zIndex = this._lastZIndex++;
	
	Event.add(l, "mousemove", this, this.component_mousemove);
	Event.add(l, "mousedown", this, this.component_mousedown);
	Event.add(l, "contextmenu", this, this.component_contextmenu);
}

/**
Appends component to the main area + relocates according to current absolute coords.
*/
proto._appendComponent = function(l) {
	var xy = Util.getXY(this.element);

	var x = parseInt(l.style.left, 10) - xy.x;
	var y = parseInt(l.style.top, 10) - xy.y;

	this.element.appendChild(l);
	l.style.top = y + "px";
	l.style.left = x + "px";
}

proto._borderCursors = {lt: "nw-resize", lb: "sw-resize", l: "w-resize", rt: "sw-resize", rb: "nw-resize", 
	r: "w-resize", t: "n-resize", b: "n-resize"};
	
proto.component_mousemove = function(ev) {
	var w = Util.findByClassName(ev.target, "cn_portaldesigner_draggableWrapper");
	if(w == null) return;
	
	var overlay = w.firstChild;
	var border = this._getResizedBorder(w);

	if(border) {
		overlay.style.cursor = this._borderCursors[border];
	} else {
		overlay.style.cursor = "move";
	}
}

/**
Returns border name as 1-2 char code, where:
	t - top
	l - left
	b - bottom
	r - right
	l and r go first for 2 char codes, i.e. "lb", "rt"
*/
proto._getResizedBorder = function(l){
	var xy = Util.getXY(l);	
	var r = xy.x + l.offsetWidth;
	var b = xy.y + l.offsetHeight;

	var ex = Event.current().clientX;
	var ey = Event.current().clientY;

	var borderSize = 8;

	if(ex < xy.x + borderSize) { // Left border
		if(ey < xy.y + borderSize) return "lt";
		else if(ey > b - borderSize) return "lb"; 
		else return "l";
	} else if(ex > r - borderSize) { // Right border
		if(ey < xy.y + borderSize) return "rt";
		else if(ey > b - borderSize) return "rb";
		else return "r";
	} else if(ey < xy.y + borderSize) {
		return "t";
	} else if(ey > b - borderSize){
		return "b";
	}
	return null;
}

proto.component_mousedown = function() {
	if(Event.current().button != 1) return;

	var w = Util.findByClassName(Event.current().target, "cn_portaldesigner_draggableWrapper");
	if(w == null) return;
	
	w.style.zIndex = this._lastZIndex++;

	var border = this._getResizedBorder(w);
	
	if(border == null) {
		this._currentDragged = w;
//		var xy = Util.getXY(w);
//		document.body.appendChild(w);
//		w.style.left = xy.x + "px";
//		w.style.top = xy.y + "px";
//		this._initComponentDragging(xy);

		this._dx = Event.current().screenX - w.offsetLeft;
		this._dy = Event.current().screenY - w.offsetTop;

//		Event.add(document.body, "mouseup", this, this.component_resize_onmouseup);
//		Event.add(document.body, "mousemove", this, this.component_resize_onmousemove);
		this._action = "move";
	} else if(border) {
		this._currentDragged = w;
		this._dw = Event.current().screenX - w.offsetWidth;
		this._dh = Event.current().screenY - w.offsetHeight;
		this._rdw = -w.offsetWidth + document.body.offsetWidth - Event.current().clientX;
		this._rdh = -w.offsetHeight + document.body.offsetHeight - Event.current().clientY;
		
		this._action = border;
		// Disable border cursor changes.	
		Event.del(w, "mousemove", this, this.component_mousemove);
	}
	Event.add(document.body, "mouseup", this, this.component_resize_onmouseup);
	Event.add(document.body, "mousemove", this, this.component_resize_onmousemove);
}

proto.component_draggable_onmouseup = function() {
	Event.del(document.body, "mouseup", this, this.component_draggable_onmouseup);
	Event.del(document.body, "mousemove", this, this.draggable_onmousemove);

	if(this._dropOK) {
		this._appendComponent(this._currentDragged);
	} else {
		this._currentDragged.parentNode.removeChild(this._currentDragged);
	}

	this._currentDragged = null;
}

proto._snapToGrid = function(v) {
	return Math.round(v / 4) * 4;
}

proto.component_resize_onmousemove = function(event) {
	Event.cancel(event);
	
	if(this._action == "move") {
		this._currentDragged.style.left = this._snapToGrid(Event.current().screenX - this._dx) + "px";
		this._currentDragged.style.top = this._snapToGrid(Event.current().screenY - this._dy) + "px";
		return;
	}

	var minW = 50, minH = 18;
		
	if(this._action.indexOf("r") != -1) {
		var w = this._snapToGrid(Math.max(Event.current().screenX - this._dw, minW));
		this._currentDragged.style.width = w + "px";
	} else if(this._action.indexOf("l") != -1) {
		var w = this._snapToGrid(Math.max(document.body.offsetWidth - this._rdw - Event.current().clientX, minW));
		var dw = this._currentDragged.offsetWidth - w;
		this._currentDragged.style.width = w + "px";
		this._currentDragged.style.left = this._currentDragged.offsetLeft + dw + "px";
	}

	if(this._action.indexOf("b") != -1) {
		var h = this._snapToGrid(Math.max(Event.current().screenY - this._dh, minH));
		this._currentDragged.style.height = h + "px";
	} else if(this._action.indexOf("t") != -1) {
		var h = this._snapToGrid(Math.max(document.body.offsetHeight - this._rdh - Event.current().clientY, minH));
		var dh = this._currentDragged.offsetHeight - h;
		this._currentDragged.style.height = h + "px";
		this._currentDragged.style.top = this._currentDragged.offsetTop + dh + "px";
	}
}

proto.component_resize_onmouseup = function() {
	Event.del(document.body, "mouseup", this, this.component_resize_onmouseup);
	Event.del(document.body, "mousemove", this, this.component_resize_onmousemove);

	Event.add(this._currentDragged, "mousemove", this, this.component_mousemove);
	
	this._currentDragged = null;
}

proto.component_contextmenu = function(ev) {
	var w = Util.findByClassName(ev.target, "cn_portaldesigner_draggableWrapper");
	if(w == null) return;

	this._currentContextElement = w;
	
	this._component_contextMenu.show(ev.clientX + document.body.scrollLeft, ev.clientY + document.body.scrollTop);
	Event.cancel(ev);
}

proto._delete_onxlclick = function() {
	CNUtil.findJSObject(Event.current().target).parentJSObject.delete_onxlclick();
}
proto.delete_onxlclick = function() {
	if(!this._currentContextElement) return;

	this._currentContextElement.parentNode.removeChild(this._currentContextElement);

	this._currentContextElement = null;
}

proto = null;
/*
	v. 0.1 - initial release.
*/
function CN_flash() {
	this._loaded = false;
	this._lastData = null;
	this._lastPostData = null;
}
CN_flash.loaded = function(id) {
	var el = document.getElementById(id);
	if(!el) Util.assert("!el, id: " + id);
	var jso = el = el.parentNode.jsObject;
	jso._loaded = true;
	if(jso._lastData !== null) {
		jso._loadDataToFlash(jso._lastData);
		jso._lastData = null;
	}
}
CN_flash.makePostback = function(id, data) {
	var el = document.getElementById(id);
	if(!el) Util.assert("!el, id: " + id);
	var el = el.parentNode;
	var jso = el.jsObject;
	jso._lastPostData = data;

	jso.formManager.postData(el);
}

var proto = CN_flash.prototype;

proto.createElement = function(node, parentElement) {
	var l = document.createElement("div");
	l.className = "cn_flash";
	parentElement.appendChild(l);
	l.jsObject = this;
	this.element = l;

	this._build(node);

	return l;
}

proto._build = function(node) {
	var obj = document.createElement("object");
	obj.id = node.getAttribute("id") + "_object";
	obj.style.width = "100%";
	obj.style.height = "100%";
	obj.appendChild(Util.createElement("param", null, {name: "allowFullScreen", value: "false"}));
	obj.appendChild(Util.createElement("param", null, {name: "quality", value: "high"}));
	obj.appendChild(Util.createElement("param", null, {name: "wmode", value: "transparent"}));
	obj.appendChild(Util.createElement("param", null, {name: "allowScriptAccess", value: "always"}));

	var p = document.createElement("param");
	p.setAttribute("name", "movie");
	p.setAttribute("value", String(node.getAttribute("src")));
	obj.appendChild(p);
	this.element.appendChild(obj);
}
proto.loadData = function(node) {
	if(Util.xmlText(node).length == 0) return;
	var data = String(Util.xmlText(node));
	if(this._loaded) {
		this._loadDataToFlash(data);
	} else {
		this._lastData = data;
	}
}
proto._loadDataToFlash = function(data) {
	var self = this;
	setTimeout(function() {
		self.element.firstChild.jsCN_loadData(data);
	}, 0);
}

proto.storeData = function(xmldoc) {
	var node = xmldoc.createElement("flash");

	if(this._lastPostData !== null) {
		node.appendChild(xmldoc.createCDATASection(this._lastPostData));
		this._lastPostData = null;
	}
	return node;
}

proto = null;

function CN_hint() {
	this._disabled = false;
	this.initiateUpload = false; // Used by formManager.
}

var proto = CN_hint.prototype;

proto.createElement = function(node, parentElement) {
	var l = Util.createElementFromHTML('<div class="cn_hint">');
	parentElement.appendChild(l);

	this.clicked = false;

	var but = VistaSupport.createImageSetButton(null, 16, 16, 0);
	l.appendChild(but);

	Event.add(but, "click", this, this._but_click);
	Event.add(but, "mousedown", this, this._but_mousedown);

	this.element = l;
	l.jsObject = this;

	this._setTooltip(node);
	this._setAutoPostBack(node.getAttribute("autoPostBack") == "true");

	return l;
}

proto.loadData = function(node) {
	this._setTooltip(node);

	var attr = node.getAttribute("autoPostBack");
	if(attr) this._setAutoPostBack(node.getAttribute("autoPostBack") == "true"); 
}

proto._setTooltip = function(node) {
	var attr = node.getAttribute("tooltip");
	if(attr) {
		if(!this.element.tipText) Tooltip.attach(this.element, String(attr));
		else this.element.tipText = String(attr);
	}
}

proto._setAutoPostBack = function(val) {
	this._autoPostBack = val;
	this.element.firstChild._noClick = !val;
	Util.toggleClass(this.element, "cn_hint_no_autopostback", !val);
}

proto.storeData = function(xmldoc) {
	if(!this.clicked) return;
	this.clicked = false;

	var node = xmldoc.createElement("hint");
	return node;
}

proto.set_disabled = function(value) {
	this._disabled = this.element.firstChild._disabled = value;
	Util.toggleClass(this.element, "cn_hint_disabled", value);
}

proto._but_mousedown = function() {
	if(!this._autoPostBack) {
		Util.cancelEvent();
	}
}

proto._but_click = function() {
	if(this._disabled) return;
	if(!this._autoPostBack) {
		Util.cancelEvent();
		return;
	}
	this.clicked = true;
	this.formManager.postData(this.element);
}

proto = null;
